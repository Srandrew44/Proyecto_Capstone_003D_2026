"""Genera apps/web/pies_trazos.py: el dibujo de los pies de la ficha en papel, como trazos SVG.

No copia la imagen: toma la línea central de cada trazo del dibujo (esqueletización), la divide
en tramos, quita las motas del escaneo, la simplifica (Ramer-Douglas-Peucker) y la convierte en
curvas suaves (Catmull-Rom a Bézier). El resultado se dibuja con un trazo uniforme, nítido a
cualquier tamaño, con las mismas formas que la ficha del cliente.

No es parte de la aplicación (necesita scikit-image). Se corre una vez, en un contenedor aparte:

    docker run --rm -v "<carpeta con ficha.png>:/img:ro" -v "<repo>:/repo" python:3.12-slim \
      sh -c "pip install -q scikit-image pillow && python /repo/scripts/vectorizar_pies.py \
             /img/ficha.png /repo/apps/web/pies_trazos.py"

`ficha.png` es la ficha podológica completa (768 x 1024) que entregó Matías el 13/11/2026.
"""

import sys

import numpy as np
from PIL import Image
from skimage.measure import label, regionprops
from skimage.morphology import remove_small_objects, skeletonize

# Recorte del dibujo en la ficha (x0, y0, x1, y1), en píxeles de la ficha original.
RECORTE = (120, 578, 642, 852)
SALIDA = 2  # el SVG mide el doble del recorte: 1044 x 548
TRABAJO = 4  # se esqueletiza a 4 veces el recorte: líneas centrales más suaves
FILA_PIES = 30  # filas del recorte por sobre esta son los rótulos (DERECHO, IZQUIERDO)
MOTA_MIN = 140  # manchas más chicas que esto (en píxeles de trabajo) son polvo del escaneo
ESPOLON_MIN = 10  # ramitas del esqueleto más cortas que esto (px de trabajo) se descartan
TOLERANCIA = 1.6  # simplificación RDP, en píxeles de trabajo

VECINOS = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]


def tinta(ruta):
    gris = Image.open(ruta).convert("L").crop(RECORTE)
    grande = gris.resize((gris.width * TRABAJO, gris.height * TRABAJO), Image.LANCZOS)
    mascara = np.array(grande) < 150
    return gris, mascara


def rotulos(gris):
    """Cajas de los rótulos (en coordenadas del SVG), para escribirlos como texto."""
    arr = np.array(gris)[:FILA_PIES] < 150
    cols = np.where(arr.any(axis=0))[0]
    grupos, inicio, previo = [], cols[0], cols[0]
    for c in cols[1:]:
        if c - previo > 8:
            grupos.append((inicio, previo))
            inicio = c
        previo = c
    grupos.append((inicio, previo))
    filas = np.where(arr.any(axis=1))[0]
    return [
        {
            "cx": float((a + b) / 2 * SALIDA),
            "y": int((filas.max() + 1) * SALIDA),
            "alto": int(np.ptp(filas) + 1) * SALIDA,
            "ancho": int(b - a + 1) * SALIDA,
        }
        for a, b in grupos
    ]


def tramos(esqueleto):
    """Divide el esqueleto en tramos que van de un extremo o cruce a otro (o lazos cerrados)."""
    puntos = set(zip(*np.nonzero(esqueleto), strict=True))

    def vecinos(p):
        return [(p[0] + dy, p[1] + dx) for dy, dx in VECINOS if (p[0] + dy, p[1] + dx) in puntos]

    grado = {p: len(vecinos(p)) for p in puntos}
    nodos = {p for p, g in grado.items() if g != 2}
    usados = set()
    resultado = []

    def caminar(inicio, siguiente):
        camino = [inicio, siguiente]
        usados.add(frozenset((inicio, siguiente)))
        actual, previo = siguiente, inicio
        while actual not in nodos:
            candidatos = [
                v for v in vecinos(actual) if v != previo and frozenset((actual, v)) not in usados
            ]
            if not candidatos:
                break
            previo, actual = actual, candidatos[0]
            usados.add(frozenset((previo, actual)))
            camino.append(actual)
            if actual == inicio:
                break
        return camino

    for nodo in nodos:
        for v in vecinos(nodo):
            if frozenset((nodo, v)) not in usados:
                resultado.append((caminar(nodo, v), True))
    # Lazos sin extremos ni cruces (p. ej. una uña cerrada).
    for p in puntos:
        for v in vecinos(p):
            if frozenset((p, v)) not in usados:
                resultado.append((caminar(p, v), False))
    return resultado, grado


def rdp(puntos, tolerancia):
    if len(puntos) < 3:
        return puntos
    a, b = np.array(puntos[0], float), np.array(puntos[-1], float)
    linea = b - a
    largo = np.hypot(*linea)
    pts = np.array(puntos, float)
    if largo == 0:
        dist = np.hypot(*(pts - a).T)
    else:
        rel = pts - a
        dist = np.abs(linea[0] * rel[:, 1] - linea[1] * rel[:, 0]) / largo
    i = int(np.argmax(dist))
    if dist[i] > tolerancia:
        return rdp(puntos[: i + 1], tolerancia)[:-1] + rdp(puntos[i:], tolerancia)
    return [puntos[0], puntos[-1]]


def a_svg(puntos):
    """Polilínea (y, x) en píxeles de trabajo -> trazo SVG suave en coordenadas de salida."""
    escala = SALIDA / TRABAJO
    pts = [(x * escala, y * escala) for y, x in puntos]
    cerrado = len(pts) > 3 and np.hypot(pts[0][0] - pts[-1][0], pts[0][1] - pts[-1][1]) < 1
    if len(pts) == 2:
        (x0, y0), (x1, y1) = pts
        return f"M{x0:.1f} {y0:.1f}L{x1:.1f} {y1:.1f}"
    d = [f"M{pts[0][0]:.1f} {pts[0][1]:.1f}"]
    for i in range(len(pts) - 1):
        p0 = pts[i - 1] if i > 0 else (pts[-2] if cerrado else pts[i])
        p1, p2 = pts[i], pts[i + 1]
        p3 = pts[i + 2] if i + 2 < len(pts) else (pts[1] if cerrado else p2)
        c1 = (p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6)
        c2 = (p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6)
        d.append(f"C{c1[0]:.1f} {c1[1]:.1f} {c2[0]:.1f} {c2[1]:.1f} {p2[0]:.1f} {p2[1]:.1f}")
    return "".join(d) + ("Z" if cerrado else "")


def main(entrada, salida):
    gris, mascara = tinta(entrada)
    mascara[: FILA_PIES * TRABAJO] = False  # los rótulos van como texto
    mascara = remove_small_objects(mascara, max_size=MOTA_MIN - 1)
    esqueleto = skeletonize(mascara)
    lista, grado = tramos(esqueleto)
    trazos = []
    for camino, con_nodos in lista:
        extremo_suelto = grado.get(camino[0]) == 1 or grado.get(camino[-1]) == 1
        cruce = grado.get(camino[0], 0) >= 3 or grado.get(camino[-1], 0) >= 3
        if con_nodos and extremo_suelto and cruce and len(camino) < ESPOLON_MIN:
            continue  # espolón del esqueleto, no es parte del dibujo
        if len(camino) < 4:
            continue
        trazos.append(a_svg(rdp(camino, TOLERANCIA)))
    # Los tramos cortos que quedan sueltos (rayitas del dibujo) se conservan.
    etiquetas = rotulos(gris)
    with open(salida, "w", encoding="utf-8") as f:
        f.write(
            '"""Trazos del dibujo de los pies (generado por scripts/vectorizar_pies.py; no '
            'editar a mano)."""\n\n'
        )
        f.write(f"ANCHO = {gris.width * SALIDA}\nALTO = {gris.height * SALIDA}\n")
        f.write(f"ROTULOS = {etiquetas!r}\n")
        f.write("TRAZOS = [\n")
        for t in trazos:
            f.write(f'    "{t}",\n')
        f.write("]\n")
    print(f"{len(trazos)} trazos, rótulos {etiquetas}, regiones {len(regionprops(label(mascara)))}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
