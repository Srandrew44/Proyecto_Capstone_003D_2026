/* Dibujo de los pies editable (web/ficha/pies.html).
 *
 * El podólogo arrastra un símbolo de la simbología hasta el pie y lo suelta donde corresponde.
 * También puede elegir el símbolo con un clic y hacer clic sobre el pie (sirve con teclado).
 * Una marca se mueve arrastrándola (incluso a otra vista) y se quita con un clic.
 *
 * Las marcas se guardan en el campo oculto `marcas` como JSON [{simbolo, vista, x, y}], con
 * x e y de 0 a 1 dentro de la vista, y viajan con el formulario de la atención. Se inicia
 * también en el contenido que trae htmx (los modales).
 */
(function () {
  // Cuánto hay que mover el puntero para que cuente como arrastre y no como clic.
  const UMBRAL = 5;

  function iniciar(raiz) {
    if (raiz.dataset.listo) return;
    raiz.dataset.listo = '1';
    // Tamaño de cada símbolo sobre el dibujo: lo fija apps/web/pies.py (data-tamano).
    const TAMANO = Number(raiz.dataset.tamano) || 22;
    const campo = raiz.querySelector('[data-marcas]');
    const lienzo = raiz.querySelector('[data-lienzo]');
    const capa = raiz.querySelector('[data-capa-marcas]');
    const lista = raiz.querySelector('[data-lista-marcas]');
    const botones = [...raiz.querySelectorAll('[data-simbolo]')];
    const nombres = Object.fromEntries(botones.map((b) => [b.dataset.simbolo, b.textContent.trim()]));
    const zonasLista = [...raiz.querySelectorAll('[data-zona]')];
    const zonas = Object.fromEntries(zonasLista.map((z) => [z.dataset.zona, z]));
    let marcas = JSON.parse(campo.value || '[]');
    let elegido = null;
    let ignorarClic = false; // el clic que el navegador dispara al terminar un arrastre

    const nombreVista = (codigo) => zonas[codigo].dataset.nombre;
    const acotar = (v) => Math.min(1, Math.max(0, Math.round(v * 1000) / 1000));
    const numero = (zona, clave) => Number(zona.dataset[clave]);

    // Punto de la pantalla -> coordenadas del dibujo (las del viewBox del SVG).
    function aDibujo(clientX, clientY) {
      const punto = lienzo.createSVGPoint();
      punto.x = clientX;
      punto.y = clientY;
      return punto.matrixTransform(lienzo.getScreenCTM().inverse());
    }

    // La vista bajo un punto del dibujo y la posición de 0 a 1 dentro de ella (o null).
    function ubicar(clientX, clientY) {
      const p = aDibujo(clientX, clientY);
      const zona = zonasLista.find((z) => {
        const x0 = numero(z, 'x0');
        return p.x >= x0 && p.x <= x0 + numero(z, 'ancho') && p.y >= 0 && p.y <= numero(z, 'alto');
      });
      if (!zona) return null;
      return {
        vista: zona.dataset.zona,
        x: acotar((p.x - numero(zona, 'x0')) / numero(zona, 'ancho')),
        y: acotar(p.y / numero(zona, 'alto')),
      };
    }

    function posicion(m) {
      const zona = zonas[m.vista];
      return {
        x: numero(zona, 'x0') + m.x * numero(zona, 'ancho') - TAMANO / 2,
        y: m.y * numero(zona, 'alto') - TAMANO / 2,
      };
    }

    function dibujar() {
      campo.value = JSON.stringify(marcas);
      capa.replaceChildren();
      lista.replaceChildren();
      marcas.forEach((m, indice) => {
        const modelo = botones.find((b) => b.dataset.simbolo === m.simbolo).querySelector('svg');
        const svg = modelo.cloneNode(true);
        const { x, y } = posicion(m);
        svg.setAttribute('x', x.toFixed(1));
        svg.setAttribute('y', y.toFixed(1));
        svg.setAttribute('width', TAMANO);
        svg.setAttribute('height', TAMANO);
        svg.removeAttribute('aria-hidden');
        svg.classList.add('cursor-grab', 'touch-none');
        svg.dataset.indice = indice;
        // Área invisible del tamaño del símbolo: los símbolos de trazo fino igual se agarran.
        const area = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        for (const [clave, valor] of [['x', -16], ['y', -16], ['width', 32], ['height', 32], ['fill', 'transparent']]) {
          area.setAttribute(clave, valor);
        }
        svg.prepend(area);
        const titulo = document.createElementNS('http://www.w3.org/2000/svg', 'title');
        titulo.textContent = `${nombres[m.simbolo]} · ${nombreVista(m.vista)} (arrastra para mover, clic para quitar)`;
        svg.prepend(titulo);
        capa.appendChild(svg);

        const item = document.createElement('li');
        item.className = 'flex items-center gap-1';
        item.textContent = `${nombres[m.simbolo]} · ${nombreVista(m.vista)}`;
        const quitar = document.createElement('button');
        quitar.type = 'button';
        quitar.className = 'text-peligro hover:underline';
        quitar.textContent = 'quitar';
        quitar.dataset.indice = indice;
        item.append(' ', quitar);
        lista.appendChild(item);
      });
      if (!marcas.length) {
        const vacio = document.createElement('li');
        vacio.className = 'text-texto-tenue';
        vacio.textContent = elegido
          ? 'Haz clic sobre el pie para marcar.'
          : 'Arrastra un símbolo hasta el pie para empezar a marcar.';
        lista.appendChild(vacio);
      }
    }

    // --- arrastrar un símbolo nuevo desde la simbología ---

    function fantasma(boton) {
      const copia = boton.querySelector('svg').cloneNode(true);
      const caja = document.createElement('div');
      caja.className = 'pointer-events-none fixed z-50 drop-shadow';
      caja.style.width = '30px';
      caja.style.height = '30px';
      copia.setAttribute('width', '30');
      copia.setAttribute('height', '30');
      caja.appendChild(copia);
      document.body.appendChild(caja);
      return caja;
    }

    function moverFantasma(caja, evento) {
      caja.style.left = `${evento.clientX - 15}px`;
      caja.style.top = `${evento.clientY - 15}px`;
    }

    botones.forEach((boton) => {
      boton.addEventListener('pointerdown', (evento) => {
        if (evento.button !== 0) return;
        const inicio = { x: evento.clientX, y: evento.clientY };
        let caja = null;
        boton.setPointerCapture(evento.pointerId);

        const mover = (e) => {
          if (!caja && Math.hypot(e.clientX - inicio.x, e.clientY - inicio.y) > UMBRAL) {
            caja = fantasma(boton);
          }
          if (caja) moverFantasma(caja, e);
        };
        const soltar = (e) => {
          boton.removeEventListener('pointermove', mover);
          boton.removeEventListener('pointerup', soltar);
          boton.removeEventListener('pointercancel', soltar);
          if (!caja) return; // fue un clic: lo maneja el evento click (elegir el símbolo)
          caja.remove();
          ignorarClic = true;
          setTimeout(() => { ignorarClic = false; }, 0);
          const lugar = e.type === 'pointerup' && ubicar(e.clientX, e.clientY);
          if (lugar) {
            marcas.push({ simbolo: boton.dataset.simbolo, ...lugar });
            dibujar();
          }
        };
        boton.addEventListener('pointermove', mover);
        boton.addEventListener('pointerup', soltar);
        boton.addEventListener('pointercancel', soltar);
      });

      boton.addEventListener('click', () => {
        if (ignorarClic) {
          ignorarClic = false;
          return;
        }
        elegido = elegido === boton.dataset.simbolo ? null : boton.dataset.simbolo;
        botones.forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.simbolo === elegido)));
        dibujar();
      });
    });

    // --- mover una marca ya puesta ---

    capa.addEventListener('pointerdown', (evento) => {
      const marca = evento.target.closest('[data-indice]');
      if (!marca || evento.button !== 0) return;
      evento.preventDefault();
      const indice = Number(marca.dataset.indice);
      const inicio = { x: evento.clientX, y: evento.clientY };
      let arrastrando = false;
      marca.setPointerCapture(evento.pointerId);

      const mover = (e) => {
        if (!arrastrando && Math.hypot(e.clientX - inicio.x, e.clientY - inicio.y) > UMBRAL) {
          arrastrando = true;
          marca.classList.add('cursor-grabbing', 'opacity-70');
        }
        if (!arrastrando) return;
        const p = aDibujo(e.clientX, e.clientY);
        marca.setAttribute('x', (p.x - TAMANO / 2).toFixed(1));
        marca.setAttribute('y', (p.y - TAMANO / 2).toFixed(1));
      };
      const soltar = (e) => {
        marca.removeEventListener('pointermove', mover);
        marca.removeEventListener('pointerup', soltar);
        marca.removeEventListener('pointercancel', soltar);
        if (!arrastrando) return; // fue un clic: lo maneja el evento click (quitar la marca)
        ignorarClic = true;
        setTimeout(() => { ignorarClic = false; }, 0);
        const lugar = e.type === 'pointerup' && ubicar(e.clientX, e.clientY);
        // Fuera de los pies (o cancelado) vuelve a su lugar.
        if (lugar) marcas[indice] = { ...marcas[indice], ...lugar };
        dibujar();
      };
      marca.addEventListener('pointermove', mover);
      marca.addEventListener('pointerup', soltar);
      marca.addEventListener('pointercancel', soltar);
    });

    // --- clics: poner con el símbolo elegido, o quitar una marca ---

    lienzo.addEventListener('click', (evento) => {
      if (ignorarClic) {
        ignorarClic = false;
        return;
      }
      const marca = evento.target.closest('[data-indice]');
      if (marca) {
        marcas.splice(Number(marca.dataset.indice), 1);
        dibujar();
        return;
      }
      if (!elegido) return;
      const lugar = ubicar(evento.clientX, evento.clientY);
      if (!lugar) return;
      marcas.push({ simbolo: elegido, ...lugar });
      dibujar();
    });

    lista.addEventListener('click', (evento) => {
      const quitar = evento.target.closest('button[data-indice]');
      if (!quitar) return;
      marcas.splice(Number(quitar.dataset.indice), 1);
      dibujar();
    });

    dibujar();
  }

  function buscar(raiz) {
    raiz.querySelectorAll('[data-dibujo-pies][data-editable]').forEach(iniciar);
  }
  document.addEventListener('DOMContentLoaded', () => buscar(document));
  document.addEventListener('htmx:load', (evento) => buscar(evento.target));
  window.MyPodoPies = { iniciar };
})();
