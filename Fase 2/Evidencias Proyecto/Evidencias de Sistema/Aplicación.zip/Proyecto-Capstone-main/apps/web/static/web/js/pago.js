// Envía al paciente a Webpay apenas carga la página de pago (formulario con el token).
document.getElementById("form-webpay")?.submit();
