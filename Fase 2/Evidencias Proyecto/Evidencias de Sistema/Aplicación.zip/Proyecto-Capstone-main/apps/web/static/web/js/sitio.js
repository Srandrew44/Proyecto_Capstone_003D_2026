/* MyPodo — comportamiento común de todas las páginas, junto a htmx.
 *
 * Las páginas las arma Django y htmx las actualiza por partes; aquí solo queda lo que tiene que
 * pasar en el navegador: avisos (toasts), el diálogo modal, los menús en el celular, el foco
 * del flujo de reserva y un par de ayudas de formulario. No hay scripts en línea: la CSP solo
 * permite archivos de este sitio.
 */
(function () {
  // "Saltar al contenido" apunta a #contenido; si la página no lo marcó, se usa su <main>.
  if (!document.getElementById('contenido')) {
    const principal = document.querySelector('main');
    if (principal) {
      principal.id = 'contenido';
      principal.tabIndex = -1;
    }
  }

  // ---- Avisos ----
  // La región [data-avisos] (role="status") viene en esqueleto.html desde que carga la página.
  // Los de éxito e información se van solos a los 10 s (no mientras el mouse o el foco están
  // encima); los de error y aviso se quedan hasta que la persona los cierra.
  const DURACION_AVISO = 10000;
  const ICONO_CERRAR =
    '<svg viewBox="0 0 24 24" class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="2"' +
    ' stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  function aviso(texto, tipo = 'success') {
    let host = document.querySelector('[data-avisos]');
    if (!host) {
      host = document.createElement('div');
      host.dataset.avisos = '';
      host.setAttribute('role', 'status');
      host.setAttribute('aria-live', 'polite');
      host.className =
        'pointer-events-none fixed inset-x-4 bottom-4 z-50 flex flex-col items-end gap-2 sm:left-auto sm:max-w-sm';
      document.body.appendChild(host);
    }
    const colores = { success: 'bg-exito', warning: 'bg-aviso', danger: 'bg-peligro', error: 'bg-peligro', info: 'bg-info' };
    const el = document.createElement('div');
    el.className = `aviso ${colores[tipo] || colores.info}`;
    const mensaje = document.createElement('p');
    mensaje.className = 'flex-1 py-0.5';
    mensaje.textContent = texto;
    const cerrar = document.createElement('button');
    cerrar.type = 'button';
    cerrar.className = 'aviso-cerrar';
    cerrar.setAttribute('aria-label', 'Cerrar aviso');
    cerrar.innerHTML = ICONO_CERRAR;
    cerrar.addEventListener('click', () => el.remove());
    el.append(mensaje, cerrar);
    host.appendChild(el);
    if (tipo === 'danger' || tipo === 'warning' || tipo === 'error') return;
    let temporizador;
    const programar = () => {
      clearTimeout(temporizador);
      temporizador = setTimeout(() => el.remove(), DURACION_AVISO);
    };
    const pausar = () => clearTimeout(temporizador);
    el.addEventListener('mouseenter', pausar);
    el.addEventListener('focusin', pausar);
    el.addEventListener('mouseleave', programar);
    el.addEventListener('focusout', programar);
    programar();
  }

  // El servidor manda avisos con la cabecera HX-Trigger: {"aviso": {"texto": "...", "tipo": "..."}}
  document.body.addEventListener('aviso', (e) => aviso(e.detail.texto, e.detail.tipo));
  // Mensajes de Django que vienen en la página (después de una redirección).
  document.querySelectorAll('[data-mensaje]').forEach((m) => {
    aviso(m.dataset.mensaje, m.dataset.tipo);
    m.remove();
  });
  document.body.addEventListener('htmx:responseError', (e) => {
    const estado = e.detail.xhr.status;
    aviso(
      estado === 403 || estado === 404
        ? 'No tienes acceso a eso o ya no existe.'
        : 'No se pudo completar la acción. Intenta de nuevo.',
      'danger'
    );
  });
  document.body.addEventListener('htmx:sendError', () =>
    aviso('Sin conexión con el servidor. Revisa tu red e intenta de nuevo.', 'danger')
  );

  // ---- Diálogo modal: su contenido lo trae htmx al #modal-contenido ----
  const modal = document.getElementById('modal');
  document.body.addEventListener('htmx:afterSwap', (e) => {
    if (modal && e.detail.target.id === 'modal-contenido' && !modal.open) modal.showModal();
  });
  document.body.addEventListener('cerrarModal', () => modal && modal.open && modal.close());
  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-cerrar-modal]') && modal) modal.close();

    const botonAbrir = e.target.closest('[data-abrir-dialogo]');
    if (botonAbrir) {
      const dialogo = document.getElementById(botonAbrir.dataset.abrirDialogo);
      if (dialogo instanceof HTMLDialogElement && !dialogo.open) dialogo.showModal();
    }

    const dialogo = e.target.closest('dialog');
    // Clic en el fondo oscuro (fuera del contenido) también cierra.
    if (dialogo?.open && (e.target === dialogo || e.target.closest('[data-cerrar-dialogo]'))) {
      dialogo.close();
    }
  });

  // ---- Menú lateral en el celular ----
  // Cerrado, el CSS lo deja con visibility: hidden (sus enlaces no reciben foco). Abierto, el
  // resto de la página queda inerte, hay un fondo oscuro que lo cierra, y Escape lo cierra
  // devolviendo el foco al botón. En escritorio (lg) siempre está visible.
  const menu = document.getElementById('menu-lateral');
  const botonMenu = document.querySelector('[data-menu]');
  const fondoMenu = document.getElementById('menu-fondo');
  const pagina = document.getElementById('pagina');
  const escritorio = window.matchMedia('(min-width: 1024px)');
  const menuAbierto = () => !!menu && menu.classList.contains('abierto');
  function abrirMenu() {
    if (!menu) return;
    menu.classList.add('abierto');
    if (fondoMenu) fondoMenu.hidden = false;
    if (pagina) pagina.inert = true;
    if (botonMenu) botonMenu.setAttribute('aria-expanded', 'true');
    const cerrar = menu.querySelector('[data-menu-cerrar]');
    if (cerrar) cerrar.focus();
  }
  function cerrarMenu(devolverFoco) {
    if (!menu) return;
    menu.classList.remove('abierto');
    if (fondoMenu) fondoMenu.hidden = true;
    if (pagina) pagina.inert = false;
    if (botonMenu) {
      botonMenu.setAttribute('aria-expanded', 'false');
      if (devolverFoco) botonMenu.focus();
    }
  }
  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-menu]')) {
      if (menuAbierto()) cerrarMenu(false);
      else abrirMenu();
    } else if (e.target.closest('[data-menu-cerrar]')) {
      cerrarMenu(true);
    }
  });
  // Al pasar a escritorio el menú queda fijo: se limpia el estado del celular.
  escritorio.addEventListener('change', () => cerrarMenu(false));

  // ---- Menú desplegable de la portada ----
  // <button data-desplegar aria-controls="id" aria-expanded="false"> abre o cierra #id (clase
  // "abierto"); se cierra con Escape, al elegir un enlace o al hacer clic fuera.
  function cerrarDesplegable(boton, devolverFoco) {
    const panel = document.getElementById(boton.getAttribute('aria-controls'));
    if (panel) panel.classList.remove('abierto');
    boton.setAttribute('aria-expanded', 'false');
    if (devolverFoco) boton.focus();
  }
  document.addEventListener('click', (e) => {
    const boton = e.target.closest('[data-desplegar]');
    if (boton) {
      const panel = document.getElementById(boton.getAttribute('aria-controls'));
      if (!panel) return;
      const abrir = !panel.classList.contains('abierto');
      panel.classList.toggle('abierto', abrir);
      boton.setAttribute('aria-expanded', String(abrir));
      return;
    }
    document.querySelectorAll('[data-desplegar][aria-expanded="true"]').forEach((b) => {
      const panel = document.getElementById(b.getAttribute('aria-controls'));
      // Clic fuera del panel, o en uno de sus enlaces: se cierra.
      if (!panel || !panel.contains(e.target) || e.target.closest('a')) cerrarDesplegable(b, false);
    });
  });

  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (document.querySelector('dialog[open]')) return; // Escape cierra el diálogo de forma nativa.
    if (menuAbierto()) {
      cerrarMenu(true);
      return;
    }
    document
      .querySelectorAll('[data-desplegar][aria-expanded="true"]')
      .forEach((b) => cerrarDesplegable(b, true));
  });

  // ---- Flujo de reserva: al pasar de paso, el foco y la vista van al paso siguiente ----
  // La plantilla marca con data-enfocar el título del paso que toca. Se hace al asentarse el
  // cambio (afterSettle) y sin animación: un desplazamiento suave lo corta el propio htmx.
  document.body.addEventListener('htmx:afterSettle', (e) => {
    if (e.detail.target.id !== 'flujo-reserva') return;
    const destino = e.detail.target.querySelector('[data-enfocar]');
    if (!destino) return;
    destino.tabIndex = -1;
    destino.focus({ preventScroll: true });
    destino.scrollIntoView({ block: 'start' });
  });

  // ---- Ayudas de formulario ----
  // Muestra un bloque según el valor de un select: <select data-muestra="otra" data-objetivo="#id">
  function alternar(select) {
    const objetivo = document.querySelector(select.dataset.objetivo);
    if (objetivo) objetivo.hidden = select.value !== select.dataset.muestra;
  }
  document.addEventListener('change', (e) => {
    if (e.target.matches('select[data-muestra]')) alternar(e.target);
  });
  document.body.addEventListener('htmx:load', (e) =>
    e.target.querySelectorAll('select[data-muestra]').forEach(alternar)
  );
  // "Ver anteriores": muestra el bloque oculto que está justo antes del botón.
  document.addEventListener('click', (e) => {
    const boton = e.target.closest('[data-revelar]');
    if (!boton) return;
    boton.previousElementSibling.hidden = false;
    boton.remove();
  });

  window.MyPodo = { aviso };
})();
