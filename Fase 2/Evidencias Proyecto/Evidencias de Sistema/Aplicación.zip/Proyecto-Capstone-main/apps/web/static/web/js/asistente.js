// Asistente: deshabilita el envío mientras responde, limpia el formulario y baja al final.
(function () {
  const form = document.getElementById("form-asistente");
  const mensajes = document.getElementById("mensajes");
  if (!form || !mensajes) return;
  const boton = document.getElementById("enviar-asistente");
  const pensando = document.getElementById("pensando");
  const bajar = () => { mensajes.scrollTop = mensajes.scrollHeight; };
  bajar();
  form.addEventListener("htmx:beforeRequest", () => {
    boton.disabled = true;
    pensando.classList.remove("hidden");
  });
  form.addEventListener("htmx:afterRequest", (evento) => {
    boton.disabled = false;
    pensando.classList.add("hidden");
    if (evento.detail.successful) form.reset();
    bajar();
  });
  // Enter envía; Shift+Enter hace un salto de línea.
  form.querySelector("textarea").addEventListener("keydown", (evento) => {
    if (evento.key === "Enter" && !evento.shiftKey) {
      evento.preventDefault();
      form.requestSubmit();
    }
  });
})();
