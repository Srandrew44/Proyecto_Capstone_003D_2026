"""Asistente virtual: visitantes (preguntas frecuentes) y pacientes (además, fotos y triaje)."""

from django.core.exceptions import ValidationError as DjangoValidationError
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_GET, require_POST

from apps.auditoria.services import ip_de
from apps.chatbot import conocimiento
from apps.chatbot import services as chatbot
from apps.chatbot.models import FotoChatbot
from apps.clinica import services as clinica_servicios
from apps.clinica.models import Consentimiento
from apps.clinica.services import ConsentimientoRequerido

from .comun import Rol, contexto_base, inicio_de

SESION = "asistente_conversacion"


def _solo_pacientes_y_visitantes(vista):
    def envoltura(request, *args, **kwargs):
        usuario = request.user
        if usuario.is_authenticated and (
            usuario.rol != Rol.PACIENTE or not hasattr(usuario, "paciente")
        ):
            return redirect(inicio_de(usuario))
        return vista(request, *args, **kwargs)

    return envoltura


def _clave_visitante(request) -> str:
    if not request.session.session_key:
        request.session.save()
    return request.session.session_key


def _conversacion(request):
    conversacion = chatbot.conversacion_para(request.user, request.session.get(SESION))
    request.session[SESION] = str(conversacion.pk)
    return conversacion


def _contexto(request, conversacion, **extra):
    usuario = request.user
    es_paciente = usuario.is_authenticated
    return contexto_base(
        "asistente",
        conversacion=conversacion,
        interacciones=conversacion.interacciones.select_related("foto"),
        es_paciente=es_paciente,
        con_fotos=chatbot.puede_usar_fotos(usuario),
        base_validada=conocimiento.VALIDADA,
        validada_por=conocimiento.VALIDADA_POR,
        plantilla_base="web/base.html" if es_paciente else "web/asistente_publico.html",
        **extra,
    )


@_solo_pacientes_y_visitantes
@require_GET
def asistente(request):
    _clave_visitante(request)
    conversacion = _conversacion(request)
    return render(request, "web/asistente.html", _contexto(request, conversacion))


@_solo_pacientes_y_visitantes
@require_POST
def enviar(request):
    """Responde con los dos mensajes nuevos (el del usuario y el del asistente), que htmx
    agrega al final. Los errores también llegan como un mensaje, con estado 200."""
    conversacion = _conversacion(request)
    try:
        interaccion = chatbot.enviar_mensaje(
            usuario=request.user,
            conversacion=conversacion,
            texto=request.POST.get("mensaje", ""),
            foto=request.FILES.get("foto"),
            clave_visitante=_clave_visitante(request),
            ip=ip_de(request),
        )
    except DjangoValidationError as exc:
        return _error(request, exc.messages[0])
    except ConsentimientoRequerido:
        return _error(request, "Para enviar fotos debes aceptar el uso del asistente.")
    except chatbot.LimiteAlcanzado as exc:
        return _error(request, str(exc))
    contexto = {"i": interaccion, "es_paciente": request.user.is_authenticated}
    return render(request, "web/asistente/interaccion.html", contexto)


def _error(request, texto):
    return render(request, "web/asistente/error.html", {"texto": texto})


@_solo_pacientes_y_visitantes
@require_POST
def nueva(request):
    request.session.pop(SESION, None)
    return redirect("web:asistente")


@require_POST
def aceptar(request):
    usuario = request.user
    if not (usuario.is_authenticated and hasattr(usuario, "paciente")):
        return redirect("web:asistente")
    if request.POST.get("acepto") == "si":
        clinica_servicios.aceptar_consentimiento(
            paciente=usuario.paciente, tipo=Consentimiento.Tipo.USO_CHATBOT, ip=ip_de(request)
        )
        request.session.pop(SESION, None)
    return redirect("web:asistente")


@require_POST
def revocar(request):
    """Retira la autorización `uso_chatbot`: el asistente vuelve a solo preguntas frecuentes."""
    usuario = request.user
    if usuario.is_authenticated and hasattr(usuario, "paciente"):
        vigente = Consentimiento.objects.filter(
            paciente=usuario.paciente,
            tipo=Consentimiento.Tipo.USO_CHATBOT,
            revocado_en__isnull=True,
        ).first()
        if vigente:
            clinica_servicios.revocar_consentimiento(consentimiento=vigente, ip=ip_de(request))
        request.session.pop(SESION, None)
    return redirect("web:asistente")


@require_GET
def foto(request, pk):
    """La foto solo la ve el paciente que la envió."""
    foto = get_object_or_404(FotoChatbot.objects.select_related("interaccion__conversacion"), pk=pk)
    if not foto.interaccion.conversacion.es_de(request.user):
        raise Http404
    respuesta = HttpResponse(bytes(foto.contenido), content_type=foto.media_type)
    respuesta["Cache-Control"] = "no-store"
    return respuesta
