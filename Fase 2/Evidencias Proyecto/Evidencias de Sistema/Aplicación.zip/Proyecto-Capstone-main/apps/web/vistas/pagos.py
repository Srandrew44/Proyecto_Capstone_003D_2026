"""Pago de la cita con Webpay Plus: ir a pagar, vuelta desde Webpay y comprobante."""

from django.core.exceptions import ValidationError as DjangoValidationError
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_http_methods

from apps.agenda.models import Notificacion
from apps.auditoria.services import ip_de
from apps.pagos import services as pagos
from apps.pagos.models import Pago

from .comun import Rol, con_rol, contexto_base, redirigir

solo_paciente = con_rol(Rol.PACIENTE)


def _mi_pago(request, pk) -> Pago:
    pago = get_object_or_404(
        Pago.objects.select_related("cita__profesional__usuario", "cita__tratamiento"),
        cita_id=pk,
    )
    # El pago ajeno responde 404, igual que una cita ajena.
    if not pago.es_de(request.user):
        raise Http404
    return pago


@solo_paciente
@require_GET
def ir_a_pagar(request, pk):
    """Abre la transacción y envía al paciente a Webpay con un formulario que se envía solo."""
    pago = _mi_pago(request, pk)
    url_retorno = request.build_absolute_uri(reverse("web:pago-retorno"))
    try:
        url, token = pagos.iniciar_webpay(pago, url_retorno=url_retorno)
    except DjangoValidationError as exc:
        return redirigir(request, reverse("web:paciente-citas"), exc.messages[0], "warning")
    contexto = contexto_base("citas", pago=pago, url=url, token=token)
    return render(request, "web/paciente/pago_ir.html", contexto)


@csrf_exempt
@require_http_methods(["GET", "POST"])
def retorno(request):
    """Vuelta desde Webpay. Transbank puede volver por POST desde su dominio: no lleva token
    CSRF y la cookie de sesión puede no venir, así que esta vista no depende de la sesión.
    Solo procesa el pago por su token y redirige al comprobante, que sí exige sesión."""
    datos = request.POST if request.method == "POST" else request.GET
    pago = pagos.procesar_retorno(datos, ip=ip_de(request))
    if pago is None:
        return redirect("web:paciente-citas")
    return redirect("web:pago-resultado", pk=pago.cita_id)


@solo_paciente
@require_GET
def resultado(request, pk):
    # Un pago cuyo plazo ya venció no debe mostrarse como "tu hora sigue reservada".
    pagos.vencer_pendientes(paciente=request.user.paciente)
    pago = _mi_pago(request, pk)
    recordatorio = pago.cita.notificaciones.filter(
        tipo=Notificacion.Tipo.RECORDATORIO, estado=Notificacion.Estado.PENDIENTE
    ).first()
    contexto = contexto_base("citas", pago=pago, cita=pago.cita, recordatorio=recordatorio)
    return render(request, "web/paciente/pago_resultado.html", contexto)
