"""Mi perfil (RF-027): el paciente y el podólogo corrigen sus datos de contacto y cambian su
contraseña. Los datos de identidad los sigue corrigiendo la consulta (ver cuentas.services)."""

from django.core.exceptions import ValidationError as DjangoValidationError
from django.shortcuts import render

from apps.auditoria.services import ip_de
from apps.cuentas import services as cuentas
from apps.cuentas.api.serializers import CambioClaveSerializer

from .comun import contexto_base, errores_de, redirigir, validar


def procesar(request, *, plantilla: str, serializador, iniciales: dict, extra=None):
    """GET muestra la página; POST guarda el perfil (accion=perfil) o la clave (accion=clave).

    Si hay errores se vuelve a mostrar la página con lo que escribió el usuario (estado 400);
    si todo sale bien se redirige con un aviso, para que recargar no reenvíe el formulario.
    """
    errores_perfil, errores_clave = {}, {}
    valores = iniciales
    if request.method == "POST":
        if request.POST.get("accion") == "clave":
            datos, errores_clave = validar(CambioClaveSerializer, request.POST)
            if not errores_clave:
                try:
                    cuentas.cambiar_clave(request, actual=datos["actual"], nueva=datos["nueva"])
                except DjangoValidationError as exc:
                    errores_clave = errores_de(exc)
                else:
                    return redirigir(request, request.path, "Contraseña cambiada.")
        else:
            datos, errores_perfil = validar(serializador, request.POST)
            if not errores_perfil:
                try:
                    cambiados = cuentas.actualizar_perfil(
                        usuario=request.user, datos=datos, ip=ip_de(request)
                    )
                except DjangoValidationError as exc:
                    errores_perfil = errores_de(exc)
                else:
                    texto = "Tus datos quedaron actualizados." if cambiados else "No había cambios."
                    return redirigir(request, request.path, texto)
            valores = {**iniciales, **{k: request.POST.get(k, "") for k in iniciales}}
    contexto = contexto_base(
        "perfil",
        valores=valores,
        errores_perfil=errores_perfil,
        errores_clave=errores_clave,
        **(extra or {}),
    )
    estado = 400 if (errores_perfil or errores_clave) else 200
    return render(request, plantilla, contexto, status=estado)
