"""Páginas que comparten todos los roles."""

from django.shortcuts import render

from apps.agenda import selectors as agenda
from apps.agenda.models import Notificacion

from .comun import Rol, con_rol, contexto_base, es_htmx

FILTROS = [
    ("", "Todos"),
    (Notificacion.Estado.ENVIADA, "Enviados"),
    (Notificacion.Estado.PENDIENTE, "Programados"),
    (Notificacion.Estado.FALLIDA, "Con error"),
]


@con_rol(*Rol.values)
def notificaciones(request):
    filtro = request.GET.get("estado", "")
    if filtro not in dict(FILTROS):
        filtro = ""
    lista = agenda.notificaciones_de(request.user)
    if filtro:
        lista = lista.filter(estado=filtro)
    contexto = contexto_base(
        "notificaciones", notificaciones=lista[:100], filtros=FILTROS, filtro=filtro
    )
    if es_htmx(request):
        return render(request, "web/parciales/notificaciones_lista.html", contexto)
    return render(request, "web/notificaciones.html", contexto)
