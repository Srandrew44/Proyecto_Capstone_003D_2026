"""Perfil del podólogo: lo que él mismo administra (foto, tratamientos, certificaciones) y la
página pública que ven los pacientes, con información limitada y solo lo verificado."""

from django.core.exceptions import ValidationError as DjangoValidationError
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404, render
from django.urls import reverse
from django.views.decorators.http import require_GET, require_POST

from apps.agenda import selectors as agenda
from apps.agenda.models import Tratamiento
from apps.cuentas import services as cuentas
from apps.cuentas.models import Certificacion, Profesional

from .comun import Rol, con_rol, contexto_base, errores_de, redirigir

solo_profesional = con_rol(Rol.PROFESIONAL)

# Verificación pública del registro: buscador oficial de la Superintendencia de Salud.
URL_REGISTRO_PRESTADORES = "https://rnpi.superdesalud.gob.cl/"


def contexto_perfil_profesional(profesional) -> dict:
    return {
        "profesional": profesional,
        "tratamientos_disponibles": agenda.tratamientos_activos(),
        "tratamientos_propios": set(profesional.tratamientos.values_list("pk", flat=True)),
        "certificaciones": profesional.certificaciones.all(),
    }


def _volver(request, texto, tipo="success"):
    return redirigir(request, reverse("web:podologo-perfil"), texto, tipo)


# --- lo que el podólogo administra desde «Mi perfil» ---


@solo_profesional
@require_POST
def foto(request):
    profesional = request.user.profesional
    if request.POST.get("accion") == "quitar":
        cuentas.quitar_foto(profesional=profesional)
        return _volver(request, "Foto quitada.")
    archivo = request.FILES.get("foto")
    if archivo is None:
        return _volver(request, "Elige una foto para subir.", "warning")
    try:
        cuentas.cambiar_foto(profesional=profesional, archivo=archivo)
    except DjangoValidationError as exc:
        return _volver(request, " ".join(exc.messages), "warning")
    return _volver(request, "Foto actualizada.")


@solo_profesional
@require_POST
def tratamientos(request):
    ids = request.POST.getlist("tratamientos")
    elegidos = Tratamiento.objects.filter(activo=True, pk__in=ids)
    cuentas.cambiar_tratamientos(profesional=request.user.profesional, tratamientos=elegidos)
    return _volver(request, "Tratamientos actualizados.")


@solo_profesional
@require_POST
def agregar_certificacion(request):
    datos = request.POST
    nombre, institucion = datos.get("nombre", "").strip(), datos.get("institucion", "").strip()
    archivo = request.FILES.get("documento")
    if not (nombre and institucion and archivo and datos.get("anio", "").isdigit()):
        return _volver(
            request, "Completa el nombre, la institución, el año y el documento.", "warning"
        )
    try:
        cuentas.agregar_certificacion(
            profesional=request.user.profesional,
            nombre=nombre[:200],
            institucion=institucion[:150],
            anio=int(datos["anio"]),
            archivo=archivo,
        )
    except DjangoValidationError as exc:
        mensajes = [m for lista in errores_de(exc).values() for m in lista]
        return _volver(request, " ".join(mensajes), "warning")
    return _volver(request, "Certificación enviada. Se mostrará a los pacientes al verificarla.")


@solo_profesional
@require_POST
def quitar_certificacion(request, pk):
    certificacion = get_object_or_404(Certificacion, pk=pk, profesional_id=request.user.pk)
    cuentas.eliminar_certificacion(certificacion=certificacion, usuario=request.user)
    return _volver(request, "Certificación quitada.")


@solo_profesional
@require_GET
def documento_certificacion(request, pk):
    """El podólogo revisa el documento que subió. Nadie más (salvo el admin) lo ve."""
    certificacion = get_object_or_404(Certificacion, pk=pk, profesional_id=request.user.pk)
    if not certificacion.documento_tipo:
        raise Http404
    respuesta = HttpResponse(
        bytes(certificacion.documento), content_type=certificacion.documento_tipo
    )
    if certificacion.documento_tipo == "application/pdf":
        respuesta["Content-Disposition"] = (
            f'attachment; filename="certificado-{certificacion.anio}.pdf"'
        )
    respuesta["Cache-Control"] = "no-store"
    return respuesta


# --- perfil público (lo ve cualquiera, pensado para el paciente que elige podólogo) ---


def _profesional_publico(pk):
    return get_object_or_404(
        Profesional.objects.select_related("usuario"), pk=pk, usuario__is_active=True
    )


@require_GET
def perfil_publico(request, pk):
    """Solo datos profesionales: nada de RUT, teléfono, correo ni documentos."""
    profesional = _profesional_publico(pk)
    contexto = contexto_base(
        "reservar",
        profesional=profesional,
        tratamientos=profesional.tratamientos.filter(activo=True),
        certificaciones=profesional.certificaciones_publicas(),
        puede_reservar=agenda.tiene_horario(profesional),
        url_registro=URL_REGISTRO_PRESTADORES,
        plantilla_base=(
            "web/base.html" if request.user.is_authenticated else "web/asistente_publico.html"
        ),
    )
    return render(request, "web/profesional_publico.html", contexto)


@require_GET
def foto_publica(request, pk):
    profesional = _profesional_publico(pk)
    if not profesional.foto:
        raise Http404
    respuesta = HttpResponse(bytes(profesional.foto), content_type="image/jpeg")
    respuesta["Cache-Control"] = "public, max-age=3600"
    return respuesta
