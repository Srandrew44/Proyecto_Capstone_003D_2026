"""Piezas de la ficha podológica que comparten la vista del paciente y la del podólogo.

Los campos siguen la ficha en papel del cliente, sin lo que el podólogo descartó.
"""

from django.db.models import Prefetch

from apps.clinica.models import AtencionClinica, FichaClinica
from apps.clinica.selectors import cambios_del_dibujo, marcas_vigentes, numerar_atenciones
from apps.web.pies import describir_cambio

SI_NO = [
    ("diabetes", "Diabetes"),
    ("hta", "Hipertensión arterial"),
    ("varices", "Várices"),
    ("ulcera_previa", "Úlcera previa"),
    ("ulcera_actual", "Úlcera actual"),
    ("amputaciones", "Amputaciones"),
    ("camina_con_ayuda", "Camina con ayuda"),
    ("calzado_adecuado", "Usa calzado adecuado"),
]
# Antecedentes donde "Sí" es buena señal: se pintan al revés que los factores de riesgo.
SI_NO_FAVORABLES = {"calzado_adecuado"}
PULSOS = [
    ("pulso_radial", "Pulso radial"),
    ("pulso_pedio_derecho", "Pulso pedio derecho"),
    ("pulso_pedio_izquierdo", "Pulso pedio izquierdo"),
]
# (campo, etiqueta, ayuda, corto): los cortos son una línea; los demás, un área de texto.
TEXTOS = [
    ("presion_arterial", "Presión arterial", "Ej.: 120/80", True),
    ("lugar_atencion_salud", "Dónde controla su salud", "Ej.: Cesfam, clínica", True),
    ("otras_patologias_cronicas", "Otras patologías crónicas", "", False),
    ("medicamentos", "Medicamentos", "", False),
    ("alergias", "Alergias", "", False),
    ("observaciones", "Observaciones", "", False),
]
CAMPOS_ATENCION = [
    ("motivo_consulta", "Motivo de consulta"),
    ("observacion", "Observación"),
    ("diagnostico", "Diagnóstico"),
    ("tratamiento", "Tratamiento realizado"),
    ("pie_derecho", "Pie derecho"),
    ("pie_izquierdo", "Pie izquierdo"),
    ("indicaciones", "Indicaciones"),
]
ESPECIALIDADES = [
    ("traumatologia", "Traumatología"),
    ("dermatologia", "Dermatología"),
    ("medicina_general", "Medicina general"),
    ("otra", "Otra especialidad"),
]
ATENCIONES_VISIBLES = 5  # el resto del historial queda tras "Ver anteriores"


def ficha_completa(fichas):
    return fichas.select_related("paciente__usuario").prefetch_related(
        Prefetch(
            "atenciones",
            queryset=AtencionClinica.objects.select_related("profesional__usuario", "correccion"),
        ),
        "atenciones__derivaciones",
        "marcas",
    )


def numeros_de(ficha) -> dict:
    return numerar_atenciones(ficha.atenciones.all())


def historial_dibujo(ficha, atenciones) -> list[dict]:
    """Cambios del dibujo de los pies listos para mostrar, del más reciente al más antiguo.

    `atenciones` son las de `historial` (ya numeradas).
    """
    por_id = {atencion.pk: atencion for atencion in atenciones}
    lineas = []
    for cambio in cambios_del_dibujo(ficha):
        atencion = por_id.get(cambio["atencion_id"])
        lineas.append(
            {
                **cambio,
                "texto": describir_cambio(cambio),
                "numero": atencion.numero if atencion else None,
                "es_correccion": bool(atencion and atencion.corrige_id),
            }
        )
    return lineas


def antecedentes(ficha: FichaClinica) -> dict:
    """Filas listas para mostrar los antecedentes mórbidos."""
    pulsos = dict(FichaClinica.Pulso.choices)
    return {
        "si_no": [
            (etiqueta, getattr(ficha, campo), campo in SI_NO_FAVORABLES)
            for campo, etiqueta in SI_NO
        ],
        "pulsos": [
            (etiqueta, pulsos.get(getattr(ficha, campo), "Sin registro"))
            for campo, etiqueta in PULSOS
        ],
        "textos": [(etiqueta, getattr(ficha, campo)) for campo, etiqueta, _, _ in TEXTOS],
    }


def historial(ficha) -> list:
    """Atenciones con su número, sus campos llenos y la atención que corrigen."""
    atenciones = list(ficha.atenciones.all())
    numeros = numerar_atenciones(atenciones)
    por_id = {a.pk: a for a in atenciones}
    for atencion in atenciones:
        atencion.numero = numeros.get(atencion.pk)
        atencion.campos = [
            (etiqueta, getattr(atencion, campo))
            for campo, etiqueta in CAMPOS_ATENCION
            if getattr(atencion, campo)
        ]
        original = por_id.get(atencion.corrige_id)
        atencion.numero_original = numeros.get(original.pk) if original else None
        atencion.cambios_dibujo = []
    return atenciones


def contexto_ficha(ficha) -> dict:
    atenciones = historial(ficha)
    cambios = historial_dibujo(ficha, atenciones)
    por_id = {atencion.pk: atencion for atencion in atenciones}
    for cambio in reversed(cambios):  # en cada atención, en el orden en que ocurrieron
        if cambio["atencion_id"] in por_id:
            por_id[cambio["atencion_id"]].cambios_dibujo.append(cambio["texto"])
    return {
        "ficha": ficha,
        "paciente": ficha.paciente,
        "antecedentes": antecedentes(ficha),
        "marcas_vigentes": marcas_vigentes(ficha),
        "cambios_dibujo": cambios,
        "atenciones": atenciones[:ATENCIONES_VISIBLES],
        "atenciones_resto": atenciones[ATENCIONES_VISIBLES:],
        "total_atenciones": len(atenciones),
    }
