"""Informe de gestión (B6) en el sitio: mismas cifras y permisos que /api/informes/."""

from datetime import timedelta
from urllib.parse import urlencode

from django.http import Http404
from django.shortcuts import render
from django.utils import timezone

from apps.clinica.api.serializers import InformeConsultaSerializer
from apps.clinica.informes import calcular_informe
from apps.cuentas.models import Profesional

from .comun import Rol, con_rol, contexto_base, es_htmx, validar

ESTADOS = [
    ("realizada", "Realizadas"),
    ("confirmada", "Confirmadas"),
    ("agendada", "Agendadas"),
    ("no_asistio", "No asistió"),
    ("cancelada", "Canceladas"),
]
ESPECIALIDADES = {
    "traumatologia": "Traumatología",
    "dermatologia": "Dermatología",
    "medicina_general": "Medicina general",
    "otra": "Otra especialidad",
}
ANTECEDENTES = [
    ("diabetes", "Diabetes"),
    ("hta", "Hipertensión arterial"),
    ("varices", "Várices"),
    ("ulcera_actual", "Úlcera actual"),
    ("amputaciones", "Amputaciones"),
]


def barras_semanales(semanas, alto=200) -> dict:
    """Geometría del gráfico de citas realizadas por semana (un SVG de una sola serie)."""
    maximo = max([1, *(s["realizadas"] for s in semanas)])
    ancho_barra, espacio, margen = 36, 14, 22
    barras = []
    for i, semana in enumerate(semanas):
        altura = round((alto - 2 * margen) * semana["realizadas"] / maximo, 1)
        x = espacio + i * (ancho_barra + espacio)
        barras.append(
            {
                **semana,
                "x": x,
                "centro": x + ancho_barra / 2,
                "y": alto - margen - altura,
                "altura": altura,
                "ancho": ancho_barra,
            }
        )
    return {
        "barras": barras,
        "alto": alto,
        "ancho": max(espacio + len(semanas) * (ancho_barra + espacio), 200),
        "base": alto - margen,
    }


def _rangos(hoy):
    inicio_mes = hoy.replace(day=1)
    fin_anterior = inicio_mes - timedelta(days=1)
    return [
        ("Este mes", inicio_mes, hoy),
        ("Mes anterior", fin_anterior.replace(day=1), fin_anterior),
        ("Últimos 30 días", hoy - timedelta(days=29), hoy),
    ]


@con_rol(Rol.PROFESIONAL, Rol.ADMIN)
def informes(request):
    datos, errores = validar(InformeConsultaSerializer, request.GET)
    if errores:
        datos, _ = validar(InformeConsultaSerializer, {})
    es_admin = request.user.rol == Rol.ADMIN
    todos = Profesional.objects.select_related("usuario").order_by(
        "usuario__apellido", "usuario__nombre"
    )
    if es_admin:
        profesionales = list(todos)
        alcance = "Toda la consulta"
        if "profesional" in datos:
            profesionales = [p for p in profesionales if p.pk == datos["profesional"]]
            if not profesionales:
                raise Http404
    else:
        profesionales = [request.user.profesional]
    if len(profesionales) == 1:
        alcance = (
            f"Profesional: {profesionales[0].usuario.nombre} {profesionales[0].usuario.apellido}"
        )
    informe = calcular_informe(
        profesionales=profesionales, desde=datos["desde"], hasta=datos["hasta"]
    )
    citas = informe["citas"]
    parametros = {"desde": datos["desde"].isoformat(), "hasta": datos["hasta"].isoformat()}
    if "profesional" in datos:
        parametros["profesional"] = str(datos["profesional"])
    contexto = contexto_base(
        "informes",
        informe=informe,
        alcance=alcance,
        errores=errores,
        es_admin=es_admin,
        lista_profesionales=todos if es_admin else [],
        profesional_elegido=str(datos.get("profesional", "")),
        desde=datos["desde"],
        hasta=datos["hasta"],
        rangos=_rangos(timezone.localdate()),
        url_pdf="/api/informes/pdf/?" + urlencode(parametros),
        estados=[(nombre, citas["por_estado"][k], citas["total"]) for k, nombre in ESTADOS],
        derivaciones=[
            (ESPECIALIDADES.get(k, k), n)
            for k, n in informe["derivaciones"]["por_especialidad"].items()
            if n
        ],
        antecedentes=[(nombre, informe["perfil_clinico"][k]) for k, nombre in ANTECEDENTES],
        grafico=barras_semanales(informe["por_semana"]),
    )
    if es_htmx(request):
        return render(request, "web/podologo/parciales/informe.html", contexto)
    return render(request, "web/podologo/informes.html", contexto)
