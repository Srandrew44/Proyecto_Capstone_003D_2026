"""Páginas del paciente: inicio, reserva, citas, ficha, consentimiento y perfil."""

from datetime import timedelta
from urllib.parse import urlencode

from django.conf import settings
from django.core.exceptions import ValidationError as DjangoValidationError
from django.http import Http404
from django.shortcuts import get_object_or_404, render
from django.urls import reverse
from django.utils import timezone

from apps.agenda import selectors as agenda
from apps.agenda import services as agenda_servicios
from apps.agenda.api.serializers import (
    CancelacionSerializer,
    ReagendamientoSerializer,
    ReservaSerializer,
)
from apps.agenda.models import Cita
from apps.auditoria.services import ip_de
from apps.clinica import selectors as clinica
from apps.clinica import services as clinica_servicios
from apps.clinica.models import Consentimiento
from apps.cuentas.api.serializers import PerfilPacienteSerializer
from apps.pagos import services as pagos
from apps.pagos.models import Pago

from .calendario import calendario
from .comun import (
    Rol,
    con_aviso,
    con_rol,
    contexto_base,
    destino_seguro,
    en_modal,
    errores_de,
    es_htmx,
    redirigir,
    validar,
)
from .ficha import contexto_ficha, ficha_completa
from .perfil import procesar as procesar_perfil

solo_paciente = con_rol(Rol.PACIENTE)
TRATAMIENTO_DATOS = Consentimiento.Tipo.TRATAMIENTO_DATOS
PENDIENTES = (Cita.Estado.AGENDADA, Cita.Estado.CONFIRMADA)


def _consentimiento_vigente(usuario):
    return (
        clinica.consentimientos_de(usuario)
        .filter(tipo=TRATAMIENTO_DATOS, revocado_en__isnull=True)
        .first()
    )


def _mi_ficha(usuario):
    return ficha_completa(clinica.fichas_visibles(usuario)).first()


@solo_paciente
def inicio(request):
    usuario = request.user
    ahora = timezone.now()
    ficha = _mi_ficha(usuario)
    vigentes = [a for a in ficha.atenciones.all() if a.vigente] if ficha else []
    contexto = contexto_base(
        "inicio",
        consentimiento=_consentimiento_vigente(usuario),
        proxima=agenda.citas_de(usuario)
        .filter(estado__in=PENDIENTES, inicio__gt=ahora)
        .order_by("inicio")
        .first(),
        ficha=ficha,
        atenciones_vigentes=len(vigentes),
        ultima=vigentes[0] if vigentes else None,
        revision=next((a for a in vigentes if a.proxima_revision), None),
        notificaciones=agenda.notificaciones_de(usuario)[:3],
    )
    if ficha:
        clinica_servicios.ver_ficha(ficha=ficha, usuario=usuario, ip=ip_de(request))
    return render(request, "web/paciente/inicio.html", contexto)


# --- reservar ---


@solo_paciente
def reservar(request):
    """Un solo flujo en tres pasos. Cada elección vuelve a pedir el bloque #flujo-reserva
    con htmx; la URL guarda las elecciones, así que recargar no las pierde."""
    if request.method == "POST":
        return _confirmar_reserva(request)
    # Solo los que tienen horario: con los demás no habría horas que elegir.
    profesionales = list(agenda.profesionales_para_reservar())
    tratamientos = list(agenda.tratamientos_activos())
    elegido_p = _buscar(profesionales, request.GET.get("profesional"))
    if elegido_p is None and len(profesionales) == 1:
        elegido_p = profesionales[0]
    elegido_t = _buscar(tratamientos, request.GET.get("tratamiento"))
    cal = None
    if elegido_p and elegido_t:
        cal = calendario(
            profesional=elegido_p,
            tratamiento=elegido_t,
            mes=request.GET.get("mes"),
            dia=request.GET.get("dia"),
            inicio=request.GET.get("inicio"),
        )
    contexto = contexto_base(
        "reservar",
        profesionales=profesionales,
        tratamientos=tratamientos,
        profesional=elegido_p,
        tratamiento=elegido_t,
        cal=cal,
        params=urlencode(
            {
                "profesional": elegido_p.pk if elegido_p else "",
                "tratamiento": elegido_t.pk if elegido_t else "",
            }
        ),
        consentimiento=_consentimiento_vigente(request.user),
        paga_en_linea=bool(elegido_t and pagos.requiere_pago(elegido_t)),
        errores={},
    )
    if es_htmx(request):
        return render(request, "web/paciente/parciales/flujo_reserva.html", contexto)
    return render(request, "web/paciente/reservar.html", contexto)


def _buscar(lista, pk):
    return next((x for x in lista if str(x.pk) == (pk or "")), None)


def _confirmar_reserva(request):
    datos, errores = validar(ReservaSerializer, request.POST)
    sin_consentimiento = False
    if not errores:
        try:
            cita = agenda_servicios.reservar_cita(
                paciente=request.user.paciente, ip=ip_de(request), **datos
            )
        except clinica_servicios.ConsentimientoRequerido:
            sin_consentimiento = True
            errores = {"general": ["Debes aceptar el consentimiento de datos para reservar."]}
        except DjangoValidationError as exc:
            errores = errores_de(exc)
        else:
            if cita.estado == Cita.Estado.PENDIENTE_PAGO:
                # La hora queda retenida; la página de pago envía al paciente a Webpay.
                return redirigir(request, reverse("web:pago-ir", args=[cita.pk]))
            return render(request, "web/paciente/parciales/reserva_lista.html", {"cita": cita})
    # Por ejemplo, otro paciente tomó la hora un momento antes.
    respuesta = render(
        request,
        "web/paciente/parciales/error_reserva.html",
        {
            "mensajes": [m for lista in errores.values() for m in lista],
            "sin_consentimiento": sin_consentimiento,
        },
    )
    respuesta["HX-Retarget"] = "#error-reserva"
    respuesta["HX-Reswap"] = "innerHTML"
    return respuesta


# --- mis citas ---


def _citas_contexto(usuario):
    ahora = timezone.now()
    # Una reserva cuyo plazo de pago venció ya no se muestra como pendiente.
    pagos.vencer_pendientes(ahora=ahora, paciente=usuario.paciente)
    citas = list(agenda.citas_de(usuario).order_by("inicio"))
    plazo = timedelta(hours=settings.AGENDA_CANCELACION_MIN_HORAS)
    proximas = [c for c in citas if c.inicio >= ahora and c.estado != Cita.Estado.CANCELADA]
    pasadas = [c for c in reversed(citas) if c not in proximas]
    for cita in proximas:
        cita.por_pagar = cita.estado == Cita.Estado.PENDIENTE_PAGO
        cita.modificable = cita.estado in PENDIENTES and cita.inicio - ahora >= plazo
        cita.pendiente = cita.estado in PENDIENTES
    return {"proximas": proximas, "pasadas": pasadas[:10], "pasadas_resto": pasadas[10:]}


@solo_paciente
def citas(request):
    contexto = contexto_base("citas", **_citas_contexto(request.user))
    return render(request, "web/paciente/citas.html", contexto)


def _mi_cita(request, pk):
    return get_object_or_404(
        agenda.citas_de(request.user).filter(paciente_id=request.user.pk), pk=pk
    )


def _citas_actualizadas(request, texto):
    contexto = contexto_base("citas", **_citas_contexto(request.user))
    respuesta = render(request, "web/paciente/parciales/listas_citas.html", contexto)
    return con_aviso(respuesta, texto, cerrar_modal=True)


@solo_paciente
def cancelar_cita(request, pk):
    cita = _mi_cita(request, pk)
    plantilla = "web/paciente/modales/cancelar.html"
    reembolso = (
        Pago.objects.filter(cita=cita, estado=Pago.Estado.AUTORIZADO)
        .values_list("monto", flat=True)
        .first()
    )
    if request.method == "GET":
        return render(request, plantilla, {"cita": cita, "errores": {}, "reembolso": reembolso})
    datos, errores = validar(CancelacionSerializer, request.POST)
    if not errores:
        try:
            agenda_servicios.cancelar_cita(
                cita=cita, usuario=request.user, ip=ip_de(request), **datos
            )
        except DjangoValidationError as exc:
            errores = errores_de(exc)
        else:
            return _citas_actualizadas(
                request, "Cita cancelada. Te enviamos un correo de confirmación."
            )
    return en_modal(request, plantilla, {"cita": cita, "errores": errores, "reembolso": reembolso})


@solo_paciente
def reagendar_cita(request, pk):
    cita = _mi_cita(request, pk)
    plantilla = "web/paciente/modales/reagendar.html"
    errores = {}
    if request.method == "POST":
        datos, errores = validar(ReagendamientoSerializer, request.POST)
        if not errores:
            try:
                agenda_servicios.reagendar_cita(
                    cita=cita, usuario=request.user, ip=ip_de(request), **datos
                )
            except DjangoValidationError as exc:
                errores = errores_de(exc)
            else:
                return _citas_actualizadas(request, "Listo: tu cita quedó en la nueva hora.")
    parametros = request.POST if request.method == "POST" else request.GET
    cal = calendario(
        profesional=cita.profesional,
        tratamiento=cita.tratamiento,
        mes=parametros.get("mes"),
        dia=parametros.get("dia"),
        inicio=parametros.get("inicio"),
        excluir=cita,
    )
    contexto = {
        "cita": cita,
        "cal": cal,
        "errores": errores,
        "url": reverse("web:paciente-reagendar", args=[cita.pk]),
        "params": "",
    }
    # Navegar por el calendario solo cambia el calendario; el resto del modal queda.
    if request.method == "GET" and request.headers.get("HX-Target") == "calendario-reagendar":
        return render(request, "web/paciente/modales/reagendar_calendario.html", contexto)
    if errores:
        return en_modal(request, plantilla, contexto)
    return render(request, plantilla, contexto)


# --- ficha, consentimiento y perfil ---


@solo_paciente
def ficha(request):
    ficha = _mi_ficha(request.user)
    contexto = contexto_base("ficha", ficha=None)
    if ficha:
        clinica_servicios.ver_ficha(ficha=ficha, usuario=request.user, ip=ip_de(request))
        contexto.update(contexto_ficha(ficha))
    return render(request, "web/paciente/ficha.html", contexto)


@solo_paciente
def consentimiento(request):
    if request.method == "POST":
        if request.POST.get("leido") != "si":
            contexto = contexto_base(
                "consentimiento",
                consentimiento=None,
                error="Marca la casilla para aceptar.",
                next=destino_seguro(request),
            )
            return render(request, "web/paciente/consentimiento.html", contexto, status=400)
        clinica_servicios.aceptar_consentimiento(
            paciente=request.user.paciente, tipo=TRATAMIENTO_DATOS, ip=ip_de(request)
        )
        # Recién registrado desde "Reservar con…": vuelve a esa reserva.
        return redirigir(
            request,
            destino_seguro(request) or reverse("web:paciente-consentimiento"),
            "Consentimiento aceptado. Ya puedes reservar.",
        )
    contexto = contexto_base(
        "consentimiento",
        consentimiento=_consentimiento_vigente(request.user),
        nuevo=bool(request.GET.get("nuevo")),
        next=destino_seguro(request),
    )
    return render(request, "web/paciente/consentimiento.html", contexto)


@solo_paciente
def revocar_consentimiento(request):
    vigente = _consentimiento_vigente(request.user)
    if vigente is None:
        raise Http404
    if request.method == "GET":
        return render(request, "web/paciente/modales/revocar.html", {"consentimiento": vigente})
    clinica_servicios.revocar_consentimiento(consentimiento=vigente, ip=ip_de(request))
    return redirigir(
        request, reverse("web:paciente-consentimiento"), "Consentimiento revocado.", "warning"
    )


@solo_paciente
def perfil(request):
    usuario = request.user
    paciente = usuario.paciente
    iniciales = {
        "telefono": usuario.telefono,
        "telefono_contacto": paciente.telefono_contacto,
        "direccion": paciente.direccion,
        "comuna": paciente.comuna,
        "actividad": paciente.actividad,
    }
    return procesar_perfil(
        request,
        plantilla="web/paciente/perfil.html",
        serializador=PerfilPacienteSerializer,
        iniciales=iniciales,
    )
