"""Piezas comunes de las vistas del sitio (Django + htmx).

Cada página la arma el servidor con los mismos servicios y selectores que usa la API, así que
aplica las mismas reglas de permisos y de negocio. Con htmx, una acción (cancelar una cita,
guardar una atención…) devuelve solo la parte de la página que cambia, y un aviso en la
cabecera HX-Trigger. Las validaciones reutilizan los serializadores de la API.
"""

import json
from functools import wraps

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import logout
from django.contrib.auth.views import redirect_to_login
from django.core.exceptions import ValidationError as DjangoValidationError
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.urls import reverse
from django.utils.dateparse import parse_date, parse_datetime
from django.utils.http import url_has_allowed_host_and_scheme

from apps.agenda.selectors import datos_consulta
from apps.cuentas.models import Usuario
from apps.cuentas.throttling import LimitePorIp

Rol = Usuario.Rol

INICIO_POR_ROL = {
    Rol.PACIENTE: "web:paciente-inicio",
    Rol.PROFESIONAL: "web:podologo-inicio",
    Rol.ADMIN: "web:informes",
}
PERFIL_POR_ROL = {Rol.PACIENTE: "paciente", Rol.PROFESIONAL: "profesional"}


def es_htmx(request) -> bool:
    return request.headers.get("HX-Request") == "true"


def inicio_de(usuario) -> str:
    return INICIO_POR_ROL.get(usuario.rol, "web:portada")


CUENTA_INCOMPLETA = (
    "Tu cuenta no está completa y no puede usarse todavía. Contacta a la consulta para que la "
    "terminen de configurar."
)


def falta_perfil(usuario) -> bool:
    """Un paciente o profesional sin su ficha de Paciente/Profesional (creado a medias)."""
    perfil = PERFIL_POR_ROL.get(usuario.rol)
    return bool(perfil) and not hasattr(usuario, perfil)


def cuenta_incompleta(request):
    """Cierra la sesión y vuelve a entrar con un aviso.

    Redirigir a su inicio no sirve: el inicio de su rol también exige el perfil y devolvería
    al mismo lugar, en un bucle sin fin. Sin sesión no hay bucle y el aviso explica qué pasa.
    """
    logout(request)
    return redirigir(request, reverse("web:entrar"), CUENTA_INCOMPLETA, "warning")


def con_rol(*roles):
    """Exige sesión y uno de los roles. Sin sesión manda a entrar (y vuelve después); con otro
    rol, a su propio inicio. Un paciente o profesional sin su perfil no entra a ninguna página:
    se le cierra la sesión con un aviso (ver ``cuenta_incompleta``)."""

    def decorador(vista):
        @wraps(vista)
        def envoltura(request, *args, **kwargs):
            usuario = request.user
            if not usuario.is_authenticated:
                if es_htmx(request):
                    # La sesión venció a mitad de la página: htmx redirige la página entera.
                    respuesta = HttpResponse(status=204)
                    respuesta["HX-Redirect"] = reverse("web:entrar")
                    return respuesta
                return redirect_to_login(request.get_full_path())
            if falta_perfil(usuario):
                return cuenta_incompleta(request)
            if usuario.rol not in roles:
                return redirect(inicio_de(usuario))
            return vista(request, *args, **kwargs)

        return envoltura

    return decorador


def contexto_base(seccion="", **extra) -> dict:
    return {
        "seccion": seccion,
        "consulta": datos_consulta(),
        "cancelacion_min_horas": settings.AGENDA_CANCELACION_MIN_HORAS,
        **extra,
    }


# --- validación ---


def validar(serializador, datos, **opciones):
    """Valida con un serializador de la API. Devuelve (datos_validos, errores).

    Los saltos de línea de un formulario llegan como \\r\\n; se guardan como \\n, igual que
    los que llegan por la API.
    """
    if hasattr(datos, "getlist"):
        datos = datos.copy()
        for campo in datos:
            datos.setlist(campo, [v.replace("\r\n", "\n") for v in datos.getlist(campo)])
    instancia = serializador(data=datos, **opciones)
    if instancia.is_valid():
        return instancia.validated_data, {}
    errores = instancia.errors
    if isinstance(errores, list):  # many=True: una lista con los errores de cada elemento
        errores = {"general": [m for item in errores for lista in item.values() for m in lista]}
    return None, _aplanar(errores)


def errores_de(exc: DjangoValidationError) -> dict:
    """Errores de un servicio, con la misma forma que los de un serializador."""
    if hasattr(exc, "error_dict"):
        return {campo: list(mensajes) for campo, mensajes in exc.message_dict.items()}
    return {"general": exc.messages}


def _aplanar(errores) -> dict:
    resultado = {}
    for campo, mensajes in errores.items():
        campo = "general" if campo in ("non_field_errors", "__all__") else campo
        if isinstance(mensajes, dict):  # una lista anidada (p. ej. las marcas del dibujo)
            mensajes = [m for lista in mensajes.values() for m in lista]
        elif mensajes and isinstance(mensajes[0], dict):
            mensajes = [m for item in mensajes for lista in item.values() for m in lista]
        resultado.setdefault(campo, []).extend(str(m) for m in mensajes)
    return resultado


def fecha_de(texto):
    """Fecha de un parámetro de la URL, o None si falta, tiene otro formato o no existe.

    parse_date da None con un formato inválido, pero lanza ValueError con uno válido que no
    es una fecha real (2030-02-30, 2030-13-01): eso era un error 500. Ambos casos se tratan
    igual, como si el parámetro no viniera.
    """
    try:
        return parse_date(texto) if texto else None
    except ValueError:
        return None


def fecha_hora_de(texto):
    """Como ``fecha_de``, para fecha y hora (también rechaza horas o zonas imposibles)."""
    try:
        return parse_datetime(texto) if texto else None
    except ValueError:
        return None


def leer_json(request, campo) -> list:
    """Lee un campo oculto con JSON (las marcas del dibujo de los pies)."""
    try:
        valor = json.loads(request.POST.get(campo) or "[]")
    except ValueError:
        return []
    return valor if isinstance(valor, list) else []


# --- respuestas ---


def con_aviso(respuesta, texto, tipo="success", cerrar_modal=False):
    """Agrega un aviso (toast) a una respuesta de htmx."""
    eventos = {"aviso": {"texto": texto, "tipo": tipo}}
    if cerrar_modal:
        eventos["cerrarModal"] = True
    respuesta["HX-Trigger"] = json.dumps(eventos)
    return respuesta


def ruta_segura(request, url: str) -> str:
    """`url` solo si es una ruta de este mismo sitio (nunca una redirección abierta)."""
    if url and url_has_allowed_host_and_scheme(
        url, allowed_hosts={request.get_host()}, require_https=request.is_secure()
    ):
        return url
    return ""


def destino_seguro(request) -> str:
    """El `next` pedido en el formulario o en la dirección, si es una ruta de este sitio."""
    return ruta_segura(request, request.POST.get("next") or request.GET.get("next") or "")


def redirigir(request, destino, texto=None, tipo="success"):
    """Redirección que funciona con y sin htmx; el aviso se muestra en la página nueva."""
    if texto:
        nivel = {"success": messages.SUCCESS, "warning": messages.WARNING}.get(tipo, messages.INFO)
        messages.add_message(request, nivel, texto)
    if es_htmx(request):
        respuesta = HttpResponse(status=204)
        respuesta["HX-Redirect"] = destino
        return respuesta
    return redirect(destino)


def en_modal(request, plantilla, contexto):
    """Vuelve a mostrar el formulario del modal (con sus errores) en el mismo modal."""
    respuesta = render(request, plantilla, contexto)
    respuesta["HX-Retarget"] = "#modal-contenido"
    respuesta["HX-Reswap"] = "innerHTML"
    return respuesta


# --- límite de registros (el mismo de la API) ---


class _VistaRegistro:
    throttle_scope = "registro"


def registro_permitido(request) -> bool:
    return LimitePorIp().allow_request(request, _VistaRegistro())


class _VistaRecuperar:
    throttle_scope = "recuperar"


def recuperacion_permitida(request) -> bool:
    return LimitePorIp().allow_request(request, _VistaRecuperar())
