"""Portada, entrar, registrarse y salir."""

import time
from urllib.parse import urlencode

from django.conf import settings
from django.core.exceptions import ValidationError as DjangoValidationError
from django.shortcuts import redirect, render
from django.urls import reverse
from django.views.decorators.http import require_POST

from apps.agenda import selectors as agenda
from apps.auditoria.services import ip_de
from apps.cuentas import services
from apps.cuentas.api.serializers import LoginSerializer, RegistroPacienteSerializer
from apps.cuentas.models import Usuario

from .comun import (
    contexto_base,
    destino_seguro,
    errores_de,
    inicio_de,
    recuperacion_permitida,
    redirigir,
    registro_permitido,
    ruta_segura,
    validar,
)

CARACTERISTICAS = [
    (
        "calendario",
        "Reserva en línea",
        "Ves solo los horarios realmente libres de cada podólogo y reservas en segundos.",
    ),
    (
        "campana",
        "Recordatorios",
        "Recibes la confirmación por correo y un recordatorio antes de tu cita.",
    ),
    (
        "ficha",
        "Tu ficha, siempre a mano",
        "Revisa tus atenciones, indicaciones y derivaciones desde tu cuenta.",
    ),
    (
        "escudo",
        "Datos protegidos",
        "Solo tu podólogo accede a tu ficha y cada acceso queda registrado.",
    ),
]
RAZONES = [
    ("estetoscopio", "Podólogos titulados", "Atención clínica con ficha podológica completa."),
    (
        "pie",
        "Pie diabético y crónico",
        "Seguimiento de cada atención y derivación cuando hace falta.",
    ),
    ("reloj", "Puntualidad", "Agenda en línea con horarios reales y pausa entre pacientes."),
]
PASOS = [
    ("Crea tu cuenta", "Con tus datos de contacto y el consentimiento de datos."),
    ("Elige podólogo y hora", "Ves solo los horarios libres de los próximos 30 días."),
    ("Recibe tu confirmación", "Te llega por correo, y un recordatorio antes de la cita."),
]


def portada(request):
    """Página pública. Solo muestra datos de presentación de la consulta, nunca de pacientes."""
    contexto = contexto_base(
        caracteristicas=CARACTERISTICAS,
        razones=RAZONES,
        pasos=PASOS,
        tratamientos=agenda.tratamientos_activos()[:6],
        profesionales=agenda.profesionales_activos()[:4],
    )
    return render(request, "web/portada.html", contexto)


def mi_inicio(request):
    """Lleva a cada usuario a su panel (o a entrar, si no tiene sesión)."""
    if not request.user.is_authenticated:
        return redirect("web:entrar")
    return redirect(inicio_de(request.user))


def entrar(request):
    """GET: formulario de entrar o de registro (?modo=registro). POST: cualquiera de los dos."""
    if request.user.is_authenticated:
        return redirect(inicio_de(request.user))
    modo = request.POST.get("accion") or request.GET.get("modo") or "entrar"
    modo = "registro" if modo == "registro" else "entrar"
    contexto = contexto_base(modo=modo, errores={}, valores={}, next=destino_seguro(request))
    if request.method == "POST":
        resultado = _registrar(request) if modo == "registro" else _entrar(request)
        if not isinstance(resultado, dict):
            return resultado
        contexto.update(errores=resultado, valores=request.POST)
        return render(request, "web/entrar.html", contexto, status=400)
    return render(request, "web/entrar.html", contexto)


def _entrar(request):
    datos, errores = validar(LoginSerializer, request.POST)
    if errores:
        return {"general": ["Escribe tu correo y tu contraseña."]}
    try:
        usuario = services.iniciar_sesion(request, **datos)
    except services.AutenticacionFallida:
        # Mensaje único: no revela si el correo existe ni si la cuenta está inactiva.
        return {"general": ["Correo o contraseña incorrectos."]}
    except services.DemasiadosIntentos:
        return {"general": ["Demasiados intentos fallidos. Espera 15 minutos y vuelve a intentar."]}
    except services.FaltaSegundoPaso as falta:
        # La contraseña es correcta, pero la sesión no se abre hasta escribir el código.
        request.session[SEGUNDO_PASO] = {
            "usuario": str(falta.usuario.pk),
            "desde": time.time(),
            "next": destino_seguro(request),
            "intentos": 0,
        }
        return redirect("web:entrar-codigo")
    return redirect(destino_seguro(request) or inicio_de(usuario))


# Segundo paso del login: cuánto dura la espera del código y cuántos intentos se permiten en
# ella (aparte, cada fallo cuenta para el freno de 5 por cuenta de bloqueo.py).
SEGUNDO_PASO = "dos_pasos_pendiente"
VIGENCIA_SEGUNDO_PASO = 300
MAX_INTENTOS_CODIGO = 5
AVISO_REPETIR = "Vuelve a escribir tu correo y tu contraseña."


def entrar_codigo(request):
    """Pide el código de la app (o de respaldo) a quien ya puso bien su contraseña."""
    if request.user.is_authenticated:
        return redirect(inicio_de(request.user))
    pendiente = request.session.get(SEGUNDO_PASO)
    usuario = None
    if pendiente and time.time() - pendiente["desde"] < VIGENCIA_SEGUNDO_PASO:
        usuario = Usuario.objects.filter(pk=pendiente["usuario"], is_active=True).first()
    if usuario is None:
        request.session.pop(SEGUNDO_PASO, None)
        return redirigir(request, reverse("web:entrar"), AVISO_REPETIR, "info")
    errores = {}
    if request.method == "POST":
        try:
            services.completar_segundo_paso(
                request, usuario=usuario, codigo=request.POST.get("codigo", "")
            )
        except services.DemasiadosIntentos:
            request.session.pop(SEGUNDO_PASO, None)
            return redirigir(
                request,
                reverse("web:entrar"),
                "Demasiados intentos fallidos. Espera 15 minutos y vuelve a intentar.",
                "warning",
            )
        except services.AutenticacionFallida:
            pendiente["intentos"] += 1
            if pendiente["intentos"] >= MAX_INTENTOS_CODIGO:
                request.session.pop(SEGUNDO_PASO, None)
                return redirigir(request, reverse("web:entrar"), AVISO_REPETIR, "warning")
            request.session[SEGUNDO_PASO] = pendiente
            errores = {"codigo": ["El código no es correcto o ya cambió. Prueba con el actual."]}
        else:
            request.session.pop(SEGUNDO_PASO, None)
            return redirect(ruta_segura(request, pendiente["next"]) or inicio_de(usuario))
    contexto = contexto_base(errores=errores)
    return render(request, "web/cuentas/codigo.html", contexto, status=400 if errores else 200)


def _registrar(request):
    if not registro_permitido(request):
        return {
            "general": ["Se hicieron demasiados registros desde esta conexión. Intenta más tarde."]
        }
    datos, errores = validar(RegistroPacienteSerializer, request.POST)
    if errores:
        return errores
    try:
        services.solicitar_registro(
            **datos, sitio=services.sitio_de(request), siguiente=destino_seguro(request)
        )
    except DjangoValidationError as exc:
        return errores_de(exc)
    # Siempre la misma respuesta: no revela si el correo o el RUT ya estaban registrados.
    return _aviso(
        request,
        "Revisa tu correo",
        f"Te enviamos un correo a {datos['email']} para terminar. Abre el enlace en las "
        f"próximas {settings.REGISTRO_VIGENCIA_HORAS} horas. Si no lo ves, revisa la carpeta "
        "de spam.",
    )


def _aviso(request, titulo, mensaje, *, status=200):
    contexto = contexto_base(titulo=titulo, mensaje=mensaje)
    return render(request, "web/cuentas/aviso.html", contexto, status=status)


def confirmar_registro(request, token):
    """GET: botón para activar (los antivirus de correo abren los enlaces, y no deben crear la
    cuenta por su cuenta). POST: crea la cuenta, abre la sesión y sigue al consentimiento."""
    if request.method == "POST":
        try:
            _, siguiente = services.confirmar_registro(request, token=token)
        except services.RegistroInvalido as exc:
            return _aviso(request, "No pudimos crear tu cuenta", str(exc), status=400)
        # El consentimiento va primero; si venía de una página (p. ej. reservar con un
        # podólogo elegido), se la pasa para volver a ella al aceptarlo.
        parametros = {"nuevo": 1}
        if siguiente := ruta_segura(request, siguiente):
            parametros["next"] = siguiente
        return redirect(f"{reverse('web:paciente-consentimiento')}?{urlencode(parametros)}")
    pendiente = services.registro_pendiente(token)
    if pendiente is None:
        return _aviso(
            request,
            "El enlace ya no sirve",
            "El enlace no es válido o ya venció. Vuelve a registrarte para recibir uno nuevo.",
            status=400,
        )
    contexto = contexto_base(email=pendiente.email, nombre=pendiente.datos.get("nombre", ""))
    return render(request, "web/cuentas/confirmar_registro.html", contexto)


def recuperar(request):
    """Pide el correo y manda el enlace. Responde igual exista o no la cuenta."""
    if request.method == "POST":
        if not recuperacion_permitida(request):
            return _aviso(
                request,
                "Demasiadas solicitudes",
                "Se pidieron demasiados enlaces desde esta conexión. Intenta más tarde.",
                status=429,
            )
        services.solicitar_recuperacion(
            email=request.POST.get("email", ""), sitio=services.sitio_de(request)
        )
        return _aviso(
            request,
            "Revisa tu correo",
            "Si el correo tiene una cuenta en MyPodo, te enviamos un enlace para crear una "
            f"contraseña nueva. Vence en {settings.PASSWORD_RESET_TIMEOUT // 60} minutos.",
        )
    return render(request, "web/cuentas/recuperar.html", contexto_base(errores={}))


def recuperar_confirmar(request, uidb64, token):
    usuario = services.usuario_para_recuperar(uidb64, token)
    if usuario is None:
        return _aviso(
            request,
            "El enlace ya no sirve",
            "El enlace no es válido, ya se usó o venció. Pide uno nuevo.",
            status=400,
        )
    errores = {}
    if request.method == "POST":
        nueva = request.POST.get("nueva", "")
        if nueva != request.POST.get("repetir", ""):
            errores = {"repetir": ["Las dos contraseñas no coinciden."]}
        else:
            try:
                services.restablecer_clave(
                    usuario=usuario,
                    nueva=nueva,
                    sitio=services.sitio_de(request),
                    ip=ip_de(request),
                )
            except DjangoValidationError as exc:
                errores = errores_de(exc)
            else:
                return redirigir(
                    request,
                    reverse("web:entrar"),
                    "Listo: tu contraseña cambió. Ya puedes iniciar sesión.",
                )
    contexto = contexto_base(errores=errores, email=usuario.email)
    return render(request, "web/cuentas/nueva_clave.html", contexto, status=400 if errores else 200)


def privacidad(request):
    return render(request, "web/privacidad.html", contexto_base())


@require_POST
def salir(request):
    services.cerrar_sesion(request)
    return redirigir(request, reverse("web:entrar"), "Cerraste tu sesión.", "info")
