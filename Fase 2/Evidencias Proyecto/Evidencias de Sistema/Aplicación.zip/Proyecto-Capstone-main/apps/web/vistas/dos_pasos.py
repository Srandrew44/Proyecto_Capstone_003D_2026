"""Verificación en dos pasos opcional desde "Mi perfil" (pacientes y podólogos).

Activar: QR para la app y un código para confirmarla; se entregan 10 códigos de respaldo que
se muestran una sola vez. Desactivar y generar códigos nuevos piden la contraseña.
"""

from django.core.exceptions import ValidationError as DjangoValidationError
from django.shortcuts import render
from django.urls import reverse
from django.utils.safestring import mark_safe
from django.views.decorators.http import require_POST

from apps.auditoria.services import ip_de
from apps.cuentas import dos_pasos
from apps.cuentas.services import sitio_de

from .comun import Rol, con_rol, contexto_base, errores_de, redirigir

con_cuenta = con_rol(Rol.PACIENTE, Rol.PROFESIONAL)
PERFIL_POR_ROL = {Rol.PACIENTE: "web:paciente-perfil", Rol.PROFESIONAL: "web:podologo-perfil"}


def _perfil(usuario) -> str:
    return reverse(PERFIL_POR_ROL[usuario.rol]) + "#dos-pasos"


def _codigos(request, codigos, *, nuevos=False):
    contexto = contexto_base("perfil", codigos=codigos, nuevos=nuevos, volver=_perfil(request.user))
    return render(request, "web/cuentas/dos_pasos_codigos.html", contexto)


@con_cuenta
def activar(request):
    usuario = request.user
    if dos_pasos.activa(usuario):
        return redirigir(request, _perfil(usuario), "La verificación en dos pasos ya está activa.")
    errores = {}
    if request.method == "POST":
        try:
            codigos = dos_pasos.confirmar(
                usuario,
                codigo=request.POST.get("codigo", ""),
                sitio=sitio_de(request),
                ip=ip_de(request),
            )
        except DjangoValidationError as exc:
            errores = errores_de(exc)
        else:
            return _codigos(request, codigos)
    disp = dos_pasos.preparar(usuario)
    contexto = contexto_base(
        "perfil",
        qr=mark_safe(dos_pasos.qr_svg(disp)),  # noqa: S308 (SVG generado aquí, sin datos del usuario)
        clave=dos_pasos.clave_texto(disp),
        errores=errores,
        volver=_perfil(usuario),
    )
    return render(
        request, "web/cuentas/dos_pasos_activar.html", contexto, status=400 if errores else 200
    )


@con_cuenta
@require_POST
def desactivar(request):
    usuario = request.user
    try:
        dos_pasos.desactivar(
            usuario, clave=request.POST.get("clave", ""), sitio=sitio_de(request), ip=ip_de(request)
        )
    except DjangoValidationError:
        return redirigir(
            request, _perfil(usuario), "La contraseña no es correcta: no se desactivó.", "warning"
        )
    return redirigir(request, _perfil(usuario), "Desactivaste la verificación en dos pasos.")


@con_cuenta
@require_POST
def codigos(request):
    usuario = request.user
    try:
        nuevos = dos_pasos.regenerar_codigos(usuario, clave=request.POST.get("clave", ""))
    except DjangoValidationError:
        return redirigir(
            request,
            _perfil(usuario),
            "La contraseña no es correcta: tus códigos siguen siendo los mismos.",
            "warning",
        )
    return _codigos(request, nuevos, nuevos=True)
