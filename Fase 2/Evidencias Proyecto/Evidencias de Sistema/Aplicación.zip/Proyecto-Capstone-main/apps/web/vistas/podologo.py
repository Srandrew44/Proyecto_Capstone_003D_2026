"""Páginas del podólogo: inicio, agenda, pacientes, ficha, horario, tratamientos y perfil."""

import json
from datetime import timedelta

from django.core.exceptions import PermissionDenied
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db.models import Q
from django.http import Http404
from django.shortcuts import get_object_or_404, render
from django.urls import reverse
from django.utils import timezone

from apps.agenda import selectors as agenda
from apps.agenda import services as agenda_servicios
from apps.agenda.api.serializers import (
    BloqueoSerializer,
    CancelacionSerializer,
    DisponibilidadSerializer,
)
from apps.agenda.models import Cita, Disponibilidad
from apps.auditoria.services import ip_de
from apps.clinica import selectors as clinica
from apps.clinica import services as clinica_servicios
from apps.clinica.api.serializers import (
    AtencionCreacionSerializer,
    CorreccionSerializer,
    DerivacionCreacionSerializer,
    FichaEdicionSerializer,
    MarcaSerializer,
)
from apps.clinica.informes import calcular_informe
from apps.cuentas.api.serializers import PerfilProfesionalSerializer

from .comun import (
    Rol,
    con_aviso,
    con_rol,
    contexto_base,
    en_modal,
    errores_de,
    es_htmx,
    fecha_de,
    leer_json,
    redirigir,
    validar,
)
from .ficha import (
    CAMPOS_ATENCION,
    ESPECIALIDADES,
    PULSOS,
    SI_NO,
    TEXTOS,
    contexto_ficha,
    ficha_completa,
)
from .informes import barras_semanales
from .perfil import procesar as procesar_perfil
from .profesionales import contexto_perfil_profesional

solo_profesional = con_rol(Rol.PROFESIONAL)
PENDIENTES = (Cita.Estado.AGENDADA, Cita.Estado.CONFIRMADA)
SIN_CONSENTIMIENTO = (
    "El paciente no tiene vigente el consentimiento de datos: no se puede registrar en su ficha "
    "hasta que lo acepte."
)


# --- inicio ---


@solo_profesional
def inicio(request):
    hoy = timezone.localdate()
    citas = list(agenda.agenda_del_dia(request.user, hoy))
    vigentes = [c for c in citas if c.estado != Cita.Estado.CANCELADA]
    informe = calcular_informe(
        profesionales=[request.user.profesional], desde=hoy.replace(day=1), hasta=hoy
    )
    contexto = contexto_base(
        "inicio",
        citas_hoy=vigentes,
        proxima=_proxima(vigentes),
        realizadas_hoy=sum(c.estado == Cita.Estado.REALIZADA for c in citas),
        informe=informe,
        mas_pedido=informe["tratamientos"][0]["tratamiento"] if informe["tratamientos"] else None,
        barras=barras_semanales(informe["por_semana"], alto=140),
        sin_horario=not agenda.tiene_horario(request.user.profesional),
    )
    return render(request, "web/podologo/inicio.html", contexto)


def _proxima(citas):
    ahora = timezone.now()
    return next((c for c in citas if c.estado in PENDIENTES and c.fin > ahora), None)


# --- agenda del día ---


def _agenda_contexto(usuario, fecha):
    ahora = timezone.now()
    citas = list(agenda.agenda_del_dia(usuario, fecha).select_related("atencion"))
    vigentes = [c for c in citas if c.estado != Cita.Estado.CANCELADA]
    proxima = _proxima(citas)
    for cita in citas:
        cita.pendiente = cita.estado in PENDIENTES and not hasattr(cita, "atencion")
        cita.comenzo = cita.inicio <= ahora
        cita.es_proxima = cita == proxima
    bloqueos = [
        b
        for b in agenda.bloqueos_de(usuario)
        if timezone.localdate(b.inicio) <= fecha <= timezone.localdate(b.fin)
    ]
    elementos = sorted(
        [{"inicio": c.inicio, "cita": c} for c in citas]
        + [{"inicio": b.inicio, "bloqueo": b} for b in bloqueos],
        key=lambda e: e["inicio"],
    )
    return contexto_base(
        "agenda",
        fecha=fecha,
        anterior=fecha - timedelta(days=1),
        siguiente=fecha + timedelta(days=1),
        hoy=timezone.localdate(),
        elementos=elementos,
        total=len(vigentes),
        realizadas=sum(c.estado == Cita.Estado.REALIZADA for c in citas),
        pendientes=sum(c.estado in PENDIENTES for c in citas),
        ingresos=sum(c.precio for c in vigentes),
    )


@solo_profesional
def agenda_dia(request):
    fecha = fecha_de(request.GET.get("fecha")) or timezone.localdate()
    contexto = _agenda_contexto(request.user, fecha)
    if es_htmx(request):
        return render(request, "web/podologo/parciales/agenda_dia.html", contexto)
    return render(request, "web/podologo/agenda.html", contexto)


def _cita_propia(request, pk):
    return get_object_or_404(
        Cita.objects.select_related("paciente__usuario"), pk=pk, profesional_id=request.user.pk
    )


def _agenda_actualizada(request, cita, texto, tipo="success"):
    contexto = _agenda_contexto(request.user, timezone.localdate(cita.inicio))
    respuesta = render(request, "web/podologo/parciales/agenda_dia.html", contexto)
    return con_aviso(respuesta, texto, tipo, cerrar_modal=True)


@solo_profesional
def inasistencia(request, pk):
    cita = _cita_propia(request, pk)
    plantilla = "web/podologo/modales/inasistencia.html"
    if request.method == "GET":
        return render(request, plantilla, {"cita": cita, "errores": {}})
    try:
        agenda_servicios.marcar_inasistencia(cita=cita, usuario=request.user, ip=ip_de(request))
    except DjangoValidationError as exc:
        return en_modal(request, plantilla, {"cita": cita, "errores": errores_de(exc)})
    return _agenda_actualizada(request, cita, "Inasistencia registrada.", "warning")


@solo_profesional
def cancelar_cita(request, pk):
    cita = _cita_propia(request, pk)
    plantilla = "web/podologo/modales/cancelar.html"
    if request.method == "GET":
        return render(request, plantilla, {"cita": cita, "errores": {}})
    datos, errores = validar(CancelacionSerializer, request.POST)
    if not errores:
        try:
            agenda_servicios.cancelar_cita(
                cita=cita, usuario=request.user, ip=ip_de(request), **datos
            )
        except DjangoValidationError as exc:
            errores = errores_de(exc)
        else:
            return _agenda_actualizada(request, cita, "Cita cancelada y paciente avisado.")
    return en_modal(request, plantilla, {"cita": cita, "errores": errores})


# --- pacientes ---


@solo_profesional
def pacientes(request):
    texto = request.GET.get("q", "").strip()
    todos = clinica.pacientes_de(request.user).select_related("ficha")
    lista = todos
    for palabra in texto.split()[:4]:
        lista = lista.filter(
            Q(usuario__nombre__icontains=palabra) | Q(usuario__apellido__icontains=palabra)
        )
    lista = lista.order_by("usuario__apellido", "usuario__nombre")
    contexto = contexto_base("pacientes", pacientes=lista, total=todos.count(), q=texto)
    if es_htmx(request):
        return render(request, "web/podologo/parciales/pacientes_filas.html", contexto)
    return render(request, "web/podologo/pacientes.html", contexto)


# --- ficha del paciente ---


def _paciente_propio(request, pk):
    """Paciente con cita no cancelada con este profesional. Lo ajeno es 404 y queda auditado."""
    paciente = clinica.pacientes_de(request.user).filter(pk=pk).first()
    if paciente is None:
        clinica_servicios.registrar_acceso_denegado(
            usuario=request.user, recurso_tipo="paciente", recurso_id=pk, ip=ip_de(request)
        )
        raise Http404
    return paciente


def _ficha_de(request, paciente):
    return ficha_completa(clinica.fichas_visibles(request.user).filter(paciente=paciente)).first()


def _citas_atendibles(request, paciente):
    """Citas de este paciente con el profesional que ya comenzaron y aún no tienen atención."""
    return list(
        Cita.objects.filter(
            profesional_id=request.user.pk,
            paciente=paciente,
            estado__in=PENDIENTES,
            inicio__lte=timezone.now(),
            atencion__isnull=True,
        )
        .select_related("tratamiento")
        .order_by("-inicio")
    )


def _base_del_dibujo(marcas) -> str:
    """Ids de las marcas con que parte el formulario (campo oculto `dibujo_base`).

    Al guardar, el servicio compara el dibujo enviado con este punto de partida, así no se
    pierde lo que otro podólogo haya cambiado mientras tanto.
    """
    return json.dumps([str(marca.pk) for marca in marcas])


def _contexto_ficha_podologo(request, paciente, ficha, **extra):
    citas = _citas_atendibles(request, paciente)
    pedida = request.GET.get("cita") or request.POST.get("cita") or ""
    datos_ficha = contexto_ficha(ficha)
    contexto = contexto_base(
        "pacientes",
        **datos_ficha,
        citas=citas,
        cita_elegida=pedida
        if any(str(c.pk) == pedida for c in citas)
        else (str(citas[0].pk) if len(citas) == 1 else ""),
        campos_atencion=CAMPOS_ATENCION,
        valores={},
        # El formulario parte con el dibujo vigente de la ficha.
        marcas_actuales=datos_ficha["marcas_vigentes"],
        dibujo_base=_base_del_dibujo(datos_ficha["marcas_vigentes"]),
        errores={},
        siguiente_numero=sum(1 for a in ficha.atenciones.all() if a.corrige_id is None) + 1,
    )
    contexto.update(extra)
    return contexto


def _form_antecedentes(ficha=None, valores=None):
    """Campos del formulario de antecedentes, con el valor actual de cada uno."""

    def valor(campo):
        if valores is not None:
            return valores.get(campo, "")
        actual = getattr(ficha, campo, None) if ficha else None
        if actual is True:
            return "true"
        if actual is False:
            return "false"
        return actual or ""

    return {
        "si_no": [(campo, etiqueta, valor(campo)) for campo, etiqueta in SI_NO],
        "pulsos": [(campo, etiqueta, valor(campo)) for campo, etiqueta in PULSOS],
        "textos": [
            (campo, etiqueta, ayuda, corto, valor(campo))
            for campo, etiqueta, ayuda, corto in TEXTOS
        ],
    }


@solo_profesional
def ficha(request, paciente):
    paciente = _paciente_propio(request, paciente)
    if request.method == "POST":
        return _crear_ficha(request, paciente)
    ficha = _ficha_de(request, paciente)
    if ficha is None:
        contexto = contexto_base(
            "pacientes", paciente=paciente, form=_form_antecedentes(), errores={}
        )
        return render(request, "web/podologo/ficha_nueva.html", contexto)
    clinica_servicios.ver_ficha(ficha=ficha, usuario=request.user, ip=ip_de(request))
    return render(
        request, "web/podologo/ficha.html", _contexto_ficha_podologo(request, paciente, ficha)
    )


def _crear_ficha(request, paciente):
    datos, errores = validar(FichaEdicionSerializer, request.POST)
    if not errores:
        try:
            clinica_servicios.crear_ficha(
                profesional=request.user.profesional, paciente=paciente, ip=ip_de(request), **datos
            )
        except clinica_servicios.ConsentimientoRequerido:
            errores = {"general": [SIN_CONSENTIMIENTO]}
        except DjangoValidationError as exc:
            errores = errores_de(exc)
        else:
            destino = reverse("web:podologo-ficha", args=[paciente.pk])
            return redirigir(request, destino, "Ficha creada.")
    contexto = contexto_base(
        "pacientes",
        paciente=paciente,
        form=_form_antecedentes(valores=request.POST),
        errores=errores,
    )
    return render(request, "web/podologo/ficha_nueva.html", contexto, status=400)


def _contenido_actualizado(request, paciente, texto):
    """Vuelve a dibujar la ficha (sin otra auditoría de lectura: la acción ya quedó auditada)."""
    ficha = _ficha_de(request, paciente)
    contexto = _contexto_ficha_podologo(request, paciente, ficha)
    respuesta = render(request, "web/podologo/parciales/ficha_contenido.html", contexto)
    respuesta["HX-Retarget"] = "#ficha-contenido"
    respuesta["HX-Reswap"] = "innerHTML"
    return con_aviso(respuesta, texto, cerrar_modal=True)


@solo_profesional
def antecedentes(request, paciente):
    paciente = _paciente_propio(request, paciente)
    ficha = _ficha_de(request, paciente)
    if ficha is None:
        raise Http404
    plantilla = "web/podologo/modales/antecedentes.html"
    if request.method == "GET":
        return render(
            request,
            plantilla,
            {"paciente": paciente, "form": _form_antecedentes(ficha), "errores": {}},
        )
    datos, errores = validar(FichaEdicionSerializer, request.POST, partial=True)
    if not errores:
        try:
            clinica_servicios.editar_ficha(
                ficha=ficha, profesional=request.user.profesional, ip=ip_de(request), **datos
            )
        except clinica_servicios.ConsentimientoRequerido:
            errores = {"general": [SIN_CONSENTIMIENTO]}
        except (DjangoValidationError, PermissionDenied) as exc:
            errores = (
                errores_de(exc)
                if isinstance(exc, DjangoValidationError)
                else {"general": [str(exc)]}
            )
        else:
            return _contenido_actualizado(request, paciente, "Antecedentes actualizados.")
    contexto = {
        "paciente": paciente,
        "form": _form_antecedentes(valores=request.POST),
        "errores": errores,
    }
    return en_modal(request, plantilla, contexto)


def _marcas(request):
    """El dibujo completo enviado, validado con el mismo serializador de la API.

    Sin el campo `marcas`, None: el dibujo no cambia (una lista vacía, en cambio, lo borra).
    """
    if "marcas" not in request.POST:
        return None, {}
    datos, errores = validar(MarcaSerializer, leer_json(request, "marcas"), many=True)
    return [dict(m) for m in (datos or [])], errores


def _base_enviada(request):
    """Ids de las marcas con que partió el formulario; None si no vino el campo."""
    if "dibujo_base" not in request.POST:
        return None
    return leer_json(request, "dibujo_base")


def _dibujo_enviado(request) -> dict:
    """Al volver a mostrar un formulario con errores: el dibujo como lo dejó el podólogo y el
    mismo punto de partida (no el dibujo vigente de ahora)."""
    contexto = {}
    if "marcas" in request.POST:
        contexto["marcas_actuales"] = leer_json(request, "marcas")
    if "dibujo_base" in request.POST:
        contexto["dibujo_base"] = json.dumps(leer_json(request, "dibujo_base"))
    return contexto


@solo_profesional
def nueva_atencion(request, paciente):
    paciente = _paciente_propio(request, paciente)
    ficha = _ficha_de(request, paciente)
    if ficha is None or request.method != "POST":
        raise Http404
    datos, errores = validar(AtencionCreacionSerializer, request.POST)
    marcas, errores_marcas = _marcas(request)
    errores = {
        **(errores or {}),
        **({"marcas": ["Hay una marca no válida en el dibujo."]} if errores_marcas else {}),
    }
    if not errores:
        datos = dict(datos)
        datos.pop("marcas", None)
        datos.pop("marcas_base", None)
        cita_id = datos.pop("cita", None)
        cita = None
        if cita_id is not None:
            cita = Cita.objects.filter(pk=cita_id, profesional_id=request.user.pk).first()
            if cita is None:
                errores = {"cita": ["Cita no encontrada."]}
        if not errores:
            try:
                clinica_servicios.registrar_atencion(
                    profesional=request.user.profesional,
                    paciente=paciente,
                    cita=cita,
                    marcas=marcas,
                    marcas_base=_base_enviada(request),
                    ip=ip_de(request),
                    **datos,
                )
            except clinica_servicios.ConsentimientoRequerido:
                errores = {"general": [SIN_CONSENTIMIENTO]}
            except (DjangoValidationError, PermissionDenied) as exc:
                errores = (
                    errores_de(exc)
                    if isinstance(exc, DjangoValidationError)
                    else {"general": [str(exc)]}
                )
            else:
                return _contenido_actualizado(request, paciente, "Atención registrada.")
    contexto = _contexto_ficha_podologo(
        request, paciente, ficha, valores=request.POST, errores=errores, **_dibujo_enviado(request)
    )
    respuesta = render(request, "web/podologo/parciales/form_atencion.html", contexto)
    respuesta["HX-Retarget"] = "#form-atencion"
    respuesta["HX-Reswap"] = "outerHTML"
    return respuesta


def _atencion_propia(request, pk):
    """Atención visible para el profesional; la ajena es 404 y queda auditada."""
    atencion = (
        clinica.atenciones_visibles(request.user)
        .select_related("ficha__paciente__usuario")
        .prefetch_related("ficha__marcas")
        .filter(pk=pk)
        .first()
    )
    if atencion is None:
        clinica_servicios.registrar_acceso_denegado(
            usuario=request.user, recurso_tipo="atencionclinica", recurso_id=pk, ip=ip_de(request)
        )
        raise Http404
    return atencion


@solo_profesional
def corregir(request, pk):
    atencion = _atencion_propia(request, pk)
    plantilla = "web/podologo/modales/corregir.html"
    numeros = clinica.numerar_atenciones(atencion.ficha.atenciones.all())
    # El dibujo es uno por paciente: la corrección parte del vigente de la ficha.
    vigentes = clinica.marcas_vigentes(atencion.ficha)
    contexto = {
        "a": atencion,
        "numero": numeros.get(atencion.pk),
        "campos_atencion": CAMPOS_ATENCION,
        "valores": {campo: getattr(atencion, campo) or "" for campo, _ in CAMPOS_ATENCION}
        | {
            "proxima_revision": atencion.proxima_revision.isoformat()
            if atencion.proxima_revision
            else ""
        },
        "marcas_actuales": vigentes,
        "dibujo_base": _base_del_dibujo(vigentes),
        "errores": {},
    }
    if request.method == "GET":
        return render(request, plantilla, contexto)

    # Solo viajan al servicio los campos que cambiaron: el resto se copia de la original. Del
    # dibujo viaja el completo y el servicio registra solo lo agregado y lo quitado.
    datos, errores = validar(CorreccionSerializer, request.POST)
    marcas, errores_marcas = _marcas(request)
    if errores_marcas:
        errores = {**(errores or {}), "marcas": ["Hay una marca no válida en el dibujo."]}
    if not errores:
        cambios = {
            campo: valor
            for campo, valor in datos.items()
            if campo not in ("motivo_correccion", "marcas", "marcas_base")
            and valor != getattr(atencion, campo)
        }
        try:
            clinica_servicios.corregir_atencion(
                atencion=atencion,
                profesional=request.user.profesional,
                motivo_correccion=datos["motivo_correccion"],
                marcas=marcas,
                marcas_base=_base_enviada(request),
                ip=ip_de(request),
                **cambios,
            )
        except clinica_servicios.ConsentimientoRequerido:
            errores = {"general": [SIN_CONSENTIMIENTO]}
        except (DjangoValidationError, PermissionDenied) as exc:
            errores = (
                errores_de(exc)
                if isinstance(exc, DjangoValidationError)
                else {"general": [str(exc)]}
            )
        else:
            return _contenido_actualizado(
                request, atencion.ficha.paciente, "Corrección registrada."
            )
    contexto.update(valores=request.POST, errores=errores, **_dibujo_enviado(request))
    return en_modal(request, plantilla, contexto)


@solo_profesional
def derivar(request, pk):
    atencion = _atencion_propia(request, pk)
    plantilla = "web/podologo/modales/derivar.html"
    numeros = clinica.numerar_atenciones(atencion.ficha.atenciones.all())
    contexto = {
        "a": atencion,
        "numero": numeros.get(atencion.pk),
        "especialidades": ESPECIALIDADES,
        "valores": {"resumen_clinico": atencion.diagnostico},
        "errores": {},
    }
    if request.method == "GET":
        return render(request, plantilla, contexto)
    datos, errores = validar(DerivacionCreacionSerializer, request.POST)
    if not errores:
        try:
            derivacion = clinica_servicios.emitir_derivacion(
                profesional=request.user.profesional, atencion=atencion, ip=ip_de(request), **datos
            )
        except clinica_servicios.ConsentimientoRequerido:
            errores = {"general": [SIN_CONSENTIMIENTO]}
        except (DjangoValidationError, PermissionDenied) as exc:
            errores = (
                errores_de(exc)
                if isinstance(exc, DjangoValidationError)
                else {"general": [str(exc)]}
            )
        else:
            return _contenido_actualizado(
                request,
                atencion.ficha.paciente,
                f"Derivación a {derivacion.especialidad_nombre} emitida. "
                "Ya puedes descargar el PDF.",
            )
    contexto.update(valores=request.POST, errores=errores)
    return en_modal(request, plantilla, contexto)


# --- horario y bloqueos ---

DIAS = Disponibilidad.DiaSemana.choices


def _horario_contexto(usuario, **extra):
    tramos = agenda.disponibilidades_de(usuario).order_by("dia_semana", "hora_inicio")
    por_dia = [(nombre, [t for t in tramos if t.dia_semana == dia]) for dia, nombre in DIAS]
    bloqueos = agenda.bloqueos_de(usuario).filter(fin__gt=timezone.now()).order_by("inicio")
    contexto = contexto_base(
        "horario",
        dias=DIAS,
        por_dia=[(nombre, lista) for nombre, lista in por_dia if lista],
        bloqueos=bloqueos,
        errores_tramo={},
        errores_bloqueo={},
        valores_bloqueo={},
    )
    contexto.update(extra)
    return contexto


@solo_profesional
def horario(request):
    return render(request, "web/podologo/horario.html", _horario_contexto(request.user))


@solo_profesional
def crear_tramo(request):
    if request.method != "POST":
        raise Http404
    datos, errores = validar(DisponibilidadSerializer, request.POST)
    if not errores:
        try:
            agenda_servicios.crear_disponibilidad(profesional=request.user.profesional, **datos)
        except DjangoValidationError as exc:
            errores = errores_de(exc)
    contexto = _horario_contexto(request.user, errores_tramo=errores)
    respuesta = render(request, "web/podologo/parciales/tramos.html", contexto)
    return respuesta if errores else con_aviso(respuesta, "Tramo agregado.")


@solo_profesional
def alternar_tramo(request, pk):
    if request.method != "POST":
        raise Http404
    tramo = get_object_or_404(agenda.disponibilidades_de(request.user), pk=pk)
    errores = {}
    try:
        agenda_servicios.actualizar_disponibilidad(tramo=tramo, activa=not tramo.activa)
    except DjangoValidationError as exc:
        errores = errores_de(exc)
    contexto = _horario_contexto(request.user, errores_tramo=errores)
    return render(request, "web/podologo/parciales/tramos.html", contexto)


@solo_profesional
def crear_bloqueo(request):
    if request.method != "POST":
        raise Http404
    datos, errores = validar(BloqueoSerializer, request.POST)
    if not errores:
        try:
            agenda_servicios.crear_bloqueo(profesional=request.user.profesional, **datos)
        except DjangoValidationError as exc:
            errores = errores_de(exc)
    contexto = _horario_contexto(
        request.user, errores_bloqueo=errores, valores_bloqueo=request.POST if errores else {}
    )
    respuesta = render(request, "web/podologo/parciales/bloqueos.html", contexto)
    if errores:
        return respuesta
    return con_aviso(respuesta, "Horario bloqueado: ya no se puede reservar en ese período.")


@solo_profesional
def quitar_bloqueo(request, pk):
    bloqueo = get_object_or_404(agenda.bloqueos_de(request.user), pk=pk)
    if request.method == "GET":
        return render(request, "web/podologo/modales/quitar_bloqueo.html", {"bloqueo": bloqueo})
    agenda_servicios.eliminar_bloqueo(bloqueo=bloqueo)
    respuesta = render(
        request, "web/podologo/parciales/bloqueos.html", _horario_contexto(request.user)
    )
    return con_aviso(respuesta, "Bloqueo quitado.", cerrar_modal=True)


# --- tratamientos y perfil ---


@solo_profesional
def tratamientos(request):
    contexto = contexto_base("tratamientos", tratamientos=agenda.tratamientos_activos())
    return render(request, "web/podologo/tratamientos.html", contexto)


@solo_profesional
def perfil(request):
    usuario = request.user
    profesional = usuario.profesional
    iniciales = {"telefono": usuario.telefono, "descripcion": profesional.descripcion}
    return procesar_perfil(
        request,
        plantilla="web/podologo/perfil.html",
        serializador=PerfilProfesionalSerializer,
        iniciales=iniciales,
        extra=contexto_perfil_profesional(profesional),
    )
