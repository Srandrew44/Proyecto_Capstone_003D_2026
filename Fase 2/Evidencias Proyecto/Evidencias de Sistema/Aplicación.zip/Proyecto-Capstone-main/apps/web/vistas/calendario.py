"""Calendario de horarios libres para reservar o cambiar una cita.

Lo arma el servidor: los días del mes con horas libres y, del día elegido, sus horas. Cada
botón del calendario es un enlace de htmx que vuelve a pedir el calendario con otro mes, día
u hora, así que no hay estado en el navegador.
"""

import calendar
from collections import defaultdict
from datetime import date, timedelta

from django.conf import settings
from django.utils import timezone

from apps.agenda.horarios import horarios_libres

from .comun import fecha_de, fecha_hora_de

MESES = [
    "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
    "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre",
]  # fmt: skip
DIAS = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]


def _mes(texto, por_defecto: date) -> date:
    fecha = fecha_de(f"{texto}-01") if texto else None
    return fecha or por_defecto.replace(day=1)


def calendario(*, profesional, tratamiento, mes=None, dia=None, inicio=None, excluir=None) -> dict:
    """Contexto de web/parciales/calendario.html. `inicio` es la hora ya elegida (ISO)."""
    hoy = timezone.localdate()
    ultimo = hoy + timedelta(days=settings.AGENDA_HORIZONTE_DIAS)
    libres = horarios_libres(
        profesional=profesional, tratamiento=tratamiento, desde=hoy, hasta=ultimo, excluir=excluir
    )
    if not libres:
        return {"sin_horas": True}
    por_dia = defaultdict(list)
    for horario in libres:
        por_dia[timezone.localdate(horario)].append(horario)

    elegido = fecha_hora_de(inicio)
    if elegido and elegido not in libres:
        elegido = None  # alguien la tomó, o la cambiaron a mano en la URL
    dia = fecha_de(dia)
    if elegido:
        dia = timezone.localdate(elegido)
    primer_dia = min(por_dia)
    if dia not in por_dia:
        dia = primer_dia
    mes = _mes(mes, dia)
    mes = min(max(mes, hoy.replace(day=1)), ultimo.replace(day=1))

    semanas = [
        [
            {
                "fecha": fecha,
                "en_mes": fecha.month == mes.month,
                "libres": len(por_dia.get(fecha, [])),
                "elegido": fecha == dia,
                "hoy": fecha == hoy,
            }
            for fecha in semana
        ]
        for semana in calendar.Calendar(firstweekday=0).monthdatescalendar(mes.year, mes.month)
    ]
    anterior = (mes - timedelta(days=1)).replace(day=1)
    siguiente = (mes + timedelta(days=32)).replace(day=1)
    return {
        "sin_horas": False,
        "titulo_mes": f"{MESES[mes.month - 1]} {mes.year}",
        "dias_semana": DIAS,
        "semanas": semanas,
        "mes_anterior": f"{anterior:%Y-%m}" if anterior >= hoy.replace(day=1) else None,
        "mes_siguiente": f"{siguiente:%Y-%m}" if siguiente <= ultimo.replace(day=1) else None,
        "mes": f"{mes:%Y-%m}",
        "dia": dia,
        "horas": por_dia.get(dia, []),
        "elegido": elegido,
    }
