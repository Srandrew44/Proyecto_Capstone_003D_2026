"""Protege las cuentas del escenario de demostración en una base publicada.

`cargar_escenario_demo` crea las cuentas @example.com con una contraseña escrita en el código
(sirve en desarrollo y en las pruebas). En un sitio público eso es una puerta abierta: quien
conozca el repositorio entra como podólogo y ve fichas. Este comando les pone una contraseña
nueva, que se lee de la variable de entorno DEMO_CLAVE_NUEVA y nunca queda en el código ni en
la terminal, o las desactiva con --desactivar.

Cambiar la contraseña también cierra las sesiones abiertas de esas cuentas (Django invalida
la sesión cuando cambia la contraseña). No toca a los administradores ni a cuentas reales.
"""

import os

from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from apps.cuentas.models import Usuario

DOMINIO_DEMO = "@example.com"
VARIABLE = "DEMO_CLAVE_NUEVA"


def cuentas_demo():
    return Usuario.objects.filter(email__iendswith=DOMINIO_DEMO, is_superuser=False)


class Command(BaseCommand):
    help = (
        f"Cambia la contraseña de las cuentas demo ({DOMINIO_DEMO}) por la de la variable "
        f"{VARIABLE}, o las desactiva con --desactivar."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--desactivar",
            action="store_true",
            help="Desactiva las cuentas demo en vez de cambiarles la contraseña.",
        )

    def handle(self, *args, desactivar, **opciones):
        cuentas = cuentas_demo()
        if desactivar:
            total = cuentas.filter(is_active=True).update(is_active=False)
            self.stdout.write(self.style.SUCCESS(f"Cuentas demo desactivadas: {total}"))
            return

        clave = os.environ.get(VARIABLE, "")
        if not clave:
            raise CommandError(f"Define la variable de entorno {VARIABLE} con la clave nueva.")
        try:
            validate_password(clave)
        except ValidationError as exc:
            raise CommandError("La clave no es segura: " + " ".join(exc.messages)) from exc

        with transaction.atomic():
            lista = list(cuentas)
            for usuario in lista:
                usuario.set_password(clave)
                usuario.save(update_fields=["password"])
        self.stdout.write(self.style.SUCCESS(f"Contraseña cambiada en {len(lista)} cuentas demo."))
