"""Escenario de demostración para recorrer el sitio con datos: podólogos, pacientes, citas,
fichas, atenciones y una derivación. Todo es ficticio (correos @example.com).

Solo corre con DEBUG activo, para no ensuciar nunca una base real. Si el escenario ya existe,
no hace nada. Las citas pasadas y las de hoy se crean directo en la base (ya ocurrieron, así
que no tiene sentido enviar sus correos); las futuras se reservan con el servicio de siempre,
por lo que generan sus correos de verdad (en desarrollo los captura Mailpit).
"""

import random
import unicodedata
from datetime import date, datetime, time, timedelta

from django.conf import settings
from django.core.management import call_command
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone

from apps.agenda import services as agenda
from apps.agenda.horarios import horarios_libres
from apps.agenda.models import Cita, Tratamiento
from apps.clinica import services as clinica
from apps.clinica.models import Consentimiento, FichaClinica, MarcaPie
from apps.cuentas import services as cuentas
from apps.cuentas.models import Usuario
from apps.cuentas.rut import calcular_dv

CLAVE = "demo-mypodo-2026"

PROFESIONALES = [
    ("podologa.demo@example.com", "Camila", "Rojas", "Podología clínica"),
    ("podologo.demo@example.com", "Tomás", "Fuentes", "Podología geriátrica"),
]
# nombre, apellido, cuerpo del RUT, nacimiento, comuna, actividad
PACIENTES = [
    ("María", "González", 11222333, date(1958, 4, 12), "Providencia", "Profesora jubilada"),
    ("Pedro", "Ramírez", 12333444, date(1971, 9, 3), "Ñuñoa", "Conductor"),
    ("Ana", "Torres", 15444555, date(1985, 1, 27), "Santiago", "Enfermera"),
    ("Luis", "Morales", 9555666, date(1949, 11, 8), "La Reina", "Jubilado"),
    ("Carmen", "Díaz", 17666777, date(1992, 6, 15), "Macul", "Diseñadora"),
]
# Qué pacientes atiende cada profesional (por posición en PACIENTES).
ATIENDE = [[0, 1, 2, 3], [3, 4]]
HORAS = [time(9), time(10, 15), time(11, 30), time(14), time(15, 15), time(16, 30)]

OBSERVACIONES = [
    "Hiperqueratosis plantar en zona metatarsal. Uñas engrosadas en ambos hallux.",
    "Onicocriptosis leve en borde lateral del hallux derecho, sin signos de infección.",
    "Piel seca con fisuras en talones. Sensibilidad conservada.",
    "Onicomicosis en uñas del segundo y tercer dedo del pie izquierdo.",
    "Control sin hallazgos nuevos. Buena evolución respecto de la atención anterior.",
]
TRATAMIENTOS = [
    "Deslaminado y limado de uñas. Enucleación de heloma.",
    "Espiculotomía del borde lateral y curación.",
    "Desbridamiento de hiperqueratosis e hidratación.",
    "Fresado de uñas y aplicación de antifúngico tópico.",
    "Corte y limado de uñas, revisión general.",
]
INDICACIONES = [
    "Hidratar los pies a diario, sin aplicar crema entre los dedos.",
    "Usar calzado amplio y evitar cortar las uñas en curva.",
    "Antifúngico tópico dos veces al día por ocho semanas.",
    "Secar bien entre los dedos y cambiar calcetines a diario.",
]


def _correo(nombre, apellido) -> str:
    """nombre.apellido@example.com, sin tildes."""
    texto = unicodedata.normalize("NFKD", f"{nombre}.{apellido}".lower())
    return texto.encode("ascii", "ignore").decode() + "@example.com"


class Command(BaseCommand):
    help = "Carga un escenario ficticio completo para ver el sitio con datos (solo en DEBUG)."

    def handle(self, *args, **opciones):
        if not settings.DEBUG:
            raise CommandError("Solo se puede cargar con DEBUG activo (desarrollo).")
        if Usuario.objects.filter(email=PROFESIONALES[0][0]).exists():
            self.stdout.write("El escenario de demostración ya estaba cargado: no se modifica.")
            return
        self.azar = random.Random(2026)
        call_command("cargar_datos_demo", stdout=self.stdout)
        with transaction.atomic():
            profesionales = self._profesionales()
            pacientes = self._pacientes()
            self._historia(profesionales, pacientes)
            self._hoy(profesionales[0], [pacientes[i] for i in ATIENDE[0]])
        # Fuera de la transacción: la reserva usa la suya y bloquea la agenda.
        reservadas = self._futuras(profesionales, pacientes)
        self.stdout.write(self.style.SUCCESS("Escenario cargado. Contraseña de todos: " + CLAVE))
        for email, *_ in PROFESIONALES:
            self.stdout.write(f"  Podólogo: {email}")
        for paciente in pacientes:
            self.stdout.write(f"  Paciente: {paciente.usuario.email}")
        self.stdout.write(f"  Citas futuras reservadas (con sus correos): {reservadas}")

    def _profesionales(self):
        creados = []
        for email, nombre, apellido, especialidad in PROFESIONALES:
            profesional = cuentas.crear_profesional(
                email=email,
                password=CLAVE,
                nombre=nombre,
                apellido=apellido,
                especialidad=especialidad,
                telefono="+56 9 5555 0000",
                numero_colegiado="DEMO-" + apellido.upper(),
            )
            call_command("cargar_datos_demo", profesional=email, stdout=self.stdout)
            creados.append(profesional)
        return creados

    def _pacientes(self):
        creados = []
        for nombre, apellido, cuerpo, nacimiento, comuna, actividad in PACIENTES:
            paciente = cuentas.registrar_paciente(
                email=_correo(nombre, apellido),
                password=CLAVE,
                nombre=nombre,
                apellido=apellido,
                rut=f"{cuerpo}-{calcular_dv(cuerpo)}",
                fecha_nacimiento=nacimiento,
                direccion=f"Calle de prueba {self.azar.randint(100, 999)}",
                comuna=comuna,
                telefono="+56 9 1111 2222",
                actividad=actividad,
                telefono_contacto="+56 9 3333 4444",
            )
            clinica.aceptar_consentimiento(
                paciente=paciente, tipo=Consentimiento.Tipo.TRATAMIENTO_DATOS
            )
            creados.append(paciente)
        return creados

    def _cita(self, profesional, paciente, dia, hora, estado, tratamiento=None):
        tratamiento = tratamiento or self.azar.choice(list(Tratamiento.objects.all()))
        inicio = datetime.combine(dia, hora, tzinfo=timezone.get_current_timezone())
        cita = Cita.objects.create(
            paciente=paciente,
            profesional=profesional,
            tratamiento=tratamiento,
            inicio=inicio,
            fin=inicio + timedelta(minutes=tratamiento.duracion_min),
            estado=Cita.Estado.CONFIRMADA,
            precio=tratamiento.precio,
        )
        if estado == Cita.Estado.REALIZADA:
            self._atender(cita)
        elif estado == Cita.Estado.CANCELADA:
            cita.estado = estado
            cita.cancelada_en = inicio - timedelta(days=2)
            cita.motivo_cancelacion = "No puedo asistir ese día."
            cita.save()
        elif estado == Cita.Estado.NO_ASISTIO:
            cita.estado = estado
            cita.save()
        return cita

    def _atender(self, cita):
        profesional, paciente = cita.profesional, cita.paciente
        if not FichaClinica.objects.filter(paciente=paciente).exists():
            clinica.crear_ficha(
                profesional=profesional,
                paciente=paciente,
                diabetes=self.azar.random() < 0.4,
                hta=self.azar.random() < 0.5,
                varices=self.azar.random() < 0.3,
                ulcera_previa=False,
                ulcera_actual=False,
                amputaciones=False,
                camina_con_ayuda=paciente.fecha_nacimiento.year < 1955,
                calzado_adecuado=self.azar.random() < 0.6,
                presion_arterial=self.azar.choice(["120/80", "130/85", "140/90"]),
                pulso_pedio_derecho="presente",
                pulso_pedio_izquierdo="presente",
                medicamentos=self.azar.choice(["", "Metformina 850 mg", "Losartán 50 mg"]),
            )
        indice = self.azar.randrange(len(OBSERVACIONES))
        return clinica.registrar_atencion(
            profesional=profesional,
            paciente=paciente,
            cita=cita,
            marcas=self._dibujo(paciente),
            ahora=cita.fin,
            motivo_consulta="Control podológico",
            observacion=OBSERVACIONES[indice],
            tratamiento=TRATAMIENTOS[indice],
            indicaciones=self.azar.choice(INDICACIONES),
            diagnostico=OBSERVACIONES[indice].split(".")[0],
        )

    def _dibujo(self, paciente):
        """Cómo queda el dibujo de los pies tras la atención: a veces se agrega o se quita un
        símbolo; si no cambia, None."""
        actuales = [
            {"simbolo": m.simbolo, "vista": m.vista, "x": m.x, "y": m.y}
            for m in MarcaPie.objects.filter(ficha__paciente=paciente, retirada_en__isnull=True)
        ]
        if actuales and self.azar.random() < 0.15:
            actuales.pop(self.azar.randrange(len(actuales)))
        elif len(actuales) < 6 and self.azar.random() < 0.4:
            actuales.append(
                {
                    "simbolo": self.azar.choice(MarcaPie.Simbolo.values),
                    "vista": self.azar.choice(MarcaPie.Vista.values),
                    "x": round(self.azar.uniform(0.35, 0.65), 3),
                    "y": round(self.azar.uniform(0.25, 0.8), 3),
                }
            )
        else:
            return None
        return actuales

    def _historia(self, profesionales, pacientes):
        """Citas desde el primer día del mes anterior hasta ayer, en días hábiles."""
        hoy = timezone.localdate()
        dia = (hoy.replace(day=1) - timedelta(days=1)).replace(day=1)
        estados = [Cita.Estado.REALIZADA] * 8 + [Cita.Estado.NO_ASISTIO, Cita.Estado.CANCELADA]
        while dia < hoy:
            # Un paciente que atienden ambos no puede tener dos citas a la misma hora.
            ocupados = set()
            if dia.weekday() < 5:
                for profesional, indices in zip(profesionales, ATIENDE, strict=True):
                    cuantas = self.azar.randint(1, 4 if indices == ATIENDE[0] else 2)
                    for hora in sorted(self.azar.sample(HORAS, cuantas)):
                        libres = [i for i in indices if (i, hora) not in ocupados]
                        if not libres:
                            continue
                        indice = self.azar.choice(libres)
                        ocupados.add((indice, hora))
                        paciente = pacientes[indice]
                        self._cita(profesional, paciente, dia, hora, self.azar.choice(estados))
            dia += timedelta(days=1)

        # Una corrección y una derivación, para verlas en la ficha.
        atencion = profesionales[0].atenciones.filter(ficha__paciente=pacientes[0]).first()
        if atencion is not None:
            corregida = clinica.corregir_atencion(
                atencion=atencion,
                profesional=profesionales[0],
                motivo_correccion="Se registró el pie equivocado.",
                pie_izquierdo="Hiperqueratosis en talón.",
            )
            clinica.emitir_derivacion(
                profesional=profesionales[0],
                atencion=corregida,
                especialidad_destino="dermatologia",
                motivo="Lesión cutánea persistente en talón izquierdo que requiere evaluación.",
                resumen_clinico="Hiperqueratosis con fisuras que no mejora con hidratación.",
            )

    def _hoy(self, profesional, pacientes):
        """Citas de hoy sin atender, para probar la agenda del día (atender, no asistió)."""
        hoy = timezone.localdate()
        if hoy.weekday() >= 5:
            return
        for paciente, hora in zip(pacientes, [HORAS[0], HORAS[2], HORAS[3], HORAS[5]], strict=True):
            self._cita(profesional, paciente, hoy, hora, Cita.Estado.CONFIRMADA)

    def _futuras(self, profesionales, pacientes) -> int:
        """Reserva con el servicio real: valida el horario y programa los correos."""
        hoy = timezone.localdate()
        tratamientos = list(Tratamiento.objects.all())
        reservadas = 0
        for profesional, indices in zip(profesionales, ATIENDE, strict=True):
            libres = horarios_libres(
                profesional=profesional,
                tratamiento=tratamientos[0],
                desde=hoy + timedelta(days=2),
                hasta=hoy + timedelta(days=12),
            )
            for paciente, inicio in zip([pacientes[i] for i in indices], libres[::7], strict=False):
                agenda.reservar_cita(
                    paciente=paciente,
                    profesional=profesional,
                    tratamiento=tratamientos[0],
                    inicio=inicio,
                    comentarios_paciente="Cita de demostración.",
                    # Confirmadas: nadie pagará estas citas en Webpay (si no, vencerían).
                    sin_cobro=True,
                )
                reservadas += 1
        return reservadas
