from django.urls import path

from .vistas import (
    acceso,
    asistente,
    dos_pasos,
    general,
    informes,
    paciente,
    pagos,
    podologo,
    profesionales,
)

app_name = "web"

urlpatterns = [
    path("", acceso.portada, name="portada"),
    path("entrar/", acceso.entrar, name="entrar"),
    path("entrar/codigo/", acceso.entrar_codigo, name="entrar-codigo"),
    path("salir/", acceso.salir, name="salir"),
    path("registro/confirmar/<str:token>/", acceso.confirmar_registro, name="registro-confirmar"),
    path("recuperar/", acceso.recuperar, name="recuperar"),
    path(
        "recuperar/<str:uidb64>/<str:token>/",
        acceso.recuperar_confirmar,
        name="recuperar-confirmar",
    ),
    path("privacidad/", acceso.privacidad, name="privacidad"),
    # Verificación en dos pasos opcional (pacientes y podólogos), desde "Mi perfil"
    path("cuenta/dos-pasos/activar/", dos_pasos.activar, name="dos-pasos-activar"),
    path("cuenta/dos-pasos/desactivar/", dos_pasos.desactivar, name="dos-pasos-desactivar"),
    path("cuenta/dos-pasos/codigos/", dos_pasos.codigos, name="dos-pasos-codigos"),
    path("mi-panel/", acceso.mi_inicio, name="mi-panel"),
    path("notificaciones/", general.notificaciones, name="notificaciones"),
    path("informes/", informes.informes, name="informes"),
    # Asistente virtual (visitantes y pacientes)
    path("asistente/", asistente.asistente, name="asistente"),
    path("asistente/enviar/", asistente.enviar, name="asistente-enviar"),
    path("asistente/nueva/", asistente.nueva, name="asistente-nueva"),
    path("asistente/aceptar/", asistente.aceptar, name="asistente-aceptar"),
    path("asistente/revocar/", asistente.revocar, name="asistente-revocar"),
    path("asistente/fotos/<uuid:pk>/", asistente.foto, name="asistente-foto"),
    # Paciente
    path("paciente/", paciente.inicio, name="paciente-inicio"),
    path("paciente/reservar/", paciente.reservar, name="paciente-reservar"),
    path("paciente/citas/", paciente.citas, name="paciente-citas"),
    path("paciente/citas/<uuid:pk>/cancelar/", paciente.cancelar_cita, name="paciente-cancelar"),
    path("paciente/citas/<uuid:pk>/reagendar/", paciente.reagendar_cita, name="paciente-reagendar"),
    path("paciente/citas/<uuid:pk>/pagar/", pagos.ir_a_pagar, name="pago-ir"),
    path("paciente/citas/<uuid:pk>/pago/", pagos.resultado, name="pago-resultado"),
    path("pagos/webpay/retorno/", pagos.retorno, name="pago-retorno"),
    path("paciente/ficha/", paciente.ficha, name="paciente-ficha"),
    path("paciente/consentimiento/", paciente.consentimiento, name="paciente-consentimiento"),
    path(
        "paciente/consentimiento/revocar/",
        paciente.revocar_consentimiento,
        name="paciente-revocar",
    ),
    path("paciente/perfil/", paciente.perfil, name="paciente-perfil"),
    # Podólogo
    path("podologo/", podologo.inicio, name="podologo-inicio"),
    path("podologo/agenda/", podologo.agenda_dia, name="podologo-agenda"),
    path(
        "podologo/citas/<uuid:pk>/inasistencia/",
        podologo.inasistencia,
        name="podologo-inasistencia",
    ),
    path("podologo/citas/<uuid:pk>/cancelar/", podologo.cancelar_cita, name="podologo-cancelar"),
    path("podologo/pacientes/", podologo.pacientes, name="podologo-pacientes"),
    path("podologo/pacientes/<uuid:paciente>/", podologo.ficha, name="podologo-ficha"),
    path(
        "podologo/pacientes/<uuid:paciente>/antecedentes/",
        podologo.antecedentes,
        name="podologo-antecedentes",
    ),
    path(
        "podologo/pacientes/<uuid:paciente>/atenciones/",
        podologo.nueva_atencion,
        name="podologo-atencion",
    ),
    path("podologo/atenciones/<uuid:pk>/corregir/", podologo.corregir, name="podologo-corregir"),
    path("podologo/atenciones/<uuid:pk>/derivar/", podologo.derivar, name="podologo-derivar"),
    path("podologo/horario/", podologo.horario, name="podologo-horario"),
    path("podologo/horario/tramos/", podologo.crear_tramo, name="podologo-tramo"),
    path(
        "podologo/horario/tramos/<uuid:pk>/alternar/",
        podologo.alternar_tramo,
        name="podologo-tramo-alternar",
    ),
    path("podologo/horario/bloqueos/", podologo.crear_bloqueo, name="podologo-bloqueo"),
    path(
        "podologo/horario/bloqueos/<uuid:pk>/quitar/",
        podologo.quitar_bloqueo,
        name="podologo-bloqueo-quitar",
    ),
    path("podologo/tratamientos/", podologo.tratamientos, name="podologo-tratamientos"),
    path("podologo/perfil/", podologo.perfil, name="podologo-perfil"),
    path("podologo/perfil/foto/", profesionales.foto, name="podologo-foto"),
    path(
        "podologo/perfil/tratamientos/",
        profesionales.tratamientos,
        name="podologo-mis-tratamientos",
    ),
    path(
        "podologo/perfil/certificaciones/",
        profesionales.agregar_certificacion,
        name="podologo-certificacion",
    ),
    path(
        "podologo/perfil/certificaciones/<uuid:pk>/quitar/",
        profesionales.quitar_certificacion,
        name="podologo-certificacion-quitar",
    ),
    path(
        "podologo/perfil/certificaciones/<uuid:pk>/documento/",
        profesionales.documento_certificacion,
        name="podologo-certificacion-documento",
    ),
    # Perfil público del podólogo (lo ve el paciente al elegir con quién atenderse)
    path("podologos/<uuid:pk>/", profesionales.perfil_publico, name="profesional-publico"),
    path("podologos/<uuid:pk>/foto/", profesionales.foto_publica, name="profesional-foto"),
]
