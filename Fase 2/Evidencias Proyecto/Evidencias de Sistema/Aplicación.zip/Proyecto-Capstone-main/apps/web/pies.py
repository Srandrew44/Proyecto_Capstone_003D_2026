"""Dibujo de los pies de la ficha podológica, con la simbología del podólogo.

El dibujo reproduce en vectores el de la ficha en papel del cliente (13/11/2026): planta
derecha, dorso derecho, dorso izquierdo y planta izquierda, con los dorsos con los dedos hacia
abajo y los ortejos mayores al centro. Sus trazos están en apps/web/pies_trazos.py, generado
desde la ficha con scripts/vectorizar_pies.py: no es la imagen pegada, sino líneas SVG con la
misma forma, nítidas a cualquier tamaño.

Encima van cuatro zonas, una por vista, donde se sueltan (o se hace clic para poner) los
símbolos. Cada marca se guarda con x e y de 0 a 1 dentro de su vista
(apps.clinica.models.MarcaPie); aquí se pasan a coordenadas del SVG.
"""

import json

from apps.clinica.models import MarcaPie

from . import pies_trazos

DIBUJO = {
    "ancho": pies_trazos.ANCHO,
    "alto": pies_trazos.ALTO,
    "trazos": pies_trazos.TRAZOS,
    "rotulos": [
        {**rotulo, "texto": texto}
        for rotulo, texto in zip(pies_trazos.ROTULOS, ("DERECHO", "IZQUIERDO"), strict=True)
    ],
}
# Cada vista: desde qué x empieza y cuánto mide en el dibujo (todas ocupan el alto completo).
# Los cortes van por los espacios entre un pie y el siguiente.
VISTAS = [
    (MarcaPie.Vista.PLANTA_DERECHO, 12, 214),
    (MarcaPie.Vista.DORSO_DERECHO, 226, 302),
    (MarcaPie.Vista.DORSO_IZQUIERDO, 528, 300),
    (MarcaPie.Vista.PLANTA_IZQUIERDO, 828, 204),
]
TAMANO_SIMBOLO = 30
# Para el historial del dibujo: "se agregó Heloma millar en la planta del pie derecho".
EN_LA_VISTA = {
    MarcaPie.Vista.PLANTA_DERECHO: "en la planta del pie derecho",
    MarcaPie.Vista.DORSO_DERECHO: "en el dorso del pie derecho",
    MarcaPie.Vista.DORSO_IZQUIERDO: "en el dorso del pie izquierdo",
    MarcaPie.Vista.PLANTA_IZQUIERDO: "en la planta del pie izquierdo",
}

# Cada símbolo se dibuja en una caja de 24 x 24 centrada en 0,0 (ver web/ficha/pies.html).
SIMBOLOS = [
    {
        "codigo": MarcaPie.Simbolo.HELOMA_INTERDIGITAL,
        "trazo": "M3 -9 L-4 9",
        "puntos": [(6, 7, 1.8)],
    },
    {
        "codigo": MarcaPie.Simbolo.HALLUX_VALGUS_PRONUNCIADO,
        "trazo": "M-2 -9 H8 M3 -9 V5 Q3 9 -1 9 H-7",
    },
    {"codigo": MarcaPie.Simbolo.HALLUX_VALGUS_INCIPIENTE, "trazo": "M3 -10 V5 Q3 9 -1 9 H-7"},
    {"codigo": MarcaPie.Simbolo.MACERACION, "puntos": [(0, 0, 4.5)]},
    {"codigo": MarcaPie.Simbolo.PACIENTE_DIABETICO, "elipse": (11, 7), "texto": "XD"},
    {
        "codigo": MarcaPie.Simbolo.HELOMA_MILLAR,
        "circulo": 10,
        "guiones": [(-5, -4), (1, -6), (4, -1), (-2, 1), (-6, 3), (2, 5), (-1, -2), (5, 3)],
    },
    {"codigo": MarcaPie.Simbolo.DEDO_EN_GARRA, "trazo": "M-9 7 L-4 -3 H9"},
]
for simbolo in SIMBOLOS:
    simbolo["nombre"] = MarcaPie.Simbolo(simbolo["codigo"]).label
POR_CODIGO = {simbolo["codigo"]: simbolo for simbolo in SIMBOLOS}
ZONA = {vista: (x0, ancho) for vista, x0, ancho in VISTAS}


def _posicion(marca):
    """Coordenadas en el SVG del centro de una marca (objeto o diccionario)."""
    leer = marca.get if isinstance(marca, dict) else lambda campo: getattr(marca, campo)
    x0, ancho = ZONA[leer("vista")]
    return x0 + float(leer("x")) * ancho, float(leer("y")) * DIBUJO["alto"], leer


def _valida(marca) -> bool:
    """Al volver a mostrar un formulario con errores, las marcas vienen del navegador."""
    leer = marca.get if isinstance(marca, dict) else lambda campo: getattr(marca, campo, None)
    try:
        return (
            leer("simbolo") in POR_CODIGO
            and leer("vista") in MarcaPie.Vista.values
            and 0 <= float(leer("x")) <= 1
            and 0 <= float(leer("y")) <= 1
        )
    except (TypeError, ValueError):
        return False


def describir_cambio(cambio) -> str:
    """Un cambio de clinica.selectors.cambios_del_dibujo, en palabras."""
    marca = cambio["marca"]
    verbo = "se agregó" if cambio["tipo"] == "alta" else "se quitó"
    return f"{verbo} {marca.get_simbolo_display()} {EN_LA_VISTA[marca.vista]}"


def dibujo(marcas=()) -> dict:
    """Contexto de la plantilla web/ficha/pies.html. Omite las marcas que no son válidas."""
    lista = []
    for marca in filter(_valida, marcas):
        cx, cy, leer = _posicion(marca)
        lista.append(
            {
                "simbolo": POR_CODIGO[leer("simbolo")],
                "nombre": MarcaPie.Simbolo(leer("simbolo")).label,
                "vista": MarcaPie.Vista(leer("vista")).label,
                "x": round(cx - TAMANO_SIMBOLO / 2, 1),
                "y": round(cy - TAMANO_SIMBOLO / 2, 1),
                "datos": {
                    "simbolo": leer("simbolo"),
                    "vista": leer("vista"),
                    "x": leer("x"),
                    "y": leer("y"),
                },
            }
        )
    return {
        "vistas": [
            {"codigo": vista.value, "nombre": vista.label, "x0": x0, "ancho": ancho}
            for vista, x0, ancho in VISTAS
        ],
        "dibujo": DIBUJO,
        "simbolos": SIMBOLOS,
        "marcas": lista,
        # Para el campo oculto del formulario: lo lee y lo actualiza static/web/js/pies.js.
        "marcas_json": json.dumps([marca["datos"] for marca in lista]),
        "tamano": TAMANO_SIMBOLO,
    }
