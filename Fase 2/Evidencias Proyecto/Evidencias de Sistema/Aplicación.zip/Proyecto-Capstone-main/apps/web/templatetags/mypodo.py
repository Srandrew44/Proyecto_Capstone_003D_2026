"""Formatos y piezas comunes de las plantillas (montos, porcentajes, estados y el dibujo)."""

import os

from django import template
from django.contrib.staticfiles import finders
from django.templatetags.static import static
from django.utils.html import format_html

from apps.web.pies import dibujo

register = template.Library()

ESTADOS_CITA = {
    "pendiente_pago": ("Pendiente de pago", "badge-warning"),
    "agendada": ("Agendada", "badge-info"),
    "confirmada": ("Confirmada", "badge-success"),
    "realizada": ("Realizada", "badge-success"),
    "cancelada": ("Cancelada", "badge-neutral"),
    "no_asistio": ("No asistió", "badge-danger"),
}


@register.filter
def pesos(monto) -> str:
    """25000 -> "$25.000" (formato chileno, sin decimales)."""
    if monto in (None, ""):
        return "—"
    return "$" + f"{int(monto):,}".replace(",", ".")


@register.filter
def porcentaje(valor) -> str:
    """12.5 -> "12,5 %" (el informe ya los entrega de 0 a 100). Sin base, "sin datos"."""
    if valor is None:
        return "sin datos"
    return f"{valor:.1f}".replace(".", ",").removesuffix(",0") + " %"


@register.filter
def horas(minutos) -> str:
    return f"{(minutos or 0) / 60:.1f}".replace(".", ",").removesuffix(",0")


@register.filter
def obtener(diccionario, clave):
    """Lee una clave variable de un diccionario: {{ errores|obtener:campo }}."""
    return (diccionario or {}).get(clave)


TIPOS_PAGO = {
    "VD": "Débito",
    "VP": "Prepago",
    "VN": "Crédito",
    "VC": "Crédito en cuotas",
    "SI": "Crédito, 3 cuotas sin interés",
    "S2": "Crédito, 2 cuotas sin interés",
    "NC": "Crédito, cuotas sin interés",
}


@register.simple_tag
def tipo_pago(codigo):
    """Código de tipo de pago de Webpay (VD, VN…) en palabras."""
    return TIPOS_PAGO.get(codigo, codigo or "—")


@register.simple_tag
def badge_estado(estado):
    texto, clase = ESTADOS_CITA.get(estado, (estado, "badge-neutral"))
    return format_html('<span class="badge {}">{}</span>', clase, texto)


@register.simple_tag
def si_no(valor, favorable=False):
    """Antecedente de sí o no: nulo es "sin registro", que no es lo mismo que "no".

    Casi todos son factores de riesgo ("Sí" en naranja). Con `favorable`, la pregunta es
    buena señal (por ejemplo "Usa calzado adecuado") y los colores se invierten.
    """
    if valor is True:
        texto, clase = "Sí", "badge-success" if favorable else "badge-warning"
    elif valor is False:
        texto, clase = "No", "badge-warning" if favorable else "badge-success"
    else:
        texto, clase = "Sin registro", "badge-neutral"
    return format_html('<span class="badge {}">{}</span>', clase, texto)


@register.simple_tag
def estatico(ruta) -> str:
    """URL de un archivo estático con su versión (?v=fecha de modificación).

    El CSS y los scripts conservan su nombre entre cambios: sin la versión, el navegador
    seguiría usando la copia vieja que guardó en caché.
    """
    url = static(ruta)
    archivo = finders.find(ruta)
    if archivo:
        url += f"?v={int(os.path.getmtime(archivo))}"
    return url


@register.inclusion_tag("web/ficha/pies.html")
def dibujo_pies(marcas=(), editable=False, nombre_campo="marcas"):
    return {**dibujo(marcas), "editable": editable, "nombre_campo": nombre_campo}


@register.filter
def rut(valor) -> str:
    """RUT con puntos: "12345678-5" -> "12.345.678-5". Solo para mostrar; se guarda sin puntos."""
    texto = str(valor or "")
    cuerpo, guion, dv = texto.rpartition("-")
    if not guion or not cuerpo.isdigit():
        return texto
    return f"{int(cuerpo):,}".replace(",", ".") + "-" + dv


@register.simple_tag
def dos_pasos_estado(usuario) -> dict:
    """Si la cuenta tiene verificación en dos pasos y cuántos códigos de respaldo le quedan."""
    from apps.cuentas import dos_pasos

    activa = dos_pasos.activa(usuario)
    return {"activa": activa, "quedan": dos_pasos.codigos_disponibles(usuario) if activa else 0}
