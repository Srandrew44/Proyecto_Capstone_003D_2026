"""Etiquetas de plantilla propias (apps/web/templatetags/mypodo.py)."""

import pytest

from apps.web.templatetags.mypodo import rut, si_no


@pytest.mark.parametrize(
    ("valor", "favorable", "texto", "clase"),
    [
        # Factor de riesgo (diabetes, úlceras…): "Sí" es la advertencia.
        (True, False, "Sí", "badge-warning"),
        (False, False, "No", "badge-success"),
        # Buena señal (usa calzado adecuado): los colores se invierten.
        (True, True, "Sí", "badge-success"),
        (False, True, "No", "badge-warning"),
        # Sin registro no es "no": siempre neutro.
        (None, False, "Sin registro", "badge-neutral"),
        (None, True, "Sin registro", "badge-neutral"),
    ],
)
def test_si_no_pinta_segun_el_sentido_de_la_pregunta(valor, favorable, texto, clase):
    assert si_no(valor, favorable) == f'<span class="badge {clase}">{texto}</span>'


@pytest.mark.parametrize(
    ("guardado", "mostrado"),
    [
        ("12345678-5", "12.345.678-5"),
        ("9555666-K", "9.555.666-K"),
        ("1234567", "1234567"),  # sin guion: se muestra tal cual
        ("", ""),
        (None, ""),
    ],
)
def test_rut_se_muestra_con_puntos(guardado, mostrado):
    assert rut(guardado) == mostrado
