"""Mi perfil (RF-027): editar datos de contacto, cambiar la contraseña y auditoría de cuenta."""

import pytest
from django.test import Client
from django.urls import reverse

from apps.auditoria.models import RegistroAuditoria
from apps.cuentas.tests.factories import CLAVE, PacienteFactory, ProfesionalFactory

pytestmark = pytest.mark.django_db
Accion = RegistroAuditoria.Accion
CLAVE_NUEVA = "Colibri-Andino-7731-pq"


def _cliente(usuario):
    cliente = Client()
    cliente.force_login(usuario)
    return cliente


CONTACTO = {
    "accion": "perfil",
    "telefono": "+56 9 1111 2222",
    "telefono_contacto": "+56 9 3333 4444",
    "direccion": "Av. Nueva 123",
    "comuna": "Ñuñoa",
    "actividad": "Profesora",
}


def test_el_paciente_edita_sus_datos_de_contacto():
    paciente = PacienteFactory()
    respuesta = _cliente(paciente.usuario).post(reverse("web:paciente-perfil"), CONTACTO)
    assert respuesta.status_code == 302
    paciente.refresh_from_db()
    paciente.usuario.refresh_from_db()
    assert paciente.usuario.telefono == "+56 9 1111 2222"
    assert (paciente.direccion, paciente.comuna, paciente.actividad) == (
        "Av. Nueva 123",
        "Ñuñoa",
        "Profesora",
    )
    registro = RegistroAuditoria.objects.get(accion=Accion.EDITAR_PERFIL)
    assert set(registro.detalle["campos"]) == {
        "telefono",
        "telefono_contacto",
        "direccion",
        "comuna",
        "actividad",
    }
    # La auditoría dice qué cambió, no los datos de contacto.
    assert "Av. Nueva" not in str(registro.detalle)


def test_el_paciente_no_puede_cambiar_sus_datos_de_identidad():
    paciente = PacienteFactory()
    rut, email, nombre = paciente.rut, paciente.usuario.email, paciente.usuario.nombre
    datos = {**CONTACTO, "rut": "11111111-1", "email": "otro@example.com", "nombre": "Otro"}
    _cliente(paciente.usuario).post(reverse("web:paciente-perfil"), datos)
    paciente.refresh_from_db()
    paciente.usuario.refresh_from_db()
    assert (paciente.rut, paciente.usuario.email, paciente.usuario.nombre) == (rut, email, nombre)


def test_un_campo_obligatorio_vacio_muestra_el_error_y_no_guarda():
    paciente = PacienteFactory()
    direccion = paciente.direccion
    respuesta = _cliente(paciente.usuario).post(
        reverse("web:paciente-perfil"), {**CONTACTO, "direccion": ""}
    )
    assert respuesta.status_code == 400
    assert 'class="form-error"' in respuesta.content.decode()
    paciente.refresh_from_db()
    assert paciente.direccion == direccion
    assert not RegistroAuditoria.objects.filter(accion=Accion.EDITAR_PERFIL).exists()


def test_guardar_sin_cambios_no_deja_registro():
    paciente = PacienteFactory()
    usuario = paciente.usuario
    datos = {
        "accion": "perfil",
        "telefono": usuario.telefono or "+56 9 0000 0000",
        "telefono_contacto": paciente.telefono_contacto,
        "direccion": paciente.direccion,
        "comuna": paciente.comuna,
        "actividad": paciente.actividad,
    }
    cliente = _cliente(usuario)
    cliente.post(reverse("web:paciente-perfil"), datos)  # la primera vez puede cambiar algo
    antes = RegistroAuditoria.objects.filter(accion=Accion.EDITAR_PERFIL).count()
    cliente.post(reverse("web:paciente-perfil"), datos)
    assert RegistroAuditoria.objects.filter(accion=Accion.EDITAR_PERFIL).count() == antes


def test_el_podologo_edita_su_telefono_y_su_presentacion_que_sale_en_la_portada():
    profesional = ProfesionalFactory()
    respuesta = _cliente(profesional.usuario).post(
        reverse("web:podologo-perfil"),
        {"accion": "perfil", "telefono": "+56 2 2222 3333", "descripcion": "Experta en pie"},
    )
    assert respuesta.status_code == 302
    profesional.refresh_from_db()
    assert profesional.descripcion == "Experta en pie"
    assert "Experta en pie" in Client().get(reverse("web:portada")).content.decode()


def test_el_podologo_no_cambia_la_pausa_ni_la_especialidad():
    profesional = ProfesionalFactory()
    pausa, especialidad = profesional.pausa_entre_citas_min, profesional.especialidad
    _cliente(profesional.usuario).post(
        reverse("web:podologo-perfil"),
        {"accion": "perfil", "descripcion": "x", "pausa_entre_citas_min": "0", "especialidad": "X"},
    )
    profesional.refresh_from_db()
    assert (profesional.pausa_entre_citas_min, profesional.especialidad) == (pausa, especialidad)


# --- contraseña ---


def _cambiar(cliente, url, actual=CLAVE, nueva=CLAVE_NUEVA, repetida=None):
    return cliente.post(
        url,
        {"accion": "clave", "actual": actual, "nueva": nueva, "repetida": repetida or nueva},
    )


@pytest.mark.parametrize("ruta", ["web:paciente-perfil", "web:podologo-perfil"])
def test_cambiar_la_contrasena_mantiene_esta_sesion_y_cierra_las_otras(ruta):
    fabrica = PacienteFactory if ruta == "web:paciente-perfil" else ProfesionalFactory
    usuario = fabrica().usuario
    esta, otra = Client(), Client()
    assert esta.login(username=usuario.email, password=CLAVE)
    assert otra.login(username=usuario.email, password=CLAVE)
    respuesta = _cambiar(esta, reverse(ruta))
    assert respuesta.status_code == 302
    usuario.refresh_from_db()
    assert usuario.check_password(CLAVE_NUEVA)
    assert esta.get(reverse(ruta)).status_code == 200
    assert otra.get(reverse(ruta)).status_code == 302  # la otra sesión quedó cerrada
    assert RegistroAuditoria.objects.filter(accion=Accion.CAMBIAR_CLAVE, usuario=usuario).exists()


@pytest.mark.parametrize(
    ("cambio", "mensaje"),
    [
        ({"actual": "no-es-la-clave"}, "La contraseña actual no es correcta."),
        ({"repetida": "Otra-Cosa-9999-zz"}, "Las contraseñas no coinciden."),
        ({"nueva": "12345678", "repetida": "12345678"}, "común"),
        ({"nueva": CLAVE, "repetida": CLAVE}, "debe ser distinta"),
    ],
)
def test_cambio_de_contrasena_rechazado(cambio, mensaje):
    paciente = PacienteFactory()
    cliente = _cliente(paciente.usuario)
    respuesta = _cambiar(cliente, reverse("web:paciente-perfil"), **cambio)
    assert respuesta.status_code == 400
    assert mensaje in respuesta.content.decode()
    paciente.usuario.refresh_from_db()
    assert paciente.usuario.check_password(CLAVE)


# --- auditoría del cierre de sesión ---


def test_cerrar_sesion_queda_en_la_auditoria():
    paciente = PacienteFactory()
    cliente = _cliente(paciente.usuario)
    cliente.post(reverse("web:salir"))
    registro = RegistroAuditoria.objects.get(accion=Accion.LOGOUT)
    assert registro.usuario == paciente.usuario


def test_cerrar_sesion_sin_sesion_no_registra_nada():
    Client().post(reverse("web:salir"))
    assert not RegistroAuditoria.objects.filter(accion=Accion.LOGOUT).exists()
