"""Flujos del sitio (Django + htmx): las mismas reglas que la API, ahora desde las páginas."""

import json
import re
from datetime import timedelta

import pytest
from django.core import mail
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from apps.agenda.horarios import horarios_libres
from apps.agenda.models import Cita
from apps.agenda.tests.factories import CitaFactory, DisponibilidadFactory, TratamientoFactory
from apps.auditoria.models import RegistroAuditoria
from apps.clinica.models import (
    AtencionClinica,
    Consentimiento,
    Derivacion,
    FichaClinica,
    MarcaPie,
)
from apps.clinica.tests.factories import (
    AtencionClinicaFactory,
    ConsentimientoFactory,
    FichaClinicaFactory,
)
from apps.cuentas.tests.factories import CLAVE, PacienteFactory, ProfesionalFactory

pytestmark = pytest.mark.django_db
HTMX = {"HTTP_HX_REQUEST": "true"}
MACERACION = {"simbolo": "maceracion", "vista": "planta_derecho", "x": 0.5, "y": 0.8}


def _cliente(usuario):
    cliente = Client()
    cliente.force_login(usuario)
    return cliente


@pytest.fixture
def cita_en_curso():
    """Una cita que ya comenzó, de un paciente con consentimiento y ficha."""
    cita = CitaFactory(inicio=timezone.now() - timedelta(minutes=10))
    ConsentimientoFactory(paciente=cita.paciente)
    FichaClinicaFactory(paciente=cita.paciente)
    return cita


# --- entrar, registrarse y salir ---


def test_entrar_abre_la_sesion_y_lleva_al_panel():
    paciente = PacienteFactory()
    respuesta = Client().post(
        reverse("web:entrar"),
        {"accion": "entrar", "email": paciente.usuario.email, "password": CLAVE},
    )
    assert respuesta.status_code == 302
    assert respuesta.url == reverse("web:paciente-inicio")


def test_entrar_con_clave_incorrecta_muestra_un_error_unico():
    paciente = PacienteFactory()
    respuesta = Client().post(
        reverse("web:entrar"),
        {"accion": "entrar", "email": paciente.usuario.email, "password": "x"},
    )
    assert respuesta.status_code == 400
    assert "Correo o contraseña incorrectos." in respuesta.content.decode()


def test_entrar_vuelve_a_la_pagina_pedida_pero_nunca_a_otro_sitio():
    paciente = PacienteFactory()
    datos = {"accion": "entrar", "email": paciente.usuario.email, "password": CLAVE}
    interna = Client().post(reverse("web:entrar"), {**datos, "next": "/paciente/citas/"})
    assert interna.url == "/paciente/citas/"
    externa = Client().post(reverse("web:entrar"), {**datos, "next": "https://otro.example.com/"})
    assert externa.url == reverse("web:paciente-inicio")


def _datos_registro(email):
    return {
        "accion": "registro",
        "email": email,
        "password": "Zorro-Azul-4471-xk",
        "nombre": "Nueva",
        "apellido": "Paciente",
        "telefono": "+56912345678",
        "rut": "12.345.678-5",
        "fecha_nacimiento": "1985-03-20",
        "direccion": "Calle 1",
        "comuna": "Ñuñoa",
        "actividad": "Profesora",
        "telefono_contacto": "+56987654321",
    }


def _confirmar_por_correo(cliente):
    """Abre el enlace del último correo y aprieta "Activar mi cuenta"."""
    enlace = re.search(r"https?://testserver(/registro/confirmar/[^/\s]+/)", mail.outbox[-1].body)
    return cliente.post(enlace.group(1))


def test_el_registro_pide_confirmar_el_correo_y_luego_lleva_al_consentimiento():
    cliente = Client()
    respuesta = cliente.post(reverse("web:entrar"), _datos_registro("nueva@example.com"))
    assert respuesta.status_code == 200
    assert "Revisa tu correo" in respuesta.content.decode()
    assert cliente.get(reverse("web:paciente-inicio")).status_code == 302  # aún sin cuenta
    confirmada = _confirmar_por_correo(cliente)
    assert confirmada.url == "/paciente/consentimiento/?nuevo=1"
    assert cliente.get(reverse("web:paciente-inicio")).status_code == 200


def test_el_registro_responde_igual_si_el_correo_ya_tiene_cuenta():
    PacienteFactory(usuario__email="nueva@example.com")
    respuesta = Client().post(reverse("web:entrar"), _datos_registro("nueva@example.com"))
    assert respuesta.status_code == 200
    assert "Revisa tu correo" in respuesta.content.decode()
    assert "Ya existe" not in respuesta.content.decode()


def test_la_pestana_de_registro_conserva_la_pagina_pedida():
    """Desde "Reservar con…" un visitante sin cuenta pasa a "Crear cuenta" sin perder el destino."""
    destino = "/paciente/reservar/?profesional=123"
    contenido = Client().get(reverse("web:entrar"), {"next": destino}).content.decode()
    assert "?modo=registro&amp;next=/paciente/reservar/%3Fprofesional%3D123" in contenido
    registro = Client().get(reverse("web:entrar"), {"modo": "registro", "next": destino})
    assert f'name="next" value="{destino}"' in registro.content.decode()


def test_el_registro_y_el_consentimiento_vuelven_a_la_reserva_pedida():
    destino = "/paciente/reservar/?profesional=123"
    cliente = Client()
    cliente.post(reverse("web:entrar"), {**_datos_registro("a@example.com"), "next": destino})
    respuesta = _confirmar_por_correo(cliente)
    assert respuesta.url == (
        "/paciente/consentimiento/?nuevo=1&next=%2Fpaciente%2Freservar%2F%3Fprofesional%3D123"
    )
    pagina = cliente.get(respuesta.url).content.decode()
    assert f'name="next" value="{destino}"' in pagina
    aceptado = cliente.post(
        reverse("web:paciente-consentimiento"), {"leido": "si", "next": destino}
    )
    assert aceptado.url == destino


def test_el_registro_y_el_consentimiento_nunca_llevan_a_otro_sitio():
    externo = "https://otro.example.com/"
    cliente = Client()
    cliente.post(reverse("web:entrar"), {**_datos_registro("b@example.com"), "next": externo})
    respuesta = _confirmar_por_correo(cliente)
    assert respuesta.url == "/paciente/consentimiento/?nuevo=1"
    aceptado = cliente.post(
        reverse("web:paciente-consentimiento"), {"leido": "si", "next": externo}
    )
    assert aceptado.url == reverse("web:paciente-consentimiento")


def test_el_registro_muestra_los_errores_junto_a_cada_campo():
    respuesta = Client().post(reverse("web:entrar"), {"accion": "registro", "rut": "1-1"})
    contenido = respuesta.content.decode()
    assert respuesta.status_code == 400
    assert contenido.count('class="form-error"') >= 5


def test_salir_cierra_la_sesion():
    cliente = _cliente(PacienteFactory().usuario)
    assert cliente.post(reverse("web:salir")).status_code == 302
    assert cliente.get(reverse("web:paciente-inicio")).status_code == 302


def test_salir_no_funciona_con_get():
    cliente = _cliente(PacienteFactory().usuario)
    assert cliente.get(reverse("web:salir")).status_code == 405


# --- consentimiento y reserva ---


def test_el_paciente_acepta_y_revoca_el_consentimiento():
    paciente = PacienteFactory()
    cliente = _cliente(paciente.usuario)
    url = reverse("web:paciente-consentimiento")
    assert cliente.post(url, {}).status_code == 400  # sin marcar la casilla
    assert cliente.post(url, {"leido": "si"}).status_code == 302
    assert Consentimiento.objects.filter(paciente=paciente, revocado_en__isnull=True).exists()
    assert cliente.post(reverse("web:paciente-revocar")).status_code == 302
    assert not Consentimiento.objects.filter(paciente=paciente, revocado_en__isnull=True).exists()


@pytest.fixture
def agenda_abierta():
    profesional = ProfesionalFactory()
    for dia in range(7):
        DisponibilidadFactory(profesional=profesional, dia_semana=dia)
    return profesional, TratamientoFactory()


def test_el_paciente_reserva_en_tres_pasos(agenda_abierta):
    profesional, tratamiento = agenda_abierta
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente)
    cliente = _cliente(paciente.usuario)
    url = reverse("web:paciente-reservar")
    flujo = cliente.get(url, {"profesional": profesional.pk, "tratamiento": tratamiento.pk}, **HTMX)
    assert 'data-hora="' in flujo.content.decode()
    hoy = timezone.localdate()
    inicio = horarios_libres(
        profesional=profesional, tratamiento=tratamiento, desde=hoy, hasta=hoy + timedelta(days=30)
    )[0]
    respuesta = cliente.post(
        url,
        {
            "profesional": profesional.pk,
            "tratamiento": tratamiento.pk,
            "inicio": inicio.isoformat(),
        },
        **HTMX,
    )
    assert "¡Reserva confirmada!" in respuesta.content.decode()
    assert Cita.objects.filter(paciente=paciente, inicio=inicio).exists()


def test_sin_consentimiento_la_reserva_se_rechaza(agenda_abierta):
    profesional, tratamiento = agenda_abierta
    paciente = PacienteFactory()
    hoy = timezone.localdate()
    inicio = horarios_libres(
        profesional=profesional, tratamiento=tratamiento, desde=hoy, hasta=hoy + timedelta(days=30)
    )[0]
    respuesta = _cliente(paciente.usuario).post(
        reverse("web:paciente-reservar"),
        {
            "profesional": profesional.pk,
            "tratamiento": tratamiento.pk,
            "inicio": inicio.isoformat(),
        },
        **HTMX,
    )
    assert "consentimiento" in respuesta.content.decode()
    assert respuesta["HX-Retarget"] == "#error-reserva"
    assert not Cita.objects.exists()


def test_el_paciente_cancela_su_cita_y_no_la_de_otro():
    cita = CitaFactory(inicio=timezone.now() + timedelta(days=5))
    ajena = CitaFactory(inicio=timezone.now() + timedelta(days=6))
    cliente = _cliente(cita.paciente.usuario)
    respuesta = cliente.post(
        reverse("web:paciente-cancelar", args=[cita.pk]), {"motivo": "Viaje"}, **HTMX
    )
    assert respuesta.status_code == 200
    assert "aviso" in json.loads(respuesta["HX-Trigger"])
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CANCELADA
    assert (
        cliente.post(reverse("web:paciente-cancelar", args=[ajena.pk]), **HTMX).status_code == 404
    )


# --- ficha clínica (podólogo) ---


def test_el_podologo_crea_la_ficha_de_su_paciente():
    cita = CitaFactory()
    ConsentimientoFactory(paciente=cita.paciente)
    cliente = _cliente(cita.profesional.usuario)
    url = reverse("web:podologo-ficha", args=[cita.paciente.pk])
    assert "Crear ficha" in cliente.get(url).content.decode()
    respuesta = cliente.post(url, {"diabetes": "true", "hta": "", "pulso_radial": "presente"})
    assert respuesta.status_code == 302
    ficha = FichaClinica.objects.get(paciente=cita.paciente)
    assert ficha.diabetes is True and ficha.hta is None and ficha.pulso_radial == "presente"


def test_sin_consentimiento_no_se_crea_la_ficha():
    cita = CitaFactory()
    cliente = _cliente(cita.profesional.usuario)
    respuesta = cliente.post(reverse("web:podologo-ficha", args=[cita.paciente.pk]), {})
    assert respuesta.status_code == 400
    assert "consentimiento" in respuesta.content.decode()
    assert not FichaClinica.objects.exists()


def test_abrir_la_ficha_queda_auditado(cita_en_curso):
    cliente = _cliente(cita_en_curso.profesional.usuario)
    contenido = cliente.get(
        reverse("web:podologo-ficha", args=[cita_en_curso.paciente.pk])
    ).content.decode()
    assert "data-dibujo-pies data-editable" in contenido
    assert RegistroAuditoria.objects.filter(accion=RegistroAuditoria.Accion.VER_FICHA).count() == 1


def test_la_atencion_se_guarda_con_su_cita_y_el_dibujo(cita_en_curso):
    cliente = _cliente(cita_en_curso.profesional.usuario)
    url = reverse("web:podologo-atencion", args=[cita_en_curso.paciente.pk])
    respuesta = cliente.post(
        url,
        {
            "cita": cita_en_curso.pk,
            "tratamiento": "Onicotomía\r\nlínea 2",
            "marcas": json.dumps([MACERACION]),
        },
        **HTMX,
    )
    assert respuesta.status_code == 200
    assert respuesta["HX-Retarget"] == "#ficha-contenido"
    atencion = AtencionClinica.objects.get()
    assert atencion.cita == cita_en_curso
    assert atencion.tratamiento == "Onicotomía\nlínea 2"  # los saltos de línea quedan como \n
    assert [m.simbolo for m in atencion.marcas_agregadas.all()] == ["maceracion"]
    assert atencion.marcas_agregadas.get().ficha == cita_en_curso.paciente.ficha
    cita_en_curso.refresh_from_db()
    assert cita_en_curso.estado == Cita.Estado.REALIZADA


def _marca_en_ficha(ficha, profesional, **datos):
    atencion = AtencionClinicaFactory(ficha=ficha, profesional=profesional)
    return MarcaPie.objects.create(ficha=ficha, atencion_alta=atencion, **(datos or MACERACION))


def test_la_ficha_muestra_un_solo_dibujo_con_las_marcas_vigentes(cita_en_curso):
    ficha, profesional = cita_en_curso.paciente.ficha, cita_en_curso.profesional
    marca = _marca_en_ficha(ficha, profesional)
    _marca_en_ficha(ficha, profesional)  # una segunda atención
    cliente = _cliente(profesional.usuario)
    contenido = cliente.get(
        reverse("web:podologo-ficha", args=[ficha.paciente_id])
    ).content.decode()
    # Un solo dibujo (el editable de la nueva atención), que parte con las marcas vigentes;
    # las tarjetas de las atenciones ya no traen el suyo.
    assert contenido.count("data-dibujo-pies") == 1
    assert contenido.count("&quot;simbolo&quot;: &quot;maceracion&quot;") == 2
    assert str(marca.pk) in contenido  # el punto de partida (dibujo_base)
    assert "se agregó Maceración en la planta del pie derecho" in contenido
    assert "Se agregó Maceración en la planta del pie derecho" in contenido  # en la tarjeta


def test_la_atencion_web_registra_solo_lo_quitado(cita_en_curso):
    ficha, profesional = cita_en_curso.paciente.ficha, cita_en_curso.profesional
    marca = _marca_en_ficha(ficha, profesional)
    cliente = _cliente(profesional.usuario)
    url = reverse("web:podologo-atencion", args=[ficha.paciente_id])
    datos = {"tratamiento": "Control", "marcas": "[]", "dibujo_base": json.dumps([str(marca.pk)])}
    respuesta = cliente.post(url, datos, **HTMX)
    assert respuesta["HX-Retarget"] == "#ficha-contenido"
    marca.refresh_from_db()
    assert marca.retirada_en is not None
    assert marca.atencion_baja.tratamiento == "Control"
    assert MarcaPie.objects.count() == 1  # no se borra ni se duplica
    assert "se quitó Maceración en la planta del pie derecho" in respuesta.content.decode()


def test_otro_podologo_no_ve_la_ficha_ni_su_dibujo(cita_en_curso):
    _marca_en_ficha(cita_en_curso.paciente.ficha, cita_en_curso.profesional)
    intruso = _cliente(ProfesionalFactory().usuario)
    url = reverse("web:podologo-ficha", args=[cita_en_curso.paciente.pk])
    assert intruso.get(url).status_code == 404
    url = reverse("web:podologo-atencion", args=[cita_en_curso.paciente.pk])
    assert intruso.post(url, {"tratamiento": "X", "marcas": "[]"}, **HTMX).status_code == 404
    assert MarcaPie.objects.get().vigente


def test_una_atencion_invalida_vuelve_al_formulario_sin_perder_lo_escrito(cita_en_curso):
    cliente = _cliente(cita_en_curso.profesional.usuario)
    url = reverse("web:podologo-atencion", args=[cita_en_curso.paciente.pk])
    marca_mala = {**MACERACION, "simbolo": "inventado"}
    respuesta = cliente.post(
        url, {"indicaciones": "Reposo", "marcas": json.dumps([marca_mala])}, **HTMX
    )
    contenido = respuesta.content.decode()
    assert respuesta["HX-Retarget"] == "#form-atencion"
    assert "Reposo" in contenido
    assert not AtencionClinica.objects.exists()


def test_la_correccion_cambia_solo_lo_que_cambio_y_conserva_el_dibujo(cita_en_curso):
    profesional = cita_en_curso.profesional
    marca = _marca_en_ficha(cita_en_curso.paciente.ficha, profesional)
    atencion = marca.atencion_alta
    cliente = _cliente(profesional.usuario)
    url = reverse("web:podologo-corregir", args=[atencion.pk])
    formulario = cliente.get(url, **HTMX).content.decode()
    assert "maceracion" in formulario  # el dibujo parte con las marcas vigentes de la ficha
    datos = {
        "motivo_correccion": "Error de tipeo",
        "motivo_consulta": atencion.motivo_consulta,
        "tratamiento": "Onicotomía corregida",
        "diagnostico": atencion.diagnostico,
        "marcas": json.dumps([MACERACION]),
        "dibujo_base": json.dumps([str(marca.pk)]),
    }
    respuesta = cliente.post(url, datos, **HTMX)
    assert respuesta.status_code == 200
    correccion = AtencionClinica.objects.get(corrige=atencion)
    assert correccion.tratamiento == "Onicotomía corregida"
    assert MarcaPie.objects.count() == 1  # el dibujo no se copia
    assert correccion.marcas_agregadas.count() == 0
    registro = RegistroAuditoria.objects.get(accion=RegistroAuditoria.Accion.CORREGIR_ATENCION)
    assert registro.detalle["campos"] == ["tratamiento"]


def test_la_correccion_web_quita_una_marca_con_su_motivo(cita_en_curso):
    profesional = cita_en_curso.profesional
    marca = _marca_en_ficha(cita_en_curso.paciente.ficha, profesional)
    cliente = _cliente(profesional.usuario)
    url = reverse("web:podologo-corregir", args=[marca.atencion_alta.pk])
    datos = {
        "motivo_correccion": "Era el otro pie",
        "tratamiento": marca.atencion_alta.tratamiento,
        "marcas": json.dumps([{**MACERACION, "vista": "planta_izquierdo"}]),
        "dibujo_base": json.dumps([str(marca.pk)]),
    }
    assert cliente.post(url, datos, **HTMX).status_code == 200
    marca.refresh_from_db()
    assert marca.motivo_baja == "Era el otro pie"
    assert marca.atencion_baja.corrige == marca.atencion_alta
    nueva = MarcaPie.objects.get(retirada_en__isnull=True)
    assert nueva.vista == "planta_izquierdo"


def test_el_podologo_deriva_y_el_pdf_queda_disponible(cita_en_curso):
    profesional = cita_en_curso.profesional
    atencion = AtencionClinicaFactory(ficha=cita_en_curso.paciente.ficha, profesional=profesional)
    cliente = _cliente(profesional.usuario)
    respuesta = cliente.post(
        reverse("web:podologo-derivar", args=[atencion.pk]),
        {"especialidad_destino": "dermatologia", "motivo": "Evaluar lesión"},
        **HTMX,
    )
    assert "Dermatología" in json.loads(respuesta["HX-Trigger"])["aviso"]["texto"]
    derivacion = Derivacion.objects.get()
    assert f"/api/derivaciones/{derivacion.pk}/pdf/" in respuesta.content.decode()


def test_otro_podologo_no_corrige_ni_ve_la_atencion(cita_en_curso):
    atencion = AtencionClinicaFactory(
        ficha=cita_en_curso.paciente.ficha, profesional=cita_en_curso.profesional
    )
    intruso = _cliente(ProfesionalFactory().usuario)
    assert (
        intruso.get(reverse("web:podologo-corregir", args=[atencion.pk]), **HTMX).status_code == 404
    )
    assert RegistroAuditoria.objects.filter(
        accion=RegistroAuditoria.Accion.ACCESO_DENEGADO
    ).exists()


def test_el_paciente_ve_su_ficha_con_el_dibujo_solo_lectura(cita_en_curso):
    _marca_en_ficha(cita_en_curso.paciente.ficha, cita_en_curso.profesional)
    contenido = (
        _cliente(cita_en_curso.paciente.usuario).get(reverse("web:paciente-ficha")).content.decode()
    )
    assert contenido.count("data-dibujo-pies") == 1
    assert "Maceración" in contenido
    assert "se agregó Maceración en la planta del pie derecho" in contenido
    assert "data-editable" not in contenido
    assert "Corregir" not in contenido


def test_el_paciente_no_ve_el_dibujo_de_otro(cita_en_curso):
    _marca_en_ficha(cita_en_curso.paciente.ficha, cita_en_curso.profesional)
    otro = PacienteFactory()
    ConsentimientoFactory(paciente=otro)
    FichaClinicaFactory(paciente=otro)
    contenido = _cliente(otro.usuario).get(reverse("web:paciente-ficha")).content.decode()
    assert "Maceración" not in contenido
    assert "Sin marcas en el dibujo." in contenido


# --- agenda, horario e informes ---


def test_la_inasistencia_se_marca_desde_la_agenda(cita_en_curso):
    cliente = _cliente(cita_en_curso.profesional.usuario)
    respuesta = cliente.post(reverse("web:podologo-inasistencia", args=[cita_en_curso.pk]), **HTMX)
    assert respuesta.status_code == 200
    cita_en_curso.refresh_from_db()
    assert cita_en_curso.estado == Cita.Estado.NO_ASISTIO


def test_un_tramo_invalido_muestra_el_error():
    profesional = ProfesionalFactory()
    respuesta = _cliente(profesional.usuario).post(
        reverse("web:podologo-tramo"),
        {"dia_semana": 0, "hora_inicio": "13:00", "hora_fin": "09:00", "activa": "true"},
        **HTMX,
    )
    assert "posterior" in respuesta.content.decode()


def test_el_informe_se_actualiza_por_partes():
    profesional = ProfesionalFactory()
    respuesta = _cliente(profesional.usuario).get(
        reverse("web:informes"), {"desde": "2026-01-01", "hasta": "2026-01-31"}, **HTMX
    )
    contenido = respuesta.content.decode()
    assert "<html" not in contenido  # solo el bloque del informe
    assert "/api/informes/pdf/?desde=2026-01-01&amp;hasta=2026-01-31" in contenido


# --- seguridad del sitio ---


def test_las_paginas_no_permiten_scripts_en_linea():
    respuesta = Client().get(reverse("web:portada"))
    csp = respuesta["Content-Security-Policy"]
    assert "script-src 'self';" in csp + ";"
    assert "unsafe-inline" not in csp.split("script-src")[1].split(";")[0]


def test_htmx_no_guarda_copias_de_las_paginas_en_el_navegador():
    contenido = Client().get(reverse("web:entrar")).content.decode()
    assert '"historyCacheSize": 0' in contenido
    assert "<script>" not in contenido


def test_htmx_sin_sesion_redirige_la_pagina_entera():
    respuesta = Client().get(reverse("web:podologo-agenda"), **HTMX)
    assert respuesta.status_code == 204
    assert respuesta["HX-Redirect"] == reverse("web:entrar")
