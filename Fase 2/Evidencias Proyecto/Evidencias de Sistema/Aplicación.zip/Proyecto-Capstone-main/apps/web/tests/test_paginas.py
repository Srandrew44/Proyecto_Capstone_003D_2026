import re
import uuid
from io import StringIO

import pytest
from django.contrib.staticfiles import finders
from django.core.management import CommandError, call_command
from django.test import Client
from django.urls import reverse

from apps.agenda.models import Cita, Notificacion
from apps.agenda.tests.factories import TratamientoFactory
from apps.auditoria.models import RegistroAuditoria
from apps.clinica.models import AtencionClinica, Derivacion
from apps.cuentas.models import Usuario
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory, UsuarioFactory

pytestmark = pytest.mark.django_db

PAGINAS_PACIENTE = [
    "web:paciente-inicio",
    "web:paciente-reservar",
    "web:paciente-citas",
    "web:paciente-ficha",
    "web:paciente-consentimiento",
    "web:paciente-perfil",
    "web:notificaciones",
]
PAGINAS_PROFESIONAL = [
    "web:podologo-inicio",
    "web:podologo-agenda",
    "web:podologo-pacientes",
    "web:podologo-horario",
    "web:podologo-tratamientos",
    "web:podologo-perfil",
    "web:informes",
    "web:notificaciones",
]


def _cliente(usuario):
    cliente = Client()
    cliente.force_login(usuario)
    return cliente


@pytest.fixture
def paciente():
    return PacienteFactory().usuario


@pytest.fixture
def profesional():
    return ProfesionalFactory().usuario


@pytest.fixture
def admin():
    return UsuarioFactory(rol=Usuario.Rol.ADMIN)


# --- acceso ---


def test_la_portada_y_entrar_son_publicas():
    cliente = Client()
    assert cliente.get(reverse("web:portada")).status_code == 200
    respuesta = cliente.get(reverse("web:entrar"))
    assert respuesta.status_code == 200
    # El formulario lleva su token CSRF.
    assert "csrftoken" in respuesta.cookies


def test_la_portada_muestra_boton_y_dialogo_para_un_tratamiento_con_detalle():
    tratamiento = TratamientoFactory(
        descripcion="Corte y limado.",
        descripcion_detallada="Primero revisamos las uñas.\n\nLuego realizamos el corte.",
    )

    respuesta = Client().get(reverse("web:portada"))

    assert respuesta.status_code == 200
    html = respuesta.content.decode()
    assert "Corte y limado." in html
    assert "Conocer más" in html
    assert f'data-abrir-dialogo="tratamiento-{tratamiento.pk}"' in html
    assert f'<dialog id="tratamiento-{tratamiento.pk}"' in html
    assert "<p>Primero revisamos las uñas.</p>\n\n<p>Luego realizamos el corte.</p>" in html


def test_la_portada_omite_el_boton_cuando_el_tratamiento_no_tiene_detalle():
    tratamiento = TratamientoFactory(descripcion_detallada="")

    respuesta = Client().get(reverse("web:portada"))

    assert respuesta.status_code == 200
    html = respuesta.content.decode()
    assert tratamiento.nombre in html
    assert "Conocer más" not in html
    assert f'<dialog id="tratamiento-{tratamiento.pk}"' not in html


@pytest.mark.parametrize("nombre", [*PAGINAS_PACIENTE, *PAGINAS_PROFESIONAL])
def test_sin_sesion_manda_a_entrar_y_vuelve_a_la_pagina(nombre):
    url = reverse(nombre)
    respuesta = Client().get(url)
    assert respuesta.status_code == 302
    assert respuesta.url == f"{reverse('web:entrar')}?next={url}"


@pytest.mark.parametrize("nombre", PAGINAS_PACIENTE)
def test_el_paciente_ve_sus_paginas(paciente, nombre):
    assert _cliente(paciente).get(reverse(nombre)).status_code == 200


@pytest.mark.parametrize("nombre", PAGINAS_PROFESIONAL)
def test_el_profesional_ve_sus_paginas(profesional, nombre):
    assert _cliente(profesional).get(reverse(nombre)).status_code == 200


def test_la_ficha_de_un_paciente_ajeno_no_existe_y_queda_auditada(profesional):
    paciente = uuid.uuid4()
    url = reverse("web:podologo-ficha", args=[paciente])
    respuesta = _cliente(profesional).get(url)
    assert respuesta.status_code == 404
    registro = RegistroAuditoria.objects.get(accion=RegistroAuditoria.Accion.ACCESO_DENEGADO)
    assert registro.recurso_id == paciente
    assert registro.usuario == profesional


@pytest.mark.parametrize("nombre", PAGINAS_PROFESIONAL[:-2] + ["web:podologo-ficha"])
def test_el_paciente_no_entra_a_paginas_del_profesional(paciente, nombre):
    args = [uuid.uuid4()] if nombre == "web:podologo-ficha" else []
    respuesta = _cliente(paciente).get(reverse(nombre, args=args))
    assert respuesta.status_code == 302
    assert respuesta.url == reverse("web:paciente-inicio")


@pytest.mark.parametrize("nombre", PAGINAS_PACIENTE[:-1])
def test_el_profesional_no_entra_a_paginas_del_paciente(profesional, nombre):
    respuesta = _cliente(profesional).get(reverse(nombre))
    assert respuesta.status_code == 302
    assert respuesta.url == reverse("web:podologo-inicio")


def test_el_administrador_ve_informes_y_no_el_modulo_del_podologo(admin):
    cliente = _cliente(admin)
    respuesta = cliente.get(reverse("web:informes"))
    assert respuesta.status_code == 200
    assert 'id="profesional"' in respuesta.content.decode()  # elige podólogo
    assert cliente.get(reverse("web:podologo-agenda")).url == reverse("web:informes")


@pytest.mark.parametrize(
    ("rol", "destino"),
    [("paciente", "web:paciente-inicio"), ("profesional", "web:podologo-inicio")],
)
def test_mi_panel_y_entrar_llevan_al_inicio_de_cada_rol(request, rol, destino):
    cliente = _cliente(request.getfixturevalue(rol))
    assert cliente.get(reverse("web:mi-panel")).url == reverse(destino)
    assert cliente.get(reverse("web:entrar")).url == reverse(destino)


def test_mi_panel_sin_sesion_manda_a_entrar():
    assert Client().get(reverse("web:mi-panel")).url == reverse("web:entrar")


def test_solo_el_administrador_elige_podologo_en_informes(profesional):
    contenido = _cliente(profesional).get(reverse("web:informes")).content.decode()
    assert 'id="profesional"' not in contenido


# --- contenido ---


def test_los_datos_del_usuario_se_muestran_escapados():
    paciente = PacienteFactory(usuario__nombre="<script>alert(1)</script>").usuario
    contenido = _cliente(paciente).get(reverse("web:paciente-inicio")).content.decode()
    assert "<script>alert(1)</script>" not in contenido
    assert "&lt;script&gt;alert(1)&lt;/script&gt;" in contenido


def test_el_perfil_del_paciente_muestra_sus_datos(paciente):
    contenido = _cliente(paciente).get(reverse("web:paciente-perfil")).content.decode()
    assert paciente.paciente.rut in contenido
    assert paciente.email in contenido


def test_el_menu_cambia_segun_el_rol(paciente, profesional):
    menu_paciente = _cliente(paciente).get(reverse("web:notificaciones")).content.decode()
    menu_profesional = _cliente(profesional).get(reverse("web:notificaciones")).content.decode()
    assert "Reservar hora" in menu_paciente and "Agenda del día" not in menu_paciente
    assert "Agenda del día" in menu_profesional and "Reservar hora" not in menu_profesional


@pytest.mark.parametrize("nombre", [*PAGINAS_PACIENTE, *PAGINAS_PROFESIONAL])
def test_los_archivos_estaticos_de_cada_pagina_existen(paciente, profesional, nombre):
    usuario = paciente if nombre in PAGINAS_PACIENTE else profesional
    contenido = _cliente(usuario).get(reverse(nombre)).content.decode()
    archivos = re.findall(r'(?:src|href)="/static/([^"?]+)', contenido)
    assert archivos
    for archivo in archivos:
        assert finders.find(archivo), archivo


# --- escenario de demostración ---


def test_el_escenario_demo_no_corre_sin_debug(settings):
    settings.DEBUG = False
    with pytest.raises(CommandError):
        call_command("cargar_escenario_demo", stdout=StringIO())


def test_el_escenario_demo_carga_datos_y_no_se_duplica(settings):
    settings.DEBUG = True
    call_command("cargar_escenario_demo", stdout=StringIO())
    assert Usuario.objects.filter(rol=Usuario.Rol.PROFESIONAL).count() == 2
    assert Usuario.objects.filter(rol=Usuario.Rol.PACIENTE).count() == 5
    assert Cita.objects.filter(estado=Cita.Estado.REALIZADA).exists()
    assert AtencionClinica.objects.filter(corrige__isnull=False).count() == 1
    assert Derivacion.objects.count() == 1
    # Las futuras se reservan con el servicio: tienen su correo de confirmación.
    assert Notificacion.objects.filter(tipo=Notificacion.Tipo.RESERVA).exists()
    # Cada atención con cita dejó su cita realizada.
    assert (
        not AtencionClinica.objects.filter(cita__isnull=False)
        .exclude(cita__estado=Cita.Estado.REALIZADA)
        .exists()
    )

    citas = Cita.objects.count()
    salida = StringIO()
    call_command("cargar_escenario_demo", stdout=salida)
    assert "ya estaba cargado" in salida.getvalue()
    assert Cita.objects.count() == citas


def test_el_escenario_demo_con_pagos_activos_deja_las_citas_confirmadas(settings):
    """Con Webpay activo (como en desarrollo y en Render) las citas demo no deben quedar
    esperando un pago que nadie hará, ni chocar con el tope de una reserva sin pagar."""
    settings.DEBUG = True
    settings.PAGOS_WEBPAY_ACTIVO = True
    call_command("cargar_escenario_demo", stdout=StringIO())
    assert Cita.objects.filter(comentarios_paciente="Cita de demostración.").exists()
    assert not Cita.objects.filter(estado=Cita.Estado.PENDIENTE_PAGO).exists()


def test_el_panel_de_administracion_usa_el_diseno_de_mypodo():
    respuesta = Client().get(reverse("admin:login"))
    html = respuesta.content.decode()
    assert "web/css/admin.css" in html
    assert "MyPodo" in html and "Administración" in html
    # Sin modo oscuro: el sitio no lo tiene.
    assert "dark_mode.css" not in html
