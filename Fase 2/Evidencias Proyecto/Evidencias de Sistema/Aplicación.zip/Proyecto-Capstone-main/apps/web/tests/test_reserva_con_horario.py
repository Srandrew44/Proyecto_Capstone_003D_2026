"""Solo se puede reservar con podólogos que tienen horario semanal.

Un podólogo recién creado en el admin no tiene tramos: antes aparecía al reservar y el paciente
veía "No hay horarios libres" sin entender por qué.
"""

import pytest
from django.test import Client
from django.urls import reverse

from apps.agenda.tests.factories import DisponibilidadFactory
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory, UsuarioFactory

pytestmark = pytest.mark.django_db


def _cliente(usuario):
    cliente = Client()
    cliente.force_login(usuario)
    return cliente


@pytest.fixture
def con_horario():
    profesional = ProfesionalFactory(usuario__nombre="Conhorario")
    DisponibilidadFactory(profesional=profesional)
    return profesional


@pytest.fixture
def sin_horario():
    return ProfesionalFactory(usuario__nombre="Sinhorario")


def test_al_reservar_solo_aparecen_los_podologos_con_horario(con_horario, sin_horario):
    pagina = _cliente(PacienteFactory().usuario).get(reverse("web:paciente-reservar"))
    contenido = pagina.content.decode()
    assert f'data-profesional="{con_horario.pk}"' in contenido
    assert f'data-profesional="{sin_horario.pk}"' not in contenido


@pytest.mark.parametrize("con_sesion", [True, False])
def test_el_perfil_publico_sin_horario_no_ofrece_reservar(con_horario, sin_horario, con_sesion):
    cliente = _cliente(PacienteFactory().usuario) if con_sesion else Client()
    sin = cliente.get(reverse("web:profesional-publico", args=[sin_horario.pk])).content.decode()
    assert 'id="sin-horario"' in sin
    assert "Reservar con" not in sin
    assert "Crear cuenta y reservar" not in sin
    con = cliente.get(reverse("web:profesional-publico", args=[con_horario.pk])).content.decode()
    assert 'id="sin-horario"' not in con
    assert ("Reservar con Conhorario" if con_sesion else "Crear cuenta y reservar") in con


def test_el_podologo_sin_horario_ve_un_aviso_para_configurarlo(con_horario, sin_horario):
    sin = _cliente(sin_horario.usuario).get(reverse("web:podologo-inicio")).content.decode()
    assert 'id="aviso-sin-horario"' in sin
    assert reverse("web:podologo-horario") in sin
    con = _cliente(con_horario.usuario).get(reverse("web:podologo-inicio")).content.decode()
    assert 'id="aviso-sin-horario"' not in con


def test_el_admin_muestra_quien_no_tiene_horario_y_permite_cargarlo(sin_horario):
    admin = UsuarioFactory(rol="admin", is_staff=True, is_superuser=True)
    cliente = _cliente(admin)
    lista = cliente.get("/admin/cuentas/profesional/").content.decode()
    assert "con horario" in lista.lower()
    ficha = cliente.get(f"/admin/cuentas/profesional/{sin_horario.pk}/change/").content.decode()
    assert "Horario semanal" in ficha
