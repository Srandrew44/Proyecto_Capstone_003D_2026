"""Comando que protege las cuentas demo en una base publicada (Render + Neon)."""

from io import StringIO

import pytest
from django.core.management import CommandError, call_command

from apps.cuentas.models import Usuario
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory, UsuarioFactory

pytestmark = pytest.mark.django_db
CLAVE_NUEVA = "Tortuga-Marina-8842-zq"


@pytest.fixture
def cuentas():
    demo_paciente = PacienteFactory(usuario__email="ana.demo@example.com")
    demo_podologo = ProfesionalFactory(usuario__email="podologo.demo@example.com")
    real = PacienteFactory(usuario__email="paciente.real@correo.cl")
    admin = UsuarioFactory(
        email="admin@example.com", rol=Usuario.Rol.ADMIN, is_superuser=True, is_staff=True
    )
    return demo_paciente.usuario, demo_podologo.usuario, real.usuario, admin


def test_cambia_la_clave_solo_de_las_cuentas_demo(cuentas, monkeypatch):
    demo_paciente, demo_podologo, real, admin = cuentas
    claves_antes = {u.pk: u.password for u in (real, admin)}
    monkeypatch.setenv("DEMO_CLAVE_NUEVA", CLAVE_NUEVA)
    salida = StringIO()
    call_command("cambiar_claves_demo", stdout=salida)
    assert "2 cuentas demo" in salida.getvalue()
    assert CLAVE_NUEVA not in salida.getvalue()
    for usuario in (demo_paciente, demo_podologo):
        usuario.refresh_from_db()
        assert usuario.check_password(CLAVE_NUEVA)
    for usuario in (real, admin):
        usuario.refresh_from_db()
        assert usuario.password == claves_antes[usuario.pk]


def test_sin_la_variable_o_con_una_clave_debil_no_cambia_nada(cuentas, monkeypatch):
    demo_paciente = cuentas[0]
    antes = demo_paciente.password
    monkeypatch.delenv("DEMO_CLAVE_NUEVA", raising=False)
    with pytest.raises(CommandError, match="DEMO_CLAVE_NUEVA"):
        call_command("cambiar_claves_demo", stdout=StringIO())
    monkeypatch.setenv("DEMO_CLAVE_NUEVA", "12345678")
    with pytest.raises(CommandError, match="no es segura"):
        call_command("cambiar_claves_demo", stdout=StringIO())
    demo_paciente.refresh_from_db()
    assert demo_paciente.password == antes


def test_desactivar_bloquea_solo_las_cuentas_demo(cuentas):
    demo_paciente, demo_podologo, real, admin = cuentas
    call_command("cambiar_claves_demo", "--desactivar", stdout=StringIO())
    for usuario in (demo_paciente, demo_podologo):
        usuario.refresh_from_db()
        assert not usuario.is_active
    for usuario in (real, admin):
        usuario.refresh_from_db()
        assert usuario.is_active
