"""Fechas imposibles en la URL y cuentas sin perfil: nunca un error 500 ni un bucle."""

import pytest
from django.contrib.messages import get_messages
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from apps.agenda.tests.factories import DisponibilidadFactory, TratamientoFactory
from apps.clinica.tests.factories import ConsentimientoFactory
from apps.cuentas.models import Usuario
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory, UsuarioFactory
from apps.web.vistas.comun import CUENTA_INCOMPLETA

pytestmark = pytest.mark.django_db


# --- fechas imposibles ---


@pytest.fixture
def reserva():
    """Paciente con sesión y la URL de reservar con podólogo y tratamiento ya elegidos."""
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    tratamiento = TratamientoFactory()
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente)
    cliente = Client()
    cliente.force_login(paciente.usuario)
    url = reverse("web:paciente-reservar")
    return cliente, f"{url}?profesional={profesional.pk}&tratamiento={tratamiento.pk}"


@pytest.mark.parametrize(
    "extra",
    [
        "&mes=2030-13",  # mes 13
        "&mes=2030-00",
        "&dia=2030-02-30",  # 30 de febrero
        "&dia=2030-04-31",
        "&inicio=2030-02-30T10:00:00-03:00",
        "&inicio=2030-01-07T25:00:00-03:00",  # hora 25
        "&inicio=2030-01-07T10:00:00%2B99:00",  # zona horaria imposible
    ],
)
def test_reservar_con_una_fecha_imposible_usa_el_valor_por_defecto(reserva, extra):
    cliente, url = reserva
    normal = cliente.get(url)
    respuesta = cliente.get(url + extra)
    assert respuesta.status_code == 200
    cal, cal_normal = respuesta.context["cal"], normal.context["cal"]
    assert cal["sin_horas"] is False
    assert (cal["mes"], cal["dia"], cal["elegido"]) == (cal_normal["mes"], cal_normal["dia"], None)


@pytest.mark.parametrize("fecha", ["2030-02-30", "2030-13-01", "2030-00-10", "no-es-fecha"])
def test_la_agenda_del_podologo_con_fecha_imposible_muestra_hoy(fecha):
    cliente = Client()
    cliente.force_login(ProfesionalFactory().usuario)
    respuesta = cliente.get(reverse("web:podologo-agenda"), {"fecha": fecha})
    assert respuesta.status_code == 200
    assert respuesta.context["fecha"] == timezone.localdate()


# --- cuentas sin perfil ---


PAGINAS = ["web:mi-panel", "web:informes", "web:notificaciones", "web:entrar"]


@pytest.fixture(params=[Usuario.Rol.PACIENTE, Usuario.Rol.PROFESIONAL])
def sin_perfil(request):
    """Usuario con rol de paciente o profesional, pero sin su Paciente/Profesional."""
    cliente = Client()
    cliente.force_login(UsuarioFactory(rol=request.param))
    return cliente, request.param


def _inicio(rol):
    return {Usuario.Rol.PACIENTE: "web:paciente-inicio"}.get(rol, "web:podologo-inicio")


@pytest.mark.parametrize("nombre", PAGINAS)
def test_una_cuenta_sin_perfil_termina_en_entrar_con_un_aviso_y_sin_bucle(sin_perfil, nombre):
    cliente, rol = sin_perfil
    respuesta = cliente.get(reverse(nombre), follow=True)
    # follow=True se detiene con un error si hay un bucle de redirecciones.
    assert respuesta.status_code == 200
    assert respuesta.redirect_chain[-1][0] == reverse("web:entrar")
    assert len(respuesta.redirect_chain) <= 3
    assert CUENTA_INCOMPLETA in [str(m) for m in get_messages(respuesta.wsgi_request)]
    assert "_auth_user_id" not in cliente.session


def test_la_pagina_de_inicio_del_rol_no_redirige_a_si_misma(sin_perfil):
    cliente, rol = sin_perfil
    respuesta = cliente.get(reverse(_inicio(rol)))
    assert respuesta.status_code == 302
    assert respuesta.url == reverse("web:entrar")


def test_con_htmx_una_cuenta_sin_perfil_recarga_en_entrar(sin_perfil):
    cliente, rol = sin_perfil
    respuesta = cliente.get(reverse(_inicio(rol)), HTTP_HX_REQUEST="true")
    assert respuesta.status_code == 204
    assert respuesta["HX-Redirect"] == reverse("web:entrar")
