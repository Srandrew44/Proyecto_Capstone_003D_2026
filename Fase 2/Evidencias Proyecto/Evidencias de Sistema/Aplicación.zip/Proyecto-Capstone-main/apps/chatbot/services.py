"""Casos de uso del asistente: enviar un mensaje, límites de uso y retención de fotos."""

from datetime import timedelta

from django.conf import settings
from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from apps.agenda import selectors as agenda
from apps.auditoria.models import RegistroAuditoria
from apps.auditoria.services import registrar
from apps.clinica.models import Consentimiento, FichaClinica
from apps.clinica.services import exigir_consentimiento

from . import clasificadores
from .fotos import limpiar_foto
from .models import ConversacionChatbot, FotoChatbot, InteraccionChatbot
from .privacidad import anonimizar

MENSAJE_MAX = 1500
TURNOS_DE_CONTEXTO = 8  # cuántos intercambios anteriores ve el modelo
FOTOS_DE_CONTEXTO = 2  # de esos, cuántas fotos se reenvían (las más recientes)


class LimiteAlcanzado(Exception):
    """Se superó la cantidad de mensajes por hora."""


# --- datos para el asistente ---


def datos_consulta() -> str:
    """Lo que el asistente puede contar de la consulta. Sale de la base, no se inventa."""
    consulta = agenda.datos_consulta()
    lineas = [f"Nombre: {consulta['nombre']}"]
    direccion = ", ".join(x for x in (consulta.get("direccion"), consulta.get("comuna")) if x)
    lineas.append(f"Dirección: {direccion or 'consultar en la clínica'}")
    if consulta.get("indicaciones"):
        lineas.append(f"Cómo llegar: {consulta['indicaciones']}")
    lineas.append("Atención solo en la consulta (no hay atención a domicilio).")
    lineas.append("Tratamientos:")
    for t in agenda.tratamientos_activos():
        precio = f"${t.precio:,}".replace(",", ".")
        lineas.append(f"- {t.nombre}: {precio}, {t.duracion_min} min. {t.descripcion}".strip())
    podologos = [
        f"{p.usuario.nombre} {p.usuario.apellido} ({p.especialidad})"
        for p in agenda.profesionales_activos()
    ]
    if podologos:
        lineas.append("Podólogos: " + "; ".join(podologos))
    lineas += [
        f"Reserva en línea con al menos {settings.AGENDA_ANTICIPACION_MIN_HORAS} horas de "
        f"anticipación y hasta {settings.AGENDA_HORIZONTE_DIAS} días adelante.",
        "Pago en línea al reservar con Webpay (débito, crédito o prepago).",
        f"Cancelar o cambiar la hora: desde «Mis citas» hasta "
        f"{settings.AGENDA_CANCELACION_MIN_HORAS} horas antes; si estaba pagada, se devuelve "
        "el pago automáticamente.",
        "Recordatorio por correo 48 horas antes de la cita.",
    ]
    return "\n".join(lineas)


SI_NO = {True: "sí", False: "no"}


def antecedentes_de(paciente) -> str:
    """Antecedentes útiles para orientar, sin nada que identifique al paciente."""
    ficha = FichaClinica.objects.filter(paciente=paciente).first()
    lineas = [f"Rango de edad: {_rango_edad(paciente.edad)}"]
    if ficha:
        campos = [
            ("Diabetes", ficha.diabetes),
            ("Hipertensión", ficha.hta),
            ("Várices", ficha.varices),
            ("Úlcera previa", ficha.ulcera_previa),
            ("Úlcera actual", ficha.ulcera_actual),
            ("Amputaciones", ficha.amputaciones),
            ("Camina con ayuda", ficha.camina_con_ayuda),
        ]
        lineas += [f"{nombre}: {SI_NO[valor]}" for nombre, valor in campos if valor is not None]
    return "\n".join(lineas)


def _rango_edad(edad: int) -> str:
    if edad < 18:
        return "menor de 18"
    if edad >= 65:
        return "65 o más"
    inicio = edad // 10 * 10
    return f"{inicio}-{inicio + 9}"


# --- conversación ---


def puede_usar_fotos(usuario) -> bool:
    """Triaje con fotos: paciente con el consentimiento `uso_chatbot` vigente."""
    if not (usuario.is_authenticated and hasattr(usuario, "paciente")):
        return False
    return Consentimiento.objects.filter(
        paciente_id=usuario.pk, tipo=Consentimiento.Tipo.USO_CHATBOT, revocado_en__isnull=True
    ).exists()


def conversacion_para(usuario, conversacion_id=None) -> ConversacionChatbot:
    """La conversación abierta del usuario (o del visitante, por el id de su sesión)."""
    paciente = usuario.paciente if puede_usar_fotos(usuario) else None
    if conversacion_id:
        existente = ConversacionChatbot.objects.filter(pk=conversacion_id).first()
        # Un visitante no puede retomar la conversación de un paciente, ni al revés.
        if existente and existente.paciente_id == (paciente.pk if paciente else None):
            return existente
    return ConversacionChatbot.objects.create(paciente=paciente)


def _exigir_limite(usuario, clave_visitante: str, ip=None) -> None:
    if usuario.is_authenticated:
        topes = [(f"chatbot:u:{usuario.pk}", settings.CHATBOT_LIMITE_PACIENTE_HORA)]
    else:
        # Por sesión y por IP: quien no guarda la cookie recibe una sesión nueva en cada
        # mensaje, pero no una IP nueva. Sin IP conocida, todos comparten un mismo tope.
        topes = [
            (f"chatbot:v:{clave_visitante}", settings.CHATBOT_LIMITE_VISITANTE_HORA),
            (f"chatbot:ip:{ip or 'sin-ip'}", settings.CHATBOT_LIMITE_IP_HORA),
        ]
    for clave, limite in topes:
        cache.add(clave, 0, timeout=3600)
        if cache.incr(clave) > limite:
            raise LimiteAlcanzado(
                "Alcanzaste el máximo de mensajes por hora. Inténtalo más tarde o comunícate "
                "con la consulta."
            )


def enviar_mensaje(
    *, usuario, conversacion, texto="", foto=None, clave_visitante="", ip=None
) -> InteraccionChatbot:
    """Procesa un mensaje y guarda la interacción con su respuesta.

    Las fotos solo se aceptan de un paciente con el consentimiento `uso_chatbot` vigente.
    El texto se guarda y se envía al modelo sin RUT, correos ni teléfonos.
    """
    texto = (texto or "").strip()
    if not texto and foto is None:
        raise ValidationError("Escribe un mensaje o adjunta una foto.")
    if len(texto) > MENSAJE_MAX:
        raise ValidationError(f"El mensaje no puede superar los {MENSAJE_MAX} caracteres.")
    paciente = conversacion.paciente
    if foto is not None:
        if paciente is None:
            raise ValidationError("Para enviar fotos debes entrar con tu cuenta de paciente.")
        exigir_consentimiento(paciente, Consentimiento.Tipo.USO_CHATBOT)
        foto = limpiar_foto(foto)
    _exigir_limite(usuario, clave_visitante, ip)

    consulta = anonimizar(texto)
    contexto = clasificadores.Contexto(
        mensaje=consulta,
        es_paciente=paciente is not None,
        datos_consulta=datos_consulta(),
        antecedentes=antecedentes_de(paciente) if paciente else "",
        foto=foto,
        historial=_historial(conversacion),
    )
    resultado = clasificadores.responder(contexto)

    with transaction.atomic():
        interaccion = InteraccionChatbot.objects.create(
            conversacion=conversacion,
            paciente=paciente,
            tipo=resultado.tipo,
            consulta=consulta,
            con_foto=foto is not None,
            respuesta=resultado.respuesta,
            categoria_triaje=resultado.categoria,
            requiere_derivacion=resultado.requiere_derivacion,
            motivo_derivacion=resultado.motivo_derivacion,
            sugerir_reserva=resultado.sugerir_reserva,
            implementacion=resultado.implementacion,
            latencia_ms=resultado.latencia_ms,
        )
        if foto is not None:
            FotoChatbot.objects.create(interaccion=interaccion, contenido=foto)
        conversacion.save(update_fields=["actualizada_en"])
        if paciente is not None:
            registrar(
                accion=RegistroAuditoria.Accion.CONSULTA_CHATBOT,
                usuario=usuario,
                recurso_tipo="interaccion_chatbot",
                recurso_id=interaccion.pk,
                ip=ip,
                detalle={"categoria": resultado.categoria, "con_foto": foto is not None},
            )
    return interaccion


def _historial(conversacion) -> list[clasificadores.Turno]:
    previas = list(
        conversacion.interacciones.select_related("foto").order_by("-creada_en")[
            :TURNOS_DE_CONTEXTO
        ]
    )
    previas.reverse()
    con_foto = [i for i in previas if hasattr(i, "foto")][-FOTOS_DE_CONTEXTO:]
    return [
        clasificadores.Turno(
            consulta=i.consulta,
            respuesta=i.respuesta,
            foto=bytes(i.foto.contenido) if i in con_foto else None,
        )
        for i in previas
    ]


def borrar_fotos_vencidas(*, ahora=None) -> int:
    """Tarea periódica: borra las fotos con más de CHATBOT_RETENCION_FOTOS_DIAS días."""
    limite = (ahora or timezone.now()) - timedelta(days=settings.CHATBOT_RETENCION_FOTOS_DIAS)
    borradas, _ = FotoChatbot.objects.filter(creada_en__lt=limite).delete()
    return borradas
