"""Asistente virtual: privacidad, fotos, clasificadores (Claude simulado y reglas) y servicios."""

import io
from datetime import timedelta

import pytest
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.utils import timezone
from PIL import Image

from apps.agenda.tests.factories import TratamientoFactory
from apps.auditoria.models import RegistroAuditoria
from apps.chatbot import clasificadores, conocimiento, services
from apps.chatbot.models import FotoChatbot, InteraccionChatbot
from apps.chatbot.privacidad import anonimizar
from apps.clinica.models import Consentimiento
from apps.clinica.services import ConsentimientoRequerido
from apps.clinica.tests.factories import ConsentimientoFactory, FichaClinicaFactory
from apps.cuentas.tests.factories import PacienteFactory
from integraciones import asistente_ia

pytestmark = pytest.mark.django_db
Categoria = InteraccionChatbot.Categoria


def foto_png(ancho=50, alto=40, exif_gps=False):
    salida = io.BytesIO()
    imagen = Image.new("RGB", (ancho, alto), (200, 150, 120))
    imagen.save(salida, format="PNG")
    return SimpleUploadedFile("pie.png", salida.getvalue(), content_type="image/png")


@pytest.fixture
def paciente_con_asistente():
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente, tipo=Consentimiento.Tipo.USO_CHATBOT)
    return paciente


@pytest.fixture
def claude_falso(monkeypatch, settings):
    """Simula Claude: registra lo que recibe y devuelve la respuesta indicada."""
    settings.ANTHROPIC_API_KEY = "clave-de-prueba"
    llamadas = []
    estado = {
        "respuesta": {
            "respuesta": "Podría ser una uña con hongo. Conviene que la evalúe el podólogo.",
            "tipo": "triaje",
            "categoria_triaje": "podologia",
            "requiere_derivacion": False,
            "motivo_derivacion": "",
            "sugerir_reserva": True,
        },
        "error": None,
    }

    def consultar(*, sistema, mensajes, esquema):
        llamadas.append({"sistema": sistema, "mensajes": mensajes})
        if estado["error"]:
            raise asistente_ia.ErrorModelo(estado["error"])
        return estado["respuesta"]

    monkeypatch.setattr(asistente_ia, "consultar", consultar)
    estado["llamadas"] = llamadas
    return estado


def _enviar(usuario, conversacion, texto="", foto=None):
    return services.enviar_mensaje(
        usuario=usuario, conversacion=conversacion, texto=texto, foto=foto, clave_visitante="v1"
    )


# --- privacidad y fotos ---


@pytest.mark.parametrize(
    ("texto", "queda"),
    [
        ("mi rut es 12.345.678-5 y me duele", "mi rut es [dato omitido] y me duele"),
        ("escríbeme a ana@correo.cl", "escríbeme a [dato omitido]"),
        ("llámame al +56 9 1234 5678", "llámame al [dato omitido]"),
        ("tengo la uña negra hace 3 días", "tengo la uña negra hace 3 días"),
    ],
)
def test_anonimizar_quita_rut_correo_y_telefono(texto, queda):
    assert anonimizar(texto) == queda


def test_la_foto_se_recodifica_en_jpeg_y_se_achica():
    from apps.chatbot.fotos import limpiar_foto

    datos = limpiar_foto(foto_png(3000, 2000))
    imagen = Image.open(io.BytesIO(datos))
    assert imagen.format == "JPEG"
    assert max(imagen.size) == 1568
    assert not imagen.getexif()


def test_un_archivo_que_no_es_foto_se_rechaza():
    from apps.chatbot.fotos import limpiar_foto

    falso = SimpleUploadedFile("pie.jpg", b"no soy una imagen", content_type="image/jpeg")
    with pytest.raises(ValidationError, match="no es una foto"):
        limpiar_foto(falso)


def test_una_foto_demasiado_pesada_se_rechaza(settings):
    from apps.chatbot.fotos import limpiar_foto

    settings.CHATBOT_FOTO_MAX_MB = 0
    with pytest.raises(ValidationError, match="no puede pesar"):
        limpiar_foto(foto_png())


# --- reglas (sin clave de API) ---


def _reglas(mensaje, es_paciente=True, antecedentes="", foto=None):
    return clasificadores.ClasificadorReglas().responder(
        clasificadores.Contexto(
            mensaje=mensaje,
            es_paciente=es_paciente,
            datos_consulta="Dirección: Calle 1\n- Podología básica: $20.000",
            antecedentes=antecedentes,
            foto=foto,
        )
    )


@pytest.mark.parametrize(
    "mensaje",
    [
        "tengo fiebre y el dedo está rojo",
        "la herida tiene pus",
        "le sale pus a la uña",
        "el dedo se puso negro",
        "no puedo apoyar el pie después de caerme",
    ],
)
def test_las_senales_de_alarma_llevan_a_urgencia(mensaje):
    resultado = _reglas(mensaje)
    assert resultado.categoria == Categoria.URGENCIA
    assert resultado.requiere_derivacion
    assert "urgencia" in resultado.respuesta


def test_herida_con_diabetes_en_la_ficha_es_urgencia():
    assert _reglas("tengo una herida en la planta").categoria != Categoria.URGENCIA
    resultado = _reglas("tengo una herida en la planta", antecedentes="Diabetes: sí")
    assert resultado.categoria == Categoria.URGENCIA


def test_la_alarma_tambien_se_avisa_al_visitante():
    assert _reglas("tengo fiebre y pus en el pie", es_paciente=False).categoria == (
        Categoria.URGENCIA
    )


@pytest.mark.parametrize(
    ("mensaje", "categoria"),
    [
        ("tengo un lunar en el pie que cambió de color", Categoria.DERMATOLOGIA),
        ("me torcí el tobillo y me duele", Categoria.TRAUMATOLOGIA),
        ("tengo la uña gruesa y amarilla", Categoria.PODOLOGIA),
    ],
)
def test_las_reglas_orientan_sin_diagnosticar(mensaje, categoria):
    resultado = _reglas(mensaje)
    assert resultado.categoria == categoria
    assert resultado.tipo == InteraccionChatbot.Tipo.TRIAJE


def test_un_visitante_con_sintomas_es_invitado_a_entrar():
    resultado = _reglas("tengo la uña gruesa y amarilla", es_paciente=False)
    assert resultado.categoria == Categoria.SIN_TRIAJE
    assert "entra con tu cuenta" in resultado.respuesta


def test_las_preguntas_frecuentes_usan_los_datos_reales():
    resultado = _reglas("¿cuánto cuesta?")
    assert resultado.tipo == InteraccionChatbot.Tipo.FAQ
    assert "$20.000" in resultado.respuesta


# --- Claude (simulado) ---


def test_sin_clave_responde_por_reglas(paciente_con_asistente):
    conversacion = services.conversacion_para(paciente_con_asistente.usuario)
    interaccion = _enviar(paciente_con_asistente.usuario, conversacion, "tengo un callo")
    assert interaccion.implementacion == InteraccionChatbot.Implementacion.REGLAS


def test_con_clave_responde_claude_con_la_foto_y_sin_datos_personales(
    claude_falso, paciente_con_asistente
):
    FichaClinicaFactory(paciente=paciente_con_asistente, diabetes=True)
    usuario = paciente_con_asistente.usuario
    usuario.nombre, usuario.apellido = "Xiomara", "Quintanilla"
    usuario.save()
    conversacion = services.conversacion_para(usuario)
    interaccion = _enviar(
        usuario, conversacion, "mi rut es 12.345.678-5, mira mi uña", foto=foto_png()
    )
    assert interaccion.implementacion == InteraccionChatbot.Implementacion.MODELO
    assert interaccion.categoria_triaje == Categoria.PODOLOGIA
    assert interaccion.sugerir_reserva
    assert FotoChatbot.objects.filter(interaccion=interaccion).exists()

    llamada = claude_falso["llamadas"][0]
    contenido = llamada["mensajes"][-1]["content"]
    assert contenido[0]["type"] == "image"
    assert contenido[0]["source"]["media_type"] == "image/jpeg"
    enviado = str(llamada)
    assert "12.345.678-5" not in enviado
    assert "Xiomara" not in enviado and "Quintanilla" not in enviado
    assert usuario.email not in enviado
    assert "Diabetes: sí" in enviado
    # La base de conocimientos va en el bloque estable, en caché.
    assert llamada["sistema"][0]["cache_control"] == {"type": "ephemeral"}
    assert "SEÑALES DE ALARMA" in llamada["sistema"][0]["text"]
    assert "PROBLEMAS DE LAS UÑAS" in llamada["sistema"][0]["text"]


def test_la_seccion_de_unas_deriva_las_manchas_oscuras_sin_golpe_al_dermatologo():
    # La única señal de una posible lesión maligna de la uña: no debe perderse al editar.
    texto = conocimiento.texto_completo()
    assert "versión 2" in texto
    bloque = conocimiento.UNAS
    inicio = bloque.index("Raya o banda oscura")
    assert "DERMATÓLOGO" in bloque[inicio : bloque.index("\n- ", inicio)]
    # Es un resumen propio: no indica medicamentos ni dosis.
    assert "mg" not in bloque and "terbinafina" not in bloque.lower()


def test_el_modelo_recibe_el_historial_para_preguntas_de_seguimiento(
    claude_falso, paciente_con_asistente
):
    usuario = paciente_con_asistente.usuario
    conversacion = services.conversacion_para(usuario)
    _enviar(usuario, conversacion, "me duele la uña", foto=foto_png())
    _enviar(usuario, conversacion, "desde hace un mes, sin fiebre")
    mensajes = claude_falso["llamadas"][1]["mensajes"]
    assert [m["role"] for m in mensajes] == ["user", "assistant", "user"]
    assert mensajes[0]["content"][0]["type"] == "image"  # la foto anterior se reenvía


def test_si_claude_falla_responde_por_reglas(claude_falso, paciente_con_asistente):
    claude_falso["error"] = "timeout"
    usuario = paciente_con_asistente.usuario
    conversacion = services.conversacion_para(usuario)
    interaccion = _enviar(usuario, conversacion, "tengo la uña gruesa", foto=foto_png())
    assert interaccion.implementacion == InteraccionChatbot.Implementacion.REGLAS
    assert "no puedo analizarla" in interaccion.respuesta


def test_la_red_de_seguridad_corrige_si_claude_no_ve_la_alarma(
    claude_falso, paciente_con_asistente
):
    usuario = paciente_con_asistente.usuario
    conversacion = services.conversacion_para(usuario)
    interaccion = _enviar(usuario, conversacion, "tengo fiebre y la uña con pus")
    assert interaccion.categoria_triaje == Categoria.URGENCIA
    assert interaccion.respuesta.startswith("⚠️")


@pytest.mark.parametrize(
    "mensaje",
    [
        "tengo una raya negra a lo largo de la uña",
        "se me puso morada la uña después de correr",
        "tengo las unas negras despues de correr",
    ],
)
def test_un_color_oscuro_solo_en_la_una_lo_decide_claude(
    mensaje, claude_falso, paciente_con_asistente
):
    # Una raya oscura o un hematoma bajo la uña no es urgencia por sí solo; Claude orienta
    # con la sección de uñas (dermatólogo o podólogo) y la red de seguridad no lo pisa.
    usuario = paciente_con_asistente.usuario
    interaccion = _enviar(usuario, services.conversacion_para(usuario), mensaje)
    assert interaccion.categoria_triaje == Categoria.PODOLOGIA
    assert not interaccion.respuesta.startswith("⚠️")


@pytest.mark.parametrize(
    "mensaje",
    [
        "el dedo se puso negro",
        "tengo la uña negra y el dedo frío",
        "la uña y la piel del dedo están moradas",
        "tengo una herida negra en el talón",
        "tengo la uña negra y el dedo está oscuro",
        "uña morada y piel oscura",
        "la uña negra y el dedo gris",
        "tengo unas manchas negras en el pie",
    ],
)
def test_un_dedo_o_la_piel_de_color_oscuro_sigue_siendo_alarma(
    mensaje, claude_falso, paciente_con_asistente
):
    usuario = paciente_con_asistente.usuario
    interaccion = _enviar(usuario, services.conversacion_para(usuario), mensaje)
    assert interaccion.categoria_triaje == Categoria.URGENCIA


def test_sin_claude_un_color_oscuro_en_la_una_sigue_siendo_alarma():
    # Las reglas no distinguen matices: ante la duda, urgencia.
    assert _reglas("tengo la uña negra").categoria == Categoria.URGENCIA


# --- servicios ---


def test_un_visitante_no_puede_enviar_fotos(django_user_model):
    from django.contrib.auth.models import AnonymousUser

    conversacion = services.conversacion_para(AnonymousUser())
    assert conversacion.paciente is None
    with pytest.raises(ValidationError, match="cuenta de paciente"):
        _enviar(AnonymousUser(), conversacion, "mira", foto=foto_png())


def test_sin_consentimiento_el_paciente_queda_en_modo_preguntas():
    paciente = PacienteFactory()
    conversacion = services.conversacion_para(paciente.usuario)
    assert conversacion.paciente is None
    assert not services.puede_usar_fotos(paciente.usuario)


def test_las_fotos_exigen_el_consentimiento_vigente(paciente_con_asistente):
    usuario = paciente_con_asistente.usuario
    conversacion = services.conversacion_para(usuario)
    Consentimiento.objects.filter(paciente=paciente_con_asistente).update(
        revocado_en=timezone.now()
    )
    with pytest.raises(ConsentimientoRequerido):
        _enviar(usuario, conversacion, "mira", foto=foto_png())


def test_un_visitante_no_retoma_la_conversacion_de_un_paciente(paciente_con_asistente):
    from django.contrib.auth.models import AnonymousUser

    ajena = services.conversacion_para(paciente_con_asistente.usuario)
    propia = services.conversacion_para(AnonymousUser(), str(ajena.pk))
    assert propia.pk != ajena.pk


def test_el_limite_por_hora_frena_los_mensajes(settings, paciente_con_asistente):
    settings.CHATBOT_LIMITE_PACIENTE_HORA = 2
    usuario = paciente_con_asistente.usuario
    conversacion = services.conversacion_para(usuario)
    _enviar(usuario, conversacion, "hola")
    _enviar(usuario, conversacion, "hola")
    with pytest.raises(services.LimiteAlcanzado):
        _enviar(usuario, conversacion, "hola")


def test_un_visitante_que_cambia_de_sesion_igual_topa_el_limite_por_ip(settings):
    """Sin guardar la cookie cada mensaje llega con una sesión nueva, pero desde la misma IP."""
    from django.contrib.auth.models import AnonymousUser

    settings.CHATBOT_LIMITE_IP_HORA = 3
    visitante = AnonymousUser()
    for n in range(3):
        conversacion = services.conversacion_para(visitante)
        services.enviar_mensaje(
            usuario=visitante,
            conversacion=conversacion,
            texto="hola",
            clave_visitante=f"sesion-{n}",
            ip="203.0.113.7",
        )
    with pytest.raises(services.LimiteAlcanzado):
        services.enviar_mensaje(
            usuario=visitante,
            conversacion=services.conversacion_para(visitante),
            texto="hola",
            clave_visitante="sesion-nueva",
            ip="203.0.113.7",
        )
    # Otra IP no se ve afectada.
    services.enviar_mensaje(
        usuario=visitante,
        conversacion=services.conversacion_para(visitante),
        texto="hola",
        clave_visitante="otra",
        ip="198.51.100.9",
    )


def test_mensaje_vacio_o_muy_largo_se_rechaza(paciente_con_asistente):
    usuario = paciente_con_asistente.usuario
    conversacion = services.conversacion_para(usuario)
    with pytest.raises(ValidationError):
        _enviar(usuario, conversacion, "   ")
    with pytest.raises(ValidationError):
        _enviar(usuario, conversacion, "a" * 1501)


def test_la_consulta_del_paciente_queda_en_la_auditoria_sin_texto(paciente_con_asistente):
    usuario = paciente_con_asistente.usuario
    conversacion = services.conversacion_para(usuario)
    interaccion = _enviar(usuario, conversacion, "tengo un callo que duele")
    registro = RegistroAuditoria.objects.get(accion=RegistroAuditoria.Accion.CONSULTA_CHATBOT)
    assert str(registro.recurso_id) == str(interaccion.pk)
    assert "callo" not in str(registro.detalle)


def test_las_fotos_se_borran_al_vencer_el_plazo(paciente_con_asistente):
    usuario = paciente_con_asistente.usuario
    conversacion = services.conversacion_para(usuario)
    interaccion = _enviar(usuario, conversacion, "mira", foto=foto_png())
    ahora = timezone.now()
    assert services.borrar_fotos_vencidas(ahora=ahora + timedelta(days=6)) == 0
    assert services.borrar_fotos_vencidas(ahora=ahora + timedelta(days=8)) == 1
    interaccion.refresh_from_db()
    assert interaccion.con_foto  # el registro de que hubo foto se conserva


def test_los_datos_de_la_consulta_vienen_de_la_base():
    TratamientoFactory(nombre="Uña encarnada", precio=25000, duracion_min=30)
    texto = services.datos_consulta()
    assert "Uña encarnada: $25.000, 30 min" in texto
