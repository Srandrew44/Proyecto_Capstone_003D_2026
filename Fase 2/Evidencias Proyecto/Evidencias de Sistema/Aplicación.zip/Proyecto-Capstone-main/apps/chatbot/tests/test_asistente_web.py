"""Página del asistente: visitantes, pacientes, consentimiento, fotos y permisos."""

import pytest
from django.test import Client
from django.urls import reverse

from apps.chatbot.models import FotoChatbot, InteraccionChatbot
from apps.clinica.models import Consentimiento
from apps.clinica.tests.factories import ConsentimientoFactory
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory

from .test_asistente import foto_png

pytestmark = pytest.mark.django_db
HTMX = {"HTTP_HX_REQUEST": "true"}


def _cliente(usuario=None):
    cliente = Client()
    if usuario:
        cliente.force_login(usuario)
    return cliente


def test_el_visitante_ve_el_asistente_sin_fotos():
    html = _cliente().get(reverse("web:asistente")).content.decode()
    assert "Asistente virtual" in html
    assert "No es un diagnóstico" in html
    assert 'name="foto"' not in html
    assert "Entra con tu cuenta" in html


def test_el_visitante_pregunta_y_recibe_respuesta():
    cliente = _cliente()
    cliente.get(reverse("web:asistente"))
    respuesta = cliente.post(
        reverse("web:asistente-enviar"), {"mensaje": "¿dónde están ubicados?"}, **HTMX
    )
    html = respuesta.content.decode()
    assert respuesta.status_code == 200
    assert "burbuja-usuario" in html and "burbuja-asistente" in html
    interaccion = InteraccionChatbot.objects.get()
    assert interaccion.paciente is None


def test_el_paciente_acepta_el_consentimiento_y_puede_enviar_fotos():
    paciente = PacienteFactory()
    cliente = _cliente(paciente.usuario)
    html = cliente.get(reverse("web:asistente")).content.decode()
    assert "Activa la orientación con fotos" in html
    assert 'name="foto"' not in html
    cliente.post(reverse("web:asistente-aceptar"), {"acepto": "si"})
    assert Consentimiento.objects.filter(
        paciente=paciente, tipo=Consentimiento.Tipo.USO_CHATBOT, revocado_en__isnull=True
    ).exists()
    html = cliente.get(reverse("web:asistente")).content.decode()
    assert 'name="foto"' in html
    respuesta = cliente.post(
        reverse("web:asistente-enviar"),
        {"mensaje": "tengo la uña gruesa", "foto": foto_png()},
        **HTMX,
    )
    html = respuesta.content.decode()
    foto = FotoChatbot.objects.get()
    assert reverse("web:asistente-foto", args=[foto.pk]) in html
    assert "Reservar hora" in html


def test_la_foto_solo_la_ve_su_dueno():
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente, tipo=Consentimiento.Tipo.USO_CHATBOT)
    cliente = _cliente(paciente.usuario)
    cliente.get(reverse("web:asistente"))
    cliente.post(reverse("web:asistente-enviar"), {"mensaje": "mira", "foto": foto_png()}, **HTMX)
    url = reverse("web:asistente-foto", args=[FotoChatbot.objects.get().pk])
    propia = cliente.get(url)
    assert propia.status_code == 200
    assert propia["Content-Type"] == "image/jpeg"
    assert _cliente(PacienteFactory().usuario).get(url).status_code == 404
    assert _cliente().get(url).status_code == 404


def test_un_error_se_muestra_como_mensaje():
    cliente = _cliente()
    cliente.get(reverse("web:asistente"))
    respuesta = cliente.post(reverse("web:asistente-enviar"), {"mensaje": ""}, **HTMX)
    assert respuesta.status_code == 200
    assert 'role="alert"' in respuesta.content.decode()


def test_nueva_conversacion_empieza_de_cero():
    cliente = _cliente()
    cliente.get(reverse("web:asistente"))
    cliente.post(reverse("web:asistente-enviar"), {"mensaje": "hola"}, **HTMX)
    cliente.post(reverse("web:asistente-nueva"))
    html = cliente.get(reverse("web:asistente")).content.decode()
    assert "burbuja-usuario" not in html


def test_el_podologo_no_usa_el_asistente_de_pacientes():
    respuesta = _cliente(ProfesionalFactory().usuario).get(reverse("web:asistente"))
    assert respuesta.status_code == 302


def test_la_portada_y_el_menu_enlazan_al_asistente():
    assert reverse("web:asistente") in _cliente().get(reverse("web:portada")).content.decode()
    paciente = PacienteFactory()
    html = _cliente(paciente.usuario).get(reverse("web:paciente-inicio")).content.decode()
    assert reverse("web:asistente") in html


def test_el_paciente_puede_retirar_la_autorizacion():
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente, tipo=Consentimiento.Tipo.USO_CHATBOT)
    cliente = _cliente(paciente.usuario)
    assert 'name="foto"' in cliente.get(reverse("web:asistente")).content.decode()
    cliente.post(reverse("web:asistente-revocar"))
    assert not Consentimiento.objects.filter(
        paciente=paciente, tipo=Consentimiento.Tipo.USO_CHATBOT, revocado_en__isnull=True
    ).exists()
    html = cliente.get(reverse("web:asistente")).content.decode()
    assert 'name="foto"' not in html
    assert "Activa la orientación con fotos" in html
