"""Panel /admin/ del asistente: conversaciones legibles, solo lectura y sin datos del paciente."""

from datetime import timedelta

import pytest
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from apps.chatbot.models import ConversacionChatbot, FotoChatbot, InteraccionChatbot
from apps.cuentas.tests.factories import PacienteFactory, UsuarioFactory

pytestmark = pytest.mark.django_db
Categoria = InteraccionChatbot.Categoria
LISTA = "admin:chatbot_conversacionchatbot_changelist"


@pytest.fixture
def cliente():
    cliente = Client()
    cliente.force_login(UsuarioFactory(rol="admin", is_staff=True, is_superuser=True))
    return cliente


@pytest.fixture
def paciente():
    return PacienteFactory(
        usuario__nombre="Ramona",
        usuario__apellido="Quispedetest",
        usuario__email="ramona.privada@example.com",
    )


def _mensaje(conversacion, consulta, *, minutos, **extra):
    interaccion = InteraccionChatbot.objects.create(
        conversacion=conversacion,
        paciente=conversacion.paciente,
        consulta=consulta,
        respuesta=f"Respuesta a: {consulta}",
        implementacion=InteraccionChatbot.Implementacion.REGLAS,
        **extra,
    )
    # La fecha se fija a mano para que el orden no dependa del orden de creación.
    InteraccionChatbot.objects.filter(pk=interaccion.pk).update(
        creada_en=timezone.now() - timedelta(minutes=minutos)
    )
    return interaccion


def _conversacion_del_paciente(paciente):
    conversacion = ConversacionChatbot.objects.create(paciente=paciente)
    # Se crean desordenadas: la última creada es la más antigua.
    _mensaje(conversacion, "Segunda pregunta", minutos=5)
    con_foto = _mensaje(
        conversacion,
        "Tercera pregunta con foto",
        minutos=1,
        con_foto=True,
        tipo=InteraccionChatbot.Tipo.TRIAJE,
        categoria_triaje=Categoria.URGENCIA,
        requiere_derivacion=True,
        motivo_derivacion="Signos de infección que avanzan",
    )
    FotoChatbot.objects.create(interaccion=con_foto, contenido=b"BYTES-DE-LA-FOTO")
    _mensaje(conversacion, "Primera pregunta", minutos=10)
    return conversacion


def test_el_detalle_muestra_los_mensajes_en_orden(cliente, paciente):
    conversacion = _conversacion_del_paciente(paciente)
    url = reverse("admin:chatbot_conversacionchatbot_change", args=[conversacion.pk])
    respuesta = cliente.get(url)
    html = respuesta.content.decode()
    assert respuesta.status_code == 200
    posiciones = [
        html.index("Primera pregunta"),
        html.index("Segunda pregunta"),
        html.index("Tercera pregunta con foto"),
    ]
    assert posiciones == sorted(posiciones)
    assert "Respuesta a: Primera pregunta" in html
    # La clasificación con su nombre legible, la derivación y quién respondió.
    assert "Urgencia" in html
    assert "Signos de infección que avanzan" in html
    assert "Reglas" in html
    assert '<div class="readonly">Paciente</div>' in html


def test_el_detalle_no_muestra_al_paciente_ni_la_foto(cliente, paciente):
    conversacion = _conversacion_del_paciente(paciente)
    url = reverse("admin:chatbot_conversacionchatbot_change", args=[conversacion.pk])
    html = cliente.get(url).content.decode()
    for dato in ("Ramona", "Quispedetest", "ramona.privada@example.com", paciente.rut):
        assert dato not in html
    assert reverse("admin:cuentas_paciente_change", args=[paciente.pk]) not in html
    assert "BYTES-DE-LA-FOTO" not in html


def test_el_detalle_escapa_el_texto_del_usuario(cliente):
    conversacion = ConversacionChatbot.objects.create()
    _mensaje(conversacion, "<script>alert(1)</script>", minutos=1)
    url = reverse("admin:chatbot_conversacionchatbot_change", args=[conversacion.pk])
    html = cliente.get(url).content.decode()
    assert "<script>alert(1)</script>" not in html
    assert "&lt;script&gt;alert(1)&lt;/script&gt;" in html


def test_la_conversacion_es_de_solo_lectura(cliente, paciente):
    conversacion = _conversacion_del_paciente(paciente)
    cambiar = reverse("admin:chatbot_conversacionchatbot_change", args=[conversacion.pk])
    borrar = reverse("admin:chatbot_conversacionchatbot_delete", args=[conversacion.pk])
    assert cliente.get(reverse("admin:chatbot_conversacionchatbot_add")).status_code == 403
    assert cliente.post(cambiar, {}).status_code == 403
    assert cliente.post(borrar, {"post": "yes"}).status_code == 403
    assert InteraccionChatbot.objects.filter(conversacion=conversacion).count() == 3


def test_la_lista_resume_cada_conversacion_sin_decir_quien(cliente, paciente):
    _conversacion_del_paciente(paciente)
    visitante = ConversacionChatbot.objects.create()
    _mensaje(visitante, "¿Dónde están?", minutos=2)
    respuesta = cliente.get(reverse(LISTA))
    html = respuesta.content.decode()
    assert respuesta.status_code == 200
    assert '<td class="field-origen">Visitante</td>' in html
    assert '<td class="field-origen">Paciente</td>' in html
    assert "Ramona" not in html and paciente.rut not in html
    filas = {c.pk: c for c in respuesta.context["cl"].result_list}
    assert sorted(c.num_mensajes for c in filas.values()) == [1, 3]
    assert [c.hubo_urgencia for c in filas.values()].count(True) == 1


def test_la_lista_no_hace_una_consulta_por_fila(cliente, paciente, django_assert_max_num_queries):
    for _ in range(5):
        _conversacion_del_paciente(paciente)
    cliente.get(reverse(LISTA))  # calienta la sesión y el caché de tipos de contenido
    with django_assert_max_num_queries(12):
        assert cliente.get(reverse(LISTA)).status_code == 200


@pytest.mark.parametrize(
    "filtro, esperadas",
    [
        ({"urgencia": "si"}, 1),
        ({"urgencia": "no"}, 1),
        ({"foto": "si"}, 1),
        ({"foto": "no"}, 1),
        ({"origen": "paciente"}, 1),
        ({"origen": "visitante"}, 1),
    ],
)
def test_los_filtros_de_la_lista(cliente, paciente, filtro, esperadas):
    _conversacion_del_paciente(paciente)
    visitante = ConversacionChatbot.objects.create()
    _mensaje(visitante, "¿Dónde están?", minutos=2)
    respuesta = cliente.get(reverse(LISTA), filtro)
    assert respuesta.status_code == 200
    assert respuesta.context["cl"].result_count == esperadas


def test_la_lista_de_mensajes_sigue_funcionando(cliente, paciente):
    conversacion = _conversacion_del_paciente(paciente)
    respuesta = cliente.get(reverse("admin:chatbot_interaccionchatbot_changelist"))
    html = respuesta.content.decode()
    assert respuesta.status_code == 200
    assert "Mensajes del asistente" in html
    assert reverse("admin:chatbot_conversacionchatbot_change", args=[conversacion.pk]) in html
    assert "Ramona" not in html
