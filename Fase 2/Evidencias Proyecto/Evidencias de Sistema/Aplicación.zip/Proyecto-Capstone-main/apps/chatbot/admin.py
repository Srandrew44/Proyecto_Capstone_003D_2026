"""Panel del asistente virtual: revisar la calidad de las orientaciones, todo de solo lectura.

Sin datos de identidad: no se muestra ni se enlaza al paciente (solo si la conversación es de un
paciente o de un visitante) y las fotos nunca se muestran, solo si el mensaje llevaba una. Las
preguntas se guardan ya sin RUT, correos ni teléfonos (privacidad.anonimizar).
"""

from django.contrib import admin
from django.db.models import Count, Exists, OuterRef
from django.urls import reverse
from django.utils.html import format_html

from .models import ConversacionChatbot, InteraccionChatbot

Categoria = InteraccionChatbot.Categoria


class _SoloLectura:
    def has_add_permission(self, request, obj=None):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


class _FiltroSiNo(admin.SimpleListFilter):
    """Filtro "Sí / No" sobre una anotación booleana del queryset."""

    anotacion = ""

    def lookups(self, request, model_admin):
        return [("si", "Sí"), ("no", "No")]

    def queryset(self, request, queryset):
        if self.value() in ("si", "no"):
            return queryset.filter(**{self.anotacion: self.value() == "si"})
        return queryset


class HuboUrgenciaFiltro(_FiltroSiNo):
    title = "hubo una urgencia"
    parameter_name = "urgencia"
    anotacion = "hubo_urgencia"


class HuboFotoFiltro(_FiltroSiNo):
    title = "hubo una foto"
    parameter_name = "foto"
    anotacion = "hubo_foto"


class OrigenFiltro(admin.SimpleListFilter):
    title = "quién conversó"
    parameter_name = "origen"

    def lookups(self, request, model_admin):
        return [("paciente", "Paciente"), ("visitante", "Visitante")]

    def queryset(self, request, queryset):
        if self.value() == "paciente":
            return queryset.filter(paciente__isnull=False)
        if self.value() == "visitante":
            return queryset.filter(paciente__isnull=True)
        return queryset


class MensajeInline(_SoloLectura, admin.StackedInline):
    """Los mensajes de la conversación, en el orden en que ocurrieron. La foto no se muestra."""

    model = InteraccionChatbot
    fields = [
        "creada_en",
        "consulta",
        "respuesta",
        "categoria_triaje",
        "requiere_derivacion",
        "motivo_derivacion",
        "con_foto",
        "implementacion",
    ]
    readonly_fields = fields
    ordering = ["creada_en"]
    extra = 0
    show_change_link = False


@admin.register(ConversacionChatbot)
class ConversacionChatbotAdmin(_SoloLectura, admin.ModelAdmin):
    list_display = ["creada_en", "actualizada_en", "mensajes", "origen", "urgencia", "foto"]
    list_filter = [HuboUrgenciaFiltro, HuboFotoFiltro, OrigenFiltro, "creada_en"]
    fields = ["creada_en", "actualizada_en", "origen"]
    readonly_fields = fields
    exclude = ["paciente"]  # nunca se muestra quién es
    inlines = [MensajeInline]

    def get_queryset(self, request):
        # Todo en la misma consulta del listado (sin una consulta extra por fila).
        mensajes = InteraccionChatbot.objects.filter(conversacion=OuterRef("pk"))
        return (
            super()
            .get_queryset(request)
            .annotate(
                num_mensajes=Count("interacciones"),
                hubo_urgencia=Exists(mensajes.filter(categoria_triaje=Categoria.URGENCIA)),
                hubo_foto=Exists(mensajes.filter(con_foto=True)),
            )
        )

    @admin.display(description="mensajes", ordering="num_mensajes")
    def mensajes(self, obj):
        return obj.num_mensajes

    @admin.display(description="de")
    def origen(self, obj):
        return "Paciente" if obj.paciente_id else "Visitante"

    @admin.display(description="urgencia", boolean=True, ordering="hubo_urgencia")
    def urgencia(self, obj):
        return obj.hubo_urgencia

    @admin.display(description="foto", boolean=True, ordering="hubo_foto")
    def foto(self, obj):
        return obj.hubo_foto


@admin.register(InteraccionChatbot)
class InteraccionChatbotAdmin(_SoloLectura, admin.ModelAdmin):
    """Todos los mensajes sueltos, para buscar por clasificación. Las fotos no se muestran."""

    list_display = [
        "creada_en",
        "tipo",
        "categoria_triaje",
        "requiere_derivacion",
        "con_foto",
        "implementacion",
        "latencia_ms",
        "ver_conversacion",
    ]
    list_filter = ["tipo", "categoria_triaje", "requiere_derivacion", "implementacion", "con_foto"]
    exclude = ["paciente"]  # nunca se muestra quién es
    readonly_fields = ["creada_en", "ver_conversacion"]

    @admin.display(description="conversación")
    def ver_conversacion(self, obj):
        url = reverse("admin:chatbot_conversacionchatbot_change", args=[obj.conversacion_id])
        return format_html('<a href="{}">Ver la conversación completa</a>', url)
