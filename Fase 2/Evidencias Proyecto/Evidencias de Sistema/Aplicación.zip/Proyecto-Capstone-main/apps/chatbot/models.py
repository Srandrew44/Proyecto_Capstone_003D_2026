"""Asistente virtual (B7): conversaciones, mensajes y fotos de los pies.

Un visitante sin sesión solo hace preguntas frecuentes. Un paciente con el consentimiento
`uso_chatbot` vigente además puede describir síntomas y adjuntar fotos para recibir una
orientación preliminar. El asistente nunca diagnostica.
"""

import uuid

from django.db import models


class ConversacionChatbot(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    # Nulo: conversación de un visitante (solo preguntas frecuentes, sin datos de salud).
    paciente = models.ForeignKey(
        "cuentas.Paciente",
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="conversaciones_chatbot",
    )
    creada_en = models.DateTimeField("inicio", auto_now_add=True)
    actualizada_en = models.DateTimeField("última actividad", auto_now=True)

    class Meta:
        verbose_name = "conversación del asistente"
        verbose_name_plural = "conversaciones del asistente"
        ordering = ["-actualizada_en"]

    def __str__(self):
        return f"Conversación {self.pk} ({self.creada_en:%d/%m/%Y})"

    def es_de(self, usuario) -> bool:
        return usuario.is_authenticated and self.paciente_id == usuario.pk


class InteraccionChatbot(models.Model):
    """Una pregunta y su respuesta (Anexo F). La consulta se guarda sin datos de contacto."""

    class Tipo(models.TextChoices):
        FAQ = "faq", "Pregunta frecuente"
        TRIAJE = "triaje", "Orientación por síntomas"

    class Categoria(models.TextChoices):
        SIN_TRIAJE = "sin_triaje", "Sin orientación clínica"
        PODOLOGIA = "podologia", "Atención podológica"
        TRAUMATOLOGIA = "traumatologia", "Traumatólogo"
        DERMATOLOGIA = "dermatologia", "Dermatólogo"
        URGENCIA = "urgencia", "Urgencia"

    class Implementacion(models.TextChoices):
        MODELO = "modelo", "Modelo de lenguaje"
        REGLAS = "reglas", "Reglas"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    conversacion = models.ForeignKey(
        ConversacionChatbot,
        on_delete=models.PROTECT,
        related_name="interacciones",
        verbose_name="conversación",
    )
    paciente = models.ForeignKey(
        "cuentas.Paciente",
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="interacciones_chatbot",
    )
    tipo = models.CharField("tipo", max_length=10, choices=Tipo.choices, default=Tipo.FAQ)
    consulta = models.TextField(
        "pregunta del usuario", help_text="Mensaje del usuario, sin RUT, correos ni teléfonos."
    )
    con_foto = models.BooleanField("adjuntó foto", default=False)
    respuesta = models.TextField("respuesta")
    categoria_triaje = models.CharField(
        "clasificación", max_length=15, choices=Categoria.choices, default=Categoria.SIN_TRIAJE
    )
    requiere_derivacion = models.BooleanField("requiere derivación", default=False)
    motivo_derivacion = models.CharField("motivo de la derivación", max_length=300, blank=True)
    sugerir_reserva = models.BooleanField("sugirió reservar", default=False)
    implementacion = models.CharField("respondió", max_length=10, choices=Implementacion.choices)
    latencia_ms = models.PositiveIntegerField("demora (ms)", default=0)
    creada_en = models.DateTimeField("fecha y hora", auto_now_add=True)

    class Meta:
        # En el panel se llaman "mensajes": cada uno es una pregunta y su respuesta.
        verbose_name = "mensaje del asistente"
        verbose_name_plural = "mensajes del asistente"
        ordering = ["creada_en"]
        indexes = [
            models.Index(fields=["conversacion", "creada_en"], name="chatbot_conv_fecha_idx"),
            models.Index(fields=["categoria_triaje", "creada_en"], name="chatbot_categoria_idx"),
        ]

    def __str__(self):
        return f"{self.get_tipo_display()} · {self.get_categoria_triaje_display()}"


class FotoChatbot(models.Model):
    """Foto de un pie que adjuntó el paciente. Es un dato de salud: se borra a los
    CHATBOT_RETENCION_FOTOS_DIAS días. Se guarda re-codificada en JPEG, sin metadatos
    (la ubicación GPS de la cámara no queda)."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    interaccion = models.OneToOneField(
        InteraccionChatbot, on_delete=models.CASCADE, related_name="foto"
    )
    contenido = models.BinaryField()
    media_type = models.CharField(max_length=20, default="image/jpeg")
    creada_en = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "foto del asistente"
        verbose_name_plural = "fotos del asistente"

    def __str__(self):
        return f"Foto {self.pk}"
