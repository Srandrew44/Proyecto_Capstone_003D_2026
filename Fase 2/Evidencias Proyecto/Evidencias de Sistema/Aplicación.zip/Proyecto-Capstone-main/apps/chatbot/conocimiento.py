"""Base de conocimientos del asistente: lo único en que se apoya para orientar.

VERSIÓN 2, PENDIENTE DE VALIDACIÓN POR EL PODÓLOGO. La redactó el equipo a partir de
información general de podología; la sección de uñas (versión 2) resume con palabras propias
el "Manual de Onicopatías" de R. Arenas. El podólogo debe revisarla y aprobarla antes de que el
asistente se use con pacientes reales. Al aprobarla, cambiar VALIDADA a True y anotar quién
la revisó y cuándo (se muestra en la página del asistente).
"""

VERSION = "2"  # 2: sección de problemas de las uñas (17/11/2026)
VALIDADA = False
VALIDADA_POR = ""  # p. ej. "Camila Rojas, podóloga, 15/11/2026"

SENALES_DE_ALARMA = """\
SEÑALES DE ALARMA: indican URGENCIA (servicio de urgencia hoy, o llamar al 131 si hay
compromiso general). Ante cualquiera de ellas, se dice primero y con claridad, sin rodeos:
- Fiebre o escalofríos junto con una herida, enrojecimiento o hinchazón del pie.
- Enrojecimiento caliente que se extiende, línea roja que sube por la pierna.
- Herida con pus, mal olor o que supura.
- Dedo o zona del pie negra, morada, gris o muy pálida; pie frío con dolor intenso. (Se
  refiere a la piel del dedo o del pie. Una mancha oscura solo bajo la uña, o una raya
  oscura en la uña, no es por sí sola una urgencia: ver PROBLEMAS DE LAS UÑAS.)
- Herida, ampolla o úlcera en una persona con diabetes, sobre todo si no siente dolor, si
  supura o si no mejora en 2 o 3 días (pie diabético: riesgo de infección grave).
- Dolor muy intenso después de un golpe o torcedura, deformidad visible, no poder apoyar el
  pie o caminar.
- Sangrado que no se detiene con presión.
- Hormigueo o pérdida de fuerza súbita en el pie o la pierna.
"""

DERIVACIONES = """\
A QUIÉN ORIENTAR (sin diagnosticar; siempre "podría", "conviene que lo evalúe"):
- PODOLOGÍA (esta consulta): uñas engrosadas, amarillas o quebradizas (posible hongo),
  uña encarnada sin signos de infección grave, callosidades e hiperqueratosis, helomas
  (callos con centro duro y doloroso), verrugas plantares, grietas en los talones, pie de
  atleta leve (picazón y descamación entre los dedos), cuidado preventivo del pie
  diabético, corte de uñas difícil en personas mayores.
- TRAUMATOLOGÍA: dolor en huesos o articulaciones, después de un golpe o torcedura sin
  señales de alarma; juanete (hallux valgus) doloroso o que aumenta; dedos en garra o en
  martillo que molestan al caminar; dolor de talón al dar los primeros pasos de la mañana
  que dura semanas (posible fascitis plantar); pie plano o cavo con dolor.
- DERMATOLOGÍA: lunar o mancha en el pie que cambió de tamaño, forma o color, que sangra
  o con bordes irregulares; lesiones de piel extensas, con ampollas o que no responden al
  cuidado habitual; eczema o psoriasis.
- URGENCIA: cualquiera de las señales de alarma.
"""

CONDICIONES = """\
CONDICIONES FRECUENTES (información general, para explicar en lenguaje simple):
- Onicomicosis (hongo en la uña): uña engrosada, amarilla, blanquecina o marrón, que se
  quiebra o se despega. Avanza lento. El podólogo limpia y rebaja la uña; el tratamiento
  antifúngico lo indica un médico. Mientras tanto: pies secos, calcetín de algodón, no
  compartir cortaúñas ni toallas, sandalias en duchas públicas.
- Uña encarnada (onicocriptosis): el borde de la uña se clava en la piel; duele, se
  enrojece y puede infectarse. El podólogo la trata. No cortar el borde en curva ni
  "escarbar". Si hay pus abundante, fiebre o el enrojecimiento se extiende: urgencia.
- Hiperqueratosis y callosidades: piel engrosada por roce o presión (zapatos, forma de
  pisar). El podólogo las rebaja sin dolor. No usar cuchillas ni callicidas en casa,
  especialmente con diabetes.
- Heloma (callo con centro): punto duro y doloroso, a menudo entre los dedos o en la
  planta. Lo trata el podólogo; conviene revisar el calzado.
- Verruga plantar: lesión de piel con puntitos negros, duele al apretar de lado; es
  contagiosa (virus). Se trata en podología; evitar andar descalzo en lugares públicos.
- Pie de atleta (tiña pedis): picazón, descamación o grietas entre los dedos. Secar bien
  entre los dedos, cambiar calcetines a diario. Si se extiende o hay heridas: evaluar.
- Grietas en los talones: piel seca y gruesa que se abre. Hidratar a diario (no entre los
  dedos); el podólogo rebaja la piel engrosada. Con diabetes, una grieta es una herida.
- Ampollas: no reventarlas; cubrir con apósito limpio. Con diabetes, evaluar pronto.
- Pie diabético (prevención): revisar los pies todos los días (con espejo si cuesta),
  no andar descalzo, calzado sin costuras que rocen, uñas cortadas rectas por un
  profesional, control podológico periódico. Cualquier herida se evalúa pronto.
"""

UNAS = """\
PROBLEMAS DE LAS UÑAS (resumen propio, en lenguaje simple, basado en el "Manual de
Onicopatías" de R. Arenas y colaboradores; no se cita textual). Sirve para explicar lo que
el paciente describe o se ve en una foto. Usar palabras de todos los días; el nombre técnico
va una sola vez, entre paréntesis. Siempre "podría ser", nunca un diagnóstico.
- Uña amarilla, blanquecina o marrón, gruesa, opaca, que se quiebra o se desmorona por la
  punta: podría ser hongo (onicomicosis), el problema de uñas más común, sobre todo en el
  dedo gordo del pie. Es más frecuente con diabetes, mala circulación o calzado cerrado.
  Hay otras causas que se le parecen (golpes repetidos, psoriasis), por eso no se trata
  "a ciegas": lo evalúa el podólogo, y el tratamiento con medicamentos lo indica un médico.
- Manchitas blancas como de tiza en la superficie de la uña del pie: podrían ser un hongo
  superficial; lo revisa el podólogo. Puntos o rayas blancas pequeñas en una sola uña
  suelen deberse a golpes o a la manicura y desaparecen al crecer la uña.
- Uña que se despega de la piel desde la punta (onicólisis): por golpes repetidos
  (deporte, calzado apretado), hongos, psoriasis, exceso de agua o algunos medicamentos. El
  espacio que queda puede infectarse. Mantener seca y corta; la evalúa el podólogo.
- Uña verde o verdosa: suele ser una bacteria que crece bajo una uña despegada y húmeda.
  Secar bien y que la revise el podólogo; si duele o hay pus, médico.
- Mancha roja, morada o negra bajo la uña después de un golpe, de un zapato apretado o de
  correr (hematoma): es sangre bajo la uña; sale sola a medida que la uña crece (meses en
  el pie). Si duele mucho y late, o el golpe fue fuerte, evaluación pronta.
- Raya o banda oscura (café o negra) a lo largo de la uña, SIN golpe previo: puede ser
  normal en pieles morenas o por algunos medicamentos, pero si es nueva, se ensancha,
  cambia de color, tiene bordes irregulares o la mancha pasa a la piel alrededor de la
  uña, debe verla un DERMATÓLOGO pronto para descartar una lesión maligna. Decirlo con
  calma, sin alarmar, pero sin restarle importancia.
- Uña encarnada (onicocriptosis): el borde de la uña se clava en la piel del costado; duele,
  se pone roja e hinchada y puede salir pus o "carne" que crece. Es común en adolescentes
  y adultos jóvenes, en el dedo gordo. Causas: cortar las esquinas en curva o muy corto,
  calzado estrecho, golpes. La trata el podólogo. En casa: no cortar en "V" ni escarbar la
  esquina, calzado holgado. Pus abundante, fiebre o enrojecimiento que avanza: urgencia.
  En una foto se ve así: el borde lateral de la uña (casi siempre del dedo gordo) metido o
  hundido en la piel del costado, y esa piel roja, hinchada o brillante, a veces con una
  pequeña herida, costra o "carne" roja junto a la uña. Si la foto muestra eso, la uña
  encarnada es la posibilidad MÁS PROBABLE y se nombra primero; la inflamación alrededor de
  la uña (paroniquia) suele ser parte de ella, no una alternativa. Orientar a podología y
  sugerir reservar, salvo que haya señales de alarma.
- Uña muy curvada hacia los lados, como teja o pinza: aprieta la piel y duele; puede ser
  de familia o por calzado ajustado. La trata el podólogo.
- Uña muy gruesa, dura y torcida, como una garra (onicogrifosis): frecuente en personas
  mayores, por golpes, mala circulación o falta de cuidado. No cortarla en casa; la rebaja
  el podólogo.
- Piel roja, hinchada y dolorosa alrededor de la uña (paroniquia): si aparece de golpe, con
  dolor que late o pus, es una infección y debe verla un médico pronto (urgencia si hay
  fiebre o el rojo avanza). Si es de larga data, con la cutícula perdida, suele deberse a
  humedad o irritantes: mantener seco y consultar.
- Rayas que cruzan la uña de lado a lado (surcos o líneas de Beau): la uña dejó de crecer un
  tiempo, por un golpe, la manicura o una enfermedad o fiebre fuerte. Si aparecen en
  varias uñas a la vez, conviene control con médico general.
- Uñas frágiles que se parten en capas: suelen deberse a la humedad o la sequedad
  repetidas; hidratar y evitar el agua prolongada.
- Uñas amarillas por esmalte, o daño por uñas acrílicas o de gel: dejar descansar la uña sin
  productos; si duele o se despega, consultar.
- Cambios en TODAS las uñas a la vez (color, forma, rayas): pueden reflejar una enfermedad
  general; además del podólogo, control con médico general.
"""

PREPARACION = """\
PREPARACIÓN PARA LA CITA DE PODOLOGÍA:
- Venir con los pies limpios y sin esmalte en las uñas (permite ver la uña).
- No cortar ni limar callos o uñas en casa los días previos.
- Traer el calzado que usa a diario y, si tiene, exámenes o la lista de medicamentos.
- Personas con diabetes: traer su último control si lo tienen.
"""

LIMITES = """\
LO QUE EL ASISTENTE NO HACE:
- No diagnostica ni confirma enfermedades: orienta y sugiere quién debería evaluar.
- No indica medicamentos, dosis, antibióticos ni cremas con receta.
- No reemplaza la evaluación del podólogo ni la de un médico.
- Una foto no permite asegurar nada: la calidad, la luz y el ángulo pueden engañar.
"""


def texto_completo() -> str:
    estado = f"Validada por {VALIDADA_POR}." if VALIDADA else "Pendiente de validación profesional."
    return "\n".join(
        [
            f"BASE DE CONOCIMIENTOS DE MYPODO (versión {VERSION}). {estado}",
            SENALES_DE_ALARMA,
            DERIVACIONES,
            CONDICIONES,
            UNAS,
            PREPARACION,
            LIMITES,
        ]
    )
