"""Quita datos de contacto e identificación del texto antes de guardarlo o enviarlo al modelo.

Decisión del proyecto: al modelo no se envían nombre, RUT ni contacto. El nombre del paciente
nunca se agrega desde el sistema; lo que el propio usuario escriba (RUT, correo, teléfono)
se reemplaza aquí. Los síntomas sí pasan: son el objeto de la consulta.
"""

import re

OMITIDO = "[dato omitido]"

_PATRONES = [
    # Correos.
    re.compile(r"[\w.+-]+@[\w-]+(\.[\w-]+)+"),
    # RUT chileno con o sin puntos: 12.345.678-5, 12345678-K.
    re.compile(r"\b\d{1,2}\.?\d{3}\.?\d{3}-[\dkK]\b"),
    # Teléfonos: +56 9 1234 5678, 912345678, 22 123 4567.
    re.compile(r"(\+?56[\s-]?)?\b9[\s-]?\d{4}[\s-]?\d{4}\b"),
    re.compile(r"(\+?56[\s-]?)?\b2[\s-]?\d{3,4}[\s-]?\d{4}\b"),
]


def anonimizar(texto: str) -> str:
    for patron in _PATRONES:
        texto = patron.sub(OMITIDO, texto)
    return texto.strip()
