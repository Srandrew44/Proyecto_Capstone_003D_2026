"""Validación y limpieza de las fotos que adjunta el paciente.

Toda foto se abre con Pillow (si no es una imagen real, se rechaza), se gira según su
orientación EXIF, se reduce a 1568 px por lado (lo que aprovecha el modelo) y se guarda como
JPEG nuevo: así no queda ningún metadato, incluida la ubicación GPS del teléfono.
"""

import io

from django.conf import settings
from django.core.exceptions import ValidationError
from PIL import Image, ImageOps, UnidentifiedImageError

FORMATOS = {"JPEG", "PNG", "WEBP"}
LADO_MAX = 1568


def limpiar_foto(archivo) -> bytes:
    limite = settings.CHATBOT_FOTO_MAX_MB * 1024 * 1024
    if archivo.size > limite:
        raise ValidationError(f"La foto no puede pesar más de {settings.CHATBOT_FOTO_MAX_MB} MB.")
    try:
        imagen = Image.open(archivo)
        imagen.verify()  # detecta archivos dañados o que no son imágenes
        archivo.seek(0)
        imagen = Image.open(archivo)
        formato = imagen.format
        imagen.load()
    except (UnidentifiedImageError, OSError, SyntaxError) as exc:
        raise ValidationError("El archivo no es una foto válida.") from exc
    if formato not in FORMATOS:
        raise ValidationError("Sube la foto en JPG, PNG o WEBP.")
    imagen = ImageOps.exif_transpose(imagen).convert("RGB")
    imagen.thumbnail((LADO_MAX, LADO_MAX))
    salida = io.BytesIO()
    imagen.save(salida, format="JPEG", quality=85)
    return salida.getvalue()
