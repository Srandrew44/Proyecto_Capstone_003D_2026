"""ClasificadorTriaje: dos implementaciones con la misma interfaz (decisión de arquitectura).

- `ClasificadorClaude`: modelo multimodal; lee las fotos, hace preguntas de seguimiento y
  orienta apoyándose solo en la base de conocimientos.
- `ClasificadorReglas`: palabras clave. Responde sin clave de API, cuando Claude falla o
  tarda, y siempre revisa las señales de alarma del texto como red de seguridad.
"""

import base64
import re
import time
import unicodedata
from dataclasses import dataclass, field

from integraciones import asistente_ia

from . import conocimiento
from .models import InteraccionChatbot

Categoria = InteraccionChatbot.Categoria
Tipo = InteraccionChatbot.Tipo
Implementacion = InteraccionChatbot.Implementacion

AVISO_URGENCIA = (
    "⚠️ Lo que describes puede ser una señal de alarma. Te recomendamos acudir hoy a un "
    "servicio de urgencia (o llamar al 131 si hay fiebre alta o te sientes mal en general). "
    "No esperes a una hora de podología."
)


@dataclass
class Turno:
    consulta: str
    respuesta: str
    foto: bytes | None = None


@dataclass
class Contexto:
    mensaje: str
    es_paciente: bool
    datos_consulta: str
    antecedentes: str = ""
    foto: bytes | None = None
    historial: list[Turno] = field(default_factory=list)


@dataclass
class Resultado:
    respuesta: str
    tipo: str = Tipo.FAQ
    categoria: str = Categoria.SIN_TRIAJE
    requiere_derivacion: bool = False
    motivo_derivacion: str = ""
    sugerir_reserva: bool = False
    implementacion: str = Implementacion.REGLAS
    latencia_ms: int = 0


def _normalizar(texto: str) -> str:
    sin_tildes = unicodedata.normalize("NFKD", texto.lower())
    return "".join(c for c in sin_tildes if not unicodedata.combining(c))


def _contiene(texto: str, palabras) -> bool:
    return any(p in texto for p in palabras)


ALARMA = [
    "fiebre", "escalofrio", "supura", "mal olor", "gangrena", "linea roja",
    "no puedo apoyar", "no puedo caminar", "fractura", "hueso roto", "deformidad",
    "sangra mucho", "no para de sangrar", "pie frio", "se extiende", "hormigueo subito",
    "perdi la fuerza",
]  # fmt: skip
# Un dedo negro o morado es alarma (falta de circulación). Si el color solo se describe en la
# uña (hematoma, raya oscura), la red de seguridad deja la decisión a Claude, que distingue
# con la base de conocimientos; sin Claude, las reglas siguen tratándolo como alarma.
COLOR_OSCURO = ["negro", "negra", "morado", "morada"]
DIABETES = ["diabetes", "diabetico", "diabetica", "azucar alta", "insulina"]
HERIDA = ["herida", "ulcera", "llaga", "ampolla", "corte", "grieta"]
DERMATOLOGIA = ["lunar", "mancha", "melanoma", "eczema", "psoriasis", "cambio de color"]
TRAUMATOLOGIA = [
    "golpe", "torcedura", "torci", "esguince", "juanete", "hallux", "dedo en garra",
    "dedo en martillo", "fascitis", "dolor de talon", "dolor en el talon", "articulacion",
    "tobillo", "pie plano",
]  # fmt: skip
PODOLOGIA = [
    "una", "unas", "hongo", "encarnad", "callo", "callosidad", "dureza", "heloma",
    "verruga", "talones", "pie de atleta", "picazon", "descamacion", "olor",
]  # fmt: skip


def detectar_alarma(mensaje: str, antecedentes: str = "", *, color_en_una: bool = True) -> bool:
    """`color_en_una=False`: un color oscuro descrito en la uña no cuenta como alarma."""
    texto = _normalizar(mensaje)
    # «pus» como palabra completa: «se me puso morada» no habla de pus.
    if _contiene(texto, ALARMA) or re.search(r"\bpus\b", texto):
        return True
    if _contiene(texto, COLOR_OSCURO) and (color_en_una or not _solo_en_la_una(mensaje)):
        return True
    diabetico = _contiene(texto, DIABETES) or "diabetes: si" in _normalizar(antecedentes)
    return diabetico and _contiene(texto, HERIDA)


# Frases que indican que el color oscuro está en la piel o el dedo, no solo en la uña.
PIEL_OSCURA = [
    "piel", "dedo negro", "dedo morado", "dedo esta", "dedo se puso", "dedo se ve",
    "dedos negros", "dedos morados", "y el dedo", "todo el dedo", "punta del dedo",
    "pie negro", "pie morado", "frio", "palido", "herida", "llaga", "ulcera", "gris",
    "azul", "dedo oscuro", "dedos oscuros", "pie oscuro",
]  # fmt: skip
# Sin tilde, «una»/«unas» suele ser el artículo («unas manchas negras en el pie» habla de la
# piel). Solo estas formas se leen como la uña; si no, se mantiene la alarma (lo seguro).
UNA_SIN_TILDE = [
    "la una ", "las unas ", "mi una ", "mis unas ", "una del pie", "una del dedo",
    "unas de los pies", "unas del pie",
]  # fmt: skip


def _solo_en_la_una(mensaje: str) -> bool:
    """Habla de la uña y no de la piel o del dedo de ese color."""
    texto = _normalizar(mensaje) + " "
    habla_de_la_una = "uña" in mensaje.lower() or _contiene(texto, UNA_SIN_TILDE)
    return habla_de_la_una and not _contiene(texto, PIEL_OSCURA)


class ClasificadorReglas:
    def responder(self, ctx: Contexto) -> Resultado:
        texto = _normalizar(ctx.mensaje)
        if detectar_alarma(ctx.mensaje, ctx.antecedentes):
            return Resultado(
                respuesta=AVISO_URGENCIA,
                tipo=Tipo.TRIAJE,
                categoria=Categoria.URGENCIA,
                requiere_derivacion=True,
                motivo_derivacion="Señal de alarma descrita por el usuario.",
            )
        faq = self._faq(texto, ctx)
        if faq:
            return faq
        if _contiene(texto, DERMATOLOGIA):
            return self._orientar(
                Categoria.DERMATOLOGIA,
                "Un lunar o mancha que cambia conviene que lo evalúe un dermatólogo.",
                ctx,
            )
        if _contiene(texto, TRAUMATOLOGIA):
            return self._orientar(
                Categoria.TRAUMATOLOGIA,
                "Un dolor de huesos, articulaciones o después de un golpe conviene que lo "
                "evalúe un traumatólogo.",
                ctx,
            )
        if _contiene(texto, PODOLOGIA) or ctx.foto:
            return self._orientar(Categoria.PODOLOGIA, None, ctx)
        return Resultado(
            respuesta=(
                "Puedo ayudarte con dudas sobre la consulta (dirección, tratamientos, precios, "
                "cómo reservar, cancelar o pagar) y con una orientación general sobre "
                "molestias en los pies. ¿Qué te gustaría saber?"
            )
        )

    def _orientar(self, categoria, motivo, ctx: Contexto) -> Resultado:
        if not ctx.es_paciente:
            return Resultado(
                respuesta=(
                    "Para orientarte según tus síntomas (y revisar una foto si quieres), "
                    "entra con tu cuenta de paciente y abre el asistente. Si notas fiebre, "
                    "pus, una zona negra o morada, o tienes diabetes y una herida, acude hoy a "
                    "un servicio de urgencia."
                ),
                tipo=Tipo.TRIAJE,
            )
        if categoria == Categoria.PODOLOGIA:
            respuesta = (
                "Por lo que describes, podría tratarse de algo que se atiende en podología "
                "(uñas, callosidades, verrugas o grietas, por ejemplo). Solo el podólogo puede "
                "confirmarlo al revisarte. Puedes reservar una hora desde «Reservar hora»."
            )
            if ctx.foto:
                respuesta = "Recibí tu foto, pero en este momento no puedo analizarla. " + respuesta
            return Resultado(
                respuesta=respuesta,
                tipo=Tipo.TRIAJE,
                categoria=categoria,
                sugerir_reserva=True,
            )
        return Resultado(
            respuesta=motivo + " Esta orientación no es un diagnóstico.",
            tipo=Tipo.TRIAJE,
            categoria=categoria,
            requiere_derivacion=True,
            motivo_derivacion=motivo,
        )

    def _faq(self, texto: str, ctx: Contexto) -> Resultado | None:
        temas = [
            (["direccion", "donde", "ubicad", "llegar", "horario", "atienden"], "consulta"),
            (["precio", "valor", "cuesta", "cuanto", "tratamientos", "servicios"], "precios"),
            (["cancel", "reagend", "cambiar la hora", "cambiar mi hora"], "cancelar"),
            (["pago", "pagar", "webpay", "tarjeta", "reembolso", "devolu"], "pago"),
            (["reserv", "agendar", "pedir hora", "tomar hora"], "reservar"),
            (["prepar", "llevar", "antes de la cita"], "preparacion"),
        ]
        for palabras, tema in temas:
            if _contiene(texto, palabras):
                return Resultado(respuesta=self._respuesta_faq(tema, ctx))
        return None

    def _respuesta_faq(self, tema: str, ctx: Contexto) -> str:
        lineas = ctx.datos_consulta.splitlines()
        if tema == "precios":
            tratamientos = [linea for linea in lineas if linea.startswith("- ")]
            return "Estos son los tratamientos y sus valores:\n" + "\n".join(tratamientos)
        if tema == "consulta":
            inicios = ("Nombre:", "Dirección:", "Cómo llegar:", "Atención solo")
            return "\n".join(linea for linea in lineas if linea.startswith(inicios))
        if tema == "cancelar":
            return (
                "Puedes cancelar o cambiar la hora desde «Mis citas» hasta 24 horas antes. "
                "Si la pagaste en línea, al cancelar te devolvemos el pago al mismo medio. "
                "Con menos de 24 horas, comunícate con la consulta."
            )
        if tema == "pago":
            return (
                "Las horas se pagan en línea al reservar, con Webpay (débito, crédito o "
                "prepago). La hora queda reservada mientras pagas. Si cancelas a tiempo, "
                "te devolvemos el pago automáticamente."
            )
        if tema == "reservar":
            return (
                "Para reservar: entra con tu cuenta, ve a «Reservar hora», elige podólogo y "
                "tratamiento, luego el día y la hora, y paga con Webpay. Se reserva con al "
                "menos 24 horas de anticipación."
            )
        return conocimiento.PREPARACION


ESQUEMA = {
    "type": "object",
    "properties": {
        "respuesta": {
            "type": "string",
            "description": "Lo que se muestra al usuario, en español de Chile, cálido y claro.",
        },
        "tipo": {"type": "string", "enum": [Tipo.FAQ, Tipo.TRIAJE]},
        "categoria_triaje": {"type": "string", "enum": list(Categoria.values)},
        "requiere_derivacion": {"type": "boolean"},
        "motivo_derivacion": {"type": "string"},
        "sugerir_reserva": {"type": "boolean"},
    },
    "required": [
        "respuesta",
        "tipo",
        "categoria_triaje",
        "requiere_derivacion",
        "motivo_derivacion",
        "sugerir_reserva",
    ],
    "additionalProperties": False,
}

INSTRUCCIONES = """\
Eres el asistente virtual de MyPodo, una consulta podológica en Chile. Ayudas con dos cosas:
1. Preguntas frecuentes sobre la consulta: usa SOLO los "Datos de la consulta" que vienen
   abajo (dirección, tratamientos, precios, reglas). Si algo no está ahí, dilo y sugiere
   contactar a la consulta. Nunca inventes precios, horarios ni datos.
2. Orientación preliminar sobre molestias de los pies (triaje), apoyándote SOLO en la base
   de conocimientos. Puedes recibir fotos de los pies.

Reglas para la orientación:
- Nunca diagnostiques ni nombres una enfermedad como segura: usa "podría", "es compatible
  con", "conviene que lo evalúe". Nunca indiques medicamentos, dosis ni cremas con receta.
- Primero revisa las señales de alarma. Si hay alguna (en el texto o en la foto), la
  categoría es "urgencia", lo dices al inicio y con claridad, y no sigues indagando.
- Si falta información para orientar, haz 1 o 2 preguntas concretas de seguimiento (desde
  cuándo, si duele, si hay fiebre o pus, si tiene diabetes, si cambió de color o tamaño,
  qué calzado usa). Si lo descrito o la foto ya apuntan a un área (por ejemplo, una posible
  uña encarnada → podología), usa esa categoría desde ya, aunque también preguntes.
  Categoría "sin_triaje" solo si todavía no puedes orientar hacia ninguna.
- Con una foto: describe con prudencia lo que se observa (color, forma, zona) y aclara que
  una foto no basta para asegurar nada. Nombra primero la posibilidad más probable según
  la base de conocimientos (en "PROBLEMAS DE LAS UÑAS" está cómo se ve cada una en foto).
  Si la foto no es de un pie o no se ve bien, pide otra con buena luz, enfocada y de cerca.
  No comentes rasgos que identifiquen a la persona.
- Cuando orientes a podología, sugiere reservar (sugerir_reserva = true). Cuando orientes a
  traumatología, dermatología o urgencia, requiere_derivacion = true y explica el motivo en
  motivo_derivacion, en una frase.
- Termina la orientación recordando, en una frase breve, que no reemplaza la evaluación
  del podólogo.
- No pidas nombre, RUT, correo, teléfono ni dirección. Si el usuario los escribe, ignóralos.
- Si te piden algo ajeno a la consulta o a los pies, responde amablemente que solo ayudas
  con eso.
- Respuestas breves (máximo unas 120 palabras), en párrafos cortos o viñetas simples, sin
  markdown complejo.
"""

MODO_VISITANTE = """\
El usuario es un VISITANTE sin sesión: solo respondes preguntas frecuentes. Si describe
síntomas o quiere enviar una foto, explícale que debe entrar con su cuenta de paciente para
la orientación. Excepción: si menciona una señal de alarma, igual le indicas urgencia.
"""

MODO_PACIENTE = """\
El usuario es un PACIENTE con sesión que aceptó el uso del asistente. Puede enviar fotos.
"""


class ClasificadorClaude:
    def responder(self, ctx: Contexto) -> Resultado:
        sistema = [
            {
                "type": "text",
                "text": INSTRUCCIONES + "\n" + conocimiento.texto_completo(),
                # Lo estable primero y en caché: instrucciones y base de conocimientos.
                "cache_control": {"type": "ephemeral"},
            },
            {"type": "text", "text": "Datos de la consulta:\n" + ctx.datos_consulta},
            {"type": "text", "text": MODO_PACIENTE if ctx.es_paciente else MODO_VISITANTE},
        ]
        if ctx.antecedentes:
            sistema.append(
                {
                    "type": "text",
                    "text": "Antecedentes registrados por el podólogo (sin datos de "
                    "identificación):\n" + ctx.antecedentes,
                }
            )
        mensajes = []
        for turno in ctx.historial:
            mensajes.append({"role": "user", "content": _contenido(turno.consulta, turno.foto)})
            mensajes.append({"role": "assistant", "content": turno.respuesta})
        mensajes.append({"role": "user", "content": _contenido(ctx.mensaje, ctx.foto)})

        datos = asistente_ia.consultar(sistema=sistema, mensajes=mensajes, esquema=ESQUEMA)
        return Resultado(
            respuesta=datos["respuesta"].strip(),
            tipo=datos["tipo"],
            categoria=datos["categoria_triaje"],
            requiere_derivacion=datos["requiere_derivacion"],
            motivo_derivacion=datos["motivo_derivacion"][:300],
            sugerir_reserva=datos["sugerir_reserva"],
            implementacion=Implementacion.MODELO,
        )


def _contenido(texto: str, foto: bytes | None):
    if not foto:
        return texto or "(sin texto)"
    return [
        {
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": "image/jpeg",
                "data": base64.standard_b64encode(foto).decode("ascii"),
            },
        },
        {"type": "text", "text": texto or "Te envío una foto de mi pie."},
    ]


def responder(ctx: Contexto) -> Resultado:
    """Claude si hay clave; si falla o tarda, reglas. Las señales de alarma del texto
    siempre se revisan con reglas, aunque responda Claude."""
    inicio = time.monotonic()
    resultado = None
    if asistente_ia.disponible():
        try:
            resultado = ClasificadorClaude().responder(ctx)
        except asistente_ia.ErrorModelo:
            resultado = None
    if resultado is None:
        resultado = ClasificadorReglas().responder(ctx)
    elif resultado.categoria != Categoria.URGENCIA and detectar_alarma(
        ctx.mensaje, ctx.antecedentes, color_en_una=False
    ):
        resultado.respuesta = AVISO_URGENCIA + "\n\n" + resultado.respuesta
        resultado.tipo = Tipo.TRIAJE
        resultado.categoria = Categoria.URGENCIA
        resultado.requiere_derivacion = True
        resultado.motivo_derivacion = "Señal de alarma descrita por el usuario."
    resultado.latencia_ms = int((time.monotonic() - inicio) * 1000)
    return resultado
