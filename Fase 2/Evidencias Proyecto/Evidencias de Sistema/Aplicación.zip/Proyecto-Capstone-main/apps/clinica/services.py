"""Escrituras y casos de uso de clínica."""

import uuid

from django.core.exceptions import PermissionDenied, ValidationError
from django.db import IntegrityError, transaction
from django.db.models import DateTimeField, F, Value
from django.db.models.functions import Greatest
from django.utils import timezone

from apps.agenda.models import Cita
from apps.auditoria.models import RegistroAuditoria
from apps.auditoria.services import registrar

from .models import (
    AtencionClinica,
    Consentimiento,
    Derivacion,
    FichaClinica,
    MarcaPie,
    clave_marca,
)
from .selectors import (
    atenciones_visibles,
    atiende_a,
    derivaciones_visibles,
    fichas_visibles,
    tiene_consentimiento_vigente,
)

# Versión vigente del texto de cada consentimiento. Los textos definitivos están por definir
# (Anexo F, sección 9): mientras tanto todos parten en "v1". La versión la fija el servidor,
# no el cliente, para que quede registrado qué texto se mostró realmente.
VERSION_TEXTO = {
    Consentimiento.Tipo.TRATAMIENTO_DATOS: "v1",
    Consentimiento.Tipo.USO_CHATBOT: "v1",
}


class ConsentimientoRequerido(PermissionDenied):
    """Falta un consentimiento vigente para realizar la acción."""


def aceptar_consentimiento(*, paciente, tipo, ip=None) -> tuple[Consentimiento, bool]:
    """Registra la aceptación. Si ya hay uno vigente del mismo tipo lo devuelve sin duplicar.

    Devuelve (consentimiento, creado).
    """
    if tipo not in VERSION_TEXTO:
        raise ValidationError({"tipo": ["Tipo de consentimiento no válido."]})
    vigentes = Consentimiento.objects.filter(paciente=paciente, tipo=tipo, revocado_en__isnull=True)
    existente = vigentes.first()
    if existente is not None:
        return existente, False
    try:
        with transaction.atomic():
            consentimiento = Consentimiento.objects.create(
                paciente=paciente, tipo=tipo, version_texto=VERSION_TEXTO[tipo]
            )
    except IntegrityError:
        # Otra solicitud simultánea lo creó primero: la restricción única evitó el duplicado.
        return vigentes.get(), False
    registrar(
        accion=RegistroAuditoria.Accion.ACEPTAR_CONSENTIMIENTO,
        usuario=paciente.usuario,
        recurso_tipo="consentimiento",
        recurso_id=consentimiento.pk,
        ip=ip,
        detalle={"tipo": tipo, "version": consentimiento.version_texto},
    )
    return consentimiento, True


def revocar_consentimiento(*, consentimiento, ip=None) -> Consentimiento:
    """Revoca un consentimiento vigente. Si ya estaba revocado no hace nada."""
    with transaction.atomic():
        if consentimiento.revocado_en is not None:
            return consentimiento
        consentimiento.revocado_en = timezone.now()
        consentimiento.save(update_fields=["revocado_en"])
        registrar(
            accion=RegistroAuditoria.Accion.REVOCAR_CONSENTIMIENTO,
            usuario=consentimiento.paciente.usuario,
            recurso_tipo="consentimiento",
            recurso_id=consentimiento.pk,
            ip=ip,
            detalle={"tipo": consentimiento.tipo},
        )
    return consentimiento


def exigir_consentimiento(paciente, tipo) -> None:
    """Para usar antes de crear la ficha (tratamiento_datos) o usar el chatbot (uso_chatbot)."""
    if not tiene_consentimiento_vigente(paciente.pk, tipo):
        raise ConsentimientoRequerido("Falta un consentimiento vigente para esta acción.")


# --- ficha, atenciones y derivaciones ---
#
# Las vistas buscan la ficha, la atención o la derivación entre las visibles para el usuario
# (selectors), así que lo ajeno responde 404. Los servicios vuelven a comprobar el acceso por
# si se llaman desde otro lugar. Ningún registro de auditoría guarda texto clínico.

CAMPOS_FICHA = {
    "diabetes",
    "varices",
    "hta",
    "otras_patologias_cronicas",
    "medicamentos",
    "alergias",
    "ulcera_previa",
    "ulcera_actual",
    "amputaciones",
    "presion_arterial",
    "camina_con_ayuda",
    "calzado_adecuado",
    "pulso_radial",
    "pulso_pedio_derecho",
    "pulso_pedio_izquierdo",
    "lugar_atencion_salud",
    "observaciones",
}
CAMPOS_ATENCION = {
    "motivo_consulta",
    "observacion",
    "tratamiento",
    "indicaciones",
    "diagnostico",
    "pie_derecho",
    "pie_izquierdo",
    "proxima_revision",
}
ESTADOS_ATENDIBLES = (Cita.Estado.AGENDADA, Cita.Estado.CONFIRMADA)
MAX_MARCAS = 80  # símbolos por atención en el dibujo de los pies


def _exigir_que_atiende(profesional, paciente) -> None:
    if not atiende_a(profesional.pk, paciente.pk):
        raise PermissionDenied("El profesional no atiende a este paciente.")


def _auditar(accion, usuario, recurso, ip, detalle=None) -> None:
    registrar(
        accion=accion,
        usuario=usuario,
        recurso_tipo=recurso._meta.model_name,
        recurso_id=recurso.pk,
        ip=ip,
        detalle=detalle,
    )


def ver_ficha(*, ficha, usuario, ip=None) -> FichaClinica:
    """Deja constancia de quién abrió la ficha (paciente o profesional)."""
    if not fichas_visibles(usuario).filter(pk=ficha.pk).exists():
        raise PermissionDenied("No tienes acceso a esta ficha.")
    _auditar(RegistroAuditoria.Accion.VER_FICHA, usuario, ficha, ip)
    return ficha


def crear_ficha(*, profesional, paciente, ip=None, **datos) -> FichaClinica:
    """Abre la ficha del paciente. Exige que lo atienda y su consentimiento vigente."""
    _validar_campos(datos)
    _exigir_que_atiende(profesional, paciente)
    exigir_consentimiento(paciente, Consentimiento.Tipo.TRATAMIENTO_DATOS)
    try:
        with transaction.atomic():
            ficha = FichaClinica.objects.create(paciente=paciente, **datos)
            _auditar(RegistroAuditoria.Accion.CREAR_FICHA, profesional.usuario, ficha, ip)
    except IntegrityError as exc:
        raise ValidationError({"paciente": ["El paciente ya tiene ficha."]}) from exc
    return ficha


def editar_ficha(*, ficha, profesional, ip=None, **cambios) -> FichaClinica:
    """Actualiza los antecedentes de la ficha. La auditoría guarda qué campos, no su texto."""
    _validar_campos(cambios)
    _exigir_que_atiende(profesional, ficha.paciente)
    exigir_consentimiento(ficha.paciente, Consentimiento.Tipo.TRATAMIENTO_DATOS)
    with transaction.atomic():
        for campo, valor in cambios.items():
            setattr(ficha, campo, valor)
        ficha.save()
        _auditar(
            RegistroAuditoria.Accion.EDITAR_FICHA,
            profesional.usuario,
            ficha,
            ip,
            detalle={"campos": sorted(cambios)},
        )
    return ficha


def _validar_campos(datos) -> None:
    desconocidos = set(datos) - CAMPOS_FICHA
    if desconocidos:
        raise ValueError(f"Campos no editables: {sorted(desconocidos)}")


def _validar_atencion(datos) -> None:
    desconocidos = set(datos) - CAMPOS_ATENCION
    if desconocidos:
        raise ValueError(f"Campos no válidos: {sorted(desconocidos)}")
    if not (datos.get("observacion", "").strip() or datos.get("tratamiento", "").strip()):
        raise ValidationError(
            {"tratamiento": ["Registra al menos la observación o el tratamiento realizado."]}
        )


def _demasiadas_marcas():
    return ValidationError({"marcas": [f"El dibujo no puede tener más de {MAX_MARCAS} símbolos."]})


def _validar_marcas(marcas) -> list[dict] | None:
    """El dibujo completo deseado, como diccionarios {simbolo, vista, x, y}.

    `None` significa que el dibujo no cambia (distinto de una lista vacía, que lo borra).
    """
    if marcas is None:
        return None
    marcas = list(marcas)
    if len(marcas) > MAX_MARCAS:
        raise _demasiadas_marcas()
    resultado = []
    for marca in marcas:
        if marca.get("simbolo") not in MarcaPie.Simbolo.values:
            raise ValidationError({"marcas": ["Símbolo no válido."]})
        if marca.get("vista") not in MarcaPie.Vista.values:
            raise ValidationError({"marcas": ["Vista del pie no válida."]})
        try:
            x, y = float(marca["x"]), float(marca["y"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ValidationError({"marcas": ["Posición no válida."]}) from exc
        if not (0 <= x <= 1 and 0 <= y <= 1):
            raise ValidationError({"marcas": ["La marca queda fuera del dibujo."]})
        resultado.append({"simbolo": marca["simbolo"], "vista": marca["vista"], "x": x, "y": y})
    return resultado


def _ids_validos(ids) -> list[uuid.UUID]:
    validos = []
    for valor in ids:
        try:
            validos.append(uuid.UUID(str(valor)))
        except ValueError:
            continue
    return validos


def _actualizar_dibujo(*, ficha, atencion, deseadas, base=None, motivo="", ahora) -> tuple:
    """Registra en la atención solo lo que se agregó y lo que se quitó del dibujo de la ficha.

    `deseadas` es el dibujo completo que dejó el podólogo. Se compara con `base`, los ids de
    las marcas con que partió el formulario (sin ella, con el dibujo vigente). Así, si otro
    podólogo cambió el dibujo mientras tanto, sus cambios no se pierden: solo se retiran las
    marcas que este formulario tenía y quitó. Nunca se borra una fila. Devuelve
    (agregadas, retiradas). Debe llamarse dentro de una transacción.
    """
    if deseadas is None:
        return [], []
    # Bloquear la ficha ordena los cambios simultáneos del mismo dibujo.
    FichaClinica.objects.select_for_update().filter(pk=ficha.pk).first()
    vigentes = {m.pk: m for m in MarcaPie.objects.filter(ficha=ficha, retirada_en__isnull=True)}
    if base is None:
        partida = list(vigentes.values())
    else:
        partida = list(MarcaPie.objects.filter(ficha=ficha, pk__in=_ids_validos(base)))
        # Ante dos iguales, la que sigue igual es la vigente (se empareja primero; ver pop).
        partida.sort(key=lambda marca: marca.pk in vigentes)

    sin_tocar = {}  # clave -> marcas de partida aún no emparejadas con una deseada
    for marca in partida:
        sin_tocar.setdefault(clave_marca(marca), []).append(marca)
    agregadas = []
    for datos in deseadas:
        iguales = sin_tocar.get(clave_marca(datos))
        if iguales:
            iguales.pop()  # sigue igual: no se registra nada
        else:
            agregadas.append(
                MarcaPie(ficha=ficha, atencion_alta=atencion, creada_en=ahora, **datos)
            )
    retiradas = [m for lista in sin_tocar.values() for m in lista if m.pk in vigentes]
    if len(vigentes) - len(retiradas) + len(agregadas) > MAX_MARCAS:
        raise _demasiadas_marcas()

    if retiradas:
        # Greatest: una atención registrada con hora pasada no retira antes de agregar.
        MarcaPie.objects.filter(pk__in=[m.pk for m in retiradas]).update(
            retirada_en=Greatest(Value(ahora, output_field=DateTimeField()), F("creada_en")),
            atencion_baja=atencion,
            motivo_baja=motivo,
        )
    MarcaPie.objects.bulk_create(agregadas)
    return agregadas, retiradas


def _validar_horas(inicio, termino, ahora) -> None:
    if inicio > ahora:
        raise ValidationError({"inicio": ["La atención no puede empezar en el futuro."]})
    if termino is not None and not inicio <= termino <= ahora:
        raise ValidationError(
            {"termino": ["Debe ser posterior al inicio y no estar en el futuro."]}
        )


def registrar_atencion(
    *,
    profesional,
    paciente,
    cita=None,
    inicio=None,
    termino=None,
    marcas=None,
    marcas_base=None,
    ip=None,
    ahora=None,
    **datos,
) -> AtencionClinica:
    """Agrega una "Atención podológica N°" a la ficha del paciente.

    Si se indica la cita, debe ser del mismo profesional y paciente, haber comenzado y estar
    agendada o confirmada; queda `realizada`. Sin cita, el profesional debe atender al
    paciente. La ficha debe existir y el consentimiento estar vigente. Se exige al menos la
    observación o el tratamiento. Hora de inicio por defecto: la de la cita, o ahora sin
    cita; hora de término por defecto: ahora si hay cita (se registra al terminar).

    `marcas` es el dibujo de los pies completo tal como queda tras la atención (sin ellas, no
    cambia); se registra en la atención solo lo agregado y lo quitado. `marcas_base` son los
    ids de las marcas con que partió el formulario (ver `_actualizar_dibujo`).
    """
    ahora = ahora or timezone.now()
    _validar_atencion(datos)
    marcas = _validar_marcas(marcas)
    if cita is None:
        _exigir_que_atiende(profesional, paciente)
    exigir_consentimiento(paciente, Consentimiento.Tipo.TRATAMIENTO_DATOS)
    ficha = FichaClinica.objects.filter(paciente=paciente).first()
    if ficha is None:
        raise ValidationError({"paciente": ["El paciente aún no tiene ficha: créala primero."]})

    with transaction.atomic():
        if cita is not None:
            cita = Cita.objects.select_for_update().get(pk=cita.pk)
            if cita.profesional_id != profesional.pk or cita.paciente_id != paciente.pk:
                raise ValidationError({"cita": ["La cita no es de este paciente y profesional."]})
            if cita.estado not in ESTADOS_ATENDIBLES:
                raise ValidationError({"cita": ["La cita no se puede atender en su estado."]})
            if cita.inicio > ahora:
                raise ValidationError({"cita": ["La cita aún no comienza."]})
            cita.estado = Cita.Estado.REALIZADA
            cita.save(update_fields=["estado"])
            inicio = inicio or cita.inicio
            termino = termino or ahora
        inicio = inicio or ahora
        _validar_horas(inicio, termino, ahora)
        atencion = AtencionClinica.objects.create(
            ficha=ficha,
            cita=cita,
            profesional=profesional,
            fecha=inicio,
            termino=termino,
            **datos,
        )
        _actualizar_dibujo(
            ficha=ficha, atencion=atencion, deseadas=marcas, base=marcas_base, ahora=ahora
        )
        _auditar(RegistroAuditoria.Accion.CREAR_ATENCION, profesional.usuario, atencion, ip)
    return atencion


def corregir_atencion(
    *,
    atencion,
    profesional,
    motivo_correccion,
    marcas=None,
    marcas_base=None,
    ip=None,
    **cambios,
) -> AtencionClinica:
    """Corrige una atención con otra enlazada a ella, sin tocar la original.

    Solo la corrige quien la registró, y solo la versión vigente (una corrección también se
    puede corregir). La corrección copia los campos de la original salvo los que cambian,
    conserva sus horas y exige un motivo. Las derivaciones quedan en la original.

    El dibujo de los pies es uno solo por paciente: sin `marcas` no cambia; con ellas (el
    dibujo completo, aunque sea una lista vacía) la corrección registra lo agregado y lo
    quitado, y lo quitado lleva el motivo de la corrección.
    """
    if atencion.profesional_id != profesional.pk:
        raise PermissionDenied("Solo quien registró la atención puede corregirla.")
    motivo_correccion = motivo_correccion.strip()
    if not motivo_correccion:
        raise ValidationError({"motivo_correccion": ["Indica qué se corrige y por qué."]})
    if len(motivo_correccion) > 200:
        raise ValidationError({"motivo_correccion": ["No puede superar los 200 caracteres."]})
    exigir_consentimiento(atencion.ficha.paciente, Consentimiento.Tipo.TRATAMIENTO_DATOS)

    with transaction.atomic():
        atencion = AtencionClinica.objects.select_for_update().get(pk=atencion.pk)
        if not atencion.vigente:
            raise ValidationError({"atencion": ["Ya fue corregida: corrige la versión vigente."]})
        datos = {campo: getattr(atencion, campo) for campo in CAMPOS_ATENCION} | cambios
        _validar_atencion(datos)
        marcas = _validar_marcas(marcas)
        try:
            with transaction.atomic():
                correccion = AtencionClinica.objects.create(
                    ficha=atencion.ficha,
                    profesional=profesional,
                    fecha=atencion.fecha,
                    termino=atencion.termino,
                    corrige=atencion,
                    motivo_correccion=motivo_correccion,
                    **datos,
                )
        except IntegrityError as exc:  # otra corrección simultánea ganó
            raise ValidationError({"atencion": ["Ya fue corregida."]}) from exc
        agregadas, retiradas = _actualizar_dibujo(
            ficha=atencion.ficha,
            atencion=correccion,
            deseadas=marcas,
            base=marcas_base,
            motivo=motivo_correccion,
            ahora=timezone.now(),
        )
        campos = sorted(cambios) + (["marcas"] if agregadas or retiradas else [])
        _auditar(
            RegistroAuditoria.Accion.CORREGIR_ATENCION,
            profesional.usuario,
            correccion,
            ip,
            detalle={"corrige": str(atencion.pk), "campos": campos},
        )
    return correccion


def ver_atencion(*, atencion, usuario, ip=None) -> AtencionClinica:
    if not atenciones_visibles(usuario).filter(pk=atencion.pk).exists():
        raise PermissionDenied("No tienes acceso a esta atención.")
    _auditar(RegistroAuditoria.Accion.VER_ATENCION, usuario, atencion, ip)
    return atencion


def emitir_derivacion(
    *,
    profesional,
    atencion,
    especialidad_destino,
    motivo,
    especialidad_detalle="",
    resumen_clinico="",
    ip=None,
) -> Derivacion:
    """Emite una derivación desde una atención propia. La auditoría guarda solo el destino."""
    if atencion.profesional_id != profesional.pk:
        raise PermissionDenied("Solo quien registró la atención emite su derivación.")
    if not atencion.vigente:
        raise ValidationError({"atencion": ["Esa atención fue corregida: usa la versión vigente."]})
    exigir_consentimiento(atencion.ficha.paciente, Consentimiento.Tipo.TRATAMIENTO_DATOS)
    especialidad_detalle = especialidad_detalle.strip()
    if especialidad_destino == Derivacion.Especialidad.OTRA and not especialidad_detalle:
        raise ValidationError({"especialidad_detalle": ["Indica a qué especialidad derivas."]})
    if especialidad_destino != Derivacion.Especialidad.OTRA:
        especialidad_detalle = ""
    if not motivo.strip():
        raise ValidationError({"motivo": ["Este campo es obligatorio."]})
    with transaction.atomic():
        derivacion = Derivacion.objects.create(
            atencion=atencion,
            especialidad_destino=especialidad_destino,
            especialidad_detalle=especialidad_detalle,
            motivo=motivo,
            resumen_clinico=resumen_clinico,
        )
        _auditar(
            RegistroAuditoria.Accion.EMITIR_DERIVACION,
            profesional.usuario,
            derivacion,
            ip,
            detalle={"especialidad": especialidad_destino},
        )
    return derivacion


def registrar_descarga(*, derivacion, usuario, ip=None) -> None:
    """Deja constancia de quién descargó el PDF de una derivación."""
    if not derivaciones_visibles(usuario).filter(pk=derivacion.pk).exists():
        raise PermissionDenied("No tienes acceso a esta derivación.")
    _auditar(RegistroAuditoria.Accion.DESCARGAR_DERIVACION, usuario, derivacion, ip)


def registrar_acceso_denegado(*, usuario, recurso_tipo, recurso_id, ip=None) -> None:
    """Deja constancia de un intento de ver o tocar un dato clínico sin acceso.

    Se llama igual exista o no el recurso, así que el registro no revela si existe.
    """
    registrar(
        accion=RegistroAuditoria.Accion.ACCESO_DENEGADO,
        usuario=usuario,
        recurso_tipo=recurso_tipo,
        recurso_id=recurso_id,
        ip=ip,
    )
