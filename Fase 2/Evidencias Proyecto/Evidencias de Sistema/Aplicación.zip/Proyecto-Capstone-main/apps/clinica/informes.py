"""Informe de gestión (B6). Se calcula al pedirlo: no tiene tabla propia.

Solo entrega cifras agregadas: ningún dato identifica a un paciente. Cada profesional ve lo
suyo; el administrador, la consulta completa con el desglose por profesional.
"""

from datetime import date, datetime, time, timedelta

from django.db.models import Count, Q, Sum
from django.db.models.functions import TruncWeek
from django.utils import timezone

from apps.agenda.models import BloqueoHorario, Cita, Disponibilidad
from apps.pagos.models import Pago

from .models import AtencionClinica, Derivacion, FichaClinica

Estado = Cita.Estado
ANTECEDENTES = ["diabetes", "hta", "varices", "ulcera_actual", "amputaciones"]


def _inicio_del_dia(dia: date) -> datetime:
    return datetime.combine(dia, time.min, tzinfo=timezone.get_current_timezone())


def _tasa(parte: int, total: int) -> float | None:
    return round(100 * parte / total, 1) if total else None


def _minutos_disponibles(profesionales, desde: date, hasta: date) -> int:
    """Minutos de atención ofrecidos: tramos activos de cada día menos los bloqueos.

    Usa los tramos vigentes hoy: si el horario cambió dentro del período, la cifra es
    aproximada (los tramos no guardan historia).
    """
    tramos = {}
    for tramo in Disponibilidad.objects.filter(profesional__in=profesionales, activa=True):
        tramos.setdefault((tramo.profesional_id, tramo.dia_semana), []).append(tramo)
    bloqueos = {}
    for bloqueo in BloqueoHorario.objects.filter(
        profesional__in=profesionales,
        inicio__lt=_inicio_del_dia(hasta + timedelta(days=1)),
        fin__gt=_inicio_del_dia(desde),
    ):
        bloqueos.setdefault(bloqueo.profesional_id, []).append(bloqueo)

    zona = timezone.get_current_timezone()
    total = timedelta()
    dia = desde
    while dia <= hasta:
        for profesional in profesionales:
            for tramo in tramos.get((profesional.pk, dia.weekday()), []):
                inicio = datetime.combine(dia, tramo.hora_inicio, tzinfo=zona)
                fin = datetime.combine(dia, tramo.hora_fin, tzinfo=zona)
                libre = fin - inicio
                for bloqueo in bloqueos.get(profesional.pk, []):
                    cruce = min(fin, bloqueo.fin) - max(inicio, bloqueo.inicio)
                    if cruce > timedelta():
                        libre -= cruce
                total += max(libre, timedelta())
        dia += timedelta(days=1)
    return int(total.total_seconds() // 60)


def _resumen_citas(citas) -> dict:
    conteo = dict(citas.values_list("estado").annotate(n=Count("id")).order_by())
    por_estado = {
        estado: conteo.get(estado, 0) for estado in Estado.values if estado != Estado.PENDIENTE_PAGO
    }
    total = sum(por_estado.values())
    atendibles = por_estado[Estado.REALIZADA] + por_estado[Estado.NO_ASISTIO]
    return {
        "total": total,
        "por_estado": por_estado,
        "tasa_inasistencia": _tasa(por_estado[Estado.NO_ASISTIO], atendibles),
        "tasa_cancelacion": _tasa(por_estado[Estado.CANCELADA], total),
    }


def _ingresos(citas) -> dict:
    sumas = citas.aggregate(
        realizados=Sum("precio", filter=Q(estado=Estado.REALIZADA), default=0),
        perdidos_por_inasistencia=Sum("precio", filter=Q(estado=Estado.NO_ASISTIO), default=0),
    )
    return sumas


def _ocupacion(citas, profesionales, desde, hasta) -> dict:
    reservados = timedelta()
    for inicio, fin in citas.exclude(estado=Estado.CANCELADA).values_list("inicio", "fin"):
        reservados += fin - inicio
    minutos_reservados = int(reservados.total_seconds() // 60)
    disponibles = _minutos_disponibles(profesionales, desde, hasta)
    return {
        "minutos_disponibles": disponibles,
        "minutos_reservados": minutos_reservados,
        "porcentaje": _tasa(minutos_reservados, disponibles),
    }


def _tratamientos(citas) -> list[dict]:
    filas = (
        citas.exclude(estado=Estado.CANCELADA)
        .values("tratamiento__nombre")
        .annotate(
            citas=Count("id"),
            realizadas=Count("id", filter=Q(estado=Estado.REALIZADA)),
            ingresos=Sum("precio", filter=Q(estado=Estado.REALIZADA), default=0),
        )
        .order_by("-citas", "tratamiento__nombre")
    )
    return [
        {
            "tratamiento": fila["tratamiento__nombre"],
            "citas": fila["citas"],
            "realizadas": fila["realizadas"],
            "ingresos": fila["ingresos"],
        }
        for fila in filas
    ]


def _pacientes(citas, profesionales, desde) -> dict:
    atendidos = set(
        citas.filter(estado=Estado.REALIZADA).values_list("paciente_id", flat=True).distinct()
    )
    # Nuevo: no tenía ninguna cita realizada con estos profesionales antes del período.
    con_historia = set(
        Cita.objects.filter(
            profesional__in=profesionales,
            paciente_id__in=atendidos,
            estado=Estado.REALIZADA,
            inicio__lt=_inicio_del_dia(desde),
        ).values_list("paciente_id", flat=True)
    )
    return {
        "atendidos": len(atendidos),
        "nuevos": len(atendidos - con_historia),
        "recurrentes": len(atendidos & con_historia),
    }, atendidos


def _perfil_clinico(pacientes_atendidos) -> dict:
    """Cuántos pacientes atendidos tienen cada antecedente: sí, no o sin registro."""
    fichas = FichaClinica.objects.filter(paciente_id__in=pacientes_atendidos)
    perfil = {"con_ficha": fichas.count()}
    for campo in ANTECEDENTES:
        perfil[campo] = fichas.aggregate(
            si=Count("id", filter=Q(**{campo: True})),
            no=Count("id", filter=Q(**{campo: False})),
            sin_registro=Count("id", filter=Q(**{f"{campo}__isnull": True})),
        )
    return perfil


def _por_semana(citas) -> list[dict]:
    filas = (
        citas.annotate(semana=TruncWeek("inicio", tzinfo=timezone.get_current_timezone()))
        .values("semana")
        .annotate(
            realizadas=Count("id", filter=Q(estado=Estado.REALIZADA)),
            canceladas=Count("id", filter=Q(estado=Estado.CANCELADA)),
            no_asistio=Count("id", filter=Q(estado=Estado.NO_ASISTIO)),
            ingresos=Sum("precio", filter=Q(estado=Estado.REALIZADA), default=0),
        )
        .order_by("semana")
    )
    return [{**fila, "semana": timezone.localtime(fila["semana"]).date()} for fila in filas]


def _clinico(profesionales, desde, hasta) -> dict:
    rango = (_inicio_del_dia(desde), _inicio_del_dia(hasta + timedelta(days=1)))
    # Las correcciones no cuentan como atenciones nuevas.
    atenciones = AtencionClinica.objects.filter(
        profesional__in=profesionales, corrige__isnull=True, fecha__gte=rango[0], fecha__lt=rango[1]
    ).count()
    derivaciones = dict(
        Derivacion.objects.filter(
            atencion__profesional__in=profesionales,
            emitida_en__gte=rango[0],
            emitida_en__lt=rango[1],
        )
        .values_list("especialidad_destino")
        .annotate(n=Count("id"))
        .order_by()
    )
    return {
        "atenciones": atenciones,
        "derivaciones": {
            "total": sum(derivaciones.values()),
            "por_especialidad": {
                especialidad: derivaciones.get(especialidad, 0)
                for especialidad in Derivacion.Especialidad.values
            },
        },
    }


def calcular_informe(*, profesionales, desde: date, hasta: date) -> dict:
    """Informe de gestión de uno o varios profesionales entre dos fechas (inclusive)."""
    profesionales = list(profesionales)
    # Una reserva que no se pagó (o se está pagando) no cuenta: nunca llegó a ser una cita.
    citas = (
        Cita.objects.filter(
            profesional__in=profesionales,
            inicio__gte=_inicio_del_dia(desde),
            inicio__lt=_inicio_del_dia(hasta + timedelta(days=1)),
        )
        .exclude(estado=Estado.PENDIENTE_PAGO)
        .exclude(pago__estado__in=Pago.SIN_COBRO)
    )
    pacientes, atendidos = _pacientes(citas, profesionales, desde)
    informe = {
        "desde": desde,
        "hasta": hasta,
        "citas": _resumen_citas(citas),
        "ingresos": _ingresos(citas),
        "ocupacion": _ocupacion(citas, profesionales, desde, hasta),
        "tratamientos": _tratamientos(citas),
        "pacientes": pacientes,
        **_clinico(profesionales, desde, hasta),
        "perfil_clinico": _perfil_clinico(atendidos),
        "por_semana": _por_semana(citas),
    }
    if len(profesionales) > 1:
        informe["por_profesional"] = [
            _resumen_profesional(profesional, citas, desde, hasta) for profesional in profesionales
        ]
    return informe


def _resumen_profesional(profesional, citas, desde, hasta) -> dict:
    propias = citas.filter(profesional=profesional)
    usuario = profesional.usuario
    return {
        "profesional": profesional.pk,
        "nombre": f"{usuario.nombre} {usuario.apellido}",
        "citas": _resumen_citas(propias),
        "ingresos": _ingresos(propias),
        "ocupacion": _ocupacion(propias, [profesional], desde, hasta),
    }
