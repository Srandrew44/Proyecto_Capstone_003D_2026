"""Consultas de clínica. Todo dato del paciente se filtra por el usuario que pregunta.

Quién ve una ficha: el propio paciente, y el profesional que tiene o tuvo con él una cita no
cancelada. Nadie más, tampoco otro profesional de la consulta.
"""

from django.db.models import Exists, OuterRef

from apps.agenda.models import Cita
from apps.cuentas.models import Paciente, Usuario

from .models import AtencionClinica, Consentimiento, Derivacion, FichaClinica, clave_marca


def consentimientos_de(usuario):
    """Consentimientos del propio usuario (un paciente solo ve lo suyo)."""
    return Consentimiento.objects.filter(paciente_id=usuario.pk).order_by("-aceptado_en")


def tiene_consentimiento_vigente(paciente_id, tipo) -> bool:
    return Consentimiento.objects.filter(
        paciente_id=paciente_id, tipo=tipo, revocado_en__isnull=True
    ).exists()


def _citas_vigentes(profesional_id):
    return Cita.objects.filter(profesional_id=profesional_id).exclude(estado=Cita.Estado.CANCELADA)


def atiende_a(profesional_id, paciente_id) -> bool:
    """El profesional tiene o tuvo una cita no cancelada con el paciente."""
    return _citas_vigentes(profesional_id).filter(paciente_id=paciente_id).exists()


def pacientes_de(usuario):
    """Pacientes cuya ficha puede abrir un profesional."""
    citas = _citas_vigentes(usuario.pk).filter(paciente=OuterRef("pk"))
    return Paciente.objects.filter(Exists(citas)).select_related("usuario")


def fichas_visibles(usuario):
    if usuario.rol == Usuario.Rol.PACIENTE:
        return FichaClinica.objects.filter(paciente_id=usuario.pk)
    if usuario.rol == Usuario.Rol.PROFESIONAL:
        return FichaClinica.objects.filter(paciente__in=pacientes_de(usuario))
    return FichaClinica.objects.none()


def atenciones_visibles(usuario):
    return AtencionClinica.objects.filter(ficha__in=fichas_visibles(usuario)).select_related(
        "profesional__usuario"
    )


def derivaciones_visibles(usuario):
    return Derivacion.objects.filter(atencion__in=atenciones_visibles(usuario)).select_related(
        "atencion__profesional__usuario", "atencion__ficha__paciente__usuario"
    )


def numerar_atenciones(atenciones) -> dict:
    """Número de cada atención en la ficha ("Atención podológica N°"), por orden de fecha.

    Una corrección lleva el mismo número que la atención que corrige.
    """
    lista = list(atenciones)
    por_id = {atencion.pk: atencion for atencion in lista}

    def original(atencion):
        while atencion.corrige_id in por_id:
            atencion = por_id[atencion.corrige_id]
        return atencion

    originales = sorted((a for a in lista if a.corrige_id is None), key=lambda a: a.fecha)
    numeros = {atencion.pk: n for n, atencion in enumerate(originales, start=1)}
    return {atencion.pk: numeros.get(original(atencion).pk) for atencion in lista}


# --- dibujo de los pies ---
#
# Reciben una ficha ya obtenida de `fichas_visibles` y usan sus marcas precargadas
# (prefetch "marcas"), así que no vuelven a consultar ni a filtrar por usuario.


def marcas_vigentes(ficha) -> list:
    """El dibujo de los pies tal como está hoy: las marcas sin retirar."""
    return [marca for marca in ficha.marcas.all() if marca.retirada_en is None]


def cambios_del_dibujo(ficha) -> list[dict]:
    """Qué se agregó y qué se quitó del dibujo, de lo más reciente a lo más antiguo.

    Cada cambio: {"tipo": "alta" o "baja", "fecha", "atencion_id", "marca", "motivo"}. Si una
    misma atención quitó y agregó un símbolo igual en el mismo lugar (pasa con las correcciones
    anteriores al dibujo único, que copiaban el dibujo), se muestra el cambio neto: ninguno.
    """
    por_atencion = {}
    for marca in ficha.marcas.all():
        por_atencion.setdefault(marca.atencion_alta_id, ([], []))[0].append(marca)
        if marca.retirada_en is not None:
            por_atencion.setdefault(marca.atencion_baja_id, ([], []))[1].append(marca)

    cambios = []
    for atencion_id, (altas, bajas) in por_atencion.items():
        quitadas = {}
        for marca in bajas:
            quitadas.setdefault(clave_marca(marca), []).append(marca)
        for marca in altas:
            iguales = quitadas.get(clave_marca(marca))
            if iguales:
                iguales.pop()  # se quitó y se volvió a poner igual: no es un cambio
                continue
            cambios.append(
                {
                    "tipo": "alta",
                    "fecha": marca.creada_en,
                    "atencion_id": atencion_id,
                    "marca": marca,
                    "motivo": "",
                }
            )
        for lista in quitadas.values():
            cambios.extend(
                {
                    "tipo": "baja",
                    "fecha": marca.retirada_en,
                    "atencion_id": atencion_id,
                    "marca": marca,
                    "motivo": marca.motivo_baja,
                }
                for marca in lista
            )
    # Más reciente primero; en un mismo momento, lo quitado antes que lo agregado.
    cambios.sort(key=lambda c: (c["fecha"], c["tipo"] == "baja"), reverse=True)
    return cambios
