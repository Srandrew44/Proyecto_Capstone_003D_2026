from datetime import timedelta

import pytest
from django.db import IntegrityError, transaction
from django.utils import timezone

from apps.auditoria.models import RegistroAuditoria
from apps.clinica import selectors, services
from apps.clinica.models import Consentimiento
from apps.cuentas.tests.factories import PacienteFactory

from .factories import ConsentimientoFactory

pytestmark = pytest.mark.django_db
Tipo = Consentimiento.Tipo


def test_no_puede_haber_dos_consentimientos_vigentes_del_mismo_tipo():
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente, tipo=Tipo.USO_CHATBOT)
    with pytest.raises(IntegrityError), transaction.atomic():
        ConsentimientoFactory(paciente=paciente, tipo=Tipo.USO_CHATBOT)


def test_se_puede_volver_a_aceptar_tras_revocar():
    paciente = PacienteFactory()
    primero = ConsentimientoFactory(paciente=paciente, tipo=Tipo.USO_CHATBOT)
    services.revocar_consentimiento(consentimiento=primero)
    nuevo, creado = services.aceptar_consentimiento(paciente=paciente, tipo=Tipo.USO_CHATBOT)
    assert creado
    assert nuevo.pk != primero.pk
    assert paciente.consentimientos.count() == 2


def test_tipos_distintos_conviven_vigentes():
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente, tipo=Tipo.TRATAMIENTO_DATOS)
    ConsentimientoFactory(paciente=paciente, tipo=Tipo.USO_CHATBOT)
    assert paciente.consentimientos.filter(revocado_en__isnull=True).count() == 2


def test_no_se_puede_revocar_antes_de_aceptar():
    ahora = timezone.now()
    with pytest.raises(IntegrityError), transaction.atomic():
        ConsentimientoFactory(aceptado_en=ahora, revocado_en=ahora - timedelta(days=1))


def test_aceptar_es_idempotente_y_audita_una_sola_vez():
    paciente = PacienteFactory()
    uno, creado_uno = services.aceptar_consentimiento(paciente=paciente, tipo=Tipo.USO_CHATBOT)
    dos, creado_dos = services.aceptar_consentimiento(paciente=paciente, tipo=Tipo.USO_CHATBOT)
    assert creado_uno
    assert not creado_dos
    assert uno.pk == dos.pk
    acciones = RegistroAuditoria.objects.filter(
        accion=RegistroAuditoria.Accion.ACEPTAR_CONSENTIMIENTO
    )
    assert acciones.count() == 1
    assert acciones.get().detalle == {"tipo": "uso_chatbot", "version": "v1"}


def test_revocar_registra_fecha_y_auditoria():
    consentimiento = ConsentimientoFactory()
    services.revocar_consentimiento(consentimiento=consentimiento)
    consentimiento.refresh_from_db()
    assert not consentimiento.vigente
    assert RegistroAuditoria.objects.filter(
        accion=RegistroAuditoria.Accion.REVOCAR_CONSENTIMIENTO,
        recurso_id=consentimiento.pk,
    ).exists()


def test_exigir_consentimiento_falla_sin_vigente_y_pasa_con_vigente():
    paciente = PacienteFactory()
    with pytest.raises(services.ConsentimientoRequerido):
        services.exigir_consentimiento(paciente, Tipo.TRATAMIENTO_DATOS)
    ConsentimientoFactory(paciente=paciente, tipo=Tipo.TRATAMIENTO_DATOS)
    services.exigir_consentimiento(paciente, Tipo.TRATAMIENTO_DATOS)


def test_un_consentimiento_revocado_no_cuenta_como_vigente():
    consentimiento = ConsentimientoFactory(tipo=Tipo.USO_CHATBOT)
    services.revocar_consentimiento(consentimiento=consentimiento)
    assert not selectors.tiene_consentimiento_vigente(consentimiento.paciente_id, Tipo.USO_CHATBOT)
