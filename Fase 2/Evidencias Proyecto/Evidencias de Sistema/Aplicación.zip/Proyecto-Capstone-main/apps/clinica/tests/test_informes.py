from datetime import date, timedelta
from uuid import uuid4

import pytest

from apps.agenda.models import Cita
from apps.agenda.tests.factories import (
    INICIO_BASE,
    BloqueoHorarioFactory,
    CitaFactory,
    DisponibilidadFactory,
    TratamientoFactory,
)
from apps.clinica.informes import calcular_informe
from apps.clinica.pdf import generar_pdf_informe
from apps.cuentas.tests.factories import CLAVE, PacienteFactory, ProfesionalFactory, UsuarioFactory

from .factories import AtencionClinicaFactory, DerivacionFactory, FichaClinicaFactory

pytestmark = pytest.mark.django_db

LUNES = INICIO_BASE.date()
Estado = Cita.Estado


def _h(horas):
    return INICIO_BASE.replace(hour=horas)


@pytest.fixture
def escenario():
    """Un lunes con tramo de 09 a 13 (240 min) y una cita de cada estado."""
    profesional = ProfesionalFactory(usuario__nombre="Ana", usuario__apellido="Rojas")
    DisponibilidadFactory(profesional=profesional)
    paciente = PacienteFactory(usuario__nombre="Rosa", usuario__apellido="Pino")
    a = TratamientoFactory(nombre="Atencion general", precio=25000)
    b = TratamientoFactory(nombre="Onicocriptosis", precio=20000)
    citas = {
        "realizada": CitaFactory(
            profesional=profesional,
            paciente=paciente,
            tratamiento=a,
            inicio=_h(9),
            estado=Estado.REALIZADA,
        ),
        "no_asistio": CitaFactory(
            profesional=profesional, tratamiento=b, inicio=_h(10), estado=Estado.NO_ASISTIO
        ),
        "cancelada": CitaFactory(
            profesional=profesional,
            tratamiento=a,
            inicio=_h(11),
            estado=Estado.CANCELADA,
            precio=30000,
        ),
        "confirmada": CitaFactory(profesional=profesional, tratamiento=a, inicio=_h(12)),
    }
    return profesional, paciente, citas


def _informe(profesionales, desde=LUNES, hasta=LUNES):
    return calcular_informe(profesionales=profesionales, desde=desde, hasta=hasta)


def test_resume_las_citas_por_estado_y_sus_tasas(escenario):
    profesional, _, _ = escenario
    citas = _informe([profesional])["citas"]
    assert citas["total"] == 4
    assert citas["por_estado"] == {
        "agendada": 0,
        "confirmada": 1,
        "cancelada": 1,
        "realizada": 1,
        "no_asistio": 1,
    }
    assert citas["tasa_inasistencia"] == 50.0  # 1 de 2 citas que debían atenderse
    assert citas["tasa_cancelacion"] == 25.0


def test_ingresos_realizados_y_perdidos_por_inasistencia(escenario):
    profesional, _, _ = escenario
    assert _informe([profesional])["ingresos"] == {
        "realizados": 25000,
        "perdidos_por_inasistencia": 20000,
    }


def test_ocupacion_descuenta_canceladas_y_bloqueos(escenario):
    profesional, _, _ = escenario
    assert _informe([profesional])["ocupacion"] == {
        "minutos_disponibles": 240,
        "minutos_reservados": 135,  # tres citas de 45 min; la cancelada no cuenta
        "porcentaje": 56.2,
    }
    BloqueoHorarioFactory(profesional=profesional, inicio=_h(8), fin=_h(10))
    assert _informe([profesional])["ocupacion"]["minutos_disponibles"] == 180


def test_tratamientos_ordenados_por_demanda(escenario):
    profesional, _, _ = escenario
    assert _informe([profesional])["tratamientos"] == [
        {"tratamiento": "Atencion general", "citas": 2, "realizadas": 1, "ingresos": 25000},
        {"tratamiento": "Onicocriptosis", "citas": 1, "realizadas": 0, "ingresos": 0},
    ]


def test_pacientes_nuevos_y_recurrentes(escenario):
    profesional, paciente, _ = escenario
    assert _informe([profesional])["pacientes"] == {"atendidos": 1, "nuevos": 1, "recurrentes": 0}
    CitaFactory(
        profesional=profesional,
        paciente=paciente,
        inicio=INICIO_BASE - timedelta(days=7),
        estado=Estado.REALIZADA,
    )
    assert _informe([profesional])["pacientes"] == {"atendidos": 1, "nuevos": 0, "recurrentes": 1}


def test_atenciones_sin_contar_correcciones_y_derivaciones_por_especialidad(escenario):
    profesional, paciente, _ = escenario
    ficha = FichaClinicaFactory(paciente=paciente)
    atencion = AtencionClinicaFactory(ficha=ficha, profesional=profesional, fecha=_h(9))
    AtencionClinicaFactory(
        ficha=ficha, profesional=profesional, fecha=_h(9), corrige=atencion, motivo_correccion="x"
    )
    AtencionClinicaFactory(ficha=ficha, profesional=profesional, fecha=_h(9) - timedelta(days=30))
    DerivacionFactory(atencion=atencion, emitida_en=_h(10), especialidad_destino="dermatologia")
    informe = _informe([profesional])
    assert informe["atenciones"] == 1
    assert informe["derivaciones"]["total"] == 1
    assert informe["derivaciones"]["por_especialidad"]["dermatologia"] == 1
    assert informe["derivaciones"]["por_especialidad"]["traumatologia"] == 0


def test_perfil_clinico_agregado_de_los_pacientes_atendidos(escenario):
    profesional, paciente, _ = escenario
    FichaClinicaFactory(paciente=paciente, diabetes=True, hta=None, varices=False)
    perfil = _informe([profesional])["perfil_clinico"]
    assert perfil["con_ficha"] == 1
    assert perfil["diabetes"] == {"si": 1, "no": 0, "sin_registro": 0}
    assert perfil["hta"] == {"si": 0, "no": 0, "sin_registro": 1}
    assert perfil["varices"] == {"si": 0, "no": 1, "sin_registro": 0}


def test_evolucion_por_semana(escenario):
    profesional, _, _ = escenario
    CitaFactory(profesional=profesional, inicio=_h(9) + timedelta(days=7), estado=Estado.REALIZADA)
    semanas = _informe([profesional], hasta=LUNES + timedelta(days=7))["por_semana"]
    assert [s["semana"] for s in semanas] == [LUNES, LUNES + timedelta(days=7)]
    assert semanas[0]["realizadas"] == 1
    assert semanas[0]["canceladas"] == 1
    assert semanas[0]["no_asistio"] == 1
    assert semanas[1]["ingresos"] == 25000


def test_fuera_del_periodo_no_cuenta(escenario):
    profesional, _, _ = escenario
    informe = _informe(
        [profesional], desde=LUNES + timedelta(days=1), hasta=LUNES + timedelta(days=2)
    )
    assert informe["citas"]["total"] == 0
    assert informe["citas"]["tasa_inasistencia"] is None
    assert informe["ocupacion"]["minutos_disponibles"] == 0
    assert informe["ocupacion"]["porcentaje"] is None


def test_varios_profesionales_traen_el_desglose(escenario):
    profesional, _, _ = escenario
    otro = ProfesionalFactory()
    CitaFactory(profesional=otro, inicio=_h(9), estado=Estado.REALIZADA)
    informe = _informe([profesional, otro])
    assert informe["citas"]["total"] == 5
    desglose = {fila["profesional"]: fila for fila in informe["por_profesional"]}
    assert desglose[profesional.pk]["citas"]["total"] == 4
    assert desglose[otro.pk]["ingresos"]["realizados"] == 25000
    assert "por_profesional" not in _informe([profesional])


# --- API ---

URL = "/api/informes/"


def _entrar(cliente, usuario):
    cliente.post("/api/auth/login/", {"email": usuario.email, "password": CLAVE}, format="json")


def _periodo():
    return {"desde": LUNES.isoformat(), "hasta": LUNES.isoformat()}


def test_el_profesional_ve_solo_su_informe(api_client, escenario):
    profesional, _, _ = escenario
    CitaFactory(inicio=_h(9), estado=Estado.REALIZADA)  # de otro profesional
    _entrar(api_client, profesional.usuario)
    respuesta = api_client.get(URL, _periodo())
    assert respuesta.status_code == 200
    datos = respuesta.json()
    assert datos["citas"]["total"] == 4
    assert "por_profesional" not in datos


def test_el_informe_no_identifica_pacientes(api_client, escenario):
    profesional, paciente, _ = escenario
    FichaClinicaFactory(paciente=paciente)
    _entrar(api_client, profesional.usuario)
    texto = api_client.get(URL, _periodo()).content.decode()
    assert "Rosa" not in texto
    assert paciente.rut not in texto
    assert str(paciente.pk) not in texto


def test_el_administrador_ve_la_consulta_completa_o_un_profesional(api_client, escenario):
    profesional, _, _ = escenario
    otro = ProfesionalFactory()
    CitaFactory(profesional=otro, inicio=_h(9), estado=Estado.REALIZADA)
    _entrar(api_client, UsuarioFactory(rol="admin"))
    datos = api_client.get(URL, _periodo()).json()
    assert datos["citas"]["total"] == 5
    assert len(datos["por_profesional"]) == 2
    solo = api_client.get(URL, {**_periodo(), "profesional": str(otro.pk)}).json()
    assert solo["citas"]["total"] == 1


def test_el_administrador_con_un_profesional_inexistente_recibe_404(api_client):
    _entrar(api_client, UsuarioFactory(rol="admin"))
    assert api_client.get(URL, {"profesional": str(uuid4())}).status_code == 404


def test_un_paciente_no_ve_informes(api_client):
    _entrar(api_client, PacienteFactory().usuario)
    assert api_client.get(URL).status_code == 403


def test_informes_exige_sesion(api_client):
    assert api_client.get(URL).status_code == 403


def test_sin_fechas_es_el_mes_en_curso(api_client):
    _entrar(api_client, ProfesionalFactory().usuario)
    datos = api_client.get(URL).json()
    assert date.fromisoformat(datos["desde"]).day == 1
    assert datos["hasta"] >= datos["desde"]


@pytest.mark.parametrize(
    "periodo",
    [
        {"desde": "2030-01-10", "hasta": "2030-01-01"},
        {"desde": "2028-01-01", "hasta": "2030-01-01"},
        {"desde": "07-01-2030"},
    ],
)
def test_periodos_invalidos_responden_400(api_client, periodo):
    _entrar(api_client, ProfesionalFactory().usuario)
    assert api_client.get(URL, periodo).status_code == 400


# --- PDF ---

PDF = "/api/informes/pdf/"


def _pdf_sin_comprimir(profesionales, alcance="Profesional: Ana Rojas", **periodo):
    informe = _informe(profesionales, **periodo)
    return generar_pdf_informe(informe, alcance=alcance, comprimir=False)


def test_el_pdf_trae_las_cifras_del_informe(escenario):
    profesional, paciente, _ = escenario
    FichaClinicaFactory(paciente=paciente, diabetes=True)
    pdf = _pdf_sin_comprimir([profesional])
    assert pdf.startswith(b"%PDF")
    for texto in (
        b"Profesional: Ana Rojas",
        b"$25.000",  # ingresos realizados, con punto de miles
        b"$20.000",  # perdido por inasistencias
        b"50,0 %",  # tasa de inasistencia
        b"56,2 %",  # ocupacion
        b"Atencion general",
        b"Onicocriptosis",
        b"07/01/2030",
    ):
        assert texto in pdf, texto


def test_el_pdf_no_identifica_pacientes(escenario):
    profesional, paciente, _ = escenario
    pdf = _pdf_sin_comprimir([profesional])
    assert b"Rosa" not in pdf
    assert paciente.rut.encode() not in pdf


def test_el_pdf_de_un_periodo_sin_datos_tambien_se_genera(escenario):
    profesional, _, _ = escenario
    pdf = _pdf_sin_comprimir(
        [profesional], desde=LUNES + timedelta(days=1), hasta=LUNES + timedelta(days=2)
    )
    assert b"sin datos" in pdf


def test_el_profesional_descarga_su_informe_en_pdf(api_client, escenario):
    profesional, _, _ = escenario
    _entrar(api_client, profesional.usuario)
    respuesta = api_client.get(PDF, _periodo())
    assert respuesta.status_code == 200
    assert respuesta["Content-Type"] == "application/pdf"
    assert respuesta["Cache-Control"] == "no-store"
    assert respuesta["Content-Disposition"] == (
        'attachment; filename="informe-20300107-20300107.pdf"'
    )
    assert respuesta.content.startswith(b"%PDF")


def test_el_pdf_del_administrador_incluye_el_desglose(api_client, escenario, monkeypatch):
    profesional, _, _ = escenario
    ProfesionalFactory()
    capturado = {}

    def generar(informe, *, alcance, comprimir=True):
        capturado.update(informe=informe, alcance=alcance)
        return b"%PDF-falso"

    monkeypatch.setattr("apps.clinica.api.views.generar_pdf_informe", generar)
    _entrar(api_client, UsuarioFactory(rol="admin"))
    assert api_client.get(PDF, _periodo()).status_code == 200
    assert capturado["alcance"] == "Toda la consulta"
    assert len(capturado["informe"]["por_profesional"]) == 2
    api_client.get(PDF, {**_periodo(), "profesional": str(profesional.pk)})
    assert capturado["alcance"] == "Profesional: Ana Rojas"


def test_el_pdf_por_profesional_se_dibuja(escenario):
    profesional, _, _ = escenario
    otro = ProfesionalFactory(usuario__nombre="Luis", usuario__apellido="Mora")
    pdf = _pdf_sin_comprimir([profesional, otro], alcance="Toda la consulta")
    assert b"Por profesional" in pdf
    assert b"Luis Mora" in pdf


def test_un_paciente_no_descarga_informes(api_client):
    _entrar(api_client, PacienteFactory().usuario)
    assert api_client.get(PDF).status_code == 403


def test_el_pdf_valida_el_periodo(api_client):
    _entrar(api_client, ProfesionalFactory().usuario)
    assert api_client.get(PDF, {"desde": "2030-01-10", "hasta": "2030-01-01"}).status_code == 400
