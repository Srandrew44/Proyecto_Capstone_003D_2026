import factory

from apps.clinica.models import AtencionClinica, Consentimiento, Derivacion, FichaClinica
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory


class ConsentimientoFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Consentimiento

    paciente = factory.SubFactory(PacienteFactory)
    tipo = Consentimiento.Tipo.TRATAMIENTO_DATOS
    version_texto = "v1"


class FichaClinicaFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = FichaClinica

    paciente = factory.SubFactory(PacienteFactory)
    diabetes = True
    otras_patologias_cronicas = "Hipotiroidismo"
    alergias = ""
    medicamentos = "Metformina"


class AtencionClinicaFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = AtencionClinica

    ficha = factory.SubFactory(FichaClinicaFactory)
    profesional = factory.SubFactory(ProfesionalFactory)
    motivo_consulta = "Dolor en el talón"
    tratamiento = "Onicotomía y deshidratación"
    diagnostico = "Fascitis plantar"


class DerivacionFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Derivacion

    atencion = factory.SubFactory(AtencionClinicaFactory)
    especialidad_destino = Derivacion.Especialidad.TRAUMATOLOGIA
    motivo = "Evaluar espolón calcáneo"
