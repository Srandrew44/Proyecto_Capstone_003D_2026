import pytest
from django.db import IntegrityError
from django.db.models import ProtectedError

from apps.agenda.tests.factories import CitaFactory
from apps.clinica.models import AtencionClinica, Derivacion

from .factories import AtencionClinicaFactory, DerivacionFactory, FichaClinicaFactory

pytestmark = pytest.mark.django_db


def test_un_paciente_tiene_una_sola_ficha():
    ficha = FichaClinicaFactory()
    with pytest.raises(IntegrityError):
        FichaClinicaFactory(paciente=ficha.paciente)


def test_una_cita_tiene_a_lo_mas_una_atencion():
    cita = CitaFactory()
    AtencionClinicaFactory(cita=cita)
    with pytest.raises(IntegrityError):
        AtencionClinicaFactory(cita=cita)


def test_una_atencion_puede_no_tener_cita():
    assert AtencionClinicaFactory().cita is None


def test_las_atenciones_se_ordenan_de_la_mas_reciente():
    ficha = FichaClinicaFactory()
    antigua = AtencionClinicaFactory(ficha=ficha)
    reciente = AtencionClinicaFactory(ficha=ficha)
    assert list(ficha.atenciones.all()) == [reciente, antigua]


def test_no_se_borra_una_ficha_con_atenciones():
    atencion = AtencionClinicaFactory()
    with pytest.raises(ProtectedError):
        atencion.ficha.delete()


def test_no_se_borra_una_atencion_con_derivaciones():
    derivacion = DerivacionFactory()
    with pytest.raises(ProtectedError):
        derivacion.atencion.delete()


def test_no_se_borra_una_cita_con_atencion():
    atencion = AtencionClinicaFactory(cita=CitaFactory())
    with pytest.raises(ProtectedError):
        atencion.cita.delete()


def test_una_derivacion_a_otra_especialidad_exige_el_detalle():
    with pytest.raises(IntegrityError):
        DerivacionFactory(especialidad_destino=Derivacion.Especialidad.OTRA)


def test_el_nombre_de_la_especialidad():
    assert DerivacionFactory().especialidad_nombre == "Traumatología"
    otra = DerivacionFactory(
        especialidad_destino=Derivacion.Especialidad.OTRA, especialidad_detalle="Vascular"
    )
    assert otra.especialidad_nombre == "Vascular"


def test_la_atencion_queda_ligada_a_su_ficha():
    atencion = AtencionClinicaFactory()
    assert AtencionClinica.objects.get(pk=atencion.pk).ficha == atencion.ficha
