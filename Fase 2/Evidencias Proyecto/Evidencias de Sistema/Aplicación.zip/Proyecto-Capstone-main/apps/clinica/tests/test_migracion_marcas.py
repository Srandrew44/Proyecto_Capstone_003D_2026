"""Migración 0008-0010: el dibujo de cada atención pasa al dibujo único de la ficha."""

import pytest
from django.db import connection
from django.db.migrations.executor import MigrationExecutor

from apps.clinica.models import MarcaPie

from .factories import AtencionClinicaFactory

ANTES = [("clinica", "0007_marcas_en_los_pies")]
DESPUES = [("clinica", "0010_marcas_de_la_ficha_obligatorias")]
MACERACION = {"simbolo": "maceracion", "vista": "planta_derecho", "x": 0.5, "y": 0.8}
HALLUX = {"simbolo": "hallux_valgus_incipiente", "vista": "dorso_izquierdo", "x": 0.2, "y": 0.1}


def _migrar(destino):
    executor = MigrationExecutor(connection)
    executor.loader.build_graph()
    executor.migrate(destino)
    return executor.loader.project_state(destino).apps


@pytest.mark.django_db(transaction=True)
def test_la_migracion_arma_el_dibujo_con_las_atenciones_vigentes_y_se_revierte():
    primera = AtencionClinicaFactory()
    ficha, profesional = primera.ficha, primera.profesional
    original = AtencionClinicaFactory(ficha=ficha, profesional=profesional)
    correccion = AtencionClinicaFactory(
        ficha=ficha,
        profesional=profesional,
        fecha=original.fecha,
        corrige=original,
        motivo_correccion="Era el otro pie",
    )
    try:
        viejas = _migrar(ANTES)
        Marca = viejas.get_model("clinica", "MarcaPie")
        Marca.objects.create(atencion_id=primera.pk, **MACERACION)
        Marca.objects.create(atencion_id=original.pk, **MACERACION)  # la corrección la quitó
        Marca.objects.create(atencion_id=correccion.pk, **HALLUX)

        _migrar(DESPUES)
        vigentes = MarcaPie.objects.filter(ficha=ficha, retirada_en__isnull=True)
        assert sorted((m.simbolo, m.atencion_alta_id) for m in vigentes) == sorted(
            [("maceracion", primera.pk), ("hallux_valgus_incipiente", correccion.pk)]
        )
        retirada = MarcaPie.objects.get(atencion_alta=original)
        assert retirada.atencion_baja_id == correccion.pk
        assert retirada.motivo_baja == "Era el otro pie"
        assert retirada.creada_en == original.fecha
        assert MarcaPie.objects.count() == 3  # no se pierde ninguna

        viejas = _migrar(ANTES)
        Marca = viejas.get_model("clinica", "MarcaPie")
        por_atencion = sorted((m.atencion_id, m.simbolo) for m in Marca.objects.all())
        assert por_atencion == sorted(
            [
                (primera.pk, "maceracion"),
                (original.pk, "maceracion"),
                (correccion.pk, "hallux_valgus_incipiente"),
            ]
        )
    finally:
        _migrar(DESPUES)  # las demás pruebas usan el esquema nuevo
