import pytest

from apps.cuentas.tests.factories import CLAVE, PacienteFactory, ProfesionalFactory

from .factories import ConsentimientoFactory

pytestmark = pytest.mark.django_db
URL = "/api/consentimientos/"


def _entrar(cliente, usuario):
    cliente.post("/api/auth/login/", {"email": usuario.email, "password": CLAVE}, format="json")


def test_exige_sesion(api_client):
    assert api_client.get(URL).status_code == 403
    assert api_client.post(URL, {"tipo": "uso_chatbot"}, format="json").status_code == 403


def test_el_profesional_no_usa_este_recurso(api_client):
    _entrar(api_client, ProfesionalFactory().usuario)
    assert api_client.get(URL).status_code == 403


def test_el_paciente_acepta_y_lista_sus_consentimientos(api_client):
    paciente = PacienteFactory()
    _entrar(api_client, paciente.usuario)
    primera = api_client.post(URL, {"tipo": "uso_chatbot"}, format="json")
    segunda = api_client.post(URL, {"tipo": "uso_chatbot"}, format="json")
    assert primera.status_code == 201
    assert segunda.status_code == 200
    assert primera.json()["id"] == segunda.json()["id"]
    lista = api_client.get(URL).json()
    assert len(lista) == 1
    assert lista[0]["vigente"] is True


def test_tipo_invalido(api_client):
    _entrar(api_client, PacienteFactory().usuario)
    respuesta = api_client.post(URL, {"tipo": "inventado"}, format="json")
    assert respuesta.status_code == 400


def test_paciente_a_no_ve_ni_revoca_lo_de_paciente_b(api_client):
    a, b = PacienteFactory(), PacienteFactory()
    de_a = ConsentimientoFactory(paciente=a)
    _entrar(api_client, b.usuario)

    assert api_client.get(URL).json() == []
    respuesta = api_client.post(f"{URL}{de_a.pk}/revocar/")
    assert respuesta.status_code == 404

    de_a.refresh_from_db()
    assert de_a.vigente


def test_el_paciente_revoca_el_suyo(api_client):
    paciente = PacienteFactory()
    consentimiento = ConsentimientoFactory(paciente=paciente)
    _entrar(api_client, paciente.usuario)
    respuesta = api_client.post(f"{URL}{consentimiento.pk}/revocar/")
    assert respuesta.status_code == 200
    assert respuesta.json()["vigente"] is False


def test_el_consentimiento_de_atencion_a_domicilio_ya_no_existe(api_client):
    # La atención es solo en la consulta fija; ese tipo se retiró del sistema.
    _entrar(api_client, PacienteFactory().usuario)
    respuesta = api_client.post(URL, {"tipo": "atencion_domicilio"}, format="json")
    assert respuesta.status_code == 400
