from datetime import timedelta

import pytest
from django.core.exceptions import PermissionDenied, ValidationError

from apps.agenda.models import Cita
from apps.agenda.tests.factories import INICIO_BASE, CitaFactory
from apps.auditoria.models import RegistroAuditoria
from apps.clinica import selectors
from apps.clinica.models import Derivacion
from apps.clinica.services import (
    ConsentimientoRequerido,
    crear_ficha,
    editar_ficha,
    emitir_derivacion,
    registrar_atencion,
    registrar_descarga,
    ver_atencion,
    ver_ficha,
)
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory, UsuarioFactory

from .factories import (
    AtencionClinicaFactory,
    ConsentimientoFactory,
    DerivacionFactory,
    FichaClinicaFactory,
)

pytestmark = pytest.mark.django_db

DURANTE = INICIO_BASE + timedelta(minutes=10)  # la cita ya comenzó
Accion = RegistroAuditoria.Accion


@pytest.fixture
def cita():
    """Cita entre un profesional y un paciente que aceptó el consentimiento de datos."""
    cita = CitaFactory()
    ConsentimientoFactory(paciente=cita.paciente)
    return cita


@pytest.fixture
def ficha(cita):
    return FichaClinicaFactory(paciente=cita.paciente)


def _registros(accion):
    return RegistroAuditoria.objects.filter(accion=accion)


# --- acceso ---


def test_el_profesional_atiende_a_quien_tiene_cita_con_el(cita):
    assert selectors.atiende_a(cita.profesional_id, cita.paciente_id)
    assert not selectors.atiende_a(ProfesionalFactory().pk, cita.paciente_id)


def test_una_cita_cancelada_no_da_acceso_a_la_ficha():
    cita = CitaFactory(estado=Cita.Estado.CANCELADA)
    FichaClinicaFactory(paciente=cita.paciente)
    assert not selectors.fichas_visibles(cita.profesional.usuario).exists()


def test_el_paciente_solo_ve_su_ficha(ficha):
    FichaClinicaFactory()
    assert list(selectors.fichas_visibles(ficha.paciente.usuario)) == [ficha]


def test_el_profesional_ve_solo_las_fichas_de_sus_pacientes(cita, ficha):
    FichaClinicaFactory()
    assert list(selectors.fichas_visibles(cita.profesional.usuario)) == [ficha]


def test_otro_profesional_de_la_consulta_no_ve_la_ficha(ficha):
    assert not selectors.fichas_visibles(ProfesionalFactory().usuario).exists()


def test_el_administrador_no_ve_fichas_por_la_api(ficha):
    admin = UsuarioFactory(rol="admin")
    assert not selectors.fichas_visibles(admin).exists()


def test_las_atenciones_y_derivaciones_siguen_la_misma_regla(cita, ficha):
    derivacion = DerivacionFactory(atencion__ficha=ficha)
    assert list(selectors.derivaciones_visibles(cita.paciente.usuario)) == [derivacion]
    assert list(selectors.derivaciones_visibles(cita.profesional.usuario)) == [derivacion]
    assert not selectors.atenciones_visibles(PacienteFactory().usuario).exists()


# --- ficha ---


def test_el_profesional_crea_la_ficha_y_queda_auditado(cita):
    ficha = crear_ficha(
        profesional=cita.profesional, paciente=cita.paciente, alergias="Penicilina", ip="10.0.0.1"
    )
    assert ficha.paciente == cita.paciente
    registro = _registros(Accion.CREAR_FICHA).get()
    assert registro.usuario == cita.profesional.usuario
    assert registro.recurso_id == ficha.pk
    assert "Penicilina" not in str(registro.detalle)


def test_no_crea_la_ficha_de_quien_no_atiende(cita):
    with pytest.raises(PermissionDenied):
        crear_ficha(profesional=ProfesionalFactory(), paciente=cita.paciente)


def test_crear_la_ficha_exige_consentimiento():
    cita = CitaFactory()
    with pytest.raises(ConsentimientoRequerido):
        crear_ficha(profesional=cita.profesional, paciente=cita.paciente)


def test_no_se_crean_dos_fichas(cita, ficha):
    with pytest.raises(ValidationError, match="ya tiene ficha"):
        crear_ficha(profesional=cita.profesional, paciente=cita.paciente)
    assert not _registros(Accion.CREAR_FICHA).exists()


def test_editar_la_ficha_audita_los_campos_y_no_el_texto(cita, ficha):
    editar_ficha(ficha=ficha, profesional=cita.profesional, alergias="Látex", medicamentos="")
    ficha.refresh_from_db()
    assert ficha.alergias == "Látex"
    registro = _registros(Accion.EDITAR_FICHA).get()
    assert registro.detalle == {"campos": ["alergias", "medicamentos"]}


def test_editar_rechaza_campos_desconocidos(cita, ficha):
    with pytest.raises(ValueError):
        editar_ficha(ficha=ficha, profesional=cita.profesional, paciente=PacienteFactory())


def test_con_el_consentimiento_revocado_la_ficha_no_se_edita(cita, ficha):
    cita.paciente.consentimientos.update(revocado_en=INICIO_BASE)
    with pytest.raises(ConsentimientoRequerido):
        editar_ficha(ficha=ficha, profesional=cita.profesional, alergias="x")


def test_ver_la_ficha_queda_auditado(cita, ficha):
    ver_ficha(ficha=ficha, usuario=cita.paciente.usuario, ip="10.0.0.2")
    ver_ficha(ficha=ficha, usuario=cita.profesional.usuario)
    usuarios = {r.usuario for r in _registros(Accion.VER_FICHA)}
    assert usuarios == {cita.paciente.usuario, cita.profesional.usuario}


def test_un_tercero_no_ve_la_ficha_ni_deja_registro(ficha):
    with pytest.raises(PermissionDenied):
        ver_ficha(ficha=ficha, usuario=ProfesionalFactory().usuario)
    assert not _registros(Accion.VER_FICHA).exists()


# --- atenciones ---


def _atender(de, **extra):
    """Atención del profesional al paciente de la cita `de`."""
    datos = {"tratamiento": "Onicotomía", "ahora": DURANTE, **extra}
    return registrar_atencion(profesional=de.profesional, paciente=de.paciente, **datos)


def test_atender_una_cita_la_deja_realizada(cita, ficha):
    atencion = _atender(cita, cita=cita, diagnostico="Fascitis plantar")
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.REALIZADA
    assert atencion.cita == cita
    assert atencion.ficha == ficha
    assert atencion.fecha == INICIO_BASE  # la hora de inicio es la de la cita
    assert atencion.termino == DURANTE  # se registra al terminar
    registro = _registros(Accion.CREAR_ATENCION).get()
    assert registro.recurso_id == atencion.pk
    assert "Fascitis" not in str(registro.detalle)


def test_se_puede_atender_sin_cita_a_un_paciente_propio(cita, ficha):
    atencion = _atender(cita)
    assert atencion.cita is None
    assert atencion.fecha == DURANTE
    assert atencion.termino is None
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CONFIRMADA


def test_sin_cita_no_se_atiende_a_un_paciente_ajeno(ficha):
    with pytest.raises(PermissionDenied):
        registrar_atencion(
            profesional=ProfesionalFactory(), paciente=ficha.paciente, tratamiento="x"
        )


def test_atender_exige_la_ficha(cita):
    with pytest.raises(ValidationError, match="no tiene ficha"):
        _atender(cita, cita=cita)


def test_la_cita_debe_ser_de_ese_paciente(cita, ficha):
    otra = CitaFactory(profesional=cita.profesional, inicio=INICIO_BASE + timedelta(hours=2))
    with pytest.raises(ValidationError, match="no es de este paciente"):
        _atender(cita, cita=otra, ahora=otra.inicio)


def test_una_cita_futura_no_se_atiende(cita, ficha):
    with pytest.raises(ValidationError, match="aún no comienza"):
        _atender(cita, cita=cita, ahora=INICIO_BASE - timedelta(minutes=1))


@pytest.mark.parametrize(
    "estado", [Cita.Estado.CANCELADA, Cita.Estado.NO_ASISTIO, Cita.Estado.REALIZADA]
)
def test_una_cita_no_activa_no_se_atiende(cita, ficha, estado):
    cita.estado = estado
    cita.save()
    with pytest.raises(ValidationError, match="no se puede atender"):
        _atender(cita, cita=cita)
    assert not _registros(Accion.CREAR_ATENCION).exists()


def test_exige_observacion_o_tratamiento(cita, ficha):
    with pytest.raises(ValidationError, match="observación o el tratamiento"):
        _atender(cita, tratamiento="  ", motivo_consulta="Control")
    assert _atender(cita, tratamiento="", observacion="Piel sana").observacion == "Piel sana"


def test_atender_exige_consentimiento_vigente(cita, ficha):
    cita.paciente.consentimientos.update(revocado_en=INICIO_BASE)
    with pytest.raises(ConsentimientoRequerido):
        _atender(cita, cita=cita)
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CONFIRMADA


def test_ver_una_atencion_queda_auditado(cita, ficha):
    atencion = AtencionClinicaFactory(ficha=ficha)
    ver_atencion(atencion=atencion, usuario=cita.paciente.usuario)
    assert _registros(Accion.VER_ATENCION).get().recurso_id == atencion.pk
    with pytest.raises(PermissionDenied):
        ver_atencion(atencion=atencion, usuario=PacienteFactory().usuario)


# --- derivaciones ---


def test_emitir_una_derivacion_audita_solo_el_destino(cita, ficha):
    atencion = AtencionClinicaFactory(ficha=ficha, profesional=cita.profesional)
    derivacion = emitir_derivacion(
        profesional=cita.profesional,
        atencion=atencion,
        especialidad_destino=Derivacion.Especialidad.DERMATOLOGIA,
        motivo="Lesión pigmentada en la planta",
    )
    assert derivacion.atencion == atencion
    registro = _registros(Accion.EMITIR_DERIVACION).get()
    assert registro.detalle == {"especialidad": "dermatologia"}


def test_solo_quien_atendio_emite_la_derivacion(cita, ficha):
    atencion = AtencionClinicaFactory(ficha=ficha)
    with pytest.raises(PermissionDenied):
        emitir_derivacion(
            profesional=cita.profesional,
            atencion=atencion,
            especialidad_destino=Derivacion.Especialidad.TRAUMATOLOGIA,
            motivo="x",
        )


def test_otra_especialidad_exige_el_detalle_y_las_demas_lo_ignoran(cita, ficha):
    atencion = AtencionClinicaFactory(ficha=ficha, profesional=cita.profesional)
    with pytest.raises(ValidationError) as error:
        emitir_derivacion(
            profesional=cita.profesional,
            atencion=atencion,
            especialidad_destino=Derivacion.Especialidad.OTRA,
            motivo="x",
        )
    assert "especialidad_detalle" in error.value.message_dict
    derivacion = emitir_derivacion(
        profesional=cita.profesional,
        atencion=atencion,
        especialidad_destino=Derivacion.Especialidad.TRAUMATOLOGIA,
        especialidad_detalle="Ignorado",
        motivo="x",
    )
    assert derivacion.especialidad_detalle == ""


def test_la_derivacion_exige_motivo_y_consentimiento(cita, ficha):
    atencion = AtencionClinicaFactory(ficha=ficha, profesional=cita.profesional)
    datos = {"profesional": cita.profesional, "atencion": atencion}
    with pytest.raises(ValidationError):
        emitir_derivacion(**datos, especialidad_destino="traumatologia", motivo=" ")
    cita.paciente.consentimientos.update(revocado_en=INICIO_BASE)
    with pytest.raises(ConsentimientoRequerido):
        emitir_derivacion(**datos, especialidad_destino="traumatologia", motivo="x")


def test_la_descarga_queda_auditada_y_un_tercero_no_descarga(cita, ficha):
    derivacion = DerivacionFactory(atencion__ficha=ficha)
    registrar_descarga(derivacion=derivacion, usuario=cita.paciente.usuario)
    assert _registros(Accion.DESCARGAR_DERIVACION).get().recurso_id == derivacion.pk
    with pytest.raises(PermissionDenied):
        registrar_descarga(derivacion=derivacion, usuario=ProfesionalFactory().usuario)
