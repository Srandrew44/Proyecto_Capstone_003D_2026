"""Dibujo de los pies: uno solo por paciente, en la ficha, con el registro de cada cambio."""

from datetime import timedelta

import pytest
from django.core.exceptions import ValidationError
from django.db import IntegrityError
from django.utils import timezone

from apps.agenda.tests.factories import INICIO_BASE, CitaFactory
from apps.auditoria.models import RegistroAuditoria
from apps.clinica.models import MarcaPie
from apps.clinica.selectors import cambios_del_dibujo, marcas_vigentes
from apps.clinica.services import MAX_MARCAS, corregir_atencion, registrar_atencion
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory

from .factories import AtencionClinicaFactory, ConsentimientoFactory, FichaClinicaFactory

pytestmark = pytest.mark.django_db

MACERACION = {"simbolo": "maceracion", "vista": "planta_derecho", "x": 0.5, "y": 0.8}
HALLUX = {"simbolo": "hallux_valgus_incipiente", "vista": "dorso_izquierdo", "x": 0.2, "y": 0.1}
MILLAR = {"simbolo": "heloma_millar", "vista": "planta_izquierdo", "x": 0.4, "y": 0.3}


@pytest.fixture
def cita():
    cita = CitaFactory()
    ConsentimientoFactory(paciente=cita.paciente)
    FichaClinicaFactory(paciente=cita.paciente)
    return cita


def _registrar(cita, marcas, **extra):
    return registrar_atencion(
        profesional=cita.profesional,
        paciente=cita.paciente,
        tratamiento="Onicotomía",
        marcas=marcas,
        **extra,
    )


def _dibujo(ficha):
    return sorted(
        (m.simbolo, m.vista, m.x, m.y)
        for m in MarcaPie.objects.filter(ficha=ficha, retirada_en__isnull=True)
    )


def _tupla(marca):
    return (marca["simbolo"], marca["vista"], marca["x"], marca["y"])


# --- altas, bajas y sin cambios ---


def test_la_atencion_agrega_las_marcas_al_dibujo_de_la_ficha(cita):
    atencion = _registrar(cita, [MACERACION, HALLUX])
    ficha = cita.paciente.ficha
    assert _dibujo(ficha) == sorted([_tupla(MACERACION), _tupla(HALLUX)])
    for marca in MarcaPie.objects.all():
        assert marca.ficha == ficha
        assert marca.atencion_alta == atencion
        assert marca.vigente
        assert marca.creada_en is not None


def test_sin_marcas_el_dibujo_no_cambia(cita):
    _registrar(cita, [MACERACION])
    segunda = _registrar(cita, None)
    assert _dibujo(cita.paciente.ficha) == [_tupla(MACERACION)]
    assert segunda.marcas_agregadas.count() == 0
    assert segunda.marcas_retiradas.count() == 0


def test_el_mismo_dibujo_no_registra_nada(cita):
    _registrar(cita, [MACERACION, HALLUX])
    segunda = _registrar(cita, [HALLUX, MACERACION])  # el orden no importa
    assert MarcaPie.objects.count() == 2
    assert segunda.marcas_agregadas.count() == 0
    assert segunda.marcas_retiradas.count() == 0


def test_el_ida_y_vuelta_por_el_navegador_no_inventa_movimientos(cita):
    _registrar(cita, [{**MACERACION, "x": 0.1 + 0.2}])  # 0.30000000000000004
    _registrar(cita, [{**MACERACION, "x": 0.3}])
    assert MarcaPie.objects.count() == 1


def test_se_registra_solo_lo_agregado_y_lo_quitado(cita):
    primera = _registrar(cita, [MACERACION, HALLUX])
    segunda = _registrar(cita, [HALLUX, MILLAR])
    assert [m.simbolo for m in segunda.marcas_agregadas.all()] == ["heloma_millar"]
    retirada = segunda.marcas_retiradas.get()
    assert retirada.simbolo == "maceracion"
    assert retirada.atencion_alta == primera
    assert retirada.retirada_en is not None
    assert retirada.motivo_baja == ""
    # Nada se borra: la marca quitada sigue en la base, ahora retirada.
    assert MarcaPie.objects.count() == 3
    assert _dibujo(cita.paciente.ficha) == sorted([_tupla(HALLUX), _tupla(MILLAR)])


def test_mover_un_simbolo_es_quitarlo_y_agregar_otro(cita):
    _registrar(cita, [MACERACION])
    segunda = _registrar(cita, [{**MACERACION, "x": 0.6}])
    assert segunda.marcas_retiradas.get().x == 0.5
    assert segunda.marcas_agregadas.get().x == 0.6
    assert MarcaPie.objects.count() == 2


def test_un_dibujo_vacio_retira_todas_las_marcas(cita):
    _registrar(cita, [MACERACION, HALLUX])
    segunda = _registrar(cita, [])
    assert segunda.marcas_retiradas.count() == 2
    assert _dibujo(cita.paciente.ficha) == []


def test_dos_simbolos_iguales_en_el_mismo_lugar_cuentan_por_separado(cita):
    _registrar(cita, [MACERACION, MACERACION])
    segunda = _registrar(cita, [MACERACION])
    assert segunda.marcas_retiradas.count() == 1
    assert len(_dibujo(cita.paciente.ficha)) == 1


def test_lo_que_otro_cambio_entretanto_no_se_pierde(cita):
    """El formulario partió de un dibujo; otro podólogo lo cambió antes de que se guardara."""
    primera = _registrar(cita, [MACERACION])
    base = [str(primera.marcas_agregadas.get().pk)]
    _registrar(cita, [MACERACION, HALLUX])  # el otro agrega un hallux
    # Este formulario partió solo con la maceración, la quita y agrega un heloma millar.
    _registrar(cita, [MILLAR], marcas_base=base)
    assert _dibujo(cita.paciente.ficha) == sorted([_tupla(HALLUX), _tupla(MILLAR)])


def test_una_base_con_ids_ajenos_o_invalidos_se_ignora(cita):
    otra = AtencionClinicaFactory()
    ajena = MarcaPie.objects.create(ficha=otra.ficha, atencion_alta=otra, **HALLUX)
    _registrar(cita, [MACERACION], marcas_base=[str(ajena.pk), "no-es-un-id"])
    ajena.refresh_from_db()
    assert ajena.vigente
    assert _dibujo(cita.paciente.ficha) == [_tupla(MACERACION)]


# --- validaciones ---


@pytest.mark.parametrize(
    "marca",
    [
        {**MACERACION, "simbolo": "inventado"},
        {**MACERACION, "vista": "tobillo"},
        {**MACERACION, "x": 1.2},
        {**MACERACION, "y": -0.1},
        {"simbolo": "maceracion", "vista": "planta_derecho"},
    ],
)
def test_una_marca_invalida_no_guarda_nada(cita, marca):
    with pytest.raises(ValidationError):
        _registrar(cita, [MACERACION, marca])
    assert MarcaPie.objects.count() == 0
    assert not cita.paciente.ficha.atenciones.exists()


def test_hay_un_tope_de_marcas_en_el_dibujo(cita):
    with pytest.raises(ValidationError):
        _registrar(cita, [MACERACION] * (MAX_MARCAS + 1))


def test_el_tope_cuenta_lo_que_otro_agrego_entretanto(cita):
    _registrar(cita, [MACERACION] * MAX_MARCAS)
    with pytest.raises(ValidationError):
        _registrar(cita, [HALLUX], marcas_base=[])
    assert MarcaPie.objects.count() == MAX_MARCAS


def test_la_base_rechaza_una_marca_fuera_del_dibujo(cita):
    atencion = AtencionClinicaFactory(ficha=cita.paciente.ficha, profesional=cita.profesional)
    with pytest.raises(IntegrityError):
        MarcaPie.objects.create(
            ficha=atencion.ficha,
            atencion_alta=atencion,
            simbolo="maceracion",
            vista="dorso_derecho",
            x=2,
            y=0,
        )


def test_la_base_exige_un_retiro_completo(cita):
    atencion = AtencionClinicaFactory(ficha=cita.paciente.ficha, profesional=cita.profesional)
    with pytest.raises(IntegrityError):
        MarcaPie.objects.create(
            ficha=atencion.ficha,
            atencion_alta=atencion,
            retirada_en=timezone.now(),  # sin la atención que la retira
            **MACERACION,
        )


def test_una_atencion_con_hora_pasada_no_retira_antes_de_agregar(cita):
    _registrar(cita, [MACERACION])
    _registrar(cita, [], ahora=timezone.now() - timedelta(days=1))
    marca = MarcaPie.objects.get()
    assert marca.retirada_en >= marca.creada_en


# --- correcciones ---


def _atencion_con_marcas(cita):
    atencion = AtencionClinicaFactory(
        ficha=cita.paciente.ficha, profesional=cita.profesional, fecha=INICIO_BASE
    )
    MarcaPie.objects.create(ficha=atencion.ficha, atencion_alta=atencion, **MACERACION)
    return atencion


def test_la_correccion_sin_marcas_no_toca_el_dibujo(cita):
    original = _atencion_con_marcas(cita)
    correccion = corregir_atencion(
        atencion=original, profesional=cita.profesional, motivo_correccion="Tipeo", tratamiento="X"
    )
    assert correccion.marcas_agregadas.count() == 0
    assert _dibujo(cita.paciente.ficha) == [_tupla(MACERACION)]  # no se duplica
    registro = RegistroAuditoria.objects.get(accion=RegistroAuditoria.Accion.CORREGIR_ATENCION)
    assert registro.detalle["campos"] == ["tratamiento"]


def test_la_correccion_con_el_mismo_dibujo_no_registra_cambios(cita):
    original = _atencion_con_marcas(cita)
    correccion = corregir_atencion(
        atencion=original,
        profesional=cita.profesional,
        motivo_correccion="Tipeo",
        tratamiento="X",
        marcas=[MACERACION],
    )
    assert correccion.marcas_agregadas.count() == 0
    assert MarcaPie.objects.count() == 1
    registro = RegistroAuditoria.objects.get(accion=RegistroAuditoria.Accion.CORREGIR_ATENCION)
    assert registro.detalle["campos"] == ["tratamiento"]


def test_la_correccion_registra_lo_que_cambia_con_su_motivo(cita):
    original = _atencion_con_marcas(cita)
    correccion = corregir_atencion(
        atencion=original,
        profesional=cita.profesional,
        motivo_correccion="Era el otro pie",
        marcas=[HALLUX],
    )
    retirada = correccion.marcas_retiradas.get()
    assert retirada.simbolo == "maceracion"
    assert retirada.motivo_baja == "Era el otro pie"
    assert retirada.atencion_baja.profesional == cita.profesional  # quién la quitó
    assert [m.vista for m in correccion.marcas_agregadas.all()] == ["dorso_izquierdo"]
    assert _dibujo(cita.paciente.ficha) == [_tupla(HALLUX)]
    registro = RegistroAuditoria.objects.get(accion=RegistroAuditoria.Accion.CORREGIR_ATENCION)
    assert registro.detalle["campos"] == ["marcas"]


# --- historial ---


def test_el_historial_cuenta_altas_y_bajas_del_mas_reciente_al_mas_antiguo(cita):
    primera = _registrar(cita, [MACERACION])
    segunda = _registrar(cita, [HALLUX])
    ficha = cita.paciente.ficha
    cambios = [(c["tipo"], c["marca"].simbolo, c["atencion_id"]) for c in cambios_del_dibujo(ficha)]
    assert cambios == [
        ("baja", "maceracion", segunda.pk),
        ("alta", "hallux_valgus_incipiente", segunda.pk),
        ("alta", "maceracion", primera.pk),
    ]
    assert [m.simbolo for m in marcas_vigentes(ficha)] == ["hallux_valgus_incipiente"]


def test_el_historial_muestra_el_cambio_neto_de_una_atencion(cita):
    """Las correcciones de antes copiaban el dibujo: quitar y poner lo mismo no es un cambio."""
    original = _atencion_con_marcas(cita)
    correccion = AtencionClinicaFactory(
        ficha=original.ficha,
        profesional=cita.profesional,
        fecha=INICIO_BASE,
        corrige=original,
        motivo_correccion="Tipeo",
    )
    MarcaPie.objects.filter(atencion_alta=original).update(
        creada_en=INICIO_BASE,
        atencion_baja=correccion,
        retirada_en=INICIO_BASE,
        motivo_baja="Tipeo",
    )
    MarcaPie.objects.create(
        ficha=original.ficha, atencion_alta=correccion, creada_en=INICIO_BASE, **MACERACION
    )
    cambios = cambios_del_dibujo(original.ficha)
    assert [(c["tipo"], c["atencion_id"]) for c in cambios] == [("alta", original.pk)]


# --- API y permisos ---


def test_la_api_recibe_el_dibujo_y_devuelve_los_cambios(api_client, cita):
    api_client.force_authenticate(cita.profesional.usuario)
    url = f"/api/pacientes/{cita.paciente.pk}/atenciones/"
    respuesta = api_client.post(
        url, {"tratamiento": "Onicotomía", "marcas": [MACERACION]}, format="json"
    )
    assert respuesta.status_code == 201
    assert respuesta.json()["marcas_agregadas"] == [MACERACION]
    respuesta = api_client.post(url, {"tratamiento": "Control", "marcas": []}, format="json")
    assert respuesta.json()["marcas_retiradas"] == [MACERACION]

    ficha = api_client.get(f"/api/pacientes/{cita.paciente.pk}/ficha/").json()
    assert ficha["dibujo"] == []
    [marca] = ficha["marcas"]
    assert marca["vigente"] is False
    assert marca["atencion_baja"] == respuesta.json()["id"]


def test_la_api_sin_marcas_no_cambia_el_dibujo(api_client, cita):
    _registrar(cita, [MACERACION])
    api_client.force_authenticate(cita.profesional.usuario)
    url = f"/api/pacientes/{cita.paciente.pk}/atenciones/"
    assert api_client.post(url, {"tratamiento": "Control"}, format="json").status_code == 201
    ficha = api_client.get(f"/api/pacientes/{cita.paciente.pk}/ficha/").json()
    assert ficha["dibujo"] == [MACERACION]


def test_la_api_rechaza_un_simbolo_desconocido(api_client, cita):
    api_client.force_authenticate(cita.profesional.usuario)
    url = f"/api/pacientes/{cita.paciente.pk}/atenciones/"
    marca = {**MACERACION, "simbolo": "inventado"}
    respuesta = api_client.post(url, {"tratamiento": "X", "marcas": [marca]}, format="json")
    assert respuesta.status_code == 400


def test_otro_podologo_no_ve_ni_cambia_el_dibujo(api_client, cita):
    _registrar(cita, [MACERACION])
    api_client.force_authenticate(ProfesionalFactory().usuario)
    assert api_client.get(f"/api/pacientes/{cita.paciente.pk}/ficha/").status_code == 404
    respuesta = api_client.post(
        f"/api/pacientes/{cita.paciente.pk}/atenciones/",
        {"tratamiento": "X", "marcas": []},
        format="json",
    )
    assert respuesta.status_code == 404
    assert _dibujo(cita.paciente.ficha) == [_tupla(MACERACION)]


def test_el_paciente_ve_solo_su_dibujo(api_client, cita):
    _registrar(cita, [MACERACION])
    otro = PacienteFactory()
    ConsentimientoFactory(paciente=otro)
    FichaClinicaFactory(paciente=otro)
    api_client.force_authenticate(cita.paciente.usuario)
    assert api_client.get("/api/mi-ficha/").json()["dibujo"] == [MACERACION]
    api_client.force_authenticate(otro.usuario)
    assert api_client.get("/api/mi-ficha/").json()["dibujo"] == []
