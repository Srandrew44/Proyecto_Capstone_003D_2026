from datetime import timedelta
from uuid import uuid4

import pytest
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import IntegrityError
from django.utils import timezone

from apps.agenda.tests.factories import INICIO_BASE, CitaFactory
from apps.auditoria.models import RegistroAuditoria
from apps.clinica.models import AtencionClinica
from apps.clinica.selectors import numerar_atenciones
from apps.clinica.services import (
    ConsentimientoRequerido,
    corregir_atencion,
    emitir_derivacion,
    registrar_atencion,
)
from apps.cuentas.tests.factories import CLAVE, PacienteFactory, ProfesionalFactory

from .factories import (
    AtencionClinicaFactory,
    ConsentimientoFactory,
    DerivacionFactory,
    FichaClinicaFactory,
)

pytestmark = pytest.mark.django_db

Accion = RegistroAuditoria.Accion


@pytest.fixture
def cita():
    cita = CitaFactory()
    ConsentimientoFactory(paciente=cita.paciente)
    return cita


@pytest.fixture
def ficha(cita):
    return FichaClinicaFactory(paciente=cita.paciente)


@pytest.fixture
def atencion(cita, ficha):
    return AtencionClinicaFactory(
        ficha=ficha,
        profesional=cita.profesional,
        fecha=INICIO_BASE,
        tratamiento="Onicotomia",
        indicaciones="Reposo",
    )


def _corregir(atencion, motivo="Error de tipeo en el tratamiento", **cambios):
    return corregir_atencion(
        atencion=atencion, profesional=atencion.profesional, motivo_correccion=motivo, **cambios
    )


# --- corrección enlazada ---


def test_la_correccion_es_otra_atencion_enlazada_y_la_original_queda_intacta(atencion):
    correccion = _corregir(atencion, tratamiento="Onicotomía")
    atencion.refresh_from_db()
    assert correccion.pk != atencion.pk
    assert correccion.corrige == atencion
    assert correccion.tratamiento == "Onicotomía"
    assert correccion.indicaciones == "Reposo"  # lo que no cambia se copia
    assert correccion.fecha == atencion.fecha
    assert atencion.tratamiento == "Onicotomia"  # la original no se toca
    assert not atencion.vigente
    assert correccion.vigente


def test_la_correccion_queda_auditada_con_la_original(atencion):
    correccion = _corregir(atencion, tratamiento="Onicotomía")
    registro = RegistroAuditoria.objects.get(accion=Accion.CORREGIR_ATENCION)
    assert registro.recurso_id == correccion.pk
    assert registro.detalle == {"corrige": str(atencion.pk), "campos": ["tratamiento"]}


def test_la_correccion_exige_un_motivo(atencion):
    with pytest.raises(ValidationError) as error:
        _corregir(atencion, motivo="  ", tratamiento="x")
    assert "motivo_correccion" in error.value.message_dict


def test_solo_quien_registro_la_atencion_la_corrige(atencion):
    otro = ProfesionalFactory()
    with pytest.raises(PermissionDenied):
        corregir_atencion(atencion=atencion, profesional=otro, motivo_correccion="x")


def test_se_corrige_solo_la_version_vigente(atencion):
    correccion = _corregir(atencion, tratamiento="Onicotomía")
    with pytest.raises(ValidationError, match="versión vigente"):
        _corregir(atencion, tratamiento="Otra cosa")
    segunda = _corregir(correccion, indicaciones="Reposo y control en 15 días")
    assert segunda.corrige == correccion


def test_la_correccion_mantiene_la_regla_de_observacion_o_tratamiento(atencion):
    with pytest.raises(ValidationError):
        _corregir(atencion, tratamiento="", observacion="")


def test_la_correccion_exige_consentimiento(atencion, cita):
    cita.paciente.consentimientos.update(revocado_en=INICIO_BASE)
    with pytest.raises(ConsentimientoRequerido):
        _corregir(atencion, tratamiento="x")


def test_no_se_deriva_desde_una_atencion_corregida(atencion):
    _corregir(atencion, tratamiento="Onicotomía")
    atencion.refresh_from_db()
    with pytest.raises(ValidationError, match="versión vigente"):
        emitir_derivacion(
            profesional=atencion.profesional,
            atencion=atencion,
            especialidad_destino="traumatologia",
            motivo="x",
        )


def test_las_derivaciones_quedan_en_la_original(atencion):
    derivacion = DerivacionFactory(atencion=atencion)
    _corregir(atencion, tratamiento="Onicotomía")
    derivacion.refresh_from_db()
    assert derivacion.atencion == atencion


def test_la_numeracion_sigue_el_orden_y_la_correccion_hereda_el_numero(atencion, ficha):
    segunda = AtencionClinicaFactory(ficha=ficha, fecha=INICIO_BASE + timedelta(days=7))
    correccion = _corregir(atencion, tratamiento="Onicotomía")
    numeros = numerar_atenciones(ficha.atenciones.all())
    assert numeros == {atencion.pk: 1, correccion.pk: 1, segunda.pk: 2}


def test_la_base_exige_motivo_en_toda_correccion(atencion):
    with pytest.raises(IntegrityError):
        AtencionClinicaFactory(ficha=atencion.ficha, corrige=atencion, motivo_correccion="")


def test_la_base_rechaza_un_termino_anterior_al_inicio(ficha):
    with pytest.raises(IntegrityError):
        AtencionClinicaFactory(
            ficha=ficha, fecha=INICIO_BASE, termino=INICIO_BASE - timedelta(minutes=1)
        )


# --- horas de la atención ---


def test_las_horas_de_inicio_y_termino_se_pueden_indicar(cita, ficha):
    ahora = INICIO_BASE + timedelta(hours=2)
    atencion = registrar_atencion(
        profesional=cita.profesional,
        paciente=cita.paciente,
        cita=cita,
        inicio=INICIO_BASE + timedelta(minutes=5),
        termino=INICIO_BASE + timedelta(minutes=50),
        tratamiento="x",
        ahora=ahora,
    )
    assert atencion.fecha == INICIO_BASE + timedelta(minutes=5)
    assert atencion.termino == INICIO_BASE + timedelta(minutes=50)


@pytest.mark.parametrize(
    ("inicio", "termino"),
    [
        (INICIO_BASE + timedelta(hours=3), None),  # inicio en el futuro
        (INICIO_BASE, INICIO_BASE - timedelta(minutes=1)),  # término antes del inicio
        (INICIO_BASE, INICIO_BASE + timedelta(hours=3)),  # término en el futuro
    ],
)
def test_horas_invalidas(cita, ficha, inicio, termino):
    with pytest.raises(ValidationError):
        registrar_atencion(
            profesional=cita.profesional,
            paciente=cita.paciente,
            inicio=inicio,
            termino=termino,
            tratamiento="x",
            ahora=INICIO_BASE + timedelta(hours=2),
        )
    assert not AtencionClinica.objects.exists()


# --- API: corrección, ficha estructurada y accesos denegados ---


def _entrar(cliente, usuario):
    cliente.post("/api/auth/login/", {"email": usuario.email, "password": CLAVE}, format="json")


def _denegados():
    return RegistroAuditoria.objects.filter(accion=Accion.ACCESO_DENEGADO)


def test_la_api_corrige_y_la_ficha_muestra_la_relacion(api_client, atencion, cita):
    _entrar(api_client, cita.profesional.usuario)
    url = f"/api/atenciones/{atencion.pk}/correcciones/"
    cuerpo = {"motivo_correccion": "Tipeo", "tratamiento": "Onicotomía"}
    respuesta = api_client.post(url, cuerpo, format="json")
    assert respuesta.status_code == 201
    datos = respuesta.json()
    assert datos["corrige"] == str(atencion.pk)
    assert datos["numero"] == 1
    ficha = api_client.get(f"/api/pacientes/{cita.paciente.pk}/ficha/").json()
    original = next(a for a in ficha["atenciones"] if a["id"] == str(atencion.pk))
    assert original["vigente"] is False
    assert original["corregida_por"] == datos["id"]


def test_la_api_exige_el_motivo_de_la_correccion(api_client, atencion, cita):
    _entrar(api_client, cita.profesional.usuario)
    respuesta = api_client.post(
        f"/api/atenciones/{atencion.pk}/correcciones/", {"tratamiento": "x"}, format="json"
    )
    assert respuesta.status_code == 400
    assert "motivo_correccion" in respuesta.json()


def test_corregir_la_atencion_de_otro_profesional_responde_403_y_se_audita(
    api_client, atencion, cita
):
    otro = ProfesionalFactory()
    CitaFactory(profesional=otro, paciente=cita.paciente, inicio=INICIO_BASE + timedelta(days=1))
    _entrar(api_client, otro.usuario)
    respuesta = api_client.post(
        f"/api/atenciones/{atencion.pk}/correcciones/",
        {"motivo_correccion": "x", "tratamiento": "x"},
        format="json",
    )
    assert respuesta.status_code == 403
    registro = _denegados().get()
    assert registro.usuario == otro.usuario
    assert registro.recurso_id == atencion.pk


def test_la_ficha_estructurada_se_edita_por_la_api(api_client, ficha, cita):
    _entrar(api_client, cita.profesional.usuario)
    cuerpo = {
        "hta": True,
        "varices": False,
        "pulso_radial": "ausente",
        "presion_arterial": "140/90",
    }
    respuesta = api_client.patch(f"/api/pacientes/{cita.paciente.pk}/ficha/", cuerpo, format="json")
    assert respuesta.status_code == 200
    ficha.refresh_from_db()
    assert (ficha.hta, ficha.varices, ficha.pulso_radial) == (True, False, "ausente")
    assert ficha.diabetes is True  # lo que no se envía no cambia


def test_un_valor_de_pulso_desconocido_responde_400(api_client, ficha, cita):
    _entrar(api_client, cita.profesional.usuario)
    url = f"/api/pacientes/{cita.paciente.pk}/ficha/"
    respuesta = api_client.patch(url, {"pulso_pedio_derecho": "fuerte"}, format="json")
    assert respuesta.status_code == 400


def test_ver_una_ficha_ajena_queda_como_acceso_denegado(api_client, ficha):
    intruso = ProfesionalFactory()
    _entrar(api_client, intruso.usuario)
    url = f"/api/pacientes/{ficha.paciente.pk}/ficha/"
    respuesta = api_client.get(url, REMOTE_ADDR="10.0.0.66")
    assert respuesta.status_code == 404
    registro = _denegados().get()
    assert registro.usuario == intruso.usuario
    assert registro.recurso_tipo == "paciente"
    assert registro.recurso_id == ficha.paciente.pk
    assert registro.ip == "10.0.0.66"
    assert not RegistroAuditoria.objects.filter(accion=Accion.VER_FICHA).exists()


def test_un_id_inexistente_deja_el_mismo_registro_sin_revelar_nada(api_client):
    _entrar(api_client, ProfesionalFactory().usuario)
    inexistente = uuid4()
    assert api_client.get(f"/api/pacientes/{inexistente}/ficha/").status_code == 404
    registro = _denegados().get()
    assert registro.recurso_id == inexistente
    assert registro.detalle == {}


def test_atenciones_y_pdf_ajenos_tambien_quedan_registrados(api_client, atencion):
    derivacion = DerivacionFactory(atencion=atencion)
    _entrar(api_client, PacienteFactory().usuario)
    assert api_client.get(f"/api/atenciones/{atencion.pk}/").status_code == 404
    assert api_client.get(f"/api/derivaciones/{derivacion.pk}/pdf/").status_code == 404
    assert {r.recurso_tipo for r in _denegados()} == {"atencionclinica", "derivacion"}


def test_el_paciente_sin_ficha_no_genera_acceso_denegado(api_client):
    _entrar(api_client, PacienteFactory().usuario)
    assert api_client.get("/api/mi-ficha/").status_code == 404
    assert not _denegados().exists()


def test_el_registro_de_acceso_denegado_no_se_pierde_con_el_404(api_client, ficha):
    """La solicitud no corre en una transacción: el registro queda aunque responda 404."""
    _entrar(api_client, ProfesionalFactory().usuario)
    api_client.get(f"/api/pacientes/{ficha.paciente.pk}/ficha/")
    assert RegistroAuditoria.objects.filter(
        accion=Accion.ACCESO_DENEGADO, fecha__lte=timezone.now()
    ).exists()
