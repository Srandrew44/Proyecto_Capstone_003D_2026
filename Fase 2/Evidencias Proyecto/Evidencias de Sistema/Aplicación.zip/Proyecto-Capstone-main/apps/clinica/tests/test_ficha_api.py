from datetime import timedelta
from uuid import uuid4

import pytest
from django.utils import timezone

from apps.agenda.models import Cita
from apps.agenda.tests.factories import INICIO_BASE, CitaFactory
from apps.auditoria.models import RegistroAuditoria
from apps.clinica.models import FichaClinica
from apps.cuentas.tests.factories import CLAVE, PacienteFactory, ProfesionalFactory

from .factories import (
    AtencionClinicaFactory,
    ConsentimientoFactory,
    DerivacionFactory,
    FichaClinicaFactory,
)

pytestmark = pytest.mark.django_db

Accion = RegistroAuditoria.Accion


def _entrar(cliente, usuario):
    cliente.post("/api/auth/login/", {"email": usuario.email, "password": CLAVE}, format="json")


def _ficha_url(paciente):
    return f"/api/pacientes/{paciente.pk}/ficha/"


@pytest.fixture
def cita():
    """Cita ya comenzada entre un profesional y un paciente con consentimiento vigente."""
    cita = CitaFactory(inicio=timezone.now() - timedelta(minutes=10))
    ConsentimientoFactory(paciente=cita.paciente)
    return cita


@pytest.fixture
def ficha(cita):
    return FichaClinicaFactory(paciente=cita.paciente)


@pytest.fixture
def profesional_cliente(api_client, cita):
    _entrar(api_client, cita.profesional.usuario)
    return api_client


# --- pacientes ---


def test_el_profesional_lista_solo_sus_pacientes(profesional_cliente, cita, ficha):
    PacienteFactory()
    datos = profesional_cliente.get("/api/pacientes/").json()
    assert datos == [
        {
            "id": str(cita.paciente.pk),
            "nombre": cita.paciente.usuario.nombre,
            "apellido": cita.paciente.usuario.apellido,
            "tiene_ficha": True,
        }
    ]


def test_un_paciente_no_lista_pacientes(api_client, cita):
    _entrar(api_client, cita.paciente.usuario)
    assert api_client.get("/api/pacientes/").status_code == 403


# --- ficha (profesional) ---


def test_el_profesional_ve_la_ficha_completa_y_queda_auditado(profesional_cliente, cita, ficha):
    atencion = AtencionClinicaFactory(ficha=ficha, profesional=cita.profesional)
    DerivacionFactory(atencion=atencion)
    respuesta = profesional_cliente.get(_ficha_url(cita.paciente), REMOTE_ADDR="10.0.0.4")
    assert respuesta.status_code == 200
    datos = respuesta.json()
    assert datos["paciente"]["rut"] == cita.paciente.rut
    assert datos["paciente"]["edad"] == cita.paciente.edad
    assert datos["paciente"]["actividad"] == cita.paciente.actividad
    assert datos["diabetes"] is True
    assert datos["varices"] is None  # no registrado
    assert datos["otras_patologias_cronicas"] == ficha.otras_patologias_cronicas
    assert datos["atenciones"][0]["numero"] == 1
    assert datos["atenciones"][0]["vigente"] is True
    assert datos["atenciones"][0]["diagnostico"] == atencion.diagnostico
    assert datos["atenciones"][0]["derivaciones"][0]["especialidad_nombre"] == "Traumatología"
    registro = RegistroAuditoria.objects.get(accion=Accion.VER_FICHA)
    assert registro.ip == "10.0.0.4"
    assert registro.recurso_id == ficha.pk


def test_la_ficha_de_un_paciente_ajeno_responde_404_sin_auditoria(api_client, ficha):
    _entrar(api_client, ProfesionalFactory().usuario)
    assert api_client.get(_ficha_url(ficha.paciente)).status_code == 404
    assert not RegistroAuditoria.objects.filter(accion=Accion.VER_FICHA).exists()


def test_sin_ficha_responde_404(profesional_cliente, cita):
    assert profesional_cliente.get(_ficha_url(cita.paciente)).status_code == 404


def test_el_profesional_crea_la_ficha(profesional_cliente, cita):
    respuesta = profesional_cliente.post(
        _ficha_url(cita.paciente), {"alergias": "Penicilina"}, format="json"
    )
    assert respuesta.status_code == 201
    assert respuesta.json()["alergias"] == "Penicilina"
    assert FichaClinica.objects.get().paciente == cita.paciente


def test_crear_una_segunda_ficha_responde_400(profesional_cliente, cita, ficha):
    respuesta = profesional_cliente.post(_ficha_url(cita.paciente), {}, format="json")
    assert respuesta.status_code == 400


def test_crear_la_ficha_sin_consentimiento_responde_403(profesional_cliente, cita):
    cita.paciente.consentimientos.update(revocado_en=timezone.now())
    respuesta = profesional_cliente.post(_ficha_url(cita.paciente), {}, format="json")
    assert respuesta.status_code == 403
    assert "consentimiento" in respuesta.json()["detail"]


def test_no_crea_la_ficha_de_un_paciente_ajeno(profesional_cliente):
    respuesta = profesional_cliente.post(_ficha_url(PacienteFactory()), {}, format="json")
    assert respuesta.status_code == 404
    assert not FichaClinica.objects.exists()


def test_el_profesional_edita_la_ficha(profesional_cliente, cita, ficha):
    respuesta = profesional_cliente.patch(
        _ficha_url(cita.paciente), {"medicamentos": "Ninguno"}, format="json"
    )
    assert respuesta.status_code == 200
    assert respuesta.json()["medicamentos"] == "Ninguno"
    assert respuesta.json()["diabetes"] is True


def test_un_texto_demasiado_largo_responde_400(profesional_cliente, cita, ficha):
    cuerpo = {"observaciones": "x" * 5001}
    assert (
        profesional_cliente.patch(_ficha_url(cita.paciente), cuerpo, format="json").status_code
        == 400
    )


def test_la_ficha_no_se_borra(profesional_cliente, cita, ficha):
    assert profesional_cliente.delete(_ficha_url(cita.paciente)).status_code == 405


# --- mi ficha (paciente) ---


def test_el_paciente_ve_su_ficha_y_queda_auditado(api_client, cita, ficha):
    _entrar(api_client, cita.paciente.usuario)
    respuesta = api_client.get("/api/mi-ficha/")
    assert respuesta.status_code == 200
    assert respuesta.json()["id"] == str(ficha.pk)
    registro = RegistroAuditoria.objects.get(accion=Accion.VER_FICHA)
    assert registro.usuario == cita.paciente.usuario


def test_el_paciente_sin_ficha_recibe_404(api_client):
    _entrar(api_client, PacienteFactory().usuario)
    assert api_client.get("/api/mi-ficha/").status_code == 404


def test_el_profesional_no_usa_mi_ficha(profesional_cliente):
    assert profesional_cliente.get("/api/mi-ficha/").status_code == 403


# --- atenciones ---


def _atenciones_url(paciente):
    return f"/api/pacientes/{paciente.pk}/atenciones/"


def test_el_profesional_registra_la_atencion_de_la_cita(profesional_cliente, cita, ficha):
    cuerpo = {
        "cita": str(cita.pk),
        "motivo_consulta": "Uña encarnada",
        "tratamiento": "Onicotomía",
        "indicaciones": "Reposo",
    }
    respuesta = profesional_cliente.post(_atenciones_url(cita.paciente), cuerpo, format="json")
    assert respuesta.status_code == 201
    assert respuesta.json()["cita"] == str(cita.pk)
    assert respuesta.json()["indicaciones"] == "Reposo"
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.REALIZADA


def test_una_cita_de_otro_profesional_responde_400(profesional_cliente, cita, ficha):
    ajena = CitaFactory(paciente=cita.paciente, inicio=INICIO_BASE)
    cuerpo = {"cita": str(ajena.pk), "tratamiento": "x"}
    respuesta = profesional_cliente.post(_atenciones_url(cita.paciente), cuerpo, format="json")
    assert respuesta.status_code == 400
    assert "cita" in respuesta.json()


def test_la_atencion_exige_observacion_o_tratamiento(profesional_cliente, cita, ficha):
    respuesta = profesional_cliente.post(_atenciones_url(cita.paciente), {}, format="json")
    assert respuesta.status_code == 400
    assert "tratamiento" in respuesta.json()


def test_un_paciente_no_registra_atenciones(api_client, cita, ficha):
    _entrar(api_client, cita.paciente.usuario)
    cuerpo = {"tratamiento": "x"}
    assert api_client.post(_atenciones_url(cita.paciente), cuerpo, format="json").status_code == 403


def test_el_paciente_ve_una_atencion_suya(api_client, cita, ficha):
    atencion = AtencionClinicaFactory(ficha=ficha)
    _entrar(api_client, cita.paciente.usuario)
    respuesta = api_client.get(f"/api/atenciones/{atencion.pk}/")
    assert respuesta.status_code == 200
    assert respuesta.json()["motivo_consulta"] == atencion.motivo_consulta
    assert RegistroAuditoria.objects.filter(accion=Accion.VER_ATENCION).count() == 1


def test_una_atencion_ajena_responde_404(api_client, ficha):
    atencion = AtencionClinicaFactory(ficha=ficha)
    _entrar(api_client, PacienteFactory().usuario)
    assert api_client.get(f"/api/atenciones/{atencion.pk}/").status_code == 404
    assert api_client.get(f"/api/atenciones/{uuid4()}/").status_code == 404


# --- derivaciones ---


def _derivar(cliente, atencion, **cuerpo):
    datos = {"especialidad_destino": "dermatologia", "motivo": "Lesión", **cuerpo}
    return cliente.post(f"/api/atenciones/{atencion.pk}/derivaciones/", datos, format="json")


def test_el_profesional_emite_una_derivacion(profesional_cliente, cita, ficha):
    atencion = AtencionClinicaFactory(ficha=ficha, profesional=cita.profesional)
    respuesta = _derivar(profesional_cliente, atencion)
    assert respuesta.status_code == 201
    assert respuesta.json()["especialidad_nombre"] == "Dermatología"


def test_derivar_desde_la_atencion_de_otro_profesional_responde_403(
    profesional_cliente, cita, ficha
):
    atencion = AtencionClinicaFactory(ficha=ficha)
    assert _derivar(profesional_cliente, atencion).status_code == 403


def test_una_especialidad_desconocida_responde_400(profesional_cliente, cita, ficha):
    atencion = AtencionClinicaFactory(ficha=ficha, profesional=cita.profesional)
    respuesta = _derivar(profesional_cliente, atencion, especialidad_destino="cardiologia")
    assert respuesta.status_code == 400


def test_otra_especialidad_sin_detalle_responde_400(profesional_cliente, cita, ficha):
    atencion = AtencionClinicaFactory(ficha=ficha, profesional=cita.profesional)
    respuesta = _derivar(profesional_cliente, atencion, especialidad_destino="otra")
    assert respuesta.status_code == 400
    assert "especialidad_detalle" in respuesta.json()
