import pytest

from apps.agenda.tests.factories import CitaFactory
from apps.auditoria.models import RegistroAuditoria
from apps.clinica.pdf import generar_pdf_derivacion
from apps.cuentas.tests.factories import CLAVE, PacienteFactory, ProfesionalFactory

from .factories import AtencionClinicaFactory, DerivacionFactory, FichaClinicaFactory

pytestmark = pytest.mark.django_db

DESCARGAR = RegistroAuditoria.Accion.DESCARGAR_DERIVACION


@pytest.fixture
def derivacion():
    paciente = PacienteFactory(usuario__nombre="Rosa", usuario__apellido="Pino")
    profesional = ProfesionalFactory(
        usuario__nombre="Ana", usuario__apellido="Rojas", numero_colegiado="12345"
    )
    CitaFactory(paciente=paciente, profesional=profesional)
    atencion = AtencionClinicaFactory(
        ficha=FichaClinicaFactory(paciente=paciente),
        profesional=profesional,
        diagnostico="Fascitis plantar cronica",
    )
    return DerivacionFactory(
        atencion=atencion, motivo="Evaluar espolon calcaneo", resumen_clinico=""
    )


def _texto(derivacion) -> bytes:
    return generar_pdf_derivacion(derivacion, comprimir=False)


def test_genera_un_pdf():
    assert generar_pdf_derivacion(DerivacionFactory()).startswith(b"%PDF")


def test_incluye_paciente_profesional_y_motivo(derivacion):
    pdf = _texto(derivacion)
    for dato in ("Rosa Pino", derivacion.atencion.ficha.paciente.rut, "Ana Rojas", "12345"):
        assert dato.encode() in pdf
    assert b"Evaluar espolon calcaneo" in pdf
    assert b"Fascitis plantar cronica" in pdf


def test_omite_el_resumen_clinico_vacio(derivacion):
    assert b"Resumen cl" not in _texto(derivacion)


def test_incluye_los_datos_de_la_consulta(derivacion, settings):
    settings.CONSULTA_NOMBRE = "Podologia Central"
    settings.CONSULTA_DIRECCION = "Av. Siempre Viva 742"
    pdf = _texto(derivacion)
    assert b"Podologia Central" in pdf
    assert b"Av. Siempre Viva 742" in pdf


def test_el_mismo_documento_sale_siempre_igual(derivacion):
    assert generar_pdf_derivacion(derivacion) == generar_pdf_derivacion(derivacion)


def test_el_texto_libre_no_se_interpreta_como_marcado():
    derivacion = DerivacionFactory(motivo="Dolor <b>agudo</b> & persistente\nsegunda linea")
    assert b"agudo" in _texto(derivacion)


# --- API ---


def _entrar(cliente, usuario):
    cliente.post("/api/auth/login/", {"email": usuario.email, "password": CLAVE}, format="json")


def _url(derivacion):
    return f"/api/derivaciones/{derivacion.pk}/pdf/"


def test_el_paciente_descarga_su_derivacion(api_client, derivacion):
    _entrar(api_client, derivacion.atencion.ficha.paciente.usuario)
    respuesta = api_client.get(_url(derivacion))
    assert respuesta.status_code == 200
    assert respuesta["Content-Type"] == "application/pdf"
    assert respuesta["Cache-Control"] == "no-store"
    disposicion = respuesta["Content-Disposition"]
    assert disposicion.startswith('attachment; filename="derivacion-')
    assert "Rosa" not in disposicion
    assert respuesta.content.startswith(b"%PDF")
    assert RegistroAuditoria.objects.get(accion=DESCARGAR).recurso_id == derivacion.pk


def test_el_profesional_que_atiende_descarga_la_derivacion(api_client, derivacion):
    _entrar(api_client, derivacion.atencion.profesional.usuario)
    assert api_client.get(_url(derivacion)).status_code == 200


@pytest.mark.parametrize("factory", [PacienteFactory, ProfesionalFactory])
def test_un_tercero_recibe_404_sin_auditoria(api_client, derivacion, factory):
    _entrar(api_client, factory().usuario)
    assert api_client.get(_url(derivacion)).status_code == 404
    assert not RegistroAuditoria.objects.filter(accion=DESCARGAR).exists()


def test_descargar_exige_sesion(api_client, derivacion):
    assert api_client.get(_url(derivacion)).status_code == 403
