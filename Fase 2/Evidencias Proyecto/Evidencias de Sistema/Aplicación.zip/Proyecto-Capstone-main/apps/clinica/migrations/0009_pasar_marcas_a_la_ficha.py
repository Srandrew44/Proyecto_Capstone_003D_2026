"""Pasa las marcas de cada atención al dibujo único de la ficha (2 de 3).

Antes cada atención tenía su propio dibujo y una corrección copiaba el de la atención que
corregía. Ahora:

- Las marcas de una atención vigente quedan vigentes en la ficha, agregadas en esa atención.
  Así el dibujo vigente reúne las marcas de todas las atenciones vigentes del paciente.
- Las de una atención reemplazada por una corrección quedan retiradas por esa corrección, con
  su motivo. Si la corrección había copiado el mismo símbolo en el mismo lugar, el historial
  muestra el cambio neto (ninguno), pero ambas filas se conservan.

No se borra ninguna fila. Fechas: el alta lleva la de la atención; el retiro, la de la
corrección (que conserva la hora de la original, porque no se guardaba cuándo se corrigió).

Al revertir, cada marca vuelve a la atención en que se agregó. Las retiradas después de esta
migración vuelven a esa atención como si siguieran en su dibujo: el retiro se pierde.
"""

from django.db import migrations

CAMPOS = ["ficha", "atencion_alta", "creada_en", "atencion_baja", "retirada_en", "motivo_baja"]


def a_la_ficha(apps, schema_editor):
    MarcaPie = apps.get_model("clinica", "MarcaPie")
    AtencionClinica = apps.get_model("clinica", "AtencionClinica")
    correcciones = {
        correccion.corrige_id: correccion
        for correccion in AtencionClinica.objects.filter(corrige__isnull=False)
    }
    for marca in MarcaPie.objects.select_related("atencion").iterator():
        atencion = marca.atencion
        marca.ficha_id = atencion.ficha_id
        marca.atencion_alta_id = atencion.pk
        marca.creada_en = atencion.fecha
        correccion = correcciones.get(atencion.pk)
        if correccion is not None:
            marca.atencion_baja_id = correccion.pk
            marca.retirada_en = max(correccion.fecha, atencion.fecha)
            marca.motivo_baja = correccion.motivo_correccion
        marca.save(update_fields=CAMPOS)


def a_la_atencion(apps, schema_editor):
    MarcaPie = apps.get_model("clinica", "MarcaPie")
    for marca in MarcaPie.objects.iterator():
        marca.atencion_id = marca.atencion_alta_id
        marca.save(update_fields=["atencion"])


class Migration(migrations.Migration):
    dependencies = [
        ("clinica", "0008_marcas_de_la_ficha"),
    ]

    operations = [
        migrations.RunPython(a_la_ficha, a_la_atencion),
    ]
