"""Deja el dibujo de los pies en la ficha: los campos nuevos pasan a obligatorios (3 de 3)."""

import django.db.models.deletion
import django.utils.timezone
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("clinica", "0009_pasar_marcas_a_la_ficha"),
    ]

    operations = [
        migrations.RemoveField(
            model_name="marcapie",
            name="atencion",
        ),
        migrations.AlterField(
            model_name="marcapie",
            name="ficha",
            field=models.ForeignKey(
                on_delete=django.db.models.deletion.PROTECT,
                related_name="marcas",
                to="clinica.fichaclinica",
            ),
        ),
        migrations.AlterField(
            model_name="marcapie",
            name="atencion_alta",
            field=models.ForeignKey(
                on_delete=django.db.models.deletion.PROTECT,
                related_name="marcas_agregadas",
                to="clinica.atencionclinica",
            ),
        ),
        migrations.AlterField(
            model_name="marcapie",
            name="creada_en",
            field=models.DateTimeField(default=django.utils.timezone.now),
        ),
        migrations.AlterModelOptions(
            name="marcapie",
            options={
                "ordering": ["creada_en", "id"],
                "verbose_name": "marca en el pie",
                "verbose_name_plural": "marcas en los pies",
            },
        ),
        migrations.AddIndex(
            model_name="marcapie",
            index=models.Index(
                condition=models.Q(("retirada_en__isnull", True)),
                fields=["ficha"],
                name="marca_pie_vigente_idx",
            ),
        ),
        migrations.AddConstraint(
            model_name="marcapie",
            constraint=models.CheckConstraint(
                condition=models.Q(
                    models.Q(("atencion_baja__isnull", True), ("retirada_en__isnull", True)),
                    models.Q(
                        ("atencion_baja__isnull", False),
                        ("retirada_en__gte", models.F("creada_en")),
                        ("retirada_en__isnull", False),
                    ),
                    _connector="OR",
                ),
                name="marca_pie_retiro_valido",
            ),
        ),
    ]
