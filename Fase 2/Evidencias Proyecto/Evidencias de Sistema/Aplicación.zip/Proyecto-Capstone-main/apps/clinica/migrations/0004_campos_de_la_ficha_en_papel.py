# Escrita a mano: renombra campos para seguir la ficha podológica en papel sin perder datos
# (makemigrations sin interacción los borraría y crearía de nuevo).

from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [
        ("clinica", "0003_ficha_atencion_derivacion"),
    ]

    operations = [
        migrations.RenameField(
            model_name="fichaclinica",
            old_name="antecedentes",
            new_name="otras_patologias_cronicas",
        ),
        migrations.RenameField(
            model_name="atencionclinica",
            old_name="evaluacion",
            new_name="observacion",
        ),
        migrations.RenameField(
            model_name="atencionclinica",
            old_name="procedimiento",
            new_name="tratamiento",
        ),
    ]
