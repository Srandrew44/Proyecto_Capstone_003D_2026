import django.db.models.deletion
import django.utils.timezone
import uuid
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('cuentas', '0002_perfiles_y_rol_admin'),
    ]

    operations = [
        migrations.CreateModel(
            name='Consentimiento',
            fields=[
                ('id', models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ('tipo', models.CharField(choices=[('tratamiento_datos', 'Tratamiento de datos personales y de salud'), ('atencion_domicilio', 'Atención a domicilio'), ('uso_chatbot', 'Uso del asistente virtual')], max_length=40)),
                ('version_texto', models.CharField(max_length=20)),
                ('aceptado_en', models.DateTimeField(default=django.utils.timezone.now)),
                ('revocado_en', models.DateTimeField(blank=True, null=True)),
                ('paciente', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='consentimientos', to='cuentas.paciente')),
            ],
            options={
                'verbose_name': 'consentimiento',
                'verbose_name_plural': 'consentimientos',
                'constraints': [
                    models.UniqueConstraint(condition=models.Q(('revocado_en__isnull', True)), fields=('paciente', 'tipo'), name='consentimiento_vigente_unico'),
                    models.CheckConstraint(condition=models.Q(('revocado_en__isnull', True), ('revocado_en__gte', models.F('aceptado_en')), _connector='OR'), name='consentimiento_revocacion_valida'),
                ],
            },
        ),
    ]
