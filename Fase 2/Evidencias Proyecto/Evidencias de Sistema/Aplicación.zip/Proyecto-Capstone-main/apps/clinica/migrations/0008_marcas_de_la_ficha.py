"""Las marcas del dibujo de los pies pasan de cada atención a la ficha del paciente (1 de 3).

Agrega los campos nuevos, todavía opcionales, y deja opcional la atención antigua para que la
migración se pueda revertir. Los datos se pasan en 0009 y los campos quedan obligatorios en
0010: van separados porque PostgreSQL no deja alterar una tabla con filas actualizadas en la
misma transacción (las claves foráneas se revisan al final).
"""

import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("clinica", "0007_marcas_en_los_pies"),
    ]

    operations = [
        migrations.AddField(
            model_name="marcapie",
            name="ficha",
            field=models.ForeignKey(
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name="marcas",
                to="clinica.fichaclinica",
            ),
        ),
        migrations.AddField(
            model_name="marcapie",
            name="atencion_alta",
            field=models.ForeignKey(
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name="marcas_agregadas",
                to="clinica.atencionclinica",
            ),
        ),
        migrations.AddField(
            model_name="marcapie",
            name="creada_en",
            field=models.DateTimeField(null=True),
        ),
        migrations.AddField(
            model_name="marcapie",
            name="atencion_baja",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name="marcas_retiradas",
                to="clinica.atencionclinica",
            ),
        ),
        migrations.AddField(
            model_name="marcapie",
            name="retirada_en",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="marcapie",
            name="motivo_baja",
            field=models.CharField(blank=True, default="", max_length=200),
            preserve_default=False,
        ),
        migrations.AlterField(
            model_name="marcapie",
            name="atencion",
            field=models.ForeignKey(
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name="marcas",
                to="clinica.atencionclinica",
            ),
        ),
    ]
