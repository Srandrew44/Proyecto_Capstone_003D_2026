from contextlib import contextmanager

from django.core.exceptions import PermissionDenied
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db.models import Prefetch
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import serializers, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.agenda.models import Cita
from apps.auditoria.services import ip_de
from apps.clinica import selectors, services
from apps.clinica.informes import calcular_informe
from apps.clinica.models import AtencionClinica
from apps.clinica.pdf import generar_pdf_derivacion, generar_pdf_informe
from apps.clinica.selectors import numerar_atenciones
from apps.cuentas.api.views import a_error_drf
from apps.cuentas.models import Profesional, Usuario
from apps.cuentas.permissions import (
    EsDuenoDelRecurso,
    EsPaciente,
    EsProfesional,
    EsProfesionalOAdministrador,
)

from .serializers import (
    AceptarConsentimientoSerializer,
    AtencionCreacionSerializer,
    AtencionSerializer,
    ConsentimientoSerializer,
    CorreccionSerializer,
    DerivacionCreacionSerializer,
    DerivacionSerializer,
    FichaEdicionSerializer,
    FichaSerializer,
    InformeConsultaSerializer,
    PacienteResumenSerializer,
)


class ConsentimientosView(APIView):
    """GET: consentimientos propios. POST: acepta uno (idempotente si ya está vigente)."""

    permission_classes = [IsAuthenticated, EsPaciente]

    def get(self, request):
        consentimientos = selectors.consentimientos_de(request.user)
        return Response(ConsentimientoSerializer(consentimientos, many=True).data)

    def post(self, request):
        serializer = AceptarConsentimientoSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            consentimiento, creado = services.aceptar_consentimiento(
                paciente=request.user.paciente,
                tipo=serializer.validated_data["tipo"],
                ip=ip_de(request),
            )
        except DjangoValidationError as exc:
            raise a_error_drf(exc) from exc
        codigo = status.HTTP_201_CREATED if creado else status.HTTP_200_OK
        return Response(ConsentimientoSerializer(consentimiento).data, status=codigo)


class RevocarConsentimientoView(APIView):
    permission_classes = [IsAuthenticated, EsPaciente, EsDuenoDelRecurso]

    def post(self, request, pk):
        # Se busca solo entre los consentimientos propios: el ajeno responde 404, no 403,
        # para no confirmar que existe.
        consentimiento = get_object_or_404(selectors.consentimientos_de(request.user), pk=pk)
        self.check_object_permissions(request, consentimiento)
        services.revocar_consentimiento(consentimiento=consentimiento, ip=ip_de(request))
        return Response(ConsentimientoSerializer(consentimiento).data)


# --- ficha clínica ---
#
# Todo se busca entre lo visible para el usuario (selectors): lo ajeno responde 404, no 403,
# para no confirmar que existe. Cada intento rechazado (404 por falta de acceso o 403 de un
# servicio) queda en la auditoría como `acceso_denegado`.


def _ficha_completa(fichas):
    return fichas.select_related("paciente__usuario").prefetch_related(
        Prefetch(
            "atenciones",
            queryset=AtencionClinica.objects.select_related("profesional__usuario", "correccion"),
        ),
        "atenciones__derivaciones",
        "atenciones__marcas_agregadas",
        "atenciones__marcas_retiradas",
        "marcas",
    )


def _sin_consentimiento():
    return Response(
        {"detail": "El paciente no tiene vigente el consentimiento de tratamiento de datos."},
        status=status.HTTP_403_FORBIDDEN,
    )


def _denegar(request, recurso_tipo, recurso_id):
    services.registrar_acceso_denegado(
        usuario=request.user, recurso_tipo=recurso_tipo, recurso_id=recurso_id, ip=ip_de(request)
    )


def _buscar(request, consulta, recurso_tipo, pk, campo="pk"):
    """Busca entre lo visible; si no está, audita el intento y responde 404."""
    objeto = consulta.filter(**{campo: pk}).first()
    if objeto is None:
        _denegar(request, recurso_tipo, pk)
        raise Http404
    return objeto


@contextmanager
def _errores_de_servicio(request, recurso_tipo, recurso_id):
    """Traduce los errores de los servicios clínicos y audita los rechazos por permiso."""
    try:
        yield
    except services.ConsentimientoRequerido:
        raise
    except PermissionDenied:
        _denegar(request, recurso_tipo, recurso_id)
        raise
    except DjangoValidationError as exc:
        raise a_error_drf(exc) from exc


def _numeros(ficha) -> dict:
    return numerar_atenciones(ficha.atenciones.all())


class PacientesView(APIView):
    """GET: pacientes del profesional (con cita no cancelada), para abrir su ficha."""

    permission_classes = [IsAuthenticated, EsProfesional]

    def get(self, request):
        pacientes = selectors.pacientes_de(request.user).select_related("ficha")
        pacientes = pacientes.order_by("usuario__apellido", "usuario__nombre")
        return Response(PacienteResumenSerializer(pacientes, many=True).data)


class FichaPacienteView(APIView):
    """Ficha de un paciente propio. GET: verla. POST: crearla. PATCH: editarla."""

    permission_classes = [IsAuthenticated, EsProfesional]

    def _ficha(self, request, pk):
        fichas = _ficha_completa(selectors.fichas_visibles(request.user))
        return _buscar(request, fichas, "paciente", pk, campo="paciente_id")

    def _respuesta(self, ficha, codigo=status.HTTP_200_OK):
        datos = FichaSerializer(ficha, context={"numeros": _numeros(ficha)}).data
        return Response(datos, status=codigo)

    def get(self, request, pk):
        ficha = self._ficha(request, pk)
        services.ver_ficha(ficha=ficha, usuario=request.user, ip=ip_de(request))
        return self._respuesta(ficha)

    def post(self, request, pk):
        paciente = _buscar(request, selectors.pacientes_de(request.user), "paciente", pk)
        cuerpo = FichaEdicionSerializer(data=request.data)
        cuerpo.is_valid(raise_exception=True)
        try:
            with _errores_de_servicio(request, "paciente", pk):
                services.crear_ficha(
                    profesional=request.user.profesional,
                    paciente=paciente,
                    ip=ip_de(request),
                    **cuerpo.validated_data,
                )
        except services.ConsentimientoRequerido:
            return _sin_consentimiento()
        return self._respuesta(self._ficha(request, pk), status.HTTP_201_CREATED)

    def patch(self, request, pk):
        ficha = self._ficha(request, pk)
        cuerpo = FichaEdicionSerializer(data=request.data, partial=True)
        cuerpo.is_valid(raise_exception=True)
        try:
            with _errores_de_servicio(request, "paciente", pk):
                services.editar_ficha(
                    ficha=ficha,
                    profesional=request.user.profesional,
                    ip=ip_de(request),
                    **cuerpo.validated_data,
                )
        except services.ConsentimientoRequerido:
            return _sin_consentimiento()
        return self._respuesta(self._ficha(request, pk))


class MiFichaView(APIView):
    """GET: el paciente ve su propia ficha e historial (solo lectura)."""

    permission_classes = [IsAuthenticated, EsPaciente]

    def get(self, request):
        fichas = _ficha_completa(selectors.fichas_visibles(request.user))
        ficha = get_object_or_404(fichas)
        services.ver_ficha(ficha=ficha, usuario=request.user, ip=ip_de(request))
        return Response(FichaSerializer(ficha, context={"numeros": _numeros(ficha)}).data)


def _atencion_respuesta(atencion, codigo=status.HTTP_200_OK):
    numeros = numerar_atenciones(atencion.ficha.atenciones.all())
    return Response(AtencionSerializer(atencion, context={"numeros": numeros}).data, status=codigo)


class AtencionesPacienteView(APIView):
    """POST: registra una atención en la ficha de un paciente propio."""

    permission_classes = [IsAuthenticated, EsProfesional]

    def post(self, request, pk):
        paciente = _buscar(request, selectors.pacientes_de(request.user), "paciente", pk)
        cuerpo = AtencionCreacionSerializer(data=request.data)
        cuerpo.is_valid(raise_exception=True)
        datos = dict(cuerpo.validated_data)
        cita_id = datos.pop("cita", None)
        cita = None
        if cita_id is not None:
            cita = Cita.objects.filter(pk=cita_id, profesional_id=request.user.pk).first()
            if cita is None:
                raise serializers.ValidationError({"cita": ["Cita no encontrada."]})
        try:
            with _errores_de_servicio(request, "paciente", pk):
                atencion = services.registrar_atencion(
                    profesional=request.user.profesional,
                    paciente=paciente,
                    cita=cita,
                    ip=ip_de(request),
                    **datos,
                )
        except services.ConsentimientoRequerido:
            return _sin_consentimiento()
        return _atencion_respuesta(atencion, status.HTTP_201_CREATED)


class AtencionView(APIView):
    """GET: una atención visible (paciente o profesional que lo atiende)."""

    permission_classes = [IsAuthenticated]

    def get(self, request, pk):
        atenciones = selectors.atenciones_visibles(request.user).prefetch_related(
            "derivaciones", "marcas_agregadas", "marcas_retiradas"
        )
        atencion = _buscar(request, atenciones, "atencionclinica", pk)
        services.ver_atencion(atencion=atencion, usuario=request.user, ip=ip_de(request))
        return _atencion_respuesta(atencion)


class CorreccionesAtencionView(APIView):
    """POST: corrige una atención propia con una nueva enlazada a ella."""

    permission_classes = [IsAuthenticated, EsProfesional]

    def post(self, request, pk):
        atenciones = selectors.atenciones_visibles(request.user).select_related("ficha__paciente")
        atencion = _buscar(request, atenciones, "atencionclinica", pk)
        cuerpo = CorreccionSerializer(data=request.data)
        cuerpo.is_valid(raise_exception=True)
        try:
            with _errores_de_servicio(request, "atencionclinica", pk):
                correccion = services.corregir_atencion(
                    atencion=atencion,
                    profesional=request.user.profesional,
                    ip=ip_de(request),
                    **cuerpo.validated_data,
                )
        except services.ConsentimientoRequerido:
            return _sin_consentimiento()
        return _atencion_respuesta(correccion, status.HTTP_201_CREATED)


class DerivacionesAtencionView(APIView):
    """POST: emite una derivación desde una atención propia y vigente."""

    permission_classes = [IsAuthenticated, EsProfesional]

    def post(self, request, pk):
        atenciones = selectors.atenciones_visibles(request.user).select_related("ficha__paciente")
        atencion = _buscar(request, atenciones, "atencionclinica", pk)
        cuerpo = DerivacionCreacionSerializer(data=request.data)
        cuerpo.is_valid(raise_exception=True)
        try:
            with _errores_de_servicio(request, "atencionclinica", pk):
                derivacion = services.emitir_derivacion(
                    profesional=request.user.profesional,
                    atencion=atencion,
                    ip=ip_de(request),
                    **cuerpo.validated_data,
                )
        except services.ConsentimientoRequerido:
            return _sin_consentimiento()
        return Response(DerivacionSerializer(derivacion).data, status=status.HTTP_201_CREATED)


class DerivacionPdfView(APIView):
    """GET: descarga el PDF de una derivación visible. Se genera en el momento y se audita."""

    permission_classes = [IsAuthenticated]

    def get(self, request, pk):
        derivacion = _buscar(
            request, selectors.derivaciones_visibles(request.user), "derivacion", pk
        )
        services.registrar_descarga(derivacion=derivacion, usuario=request.user, ip=ip_de(request))
        respuesta = HttpResponse(generar_pdf_derivacion(derivacion), content_type="application/pdf")
        # El nombre del archivo no lleva datos del paciente.
        fecha = timezone.localtime(derivacion.emitida_en)
        respuesta["Content-Disposition"] = f'attachment; filename="derivacion-{fecha:%Y%m%d}.pdf"'
        respuesta["Cache-Control"] = "no-store"
        return respuesta


def _informe_pedido(request):
    """Valida el período y resuelve de quién es el informe. Devuelve (informe, alcance).

    El profesional ve solo lo suyo. El administrador ve toda la consulta, o un profesional
    con `?profesional=<id>`.
    """
    consulta = InformeConsultaSerializer(data=request.query_params)
    consulta.is_valid(raise_exception=True)
    datos = consulta.validated_data
    if request.user.rol == Usuario.Rol.ADMIN:
        profesionales = Profesional.objects.select_related("usuario").order_by(
            "usuario__apellido", "usuario__nombre"
        )
        alcance = "Toda la consulta"
        if "profesional" in datos:
            profesionales = list(profesionales.filter(pk=datos["profesional"]))
            if not profesionales:
                raise Http404
    else:
        profesionales = [request.user.profesional]
    if len(profesionales) == 1:
        usuario = profesionales[0].usuario
        alcance = f"Profesional: {usuario.nombre} {usuario.apellido}"
    informe = calcular_informe(
        profesionales=profesionales, desde=datos["desde"], hasta=datos["hasta"]
    )
    return informe, alcance


class InformesView(APIView):
    """GET: informe de gestión del período. Solo cifras agregadas, sin datos de pacientes."""

    permission_classes = [IsAuthenticated, EsProfesionalOAdministrador]

    def get(self, request):
        informe, _ = _informe_pedido(request)
        return Response(informe)


class InformePdfView(APIView):
    """GET: el mismo informe en PDF (lo pidió el podólogo). Mismos parámetros y permisos."""

    permission_classes = [IsAuthenticated, EsProfesionalOAdministrador]

    def get(self, request):
        informe, alcance = _informe_pedido(request)
        respuesta = HttpResponse(
            generar_pdf_informe(informe, alcance=alcance), content_type="application/pdf"
        )
        nombre = f"informe-{informe['desde']:%Y%m%d}-{informe['hasta']:%Y%m%d}.pdf"
        respuesta["Content-Disposition"] = f'attachment; filename="{nombre}"'
        respuesta["Cache-Control"] = "no-store"
        return respuesta
