from django.urls import path

from . import views

urlpatterns = [
    path("consentimientos/", views.ConsentimientosView.as_view(), name="consentimientos"),
    path(
        "consentimientos/<uuid:pk>/revocar/",
        views.RevocarConsentimientoView.as_view(),
        name="consentimiento-revocar",
    ),
    path("pacientes/", views.PacientesView.as_view(), name="pacientes"),
    path("pacientes/<uuid:pk>/ficha/", views.FichaPacienteView.as_view(), name="ficha-paciente"),
    path(
        "pacientes/<uuid:pk>/atenciones/",
        views.AtencionesPacienteView.as_view(),
        name="atenciones-paciente",
    ),
    path("mi-ficha/", views.MiFichaView.as_view(), name="mi-ficha"),
    path("informes/", views.InformesView.as_view(), name="informes"),
    path("informes/pdf/", views.InformePdfView.as_view(), name="informe-pdf"),
    path("atenciones/<uuid:pk>/", views.AtencionView.as_view(), name="atencion"),
    path(
        "atenciones/<uuid:pk>/correcciones/",
        views.CorreccionesAtencionView.as_view(),
        name="correcciones-atencion",
    ),
    path("derivaciones/<uuid:pk>/pdf/", views.DerivacionPdfView.as_view(), name="derivacion-pdf"),
    path(
        "atenciones/<uuid:pk>/derivaciones/",
        views.DerivacionesAtencionView.as_view(),
        name="derivaciones-atencion",
    ),
]
