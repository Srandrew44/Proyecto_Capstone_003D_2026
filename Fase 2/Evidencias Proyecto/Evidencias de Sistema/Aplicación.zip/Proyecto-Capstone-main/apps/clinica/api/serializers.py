from django.utils import timezone
from rest_framework import serializers

from apps.clinica.models import AtencionClinica, Consentimiento, Derivacion, FichaClinica, MarcaPie
from apps.clinica.selectors import marcas_vigentes
from apps.clinica.services import MAX_MARCAS
from apps.cuentas.models import Paciente

TEXTO_MAX = 5000  # tope de cada campo de texto libre clínico


class ConsentimientoSerializer(serializers.ModelSerializer):
    vigente = serializers.BooleanField(read_only=True)

    class Meta:
        model = Consentimiento
        fields = ["id", "tipo", "version_texto", "aceptado_en", "revocado_en", "vigente"]
        read_only_fields = fields


class AceptarConsentimientoSerializer(serializers.Serializer):
    tipo = serializers.ChoiceField(choices=Consentimiento.Tipo.choices)


def _texto(**extra):
    return serializers.CharField(
        required=False, allow_blank=True, max_length=TEXTO_MAX, trim_whitespace=False, **extra
    )


class PacienteResumenSerializer(serializers.ModelSerializer):
    """Para elegir paciente: sin RUT ni datos de contacto."""

    id = serializers.UUIDField(source="pk", read_only=True)
    nombre = serializers.CharField(source="usuario.nombre", read_only=True)
    apellido = serializers.CharField(source="usuario.apellido", read_only=True)
    tiene_ficha = serializers.SerializerMethodField()

    class Meta:
        model = Paciente
        fields = ["id", "nombre", "apellido", "tiene_ficha"]
        read_only_fields = fields

    def get_tiene_ficha(self, paciente) -> bool:
        return hasattr(paciente, "ficha")


class DatosPacienteSerializer(serializers.ModelSerializer):
    """Datos personales de la ficha podológica, leídos del perfil (no se duplican)."""

    id = serializers.UUIDField(source="pk", read_only=True)
    nombre = serializers.CharField(source="usuario.nombre", read_only=True)
    apellido = serializers.CharField(source="usuario.apellido", read_only=True)
    email = serializers.EmailField(source="usuario.email", read_only=True)
    telefono = serializers.CharField(source="usuario.telefono", read_only=True)
    edad = serializers.IntegerField(read_only=True)

    class Meta:
        model = Paciente
        fields = [
            "id",
            "nombre",
            "apellido",
            "rut",
            "fecha_nacimiento",
            "edad",
            "actividad",
            "email",
            "telefono",
            "telefono_contacto",
            "direccion",
            "comuna",
        ]
        read_only_fields = fields


class DerivacionSerializer(serializers.ModelSerializer):
    especialidad_nombre = serializers.CharField(read_only=True)

    class Meta:
        model = Derivacion
        fields = [
            "id",
            "especialidad_destino",
            "especialidad_detalle",
            "especialidad_nombre",
            "motivo",
            "resumen_clinico",
            "emitida_en",
        ]
        read_only_fields = fields


class MarcaSerializer(serializers.Serializer):
    """Un símbolo en el dibujo de los pies; x e y van de 0 a 1 dentro de la vista."""

    simbolo = serializers.ChoiceField(choices=MarcaPie.Simbolo.choices)
    vista = serializers.ChoiceField(choices=MarcaPie.Vista.choices)
    x = serializers.FloatField(min_value=0, max_value=1)
    y = serializers.FloatField(min_value=0, max_value=1)


class MarcaHistorialSerializer(serializers.ModelSerializer):
    """Una marca del dibujo de la ficha con su historia: en qué atención se agregó y quitó."""

    vigente = serializers.BooleanField(read_only=True)

    class Meta:
        model = MarcaPie
        fields = [
            "id",
            "simbolo",
            "vista",
            "x",
            "y",
            "vigente",
            "atencion_alta",
            "creada_en",
            "atencion_baja",
            "retirada_en",
            "motivo_baja",
        ]
        read_only_fields = fields


class AtencionSerializer(serializers.ModelSerializer):
    """Una atención con su número en la ficha y su relación con las correcciones.

    `marcas_agregadas` y `marcas_retiradas` son los cambios que hizo al dibujo de la ficha.
    """

    numero = serializers.SerializerMethodField()
    vigente = serializers.BooleanField(read_only=True)
    corregida_por = serializers.SerializerMethodField()
    profesional_nombre = serializers.SerializerMethodField()
    derivaciones = DerivacionSerializer(many=True, read_only=True)
    marcas_agregadas = MarcaSerializer(many=True, read_only=True)
    marcas_retiradas = MarcaSerializer(many=True, read_only=True)

    class Meta:
        model = AtencionClinica
        fields = [
            "id",
            "numero",
            "cita",
            "profesional",
            "profesional_nombre",
            "fecha",
            "termino",
            "motivo_consulta",
            "observacion",
            "tratamiento",
            "indicaciones",
            "diagnostico",
            "pie_derecho",
            "pie_izquierdo",
            "proxima_revision",
            "vigente",
            "corrige",
            "motivo_correccion",
            "corregida_por",
            "derivaciones",
            "marcas_agregadas",
            "marcas_retiradas",
        ]
        read_only_fields = fields

    def get_numero(self, atencion) -> int | None:
        return self.context.get("numeros", {}).get(atencion.pk)

    def get_corregida_por(self, atencion) -> str | None:
        correccion = getattr(atencion, "correccion", None)
        return str(correccion.pk) if correccion else None

    def get_profesional_nombre(self, atencion) -> str:
        usuario = atencion.profesional.usuario
        return f"{usuario.nombre} {usuario.apellido}"


CAMPOS_FICHA = [
    "diabetes",
    "varices",
    "hta",
    "otras_patologias_cronicas",
    "medicamentos",
    "alergias",
    "ulcera_previa",
    "ulcera_actual",
    "amputaciones",
    "presion_arterial",
    "camina_con_ayuda",
    "calzado_adecuado",
    "pulso_radial",
    "pulso_pedio_derecho",
    "pulso_pedio_izquierdo",
    "lugar_atencion_salud",
    "observaciones",
]


class FichaSerializer(serializers.ModelSerializer):
    """La ficha con su dibujo de los pies: `dibujo` es el vigente (mismo formato que se envía
    al registrar una atención) y `marcas`, todas, también las retiradas, con su historia."""

    paciente = DatosPacienteSerializer(read_only=True)
    atenciones = AtencionSerializer(many=True, read_only=True)
    dibujo = serializers.SerializerMethodField()
    marcas = MarcaHistorialSerializer(many=True, read_only=True)

    class Meta:
        model = FichaClinica
        fields = [
            "id",
            "paciente",
            *CAMPOS_FICHA,
            "creada_en",
            "actualizada_en",
            "dibujo",
            "marcas",
            "atenciones",
        ]
        read_only_fields = fields

    def get_dibujo(self, ficha) -> list[dict]:
        return MarcaSerializer(marcas_vigentes(ficha), many=True).data


class FichaEdicionSerializer(serializers.ModelSerializer):
    """Cuerpo para crear (POST) o editar (PATCH) la ficha. Todos los campos son opcionales."""

    class Meta:
        model = FichaClinica
        fields = CAMPOS_FICHA
        extra_kwargs = {
            campo: {"required": False, "max_length": TEXTO_MAX}
            for campo in ("otras_patologias_cronicas", "medicamentos", "alergias", "observaciones")
        }


def _base_del_dibujo():
    """Ids de las marcas vigentes con que partió el cliente (`id` en `marcas` de la ficha).

    Opcional: con ellos, lo que otro cambió en el dibujo entretanto no se pierde; sin ellos,
    `marcas` se compara con el dibujo vigente al momento de guardar.
    """
    return serializers.ListField(
        child=serializers.UUIDField(), required=False, max_length=MAX_MARCAS
    )


class _AtencionDatosSerializer(serializers.Serializer):
    motivo_consulta = _texto()
    observacion = _texto()
    tratamiento = _texto()
    indicaciones = _texto()
    diagnostico = _texto()
    pie_derecho = _texto()
    pie_izquierdo = _texto()
    proxima_revision = serializers.DateField(required=False, allow_null=True)


class AtencionCreacionSerializer(_AtencionDatosSerializer):
    """Sin `inicio`, la hora de la cita (o ahora); sin `termino`, ahora si hay cita."""

    cita = serializers.UUIDField(required=False, allow_null=True)
    inicio = serializers.DateTimeField(required=False)
    termino = serializers.DateTimeField(required=False, allow_null=True)
    # El dibujo de la ficha completo tal como queda tras la atención; sin él, no cambia.
    marcas = MarcaSerializer(many=True, required=False, max_length=MAX_MARCAS)
    marcas_base = _base_del_dibujo()


class CorreccionSerializer(_AtencionDatosSerializer):
    """Solo los campos que cambian; el resto se copia de la atención original.

    Sin `marcas` el dibujo de la ficha no cambia; con ellas (el dibujo completo) la corrección
    registra lo agregado y lo quitado.
    """

    motivo_correccion = serializers.CharField(max_length=200)
    marcas = MarcaSerializer(many=True, required=False, max_length=MAX_MARCAS)
    marcas_base = _base_del_dibujo()


class DerivacionCreacionSerializer(serializers.Serializer):
    especialidad_destino = serializers.ChoiceField(choices=Derivacion.Especialidad.choices)
    especialidad_detalle = serializers.CharField(required=False, allow_blank=True, max_length=100)
    motivo = serializers.CharField(max_length=TEXTO_MAX)
    resumen_clinico = _texto()


class InformeConsultaSerializer(serializers.Serializer):
    """Parámetros de GET /api/informes/. Sin fechas: desde el día 1 del mes hasta hoy."""

    desde = serializers.DateField(required=False)
    hasta = serializers.DateField(required=False)
    profesional = serializers.UUIDField(required=False)

    def validate(self, attrs):
        hoy = timezone.localdate()
        hasta = attrs.get("hasta", hoy)
        desde = attrs.get("desde", hasta.replace(day=1))
        if hasta < desde:
            raise serializers.ValidationError({"hasta": "No puede ser anterior a `desde`."})
        if (hasta - desde).days > 366:
            raise serializers.ValidationError({"hasta": "El período no puede superar un año."})
        attrs["desde"], attrs["hasta"] = desde, hasta
        return attrs
