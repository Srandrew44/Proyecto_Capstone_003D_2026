import uuid

from django.db import models
from django.utils import timezone


class Consentimiento(models.Model):
    """Consentimiento informado de un paciente, con la versión del texto que aceptó."""

    class Tipo(models.TextChoices):
        TRATAMIENTO_DATOS = "tratamiento_datos", "Tratamiento de datos personales y de salud"
        USO_CHATBOT = "uso_chatbot", "Uso del asistente virtual"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    paciente = models.ForeignKey(
        "cuentas.Paciente",
        on_delete=models.PROTECT,
        related_name="consentimientos",
    )
    tipo = models.CharField(max_length=40, choices=Tipo.choices)
    version_texto = models.CharField(max_length=20)
    aceptado_en = models.DateTimeField(default=timezone.now)
    revocado_en = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = "consentimiento"
        verbose_name_plural = "consentimientos"
        constraints = [
            # A lo más un consentimiento vigente por paciente y tipo.
            models.UniqueConstraint(
                fields=["paciente", "tipo"],
                condition=models.Q(revocado_en__isnull=True),
                name="consentimiento_vigente_unico",
            ),
            models.CheckConstraint(
                condition=models.Q(revocado_en__isnull=True)
                | models.Q(revocado_en__gte=models.F("aceptado_en")),
                name="consentimiento_revocacion_valida",
            ),
        ]

    def __str__(self):
        return f"{self.tipo} ({self.paciente_id})"

    @property
    def vigente(self) -> bool:
        return self.revocado_en is None

    def es_de(self, usuario) -> bool:
        # La clave del paciente es la del usuario, así que se compara sin consultar la base.
        return usuario.is_authenticated and self.paciente_id == usuario.pk


class FichaClinica(models.Model):
    """Ficha podológica del paciente: una por paciente, compartida por quienes lo atienden.

    Sigue la ficha podológica en papel del cliente, sin los campos que el podólogo descartó
    (estado civil, quién deriva, CESFAM). Los "Antecedentes personales" (RUN, edad, actividad,
    contacto) viven en el perfil del paciente y no se duplican aquí; esta ficha guarda los
    "Antecedentes mórbidos", que llena el podólogo. Los datos de sí o no admiten nulo: "no
    registrado" no es lo mismo que "no". Se crea solo con el consentimiento
    `tratamiento_datos` vigente.
    """

    class Pulso(models.TextChoices):
        PRESENTE = "presente", "Presente"
        DISMINUIDO = "disminuido", "Disminuido"
        AUSENTE = "ausente", "Ausente"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    paciente = models.OneToOneField(
        "cuentas.Paciente",
        on_delete=models.PROTECT,
        related_name="ficha",
    )
    diabetes = models.BooleanField(null=True, blank=True)
    varices = models.BooleanField(null=True, blank=True)
    hta = models.BooleanField(null=True, blank=True, help_text="Hipertensión arterial.")
    otras_patologias_cronicas = models.TextField(blank=True)
    medicamentos = models.TextField(blank=True)
    alergias = models.TextField(blank=True)  # no está en el papel, pero es clave al tratar
    ulcera_previa = models.BooleanField(null=True, blank=True)
    ulcera_actual = models.BooleanField(null=True, blank=True)
    amputaciones = models.BooleanField(null=True, blank=True)
    presion_arterial = models.CharField(max_length=15, blank=True, help_text="Ej.: 120/80.")
    camina_con_ayuda = models.BooleanField(null=True, blank=True)
    calzado_adecuado = models.BooleanField(null=True, blank=True)
    pulso_radial = models.CharField(max_length=12, choices=Pulso.choices, blank=True)
    pulso_pedio_derecho = models.CharField(max_length=12, choices=Pulso.choices, blank=True)
    pulso_pedio_izquierdo = models.CharField(max_length=12, choices=Pulso.choices, blank=True)
    lugar_atencion_salud = models.CharField(max_length=150, blank=True)
    observaciones = models.TextField(blank=True)
    creada_en = models.DateTimeField(auto_now_add=True)
    actualizada_en = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "ficha clínica"
        verbose_name_plural = "fichas clínicas"

    def __str__(self):
        return f"Ficha de {self.paciente}"


class AtencionClinica(models.Model):
    """Una "Atención podológica N°" de la ficha. No se edita ni se borra.

    Un error se arregla con una corrección enlazada: una atención nueva que apunta a la
    original (`corrige`) y dice por qué. La original deja de estar vigente, pero sigue en el
    historial. La cita es opcional (0..1 a 0..1); si existe, es del mismo paciente y
    profesional. `fecha` es la hora de inicio y `termino` la de término.
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    ficha = models.ForeignKey(FichaClinica, on_delete=models.PROTECT, related_name="atenciones")
    cita = models.OneToOneField(
        "agenda.Cita",
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="atencion",
    )
    profesional = models.ForeignKey(
        "cuentas.Profesional",
        on_delete=models.PROTECT,
        related_name="atenciones",
    )
    fecha = models.DateTimeField(default=timezone.now)
    termino = models.DateTimeField(null=True, blank=True)
    motivo_consulta = models.TextField(blank=True)
    observacion = models.TextField(blank=True)
    tratamiento = models.TextField(blank=True)
    indicaciones = models.TextField(blank=True)
    diagnostico = models.TextField(blank=True)
    # Hallazgos que en el papel se marcan sobre el dibujo de cada pie.
    pie_derecho = models.TextField(blank=True)
    pie_izquierdo = models.TextField(blank=True)
    proxima_revision = models.DateField(null=True, blank=True)
    corrige = models.OneToOneField(
        "self",
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="correccion",
    )
    motivo_correccion = models.CharField(max_length=200, blank=True)

    class Meta:
        verbose_name = "atención clínica"
        verbose_name_plural = "atenciones clínicas"
        ordering = ["-fecha"]
        indexes = [models.Index(fields=["ficha", "fecha"], name="atencion_ficha_fecha_idx")]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(termino__isnull=True) | models.Q(termino__gte=models.F("fecha")),
                name="atencion_termino_valido",
            ),
            # Toda corrección dice por qué se hizo.
            models.CheckConstraint(
                condition=models.Q(corrige__isnull=True) | ~models.Q(motivo_correccion=""),
                name="atencion_correccion_con_motivo",
            ),
        ]

    def __str__(self):
        return f"Atención del {timezone.localtime(self.fecha):%d/%m/%Y %H:%M}"

    @property
    def vigente(self) -> bool:
        """Falsa si una corrección la reemplazó."""
        return not hasattr(self, "correccion")


class Derivacion(models.Model):
    """Derivación a otro especialista. No se edita ni se borra; el PDF se genera al pedirlo."""

    class Especialidad(models.TextChoices):
        TRAUMATOLOGIA = "traumatologia", "Traumatología"
        DERMATOLOGIA = "dermatologia", "Dermatología"
        MEDICINA_GENERAL = "medicina_general", "Medicina general"
        OTRA = "otra", "Otra especialidad"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    atencion = models.ForeignKey(
        AtencionClinica,
        on_delete=models.PROTECT,
        related_name="derivaciones",
    )
    especialidad_destino = models.CharField(max_length=30, choices=Especialidad.choices)
    # Solo cuando la especialidad es "otra": cuál es.
    especialidad_detalle = models.CharField(max_length=100, blank=True)
    motivo = models.TextField()
    resumen_clinico = models.TextField(blank=True)
    emitida_en = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = "derivación"
        verbose_name_plural = "derivaciones"
        ordering = ["-emitida_en"]
        constraints = [
            models.CheckConstraint(
                condition=~models.Q(especialidad_destino="otra")
                | ~models.Q(especialidad_detalle=""),
                name="derivacion_otra_con_detalle",
            ),
        ]

    def __str__(self):
        return f"Derivación a {self.especialidad_nombre}"

    @property
    def especialidad_nombre(self) -> str:
        if self.especialidad_destino == self.Especialidad.OTRA:
            return self.especialidad_detalle
        return self.get_especialidad_destino_display()


class MarcaPie(models.Model):
    """Un símbolo de la simbología podológica dibujado sobre los pies del paciente.

    Como en la ficha en papel, hay un solo dibujo por paciente: las marcas son de la ficha.
    El dibujo tiene cuatro vistas: planta y dorso de cada pie. `x` e `y` van de 0 a 1 dentro
    de la vista, así no dependen del tamaño con que se muestre el dibujo.

    Es registro clínico: una marca nunca se borra ni cambia de lugar. Se agrega en una
    atención (`atencion_alta`) y, si deja de estar, se retira en otra (`atencion_baja`, que
    dice quién la retiró), con la fecha y, en una corrección, su motivo. Mover un símbolo es
    retirar el anterior y agregar uno nuevo. El dibujo vigente son las marcas sin retirar.
    """

    class Simbolo(models.TextChoices):
        # Simbología entregada por el podólogo (30/10/2026). Faltan otros símbolos del papel,
        # como el cuadriculado de las uñas: se agregan aquí cuando se confirmen.
        HELOMA_INTERDIGITAL = "heloma_interdigital", "Heloma interdigital"
        HALLUX_VALGUS_PRONUNCIADO = "hallux_valgus_pronunciado", "Hallux valgus pronunciado"
        HALLUX_VALGUS_INCIPIENTE = "hallux_valgus_incipiente", "Hallux valgus incipiente"
        MACERACION = "maceracion", "Maceración"
        PACIENTE_DIABETICO = "paciente_diabetico", "Paciente diabético"
        HELOMA_MILLAR = "heloma_millar", "Heloma millar"
        DEDO_EN_GARRA = "dedo_en_garra", "Dedo en garra"

    class Vista(models.TextChoices):
        # En el orden del papel, de izquierda a derecha.
        PLANTA_DERECHO = "planta_derecho", "Planta del pie derecho"
        DORSO_DERECHO = "dorso_derecho", "Dorso del pie derecho"
        DORSO_IZQUIERDO = "dorso_izquierdo", "Dorso del pie izquierdo"
        PLANTA_IZQUIERDO = "planta_izquierdo", "Planta del pie izquierdo"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    ficha = models.ForeignKey(FichaClinica, on_delete=models.PROTECT, related_name="marcas")
    simbolo = models.CharField(max_length=30, choices=Simbolo.choices)
    vista = models.CharField(max_length=20, choices=Vista.choices)
    x = models.FloatField()
    y = models.FloatField()
    atencion_alta = models.ForeignKey(
        AtencionClinica, on_delete=models.PROTECT, related_name="marcas_agregadas"
    )
    creada_en = models.DateTimeField(default=timezone.now)
    atencion_baja = models.ForeignKey(
        AtencionClinica,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="marcas_retiradas",
    )
    retirada_en = models.DateTimeField(null=True, blank=True)
    motivo_baja = models.CharField(max_length=200, blank=True)

    class Meta:
        verbose_name = "marca en el pie"
        verbose_name_plural = "marcas en los pies"
        ordering = ["creada_en", "id"]
        indexes = [
            models.Index(
                fields=["ficha"],
                condition=models.Q(retirada_en__isnull=True),
                name="marca_pie_vigente_idx",
            )
        ]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(x__gte=0, x__lte=1, y__gte=0, y__lte=1),
                name="marca_pie_dentro_de_la_vista",
            ),
            # Una marca retirada dice cuándo y en qué atención; una vigente, ninguna de las dos.
            models.CheckConstraint(
                condition=models.Q(retirada_en__isnull=True, atencion_baja__isnull=True)
                | models.Q(
                    retirada_en__isnull=False,
                    atencion_baja__isnull=False,
                    retirada_en__gte=models.F("creada_en"),
                ),
                name="marca_pie_retiro_valido",
            ),
        ]

    def __str__(self):
        return f"{self.get_simbolo_display()} ({self.get_vista_display()})"

    @property
    def vigente(self) -> bool:
        return self.retirada_en is None


def clave_marca(marca) -> tuple:
    """Lo que identifica una marca en el dibujo: símbolo, vista y lugar (objeto o diccionario).

    El lugar se redondea para que el ida y vuelta por el navegador no invente movimientos.
    """
    leer = marca.get if isinstance(marca, dict) else lambda campo: getattr(marca, campo)
    return (leer("simbolo"), leer("vista"), round(float(leer("x")), 4), round(float(leer("y")), 4))
