"""PDF de la derivación y del informe de gestión. Se generan al pedirlos y no se guardan.

Derivación: no quedan archivos con datos de salud en el disco, y como no cambia, el documento
sale siempre igual. Informe: solo cifras agregadas, sin datos que identifiquen pacientes.
"""

from io import BytesIO
from xml.sax.saxutils import escape

from django.conf import settings
from django.utils import timezone
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.shapes import Drawing
from reportlab.lib import colors
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (
    KeepTogether,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from .models import Derivacion


def _parrafos(texto: str, estilo) -> list[Paragraph]:
    """Texto libre del profesional, escapado y con sus saltos de línea."""
    return [Paragraph(escape(linea) or "&nbsp;", estilo) for linea in texto.splitlines()]


def generar_pdf_derivacion(derivacion: Derivacion, *, comprimir: bool = True) -> bytes:
    atencion = derivacion.atencion
    paciente = atencion.ficha.paciente
    profesional = atencion.profesional
    emitida = timezone.localtime(derivacion.emitida_en)

    estilos = getSampleStyleSheet()
    normal, titulo, seccion = estilos["Normal"], estilos["Title"], estilos["Heading3"]
    pequeno = estilos["Italic"]

    contenido = [
        Paragraph(escape(settings.CONSULTA_NOMBRE or "Consulta podológica"), estilos["Heading2"]),
    ]
    direccion = ", ".join(p for p in (settings.CONSULTA_DIRECCION, settings.CONSULTA_COMUNA) if p)
    if direccion:
        contenido.append(Paragraph(escape(direccion), normal))
    contenido += [
        Spacer(1, 0.6 * cm),
        Paragraph(escape(f"Derivación a {derivacion.especialidad_nombre}"), titulo),
        Paragraph(f"Fecha de emisión: {emitida:%d/%m/%Y %H:%M}", normal),
        Spacer(1, 0.4 * cm),
        Paragraph("Paciente", seccion),
        Paragraph(escape(f"{paciente.usuario.nombre} {paciente.usuario.apellido}"), normal),
        Paragraph(f"RUT: {escape(paciente.rut)}", normal),
        Paragraph(f"Edad: {paciente.edad_al(emitida.date())} años", normal),
        Paragraph("Motivo de la derivación", seccion),
        *_parrafos(derivacion.motivo, normal),
    ]
    if atencion.diagnostico:
        contenido += [
            Paragraph("Diagnóstico podológico", seccion),
            *_parrafos(atencion.diagnostico, normal),
        ]
    if derivacion.resumen_clinico:
        contenido += [
            Paragraph("Resumen clínico", seccion),
            *_parrafos(derivacion.resumen_clinico, normal),
        ]
    contenido += [
        Spacer(1, 1.6 * cm),
        Paragraph("_______________________________", normal),
        Paragraph(escape(f"{profesional.usuario.nombre} {profesional.usuario.apellido}"), normal),
        Paragraph(escape(profesional.especialidad), normal),
    ]
    if profesional.numero_colegiado:
        contenido.append(
            Paragraph(f"N.º de registro: {escape(profesional.numero_colegiado)}", normal)
        )
    contenido += [
        Spacer(1, 1 * cm),
        Paragraph("Documento confidencial: contiene datos de salud del paciente.", pequeno),
    ]

    salida = BytesIO()
    documento = SimpleDocTemplate(
        salida,
        pagesize=LETTER,
        title=f"Derivación a {derivacion.especialidad_nombre}",
        author=f"{profesional.usuario.nombre} {profesional.usuario.apellido}",
        leftMargin=2.2 * cm,
        rightMargin=2.2 * cm,
        topMargin=2 * cm,
        bottomMargin=2 * cm,
        invariant=1,
        pageCompression=1 if comprimir else 0,
    )
    documento.build(contenido)
    return salida.getvalue()


# --- informe de gestión ---

ESTADOS = [
    ("confirmada", "Confirmadas"),
    ("agendada", "Agendadas"),
    ("realizada", "Realizadas"),
    ("no_asistio", "No asistió"),
    ("cancelada", "Canceladas"),
]
ANTECEDENTES = [
    ("diabetes", "Diabetes"),
    ("hta", "Hipertensión arterial"),
    ("varices", "Várices"),
    ("ulcera_actual", "Úlcera actual"),
    ("amputaciones", "Amputaciones"),
]
GRIS = colors.HexColor("#E8EEF2")
AZUL = colors.HexColor("#2F6690")


def _pesos(monto: int) -> str:
    return "$" + f"{monto:,}".replace(",", ".")


def _porcentaje(valor) -> str:
    return "sin datos" if valor is None else f"{valor:.1f} %".replace(".", ",")


def _tabla(filas, anchos, encabezado=True) -> Table:
    tabla = Table(filas, colWidths=anchos, hAlign="LEFT")
    estilo = [
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
        ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]
    if encabezado:
        estilo += [
            ("BACKGROUND", (0, 0), (-1, 0), GRIS),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ]
    tabla.setStyle(TableStyle(estilo))
    return tabla


def _grafico_semanal(semanas) -> Drawing:
    """Barras de citas realizadas por semana."""
    dibujo = Drawing(16 * cm, 5.5 * cm)
    grafico = VerticalBarChart()
    grafico.x, grafico.y = 1.2 * cm, 1 * cm
    grafico.width, grafico.height = 14 * cm, 4 * cm
    grafico.data = [[semana["realizadas"] for semana in semanas]]
    grafico.categoryAxis.categoryNames = [f"{semana['semana']:%d/%m}" for semana in semanas]
    grafico.categoryAxis.labels.fontSize = 7
    grafico.categoryAxis.labels.fontName = "Helvetica"
    # Son cantidades de citas: el eje va en enteros.
    maximo = max(grafico.data[0], default=0)
    grafico.valueAxis.valueMin = 0
    grafico.valueAxis.valueMax = max(maximo, 1)
    grafico.valueAxis.valueStep = max(1, -(-maximo // 5))
    grafico.valueAxis.labelTextFormat = "%d"
    grafico.valueAxis.labels.fontSize = 7
    grafico.valueAxis.labels.fontName = "Helvetica"
    grafico.bars[0].fillColor = AZUL
    dibujo.add(grafico)
    return dibujo


def _sin_titulos_huerfanos(contenido, estilo_titulo) -> list:
    """Une cada título de sección con lo que sigue, para que no quede solo al pie de página."""
    juntos = []
    for elemento in contenido:
        anterior = juntos[-1] if juntos else None
        if isinstance(anterior, Paragraph) and anterior.style is estilo_titulo:
            juntos[-1] = KeepTogether([anterior, elemento])
        else:
            juntos.append(elemento)
    return juntos


def generar_pdf_informe(informe: dict, *, alcance: str, comprimir: bool = True) -> bytes:
    """PDF del informe de gestión. `alcance` dice de quién es (un profesional o la consulta)."""
    estilos = getSampleStyleSheet()
    normal, seccion = estilos["Normal"], estilos["Heading3"]
    celda = ParagraphStyle("celda", parent=normal, fontSize=9, leading=11)
    citas, ingresos, ocupacion = informe["citas"], informe["ingresos"], informe["ocupacion"]
    periodo = f"{informe['desde']:%d/%m/%Y} al {informe['hasta']:%d/%m/%Y}"

    contenido = [
        Paragraph(escape(settings.CONSULTA_NOMBRE or "Consulta podológica"), estilos["Heading2"]),
        Paragraph("Informe de gestión", estilos["Title"]),
        Paragraph(escape(f"{alcance} · Período: {periodo}"), normal),
        Paragraph(f"Generado el {timezone.localtime():%d/%m/%Y %H:%M}", normal),
        Spacer(1, 0.4 * cm),
        Paragraph("Resumen", seccion),
        _tabla(
            [
                ["Citas del período", str(citas["total"])],
                ["Tasa de inasistencia", _porcentaje(citas["tasa_inasistencia"])],
                ["Tasa de cancelación", _porcentaje(citas["tasa_cancelacion"])],
                ["Ingresos (citas realizadas)", _pesos(ingresos["realizados"])],
                ["Perdido por inasistencias", _pesos(ingresos["perdidos_por_inasistencia"])],
                ["Ocupación de la agenda", _porcentaje(ocupacion["porcentaje"])],
                [
                    "Horas reservadas / disponibles",
                    f"{ocupacion['minutos_reservados'] / 60:.1f} / "
                    f"{ocupacion['minutos_disponibles'] / 60:.1f}".replace(".", ","),
                ],
            ],
            [9.6 * cm, 5 * cm],
            encabezado=False,
        ),
        Paragraph("Citas por estado", seccion),
        _tabla(
            [["Estado", "Citas"]]
            + [[nombre, str(citas["por_estado"][clave])] for clave, nombre in ESTADOS],
            [9.6 * cm, 5 * cm],
        ),
    ]

    if informe["tratamientos"]:
        contenido += [
            Paragraph("Tratamientos", seccion),
            _tabla(
                [["Tratamiento", "Citas", "Realizadas", "Ingresos"]]
                + [
                    [
                        Paragraph(escape(fila["tratamiento"]), celda),
                        str(fila["citas"]),
                        str(fila["realizadas"]),
                        _pesos(fila["ingresos"]),
                    ]
                    for fila in informe["tratamientos"]
                ],
                [7 * cm, 2.2 * cm, 2.4 * cm, 3 * cm],
            ),
        ]

    pacientes, derivaciones = informe["pacientes"], informe["derivaciones"]
    contenido += [
        Paragraph("Pacientes y atenciones", seccion),
        _tabla(
            [
                ["Pacientes atendidos", str(pacientes["atendidos"])],
                ["Nuevos", str(pacientes["nuevos"])],
                ["Recurrentes", str(pacientes["recurrentes"])],
                ["Atenciones registradas", str(informe["atenciones"])],
                ["Derivaciones emitidas", str(derivaciones["total"])],
            ],
            [9.6 * cm, 5 * cm],
            encabezado=False,
        ),
    ]
    if derivaciones["total"]:
        nombres = dict(Derivacion.Especialidad.choices)
        contenido += [
            Paragraph("Derivaciones por especialidad", seccion),
            _tabla(
                [["Especialidad", "Derivaciones"]]
                + [
                    [nombres[clave], str(n)]
                    for clave, n in derivaciones["por_especialidad"].items()
                    if n
                ],
                [9.6 * cm, 5 * cm],
            ),
        ]

    perfil = informe["perfil_clinico"]
    contenido += [
        Paragraph(
            f"Perfil clínico de los pacientes atendidos ({perfil['con_ficha']} con ficha)", seccion
        ),
        _tabla(
            [["Antecedente", "Sí", "No", "Sin registro"]]
            + [
                [
                    nombre,
                    str(perfil[clave]["si"]),
                    str(perfil[clave]["no"]),
                    str(perfil[clave]["sin_registro"]),
                ]
                for clave, nombre in ANTECEDENTES
            ],
            [7 * cm, 2.2 * cm, 2.2 * cm, 3.2 * cm],
        ),
    ]

    if informe["por_semana"]:
        contenido += [
            Paragraph("Citas realizadas por semana", seccion),
            _grafico_semanal(informe["por_semana"]),
            _tabla(
                [["Semana del", "Realizadas", "Canceladas", "No asistió", "Ingresos"]]
                + [
                    [
                        f"{semana['semana']:%d/%m/%Y}",
                        str(semana["realizadas"]),
                        str(semana["canceladas"]),
                        str(semana["no_asistio"]),
                        _pesos(semana["ingresos"]),
                    ]
                    for semana in informe["por_semana"]
                ],
                [3.8 * cm, 2.6 * cm, 2.6 * cm, 2.6 * cm, 3 * cm],
            ),
        ]

    if "por_profesional" in informe:
        contenido += [
            Paragraph("Por profesional", seccion),
            _tabla(
                [["Profesional", "Citas", "Inasistencia", "Ingresos", "Ocupación"]]
                + [
                    [
                        Paragraph(escape(fila["nombre"]), celda),
                        str(fila["citas"]["total"]),
                        _porcentaje(fila["citas"]["tasa_inasistencia"]),
                        _pesos(fila["ingresos"]["realizados"]),
                        _porcentaje(fila["ocupacion"]["porcentaje"]),
                    ]
                    for fila in informe["por_profesional"]
                ],
                [5 * cm, 1.8 * cm, 2.6 * cm, 2.8 * cm, 2.4 * cm],
            ),
        ]

    contenido += [
        Spacer(1, 0.6 * cm),
        Paragraph(
            "La ocupación usa los horarios de atención vigentes; si cambiaron dentro del "
            "período, la cifra es aproximada. Este informe no contiene datos que identifiquen "
            "a pacientes.",
            estilos["Italic"],
        ),
    ]

    salida = BytesIO()
    SimpleDocTemplate(
        salida,
        pagesize=LETTER,
        title=f"Informe de gestión {periodo}",
        leftMargin=2 * cm,
        rightMargin=2 * cm,
        topMargin=1.8 * cm,
        bottomMargin=1.8 * cm,
        pageCompression=1 if comprimir else 0,
    ).build(_sin_titulos_huerfanos(contenido, seccion))
    return salida.getvalue()
