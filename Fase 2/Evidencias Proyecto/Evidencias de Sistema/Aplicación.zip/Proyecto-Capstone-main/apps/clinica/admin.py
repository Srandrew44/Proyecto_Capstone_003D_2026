from django.contrib import admin

from .models import Consentimiento


@admin.register(Consentimiento)
class ConsentimientoAdmin(admin.ModelAdmin):
    """Solo lectura: los consentimientos los acepta y revoca el propio paciente."""

    list_display = ("paciente", "tipo", "version_texto", "aceptado_en", "revocado_en")
    list_filter = ("tipo",)
    list_select_related = ("paciente__usuario",)

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
