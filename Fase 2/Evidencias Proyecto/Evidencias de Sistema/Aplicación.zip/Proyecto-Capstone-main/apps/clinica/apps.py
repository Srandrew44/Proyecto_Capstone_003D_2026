from django.apps import AppConfig


class ClinicaConfig(AppConfig):
    name = "apps.clinica"
    label = "clinica"
    verbose_name = "Clínica"
