from datetime import time

import pytest

from apps.cuentas.tests.factories import CLAVE, PacienteFactory, ProfesionalFactory

from .factories import DisponibilidadFactory, TratamientoFactory

pytestmark = pytest.mark.django_db
TRATAMIENTOS = "/api/tratamientos/"
DISPONIBILIDADES = "/api/disponibilidades/"
TRAMO = {"dia_semana": 0, "hora_inicio": "09:00", "hora_fin": "13:00"}


def _entrar(cliente, usuario):
    cliente.post("/api/auth/login/", {"email": usuario.email, "password": CLAVE}, format="json")


def _editar(cliente, tramo, cuerpo):
    return cliente.patch(f"{DISPONIBILIDADES}{tramo.pk}/", cuerpo, format="json")


def test_tratamientos_exige_sesion(api_client):
    assert api_client.get(TRATAMIENTOS).status_code == 403


def test_tratamientos_lista_solo_activos_ordenados(api_client):
    TratamientoFactory(nombre="Zeta")
    TratamientoFactory(nombre="Alfa")
    TratamientoFactory(nombre="Oculto", activo=False)
    _entrar(api_client, PacienteFactory().usuario)
    respuesta = api_client.get(TRATAMIENTOS)
    assert respuesta.status_code == 200
    assert [t["nombre"] for t in respuesta.json()] == ["Alfa", "Zeta"]
    assert "activo" not in respuesta.json()[0]


def test_el_profesional_tambien_ve_los_tratamientos(api_client):
    TratamientoFactory()
    _entrar(api_client, ProfesionalFactory().usuario)
    assert len(api_client.get(TRATAMIENTOS).json()) == 1


def test_disponibilidades_exige_sesion(api_client):
    assert api_client.get(DISPONIBILIDADES).status_code == 403
    assert api_client.post(DISPONIBILIDADES, TRAMO, format="json").status_code == 403


def test_el_paciente_no_usa_disponibilidades(api_client):
    _entrar(api_client, PacienteFactory().usuario)
    assert api_client.get(DISPONIBILIDADES).status_code == 403
    assert api_client.post(DISPONIBILIDADES, TRAMO, format="json").status_code == 403


def test_el_profesional_lista_solo_sus_tramos(api_client):
    profesional = ProfesionalFactory()
    propio = DisponibilidadFactory(profesional=profesional)
    DisponibilidadFactory()
    _entrar(api_client, profesional.usuario)
    respuesta = api_client.get(DISPONIBILIDADES).json()
    assert [t["id"] for t in respuesta] == [str(propio.pk)]


def test_el_profesional_crea_un_tramo(api_client):
    profesional = ProfesionalFactory()
    _entrar(api_client, profesional.usuario)
    respuesta = api_client.post(DISPONIBILIDADES, TRAMO, format="json")
    assert respuesta.status_code == 201
    assert respuesta.json()["hora_inicio"] == "09:00:00"
    assert respuesta.json()["activa"] is True
    assert profesional.disponibilidades.count() == 1


def test_crear_un_tramo_solapado_responde_400(api_client):
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    _entrar(api_client, profesional.usuario)
    solapado = {"dia_semana": 0, "hora_inicio": "12:00", "hora_fin": "15:00"}
    respuesta = api_client.post(DISPONIBILIDADES, solapado, format="json")
    assert respuesta.status_code == 400
    assert "solapa" in str(respuesta.json())
    assert profesional.disponibilidades.count() == 1


def test_crear_un_tramo_con_horas_invertidas_responde_400(api_client):
    _entrar(api_client, ProfesionalFactory().usuario)
    invertido = {"dia_semana": 0, "hora_inicio": "13:00", "hora_fin": "09:00"}
    respuesta = api_client.post(DISPONIBILIDADES, invertido, format="json")
    assert respuesta.status_code == 400
    assert "hora_fin" in respuesta.json()


def test_crear_un_tramo_con_dia_invalido_responde_400(api_client):
    _entrar(api_client, ProfesionalFactory().usuario)
    respuesta = api_client.post(DISPONIBILIDADES, {**TRAMO, "dia_semana": 7}, format="json")
    assert respuesta.status_code == 400


def test_editar_las_horas_de_un_tramo(api_client):
    profesional = ProfesionalFactory()
    tramo = DisponibilidadFactory(profesional=profesional)
    _entrar(api_client, profesional.usuario)
    respuesta = _editar(api_client, tramo, {"hora_fin": "14:00"})
    assert respuesta.status_code == 200
    tramo.refresh_from_db()
    assert tramo.hora_fin == time(14)


def test_desactivar_un_tramo_libera_el_horario(api_client):
    profesional = ProfesionalFactory()
    tramo = DisponibilidadFactory(profesional=profesional)
    _entrar(api_client, profesional.usuario)
    desactivar = _editar(api_client, tramo, {"activa": False})
    assert desactivar.status_code == 200
    assert api_client.post(DISPONIBILIDADES, TRAMO, format="json").status_code == 201


def test_editar_un_tramo_ajeno_responde_404(api_client):
    ajeno = DisponibilidadFactory()
    _entrar(api_client, ProfesionalFactory().usuario)
    respuesta = _editar(api_client, ajeno, {"activa": False})
    assert respuesta.status_code == 404
    ajeno.refresh_from_db()
    assert ajeno.activa is True


def test_editar_para_solapar_responde_400_y_no_cambia(api_client):
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional, hora_inicio=time(9), hora_fin=time(13))
    segundo = DisponibilidadFactory(
        profesional=profesional, hora_inicio=time(14), hora_fin=time(18)
    )
    _entrar(api_client, profesional.usuario)
    respuesta = _editar(api_client, segundo, {"hora_inicio": "12:00"})
    assert respuesta.status_code == 400
    segundo.refresh_from_db()
    assert segundo.hora_inicio == time(14)


def test_reactivar_un_tramo_solapado_responde_400(api_client):
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional, hora_inicio=time(9), hora_fin=time(13))
    inactivo = DisponibilidadFactory(
        profesional=profesional, hora_inicio=time(12), hora_fin=time(15), activa=False
    )
    _entrar(api_client, profesional.usuario)
    respuesta = _editar(api_client, inactivo, {"activa": True})
    assert respuesta.status_code == 400
    inactivo.refresh_from_db()
    assert inactivo.activa is False


def test_no_se_puede_borrar_un_tramo(api_client):
    profesional = ProfesionalFactory()
    tramo = DisponibilidadFactory(profesional=profesional)
    _entrar(api_client, profesional.usuario)
    assert api_client.delete(f"{DISPONIBILIDADES}{tramo.pk}/").status_code == 405


def test_el_profesional_de_un_tramo_no_se_cambia_por_api(api_client):
    profesional = ProfesionalFactory()
    otro = ProfesionalFactory()
    tramo = DisponibilidadFactory(profesional=profesional)
    _entrar(api_client, profesional.usuario)
    respuesta = _editar(api_client, tramo, {"profesional": str(otro.pk), "hora_fin": "14:00"})
    assert respuesta.status_code == 200
    tramo.refresh_from_db()
    assert tramo.profesional_id == profesional.pk
