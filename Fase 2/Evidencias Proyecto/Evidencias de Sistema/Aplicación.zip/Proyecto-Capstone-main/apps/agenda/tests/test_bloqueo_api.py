from datetime import timedelta

import pytest

from apps.agenda.models import BloqueoHorario
from apps.cuentas.tests.factories import CLAVE, PacienteFactory, ProfesionalFactory

from .factories import (
    INICIO_BASE,
    BloqueoHorarioFactory,
    CitaFactory,
    DisponibilidadFactory,
    TratamientoFactory,
)

pytestmark = pytest.mark.django_db

BLOQUEOS = "/api/bloqueos/"


@pytest.fixture(autouse=True)
def reglas_de_agenda(settings):
    settings.AGENDA_ANTICIPACION_MIN_HORAS = 24
    # La API usa la hora real: el horizonte se amplía para llegar al lunes de las pruebas.
    settings.AGENDA_HORIZONTE_DIAS = 3650


@pytest.fixture
def profesional():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    return profesional


def _entrar(cliente, usuario):
    cliente.post("/api/auth/login/", {"email": usuario.email, "password": CLAVE}, format="json")


def _cuerpo(inicio=INICIO_BASE, horas=1, **extra):
    fin = inicio + timedelta(hours=horas)
    return {"inicio": inicio.isoformat(), "fin": fin.isoformat(), **extra}


def test_bloqueos_exige_sesion(api_client):
    assert api_client.get(BLOQUEOS).status_code == 403


def test_un_paciente_no_puede_bloquear(api_client):
    _entrar(api_client, PacienteFactory().usuario)
    assert api_client.post(BLOQUEOS, _cuerpo(), format="json").status_code == 403
    assert api_client.get(BLOQUEOS).status_code == 403


def test_el_profesional_crea_un_bloqueo(api_client, profesional):
    _entrar(api_client, profesional.usuario)
    respuesta = api_client.post(BLOQUEOS, _cuerpo(motivo="Congreso"), format="json")
    assert respuesta.status_code == 201
    assert respuesta.json()["motivo"] == "Congreso"
    bloqueo = BloqueoHorario.objects.get()
    assert bloqueo.profesional == profesional
    assert bloqueo.inicio == INICIO_BASE


def test_el_profesional_solo_ve_sus_bloqueos(api_client, profesional):
    propio = BloqueoHorarioFactory(profesional=profesional)
    BloqueoHorarioFactory()
    _entrar(api_client, profesional.usuario)
    respuesta = api_client.get(BLOQUEOS)
    assert respuesta.status_code == 200
    assert [b["id"] for b in respuesta.json()] == [str(propio.pk)]


def test_un_bloqueo_que_cruza_citas_responde_400(api_client, profesional):
    CitaFactory(profesional=profesional)
    _entrar(api_client, profesional.usuario)
    respuesta = api_client.post(BLOQUEOS, _cuerpo(), format="json")
    assert respuesta.status_code == 400
    assert "07/01/2030 09:00" in str(respuesta.json())
    assert not BloqueoHorario.objects.exists()


def test_un_fin_anterior_al_inicio_responde_400(api_client, profesional):
    _entrar(api_client, profesional.usuario)
    respuesta = api_client.post(BLOQUEOS, _cuerpo(horas=-1), format="json")
    assert respuesta.status_code == 400
    assert "fin" in respuesta.json()


def test_el_profesional_borra_su_bloqueo(api_client, profesional):
    bloqueo = BloqueoHorarioFactory(profesional=profesional)
    _entrar(api_client, profesional.usuario)
    assert api_client.delete(f"{BLOQUEOS}{bloqueo.pk}/").status_code == 204
    assert not BloqueoHorario.objects.exists()


def test_el_bloqueo_ajeno_responde_404_y_no_se_borra(api_client, profesional):
    ajeno = BloqueoHorarioFactory()
    _entrar(api_client, profesional.usuario)
    assert api_client.delete(f"{BLOQUEOS}{ajeno.pk}/").status_code == 404
    assert BloqueoHorario.objects.filter(pk=ajeno.pk).exists()


def test_un_bloqueo_no_se_edita(api_client, profesional):
    bloqueo = BloqueoHorarioFactory(profesional=profesional)
    _entrar(api_client, profesional.usuario)
    respuesta = api_client.patch(f"{BLOQUEOS}{bloqueo.pk}/", {"motivo": "x"}, format="json")
    assert respuesta.status_code == 405


def test_los_horarios_libres_restan_el_bloqueo(api_client, profesional):
    tratamiento = TratamientoFactory()
    BloqueoHorarioFactory(
        profesional=profesional, inicio=INICIO_BASE, fin=INICIO_BASE.replace(hour=11)
    )
    _entrar(api_client, PacienteFactory().usuario)
    consulta = {
        "profesional": str(profesional.pk),
        "tratamiento": str(tratamiento.pk),
        "desde": INICIO_BASE.date().isoformat(),
        "hasta": INICIO_BASE.date().isoformat(),
    }
    horarios = api_client.get("/api/horarios-libres/", consulta).json()["horarios"]
    assert [h[11:16] for h in horarios] == ["11:00", "12:00"]
