import pytest

from apps.cuentas.tests.factories import CLAVE, PacienteFactory, ProfesionalFactory

pytestmark = pytest.mark.django_db
URL = "/api/consulta/"


def _entrar(cliente, usuario):
    cliente.post("/api/auth/login/", {"email": usuario.email, "password": CLAVE}, format="json")


def test_la_consulta_exige_sesion(api_client):
    assert api_client.get(URL).status_code == 403


@pytest.mark.parametrize("fabrica", [PacienteFactory, ProfesionalFactory])
def test_cualquier_usuario_con_sesion_ve_la_consulta(api_client, settings, fabrica):
    settings.CONSULTA_NOMBRE = "Consulta Podológica Demo"
    settings.CONSULTA_DIRECCION = "Av. Siempre Viva 742"
    settings.CONSULTA_COMUNA = "Ñuñoa"
    settings.CONSULTA_INDICACIONES = "Oficina 12, segundo piso"
    settings.CONSULTA_TELEFONO = "+56 2 2345 6789"
    settings.CONSULTA_CORREO = "contacto@consulta.example"
    settings.CONSULTA_HORARIO = "Lunes a viernes de 9:00 a 18:00"
    _entrar(api_client, fabrica().usuario)
    respuesta = api_client.get(URL)
    assert respuesta.status_code == 200
    assert respuesta.json() == {
        "nombre": "Consulta Podológica Demo",
        "direccion": "Av. Siempre Viva 742",
        "comuna": "Ñuñoa",
        "indicaciones": "Oficina 12, segundo piso",
        "telefono": "+56 2 2345 6789",
        "correo": "contacto@consulta.example",
        "horario": "Lunes a viernes de 9:00 a 18:00",
    }
