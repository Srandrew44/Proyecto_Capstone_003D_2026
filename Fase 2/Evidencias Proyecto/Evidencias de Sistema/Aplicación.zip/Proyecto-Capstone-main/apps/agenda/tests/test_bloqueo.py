from datetime import timedelta
from unittest import mock

import pytest
from django.contrib.admin.models import LogEntry
from django.core.exceptions import ValidationError
from django.db import IntegrityError
from django.utils import timezone

from apps.agenda.horarios import horarios_libres
from apps.agenda.models import BloqueoHorario, Cita
from apps.agenda.services import crear_bloqueo, eliminar_bloqueo, reagendar_cita, reservar_cita
from apps.clinica.tests.factories import ConsentimientoFactory
from apps.cuentas.models import Usuario
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory, UsuarioFactory
from apps.pagos.models import Pago

from .factories import (
    INICIO_BASE,
    BloqueoHorarioFactory,
    CitaFactory,
    DisponibilidadFactory,
    TratamientoFactory,
)

pytestmark = pytest.mark.django_db

AHORA = INICIO_BASE - timedelta(days=3)
LUNES = INICIO_BASE.date()


def _h(horas, minutos=0):
    """Instante del lunes de las pruebas a la hora indicada."""
    return INICIO_BASE.replace(hour=horas, minute=minutos)


@pytest.fixture(autouse=True)
def reglas_de_agenda(settings):
    settings.AGENDA_ANTICIPACION_MIN_HORAS = 24
    settings.AGENDA_HORIZONTE_DIAS = 30
    settings.AGENDA_CANCELACION_MIN_HORAS = 24


@pytest.fixture
def profesional():
    """Profesional con pausa de 15 min y un tramo los lunes de 09:00 a 13:00."""
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    return profesional


@pytest.fixture
def tratamiento():
    return TratamientoFactory(duracion_min=45)


def _libres(profesional, tratamiento):
    return horarios_libres(
        profesional=profesional, tratamiento=tratamiento, desde=LUNES, hasta=LUNES, ahora=AHORA
    )


def _bloquear(profesional, inicio, fin, **extra):
    return crear_bloqueo(profesional=profesional, inicio=inicio, fin=fin, ahora=AHORA, **extra)


# --- modelo ---


def test_el_fin_debe_ser_posterior_al_inicio():
    with pytest.raises(IntegrityError):
        BloqueoHorarioFactory(fin=INICIO_BASE)


def test_es_de_su_profesional():
    bloqueo = BloqueoHorarioFactory()
    assert bloqueo.es_de(bloqueo.profesional.usuario)
    assert not bloqueo.es_de(ProfesionalFactory().usuario)


# --- servicio ---


def test_crea_un_bloqueo(profesional):
    bloqueo = _bloquear(profesional, _h(10), _h(11), motivo="  Trámite  ")
    bloqueo.refresh_from_db()
    assert bloqueo.profesional == profesional
    assert bloqueo.motivo == "Trámite"


def test_rechaza_un_fin_anterior_al_inicio(profesional):
    with pytest.raises(ValidationError) as error:
        _bloquear(profesional, _h(11), _h(10))
    assert "fin" in error.value.message_dict


def test_rechaza_un_bloqueo_que_ya_termino(profesional):
    with pytest.raises(ValidationError, match="ya terminó"):
        _bloquear(profesional, AHORA - timedelta(hours=2), AHORA - timedelta(hours=1))


def test_rechaza_un_motivo_demasiado_largo(profesional):
    with pytest.raises(ValidationError) as error:
        _bloquear(profesional, _h(10), _h(11), motivo="x" * 201)
    assert "motivo" in error.value.message_dict


def test_rechaza_un_bloqueo_que_cruza_citas_y_dice_cuales(profesional):
    CitaFactory(profesional=profesional, inicio=_h(10))
    with pytest.raises(ValidationError, match="07/01/2030 10:00"):
        _bloquear(profesional, _h(9), _h(12))
    assert not BloqueoHorario.objects.exists()


def test_una_cita_cancelada_no_impide_el_bloqueo(profesional):
    CitaFactory(profesional=profesional, inicio=_h(10), estado=Cita.Estado.CANCELADA)
    assert _bloquear(profesional, _h(9), _h(12))


def test_las_citas_de_otro_profesional_no_impiden_el_bloqueo(profesional):
    CitaFactory(inicio=_h(10))
    assert _bloquear(profesional, _h(9), _h(12))


def test_un_bloqueo_contiguo_a_una_cita_se_permite(profesional):
    cita = CitaFactory(profesional=profesional, inicio=_h(9))
    assert _bloquear(profesional, cita.fin, _h(11))


def test_eliminar_un_bloqueo_libera_los_horarios(profesional, tratamiento):
    bloqueo = _bloquear(profesional, _h(9), _h(13))
    assert _libres(profesional, tratamiento) == []
    eliminar_bloqueo(bloqueo=bloqueo)
    assert len(_libres(profesional, tratamiento)) == 4


# --- horarios libres ---


def test_un_bloqueo_quita_los_horarios_que_cruza(profesional, tratamiento):
    _bloquear(profesional, _h(10), _h(11))
    assert _libres(profesional, tratamiento) == [_h(9), _h(11), _h(12)]


def test_tras_un_bloqueo_los_horarios_parten_en_su_fin(profesional, tratamiento):
    _bloquear(profesional, _h(9), _h(9, 30))
    assert _libres(profesional, tratamiento) == [_h(9, 30), _h(10, 30), _h(11, 30)]


def test_una_cita_no_necesita_pausa_antes_de_un_bloqueo(profesional, tratamiento):
    # La cita de las 09:00 termina 09:45, justo cuando empieza el bloqueo.
    _bloquear(profesional, _h(9, 45), _h(10, 45))
    assert _libres(profesional, tratamiento) == [_h(9), _h(10, 45), _h(11, 45)]


def test_un_bloqueo_de_todo_el_dia_deja_el_dia_sin_horarios(profesional, tratamiento):
    _bloquear(profesional, _h(0), _h(23, 59))
    assert _libres(profesional, tratamiento) == []


def test_el_bloqueo_de_otro_profesional_no_afecta(profesional, tratamiento):
    BloqueoHorarioFactory(inicio=_h(9), fin=_h(13))
    assert len(_libres(profesional, tratamiento)) == 4


def test_no_se_reserva_en_un_horario_bloqueado(profesional, tratamiento):
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente)
    _bloquear(profesional, _h(9), _h(10))
    with pytest.raises(ValidationError) as error:
        reservar_cita(
            paciente=paciente,
            profesional=profesional,
            tratamiento=tratamiento,
            inicio=_h(9),
            ahora=AHORA,
        )
    assert "inicio" in error.value.message_dict


def test_no_se_reagenda_a_un_horario_bloqueado(profesional, tratamiento):
    cita = CitaFactory(profesional=profesional, tratamiento=tratamiento, inicio=_h(9))
    _bloquear(profesional, _h(11), _h(12))
    with pytest.raises(ValidationError):
        reagendar_cita(cita=cita, usuario=cita.paciente.usuario, inicio=_h(11), ahora=AHORA)


# --- admin ---

AGREGAR = "/admin/agenda/bloqueohorario/add/"


@pytest.fixture
def cliente_admin(client):
    client.force_login(UsuarioFactory(rol=Usuario.Rol.ADMIN, is_staff=True, is_superuser=True))
    return client


def _enviar_admin(cliente, profesional, inicio, fin, motivo=""):
    inicio, fin = timezone.localtime(inicio), timezone.localtime(fin)
    datos = {
        "profesional": profesional.pk,
        "inicio_0": f"{inicio:%Y-%m-%d}",
        "inicio_1": f"{inicio:%H:%M:%S}",
        "fin_0": f"{fin:%Y-%m-%d}",
        "fin_1": f"{fin:%H:%M:%S}",
        "motivo": motivo,
    }
    return cliente.post(AGREGAR, datos)


def test_el_admin_crea_el_bloqueo_con_el_servicio(cliente_admin, profesional):
    with mock.patch("apps.agenda.admin.crear_bloqueo", wraps=crear_bloqueo) as servicio:
        respuesta = _enviar_admin(cliente_admin, profesional, _h(9), _h(12), "Trámite")
    assert respuesta.status_code == 302, respuesta.content.decode()
    servicio.assert_called_once()
    bloqueo = BloqueoHorario.objects.get()
    assert (bloqueo.profesional, bloqueo.inicio, bloqueo.fin) == (profesional, _h(9), _h(12))
    assert bloqueo.motivo == "Trámite"
    # El historial del admin apunta al bloqueo que creó el servicio.
    assert LogEntry.objects.get().object_id == str(bloqueo.pk)


def test_el_admin_vence_los_pagos_atrasados_antes_de_bloquear(cliente_admin, profesional):
    """Antes el formulario validaba solo: una cita impaga y vencida impedía el bloqueo."""
    cita = CitaFactory(profesional=profesional, inicio=_h(10), estado=Cita.Estado.PENDIENTE_PAGO)
    Pago.objects.create(
        cita=cita,
        monto=cita.precio,
        orden_compra="ORDEN-ADMIN-1",
        vence_en=timezone.now() - timedelta(minutes=1),
    )
    respuesta = _enviar_admin(cliente_admin, profesional, _h(9), _h(12))
    assert respuesta.status_code == 302, respuesta.content.decode()
    assert BloqueoHorario.objects.count() == 1
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CANCELADA


def test_el_admin_muestra_en_el_formulario_el_rechazo_del_servicio(cliente_admin, profesional):
    CitaFactory(profesional=profesional, inicio=_h(10))
    respuesta = _enviar_admin(cliente_admin, profesional, _h(9), _h(12))
    assert respuesta.status_code == 200
    assert "Cancélalas o reagéndalas" in str(respuesta.context["adminform"].form.errors)
    assert not BloqueoHorario.objects.exists()


def test_el_admin_explica_que_el_fin_va_despues_del_inicio(cliente_admin, profesional):
    respuesta = _enviar_admin(cliente_admin, profesional, _h(12), _h(9))
    assert respuesta.status_code == 200
    assert "Debe ser posterior al inicio." in str(respuesta.context["adminform"].form.errors)
    assert not BloqueoHorario.objects.exists()


def test_el_admin_no_edita_bloqueos(cliente_admin, profesional):
    bloqueo = BloqueoHorarioFactory(profesional=profesional)
    url = f"/admin/agenda/bloqueohorario/{bloqueo.pk}/change/"
    assert cliente_admin.post(url, {"profesional": profesional.pk}).status_code == 403
    assert cliente_admin.get(url).status_code == 200  # se puede ver (y borrar), no cambiar
