from datetime import timedelta
from uuid import uuid4

import pytest
from django.utils import timezone

from apps.agenda.models import Cita
from apps.auditoria.models import RegistroAuditoria
from apps.cuentas.tests.factories import CLAVE, PacienteFactory, ProfesionalFactory

from .factories import INICIO_BASE, CitaFactory, DisponibilidadFactory

pytestmark = pytest.mark.django_db

CITAS = "/api/citas/"
ONCE = INICIO_BASE + timedelta(hours=2)


@pytest.fixture(autouse=True)
def reglas_de_agenda(settings):
    settings.AGENDA_ANTICIPACION_MIN_HORAS = 24
    # La API usa la hora real: el horizonte se amplía para llegar al lunes de las pruebas.
    settings.AGENDA_HORIZONTE_DIAS = 3650
    settings.AGENDA_CANCELACION_MIN_HORAS = 24


@pytest.fixture
def cita():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    return CitaFactory(profesional=profesional)


def _entrar(cliente, usuario):
    cliente.post("/api/auth/login/", {"email": usuario.email, "password": CLAVE}, format="json")


def _url(cita):
    return f"{CITAS}{cita.pk}/reagendar/"


def _mover(cliente, cita, inicio=ONCE):
    return cliente.post(_url(cita), {"inicio": inicio.isoformat()}, format="json")


def _inicio(cita):
    cita.refresh_from_db()
    return cita.inicio


def test_reagendar_exige_sesion(api_client, cita):
    assert _mover(api_client, cita).status_code == 403


def test_el_paciente_reagenda_su_cita(api_client, cita):
    _entrar(api_client, cita.paciente.usuario)
    respuesta = _mover(api_client, cita)
    assert respuesta.status_code == 200
    datos = respuesta.json()
    assert datos["id"] == str(cita.pk)
    assert datos["inicio"][11:16] == "11:00"
    assert datos["fin"][11:16] == "11:45"
    assert datos["estado"] == "confirmada"
    assert _inicio(cita) == ONCE


def test_el_profesional_reagenda_una_cita_de_su_agenda(api_client, cita):
    _entrar(api_client, cita.profesional.usuario)
    assert _mover(api_client, cita).status_code == 200
    assert _inicio(cita) == ONCE


@pytest.mark.parametrize("factory", [PacienteFactory, ProfesionalFactory])
def test_un_tercero_recibe_404_y_la_cita_sigue_igual(api_client, cita, factory):
    _entrar(api_client, factory().usuario)
    assert _mover(api_client, cita).status_code == 404
    assert _inicio(cita) == INICIO_BASE


def test_una_cita_inexistente_responde_404(api_client):
    _entrar(api_client, PacienteFactory().usuario)
    respuesta = api_client.post(f"{CITAS}{uuid4()}/reagendar/", {"inicio": ONCE.isoformat()})
    assert respuesta.status_code == 404


def test_un_horario_no_disponible_responde_400(api_client, cita):
    _entrar(api_client, cita.paciente.usuario)
    respuesta = _mover(api_client, cita, inicio=ONCE + timedelta(minutes=30))
    assert respuesta.status_code == 400
    assert "inicio" in respuesta.json()
    assert _inicio(cita) == INICIO_BASE


def test_el_paciente_no_reagenda_con_menos_de_24_horas(api_client):
    profesional = ProfesionalFactory()
    cita = CitaFactory(profesional=profesional, inicio=timezone.now() + timedelta(hours=10))
    _entrar(api_client, cita.paciente.usuario)
    respuesta = _mover(api_client, cita)
    assert respuesta.status_code == 400
    assert "24 horas" in str(respuesta.json())


def test_reagendar_exige_el_nuevo_inicio(api_client, cita):
    _entrar(api_client, cita.paciente.usuario)
    respuesta = api_client.post(_url(cita), {}, format="json")
    assert respuesta.status_code == 400
    assert "inicio" in respuesta.json()


def test_reagendar_solo_acepta_post(api_client, cita):
    _entrar(api_client, cita.paciente.usuario)
    assert api_client.get(_url(cita)).status_code == 405


def test_la_api_registra_la_ip_en_la_auditoria(api_client, cita):
    _entrar(api_client, cita.paciente.usuario)
    respuesta = api_client.post(
        _url(cita), {"inicio": ONCE.isoformat()}, format="json", REMOTE_ADDR="10.0.0.9"
    )
    assert respuesta.status_code == 200
    registro = RegistroAuditoria.objects.get(accion=RegistroAuditoria.Accion.REAGENDAR_CITA)
    assert registro.recurso_id == cita.pk
    assert registro.ip == "10.0.0.9"
    assert Cita.objects.count() == 1
