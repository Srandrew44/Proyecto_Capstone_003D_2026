from datetime import timedelta

import pytest
from django.utils import timezone

from apps.agenda.models import Cita
from apps.cuentas.tests.factories import CLAVE, ProfesionalFactory

from .factories import INICIO_BASE, CitaFactory

pytestmark = pytest.mark.django_db

AGENDA = "/api/agenda-del-dia/"


def _entrar(cliente, usuario):
    cliente.post("/api/auth/login/", {"email": usuario.email, "password": CLAVE}, format="json")


def _inasistencia(cliente, cita):
    return cliente.post(f"/api/citas/{cita.pk}/inasistencia/")


def test_la_agenda_del_dia_muestra_al_paciente(api_client):
    cita = CitaFactory()
    CitaFactory(profesional=cita.profesional, inicio=INICIO_BASE + timedelta(days=1))
    _entrar(api_client, cita.profesional.usuario)
    respuesta = api_client.get(AGENDA, {"fecha": INICIO_BASE.date().isoformat()})
    assert respuesta.status_code == 200
    datos = respuesta.json()
    assert datos["fecha"] == "2030-01-07"
    assert len(datos["citas"]) == 1
    usuario = cita.paciente.usuario
    assert datos["citas"][0]["paciente"] == str(cita.paciente.pk)
    assert datos["citas"][0]["paciente_nombre"] == f"{usuario.nombre} {usuario.apellido}"
    assert datos["citas"][0]["tiene_atencion"] is False


def test_sin_fecha_muestra_el_dia_de_hoy(api_client):
    profesional = ProfesionalFactory()
    _entrar(api_client, profesional.usuario)
    datos = api_client.get(AGENDA).json()
    assert datos["fecha"] == timezone.localdate().isoformat()


def test_la_agenda_del_dia_es_solo_para_profesionales(api_client):
    cita = CitaFactory()
    _entrar(api_client, cita.paciente.usuario)
    assert api_client.get(AGENDA).status_code == 403


def test_una_fecha_mal_escrita_responde_400(api_client):
    _entrar(api_client, ProfesionalFactory().usuario)
    assert api_client.get(AGENDA, {"fecha": "07-01-2030"}).status_code == 400


def test_el_profesional_marca_la_inasistencia(api_client):
    cita = CitaFactory(inicio=timezone.now() - timedelta(minutes=30))
    _entrar(api_client, cita.profesional.usuario)
    respuesta = _inasistencia(api_client, cita)
    assert respuesta.status_code == 200
    assert respuesta.json()["estado"] == "no_asistio"


def test_la_inasistencia_de_una_cita_futura_responde_400(api_client):
    cita = CitaFactory()
    _entrar(api_client, cita.profesional.usuario)
    assert _inasistencia(api_client, cita).status_code == 400
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CONFIRMADA


def test_otro_profesional_recibe_404(api_client):
    cita = CitaFactory(inicio=timezone.now() - timedelta(minutes=30))
    _entrar(api_client, ProfesionalFactory().usuario)
    assert _inasistencia(api_client, cita).status_code == 404


def test_el_paciente_no_marca_la_inasistencia(api_client):
    cita = CitaFactory(inicio=timezone.now() - timedelta(minutes=30))
    _entrar(api_client, cita.paciente.usuario)
    assert _inasistencia(api_client, cita).status_code == 403
