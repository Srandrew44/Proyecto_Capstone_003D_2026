from datetime import timedelta

import pytest
from django.contrib.auth.models import AnonymousUser
from django.db import IntegrityError, transaction
from django.db.models import ProtectedError

from apps.agenda.models import Cita
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory

from .factories import INICIO_BASE, CitaFactory, TratamientoFactory

pytestmark = pytest.mark.django_db


def hora(minutos: int):
    """Instante `minutos` después del inicio base (lunes 09:00)."""
    return INICIO_BASE + timedelta(minutes=minutos)


def test_una_cita_nueva_queda_confirmada():
    cita = CitaFactory()
    assert cita.estado == Cita.Estado.CONFIRMADA
    assert cita.cancelada_en is None
    assert cita.creada_en is not None


def test_str_muestra_paciente_profesional_y_hora_local():
    cita = CitaFactory(inicio=hora(0))
    assert str(cita) == f"{cita.paciente} con {cita.profesional} el 07/01/2030 09:00"


def test_las_citas_se_ordenan_por_inicio():
    tarde = CitaFactory(inicio=hora(120))
    temprano = CitaFactory(inicio=hora(0))
    assert list(Cita.objects.all()) == [temprano, tarde]


def test_es_de_reconoce_al_paciente_y_al_profesional():
    cita = CitaFactory()
    assert cita.es_de(cita.paciente.usuario)
    assert cita.es_de(cita.profesional.usuario)


def test_es_de_rechaza_a_otros_y_a_anonimos():
    cita = CitaFactory()
    assert not cita.es_de(PacienteFactory().usuario)
    assert not cita.es_de(ProfesionalFactory().usuario)
    assert not cita.es_de(AnonymousUser())


# --- No solapamiento por profesional ---


@pytest.mark.parametrize("desplazamiento", [-30, 0, 30])
def test_citas_cruzadas_del_mismo_profesional_se_rechazan(desplazamiento):
    profesional = ProfesionalFactory()
    CitaFactory(profesional=profesional, inicio=hora(0))
    with pytest.raises(IntegrityError), transaction.atomic():
        CitaFactory(profesional=profesional, inicio=hora(desplazamiento))


def test_citas_contiguas_del_mismo_profesional_se_permiten():
    # La base solo impide el cruce directo; la pausa de 15 min la exige el servicio.
    profesional = ProfesionalFactory()
    CitaFactory(profesional=profesional, inicio=hora(0))
    CitaFactory(profesional=profesional, inicio=hora(45))
    assert profesional.citas.count() == 2


def test_el_mismo_horario_con_otro_profesional_se_permite():
    CitaFactory(inicio=hora(0))
    CitaFactory(inicio=hora(0))
    assert Cita.objects.count() == 2


@pytest.mark.parametrize(
    "estado",
    [
        Cita.Estado.AGENDADA,
        Cita.Estado.CONFIRMADA,
        Cita.Estado.REALIZADA,
        Cita.Estado.NO_ASISTIO,
    ],
)
def test_las_citas_no_canceladas_ocupan_el_horario_del_profesional(estado):
    profesional = ProfesionalFactory()
    CitaFactory(profesional=profesional, inicio=hora(0), estado=estado)
    with pytest.raises(IntegrityError), transaction.atomic():
        CitaFactory(profesional=profesional, inicio=hora(30))


def test_una_cita_cancelada_libera_el_horario_del_profesional():
    profesional = ProfesionalFactory()
    CitaFactory(profesional=profesional, inicio=hora(0), estado=Cita.Estado.CANCELADA)
    CitaFactory(profesional=profesional, inicio=hora(0))
    assert profesional.citas.count() == 2


# --- No solapamiento por paciente ---


def test_un_paciente_no_puede_tener_dos_citas_cruzadas_con_distintos_profesionales():
    paciente = PacienteFactory()
    CitaFactory(paciente=paciente, inicio=hora(0))
    with pytest.raises(IntegrityError), transaction.atomic():
        CitaFactory(paciente=paciente, inicio=hora(30))


def test_un_paciente_puede_reservar_sobre_una_cita_suya_cancelada():
    paciente = PacienteFactory()
    CitaFactory(paciente=paciente, inicio=hora(0), estado=Cita.Estado.CANCELADA)
    CitaFactory(paciente=paciente, inicio=hora(0))
    assert paciente.citas.count() == 2


# --- Otras reglas del modelo ---


@pytest.mark.parametrize("desplazamiento", [0, -30])
def test_el_fin_debe_ser_posterior_al_inicio(desplazamiento):
    with pytest.raises(IntegrityError), transaction.atomic():
        CitaFactory(inicio=hora(0), fin=hora(desplazamiento))


@pytest.mark.parametrize("relacion", ["paciente", "profesional", "tratamiento"])
def test_no_se_borra_lo_que_tiene_citas(relacion):
    cita = CitaFactory()
    with pytest.raises(ProtectedError):
        getattr(cita, relacion).delete()


def test_el_precio_de_la_cita_no_cambia_si_cambia_el_del_tratamiento():
    cita = CitaFactory(tratamiento=TratamientoFactory(precio=25000))
    cita.tratamiento.precio = 30000
    cita.tratamiento.save()
    cita.refresh_from_db()
    assert cita.precio == 25000
