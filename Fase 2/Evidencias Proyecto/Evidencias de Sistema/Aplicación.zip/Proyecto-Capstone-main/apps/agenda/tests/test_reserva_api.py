from datetime import timedelta

import pytest

from apps.agenda.models import Cita
from apps.clinica.tests.factories import ConsentimientoFactory
from apps.cuentas.tests.factories import CLAVE, PacienteFactory, ProfesionalFactory

from .factories import INICIO_BASE, CitaFactory, DisponibilidadFactory, TratamientoFactory

pytestmark = pytest.mark.django_db

PROFESIONALES = "/api/profesionales/"
HORARIOS = "/api/horarios-libres/"
CITAS = "/api/citas/"
LUNES = INICIO_BASE.date().isoformat()


@pytest.fixture(autouse=True)
def reglas_de_reserva(settings):
    settings.AGENDA_ANTICIPACION_MIN_HORAS = 24
    # La API usa la hora real: el horizonte se amplía para llegar al lunes de las pruebas.
    settings.AGENDA_HORIZONTE_DIAS = 3650


@pytest.fixture
def profesional():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    return profesional


@pytest.fixture
def paciente():
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente)
    return paciente


@pytest.fixture
def tratamiento():
    return TratamientoFactory(duracion_min=45, precio=25000)


def _entrar(cliente, usuario):
    cliente.post("/api/auth/login/", {"email": usuario.email, "password": CLAVE}, format="json")


def _cuerpo(profesional, tratamiento, inicio=INICIO_BASE, **extra):
    return {
        "profesional": str(profesional.pk),
        "tratamiento": str(tratamiento.pk),
        "inicio": inicio.isoformat(),
        **extra,
    }


def _horarios(cliente, profesional, tratamiento, **parametros):
    consulta = {"profesional": str(profesional.pk), "tratamiento": str(tratamiento.pk)}
    return cliente.get(HORARIOS, {**consulta, **parametros})


# --- profesionales ---


def test_profesionales_exige_sesion(api_client):
    assert api_client.get(PROFESIONALES).status_code == 403


def test_profesionales_lista_solo_activos_con_horario_sin_datos_internos(api_client, paciente):
    for apellido, nombre in (("Zamora", "Ana"), ("Araya", "Beto")):
        DisponibilidadFactory(
            profesional=ProfesionalFactory(usuario__apellido=apellido, usuario__nombre=nombre)
        )
    DisponibilidadFactory(
        profesional=ProfesionalFactory(usuario__apellido="Inactivo", usuario__is_active=False)
    )
    # Sin horario (p. ej. recién creado en el admin): con él no hay horas que reservar.
    ProfesionalFactory(usuario__apellido="Nuevo")
    DisponibilidadFactory(profesional=ProfesionalFactory(usuario__apellido="Pausado"), activa=False)
    _entrar(api_client, paciente.usuario)
    respuesta = api_client.get(PROFESIONALES)
    assert respuesta.status_code == 200
    assert [p["apellido"] for p in respuesta.json()] == ["Araya", "Zamora"]
    assert set(respuesta.json()[0]) == {"id", "nombre", "apellido", "especialidad"}


# --- horarios libres ---


def test_horarios_exige_sesion(api_client, profesional, tratamiento):
    assert _horarios(api_client, profesional, tratamiento).status_code == 403


def test_horarios_lista_los_inicios_del_dia(api_client, paciente, profesional, tratamiento):
    _entrar(api_client, paciente.usuario)
    respuesta = _horarios(api_client, profesional, tratamiento, desde=LUNES, hasta=LUNES)
    assert respuesta.status_code == 200
    horas = [h[11:16] for h in respuesta.json()["horarios"]]
    assert horas == ["09:00", "10:00", "11:00", "12:00"]


def test_horarios_no_ofrece_lo_ya_reservado(api_client, paciente, profesional, tratamiento):
    CitaFactory(profesional=profesional, tratamiento=tratamiento)
    _entrar(api_client, paciente.usuario)
    respuesta = _horarios(api_client, profesional, tratamiento, desde=LUNES, hasta=LUNES)
    assert [h[11:16] for h in respuesta.json()["horarios"]][0] == "10:00"


def test_horarios_sin_fechas_responde_la_semana_siguiente(
    api_client, paciente, profesional, tratamiento
):
    _entrar(api_client, paciente.usuario)
    respuesta = _horarios(api_client, profesional, tratamiento)
    assert respuesta.status_code == 200
    assert isinstance(respuesta.json()["horarios"], list)


def test_horarios_exige_profesional_y_tratamiento(api_client, paciente):
    _entrar(api_client, paciente.usuario)
    respuesta = api_client.get(HORARIOS)
    assert respuesta.status_code == 400
    assert {"profesional", "tratamiento"} <= set(respuesta.json())


def test_horarios_rechaza_un_tratamiento_inactivo(api_client, paciente, profesional):
    inactivo = TratamientoFactory(activo=False)
    _entrar(api_client, paciente.usuario)
    assert _horarios(api_client, profesional, inactivo).status_code == 400


def test_horarios_rechaza_un_profesional_inactivo(api_client, paciente, tratamiento):
    inactivo = ProfesionalFactory(usuario__is_active=False)
    _entrar(api_client, paciente.usuario)
    assert _horarios(api_client, inactivo, tratamiento).status_code == 400


def test_horarios_rechaza_identificadores_mal_formados(api_client, paciente, tratamiento):
    _entrar(api_client, paciente.usuario)
    respuesta = api_client.get(HORARIOS, {"profesional": "no-es-un-uuid", "tratamiento": "x"})
    assert respuesta.status_code == 400


def test_horarios_rechaza_fechas_pasadas(api_client, paciente, profesional, tratamiento):
    _entrar(api_client, paciente.usuario)
    respuesta = _horarios(api_client, profesional, tratamiento, desde="2000-01-03")
    assert respuesta.status_code == 400
    assert "desde" in respuesta.json()


def test_horarios_rechaza_un_rango_invertido(api_client, paciente, profesional, tratamiento):
    _entrar(api_client, paciente.usuario)
    respuesta = _horarios(api_client, profesional, tratamiento, desde=LUNES, hasta="2029-12-01")
    assert respuesta.status_code == 400
    assert "hasta" in respuesta.json()


def test_horarios_rechaza_un_rango_demasiado_largo(api_client, paciente, profesional, tratamiento):
    _entrar(api_client, paciente.usuario)
    hasta = (INICIO_BASE + timedelta(days=40)).date().isoformat()
    respuesta = _horarios(api_client, profesional, tratamiento, desde=LUNES, hasta=hasta)
    assert respuesta.status_code == 400


# --- reservar ---


def test_reservar_exige_sesion(api_client, profesional, tratamiento):
    assert (
        api_client.post(CITAS, _cuerpo(profesional, tratamiento), format="json").status_code == 403
    )


def test_el_profesional_no_puede_reservar(api_client, profesional, tratamiento):
    _entrar(api_client, profesional.usuario)
    respuesta = api_client.post(CITAS, _cuerpo(profesional, tratamiento), format="json")
    assert respuesta.status_code == 403
    assert Cita.objects.count() == 0


def test_el_paciente_reserva_una_cita(api_client, paciente, profesional, tratamiento):
    _entrar(api_client, paciente.usuario)
    cuerpo = _cuerpo(profesional, tratamiento, comentarios_paciente="Dolor al caminar")
    respuesta = api_client.post(CITAS, cuerpo, format="json")
    assert respuesta.status_code == 201
    datos = respuesta.json()
    assert datos["estado"] == "confirmada"
    assert datos["precio"] == 25000
    assert datos["profesional"] == str(profesional.pk)
    assert datos["tratamiento"] == str(tratamiento.pk)
    assert datos["tratamiento_nombre"] == tratamiento.nombre
    assert datos["comentarios_paciente"] == "Dolor al caminar"
    assert datos["inicio"][11:16] == "09:00"
    assert datos["fin"][11:16] == "09:45"
    cita = Cita.objects.get()
    assert cita.paciente_id == paciente.pk


def test_el_paciente_sale_de_la_sesion_y_no_del_cuerpo(
    api_client, paciente, profesional, tratamiento
):
    otro = PacienteFactory()
    _entrar(api_client, paciente.usuario)
    cuerpo = _cuerpo(profesional, tratamiento, paciente=str(otro.pk))
    assert api_client.post(CITAS, cuerpo, format="json").status_code == 201
    assert Cita.objects.get().paciente_id == paciente.pk


def test_reservar_sin_consentimiento_responde_403(api_client, profesional, tratamiento):
    sin_consentimiento = PacienteFactory()
    _entrar(api_client, sin_consentimiento.usuario)
    respuesta = api_client.post(CITAS, _cuerpo(profesional, tratamiento), format="json")
    assert respuesta.status_code == 403
    assert "consentimiento" in respuesta.json()["detail"]
    assert Cita.objects.count() == 0


def test_reservar_un_horario_no_ofrecido_responde_400(
    api_client, paciente, profesional, tratamiento
):
    _entrar(api_client, paciente.usuario)
    cuerpo = _cuerpo(profesional, tratamiento, inicio=INICIO_BASE + timedelta(minutes=30))
    respuesta = api_client.post(CITAS, cuerpo, format="json")
    assert respuesta.status_code == 400
    assert "inicio" in respuesta.json()


def test_dos_pacientes_no_reservan_el_mismo_horario(api_client, paciente, profesional, tratamiento):
    CitaFactory(profesional=profesional, tratamiento=tratamiento)
    _entrar(api_client, paciente.usuario)
    respuesta = api_client.post(CITAS, _cuerpo(profesional, tratamiento), format="json")
    assert respuesta.status_code == 400
    assert Cita.objects.count() == 1


def test_reservar_exige_los_campos_obligatorios(api_client, paciente):
    _entrar(api_client, paciente.usuario)
    respuesta = api_client.post(CITAS, {}, format="json")
    assert respuesta.status_code == 400
    assert {"profesional", "tratamiento", "inicio"} <= set(respuesta.json())


def test_reservar_con_profesional_inactivo_responde_400(api_client, paciente, tratamiento):
    inactivo = ProfesionalFactory(usuario__is_active=False)
    DisponibilidadFactory(profesional=inactivo)
    _entrar(api_client, paciente.usuario)
    respuesta = api_client.post(CITAS, _cuerpo(inactivo, tratamiento), format="json")
    assert respuesta.status_code == 400
    assert "profesional" in respuesta.json()


# --- mis citas ---


def test_mis_citas_exige_sesion(api_client):
    assert api_client.get(CITAS).status_code == 403


def test_el_paciente_solo_ve_sus_citas(api_client, paciente, profesional, tratamiento):
    propia = CitaFactory(paciente=paciente, profesional=profesional, tratamiento=tratamiento)
    CitaFactory(inicio=INICIO_BASE + timedelta(days=7))
    _entrar(api_client, paciente.usuario)
    respuesta = api_client.get(CITAS)
    assert respuesta.status_code == 200
    assert [c["id"] for c in respuesta.json()] == [str(propia.pk)]


def test_el_profesional_solo_ve_sus_citas(api_client, profesional, tratamiento):
    propia = CitaFactory(profesional=profesional, tratamiento=tratamiento)
    CitaFactory(inicio=INICIO_BASE + timedelta(days=7))
    _entrar(api_client, profesional.usuario)
    assert [c["id"] for c in api_client.get(CITAS).json()] == [str(propia.pk)]


def test_las_citas_no_exponen_datos_del_paciente(api_client, paciente, profesional, tratamiento):
    CitaFactory(paciente=paciente, profesional=profesional, tratamiento=tratamiento)
    _entrar(api_client, profesional.usuario)
    cita = api_client.get(CITAS).json()[0]
    assert not {"paciente", "rut", "direccion", "telefono_contacto"} & set(cita)
