from datetime import timedelta

import pytest
from django.core.exceptions import ValidationError

from apps.agenda.models import Cita
from apps.agenda.services import reservar_cita
from apps.clinica.services import ConsentimientoRequerido
from apps.clinica.tests.factories import ConsentimientoFactory
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory

from .factories import INICIO_BASE, CitaFactory, DisponibilidadFactory, TratamientoFactory

pytestmark = pytest.mark.django_db

AHORA = INICIO_BASE - timedelta(days=3)  # con tiempo de sobra para la anticipación mínima


@pytest.fixture(autouse=True)
def reglas_de_reserva(settings):
    settings.AGENDA_ANTICIPACION_MIN_HORAS = 24
    settings.AGENDA_HORIZONTE_DIAS = 30


@pytest.fixture
def profesional():
    """Profesional con pausa de 15 min y un tramo los lunes de 09:00 a 13:00."""
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    return profesional


@pytest.fixture
def paciente():
    """Paciente que ya aceptó el consentimiento de tratamiento de datos."""
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente)
    return paciente


@pytest.fixture
def tratamiento():
    return TratamientoFactory(duracion_min=45, precio=25000)


def _reservar(paciente, profesional, tratamiento, inicio=INICIO_BASE, ahora=AHORA, **extra):
    return reservar_cita(
        paciente=paciente,
        profesional=profesional,
        tratamiento=tratamiento,
        inicio=inicio,
        ahora=ahora,
        **extra,
    )


def test_reserva_una_cita_confirmada(paciente, profesional, tratamiento):
    cita = _reservar(paciente, profesional, tratamiento)
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CONFIRMADA
    assert cita.paciente == paciente
    assert cita.profesional == profesional
    assert cita.tratamiento == tratamiento
    assert cita.inicio == INICIO_BASE
    assert cita.fin == INICIO_BASE + timedelta(minutes=45)


def test_copia_el_precio_y_no_cambia_si_el_tratamiento_cambia(paciente, profesional, tratamiento):
    cita = _reservar(paciente, profesional, tratamiento)
    tratamiento.precio = 99000
    tratamiento.save()
    cita.refresh_from_db()
    assert cita.precio == 25000


def test_guarda_los_comentarios_del_paciente(paciente, profesional, tratamiento):
    cita = _reservar(paciente, profesional, tratamiento, comentarios_paciente="Uña encarnada")
    assert cita.comentarios_paciente == "Uña encarnada"


def test_exige_consentimiento_de_tratamiento_de_datos(profesional, tratamiento):
    sin_consentimiento = PacienteFactory()
    with pytest.raises(ConsentimientoRequerido):
        _reservar(sin_consentimiento, profesional, tratamiento)
    assert Cita.objects.count() == 0


def test_un_consentimiento_revocado_no_sirve(profesional, tratamiento):
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente, revocado_en=AHORA + timedelta(days=1))
    with pytest.raises(ConsentimientoRequerido):
        _reservar(paciente, profesional, tratamiento)


def test_rechaza_un_tratamiento_inactivo(paciente, profesional):
    inactivo = TratamientoFactory(activo=False)
    with pytest.raises(ValidationError) as error:
        _reservar(paciente, profesional, inactivo)
    assert "tratamiento" in error.value.message_dict


def test_rechaza_un_profesional_inactivo(paciente, tratamiento):
    profesional = ProfesionalFactory(usuario__is_active=False)
    DisponibilidadFactory(profesional=profesional)
    with pytest.raises(ValidationError) as error:
        _reservar(paciente, profesional, tratamiento)
    assert "profesional" in error.value.message_dict


def test_rechaza_un_horario_que_no_se_ofrece(paciente, profesional, tratamiento):
    media_hora_despues = INICIO_BASE + timedelta(minutes=30)
    with pytest.raises(ValidationError) as error:
        _reservar(paciente, profesional, tratamiento, inicio=media_hora_despues)
    assert "inicio" in error.value.message_dict
    assert Cita.objects.count() == 0


def test_rechaza_un_horario_fuera_del_tramo(paciente, profesional, tratamiento):
    tarde = INICIO_BASE.replace(hour=15)
    with pytest.raises(ValidationError):
        _reservar(paciente, profesional, tratamiento, inicio=tarde)


def test_rechaza_un_horario_ya_reservado(profesional, tratamiento, paciente):
    CitaFactory(profesional=profesional, tratamiento=tratamiento)
    with pytest.raises(ValidationError) as error:
        _reservar(paciente, profesional, tratamiento)
    assert "inicio" in error.value.message_dict
    assert Cita.objects.count() == 1


def test_respeta_la_pausa_entre_citas(paciente, profesional, tratamiento):
    _reservar(paciente, profesional, tratamiento)
    otro = PacienteFactory()
    ConsentimientoFactory(paciente=otro)
    # La primera cita termina 09:45: con la pausa de 15 min el siguiente horario es 10:00.
    with pytest.raises(ValidationError):
        _reservar(otro, profesional, tratamiento, inicio=INICIO_BASE + timedelta(minutes=45))
    cita = _reservar(otro, profesional, tratamiento, inicio=INICIO_BASE + timedelta(minutes=60))
    assert cita.inicio == INICIO_BASE + timedelta(minutes=60)


def test_exige_24_horas_de_anticipacion(paciente, profesional, tratamiento):
    ahora = INICIO_BASE - timedelta(hours=23)
    with pytest.raises(ValidationError):
        _reservar(paciente, profesional, tratamiento, ahora=ahora)


def test_acepta_justo_24_horas_antes(paciente, profesional, tratamiento):
    cita = _reservar(paciente, profesional, tratamiento, ahora=INICIO_BASE - timedelta(hours=24))
    assert cita.inicio == INICIO_BASE


def test_no_reserva_mas_alla_del_horizonte(paciente, profesional, tratamiento):
    ahora = INICIO_BASE - timedelta(days=40)
    with pytest.raises(ValidationError):
        _reservar(paciente, profesional, tratamiento, ahora=ahora)


def test_un_paciente_no_puede_tener_dos_citas_cruzadas(paciente, tratamiento):
    uno = ProfesionalFactory()
    otro = ProfesionalFactory()
    DisponibilidadFactory(profesional=uno)
    DisponibilidadFactory(profesional=otro)
    _reservar(paciente, uno, tratamiento)
    with pytest.raises(ValidationError) as error:
        _reservar(paciente, otro, tratamiento)
    assert "Ya tienes una cita" in error.value.message_dict["inicio"][0]
    assert Cita.objects.count() == 1


def test_el_mismo_horario_sirve_con_otro_profesional(paciente, tratamiento):
    uno = ProfesionalFactory()
    otro = ProfesionalFactory()
    DisponibilidadFactory(profesional=uno)
    DisponibilidadFactory(profesional=otro)
    otro_paciente = PacienteFactory()
    ConsentimientoFactory(paciente=otro_paciente)
    _reservar(paciente, uno, tratamiento)
    _reservar(otro_paciente, otro, tratamiento)
    assert Cita.objects.count() == 2


def test_una_cita_cancelada_libera_el_horario(paciente, profesional, tratamiento):
    CitaFactory(profesional=profesional, tratamiento=tratamiento, estado=Cita.Estado.CANCELADA)
    cita = _reservar(paciente, profesional, tratamiento)
    assert cita.estado == Cita.Estado.CONFIRMADA


def test_exige_una_hora_con_zona_horaria(paciente, profesional, tratamiento):
    ingenua = INICIO_BASE.replace(tzinfo=None)
    with pytest.raises(ValueError):
        _reservar(paciente, profesional, tratamiento, inicio=ingenua)
