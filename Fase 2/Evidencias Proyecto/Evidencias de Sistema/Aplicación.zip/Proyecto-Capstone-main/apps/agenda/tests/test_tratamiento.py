import pytest
from django.contrib import admin
from django.db import IntegrityError, transaction

from apps.agenda.admin import TratamientoAdmin
from apps.agenda.models import Tratamiento

from .factories import TratamientoFactory

pytestmark = pytest.mark.django_db


def test_str_es_el_nombre():
    assert str(TratamientoFactory(nombre="Quiropodia")) == "Quiropodia"


def test_el_nombre_es_unico():
    TratamientoFactory(nombre="Quiropodia")
    with pytest.raises(IntegrityError), transaction.atomic():
        TratamientoFactory(nombre="Quiropodia")


@pytest.mark.parametrize("duracion", [0])
def test_la_duracion_debe_ser_positiva(duracion):
    with pytest.raises(IntegrityError), transaction.atomic():
        TratamientoFactory(duracion_min=duracion)


def test_el_precio_no_puede_ser_negativo():
    with pytest.raises(IntegrityError), transaction.atomic():
        TratamientoFactory(precio=-1)


def test_precio_cero_es_valido():
    assert TratamientoFactory(precio=0).precio == 0


def test_nuevo_tratamiento_esta_activo_por_defecto():
    tratamiento = Tratamiento.objects.create(nombre="Reflexología", duracion_min=30, precio=20000)
    assert tratamiento.activo


def test_el_admin_no_permite_borrar(rf):
    model_admin = TratamientoAdmin(Tratamiento, admin.site)
    assert model_admin.has_delete_permission(rf.get("/")) is False
