"""Topes por paciente al reservar: nadie puede retener la agenda reservando sin pagar."""

from datetime import timedelta

import pytest
from django.core.exceptions import ValidationError

from apps.agenda.horarios import horarios_libres
from apps.agenda.models import Cita
from apps.agenda.services import reservar_cita
from apps.clinica.tests.factories import ConsentimientoFactory
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory

from .factories import INICIO_BASE, CitaFactory, DisponibilidadFactory, TratamientoFactory

pytestmark = pytest.mark.django_db

AHORA = INICIO_BASE - timedelta(days=3)


@pytest.fixture(autouse=True)
def reglas(settings):
    settings.AGENDA_ANTICIPACION_MIN_HORAS = 24
    settings.AGENDA_HORIZONTE_DIAS = 30
    settings.AGENDA_MAX_CITAS_FUTURAS = 3


@pytest.fixture
def profesional():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    return profesional


@pytest.fixture
def paciente():
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente)
    return paciente


@pytest.fixture
def tratamiento():
    return TratamientoFactory(duracion_min=45, precio=25000)


def _reservar(paciente, profesional, tratamiento, inicio=INICIO_BASE, ahora=AHORA):
    return reservar_cita(
        paciente=paciente,
        profesional=profesional,
        tratamiento=tratamiento,
        inicio=inicio,
        ahora=ahora,
    )


def test_un_paciente_no_retiene_toda_la_agenda_sin_pagar(
    settings, paciente, profesional, tratamiento
):
    settings.PAGOS_WEBPAY_ACTIVO = True
    dia = INICIO_BASE.date()
    libres = horarios_libres(
        profesional=profesional, tratamiento=tratamiento, desde=dia, hasta=dia, ahora=AHORA
    )
    assert len(libres) > 1
    _reservar(paciente, profesional, tratamiento, inicio=libres[0])
    with pytest.raises(ValidationError, match="Ya tienes una reserva esperando pago"):
        _reservar(paciente, profesional, tratamiento, inicio=libres[1])
    quedan = horarios_libres(
        profesional=profesional, tratamiento=tratamiento, desde=dia, hasta=dia, ahora=AHORA
    )
    assert len(quedan) >= len(libres) - 2  # solo la hora retenida (y su pausa)


def test_la_reserva_esperando_pago_tambien_frena_con_otro_profesional(
    settings, paciente, profesional, tratamiento
):
    settings.PAGOS_WEBPAY_ACTIVO = True
    otro = ProfesionalFactory()
    DisponibilidadFactory(profesional=otro)
    _reservar(paciente, profesional, tratamiento)
    with pytest.raises(ValidationError, match="esperando pago"):
        _reservar(paciente, otro, tratamiento, inicio=INICIO_BASE + timedelta(hours=2))


def test_al_vencer_el_pago_puede_reservar_otra_hora(settings, paciente, profesional, tratamiento):
    settings.PAGOS_WEBPAY_ACTIVO = True
    settings.PAGOS_PLAZO_MIN = 15
    primera = _reservar(paciente, profesional, tratamiento)
    despues = AHORA + timedelta(minutes=16)
    segunda = _reservar(
        paciente, profesional, tratamiento, inicio=INICIO_BASE + timedelta(hours=2), ahora=despues
    )
    primera.refresh_from_db()
    assert primera.estado == Cita.Estado.CANCELADA
    assert segunda.estado == Cita.Estado.PENDIENTE_PAGO


def test_tope_de_citas_futuras_por_paciente(paciente, profesional, tratamiento):
    for semana in range(1, 4):
        CitaFactory(
            paciente=paciente,
            tratamiento=tratamiento,
            inicio=INICIO_BASE + timedelta(weeks=semana),
            estado=Cita.Estado.CONFIRMADA,
        )
    with pytest.raises(ValidationError, match=r"máximo de citas próximas .*\(3\)"):
        _reservar(paciente, profesional, tratamiento)
    assert not Cita.objects.filter(paciente=paciente, inicio=INICIO_BASE).exists()


def test_el_tope_no_cuenta_citas_pasadas_ni_canceladas(paciente, profesional, tratamiento):
    CitaFactory(
        paciente=paciente,
        tratamiento=tratamiento,
        inicio=AHORA - timedelta(days=7),
        estado=Cita.Estado.REALIZADA,
    )
    for semana in range(1, 3):
        CitaFactory(
            paciente=paciente,
            tratamiento=tratamiento,
            inicio=INICIO_BASE + timedelta(weeks=semana),
            estado=Cita.Estado.CANCELADA,
        )
    CitaFactory(
        paciente=paciente,
        tratamiento=tratamiento,
        inicio=INICIO_BASE + timedelta(weeks=3),
        estado=Cita.Estado.AGENDADA,
    )
    CitaFactory(
        paciente=paciente,
        tratamiento=tratamiento,
        inicio=INICIO_BASE + timedelta(weeks=4),
        estado=Cita.Estado.CONFIRMADA,
    )
    assert _reservar(paciente, profesional, tratamiento).estado == Cita.Estado.CONFIRMADA


def test_el_tope_se_configura(settings, paciente, profesional, tratamiento):
    settings.AGENDA_MAX_CITAS_FUTURAS = 1
    CitaFactory(
        paciente=paciente,
        tratamiento=tratamiento,
        inicio=INICIO_BASE + timedelta(weeks=1),
        estado=Cita.Estado.CONFIRMADA,
    )
    with pytest.raises(ValidationError, match=r"máximo de citas próximas .*\(1\)"):
        _reservar(paciente, profesional, tratamiento)
