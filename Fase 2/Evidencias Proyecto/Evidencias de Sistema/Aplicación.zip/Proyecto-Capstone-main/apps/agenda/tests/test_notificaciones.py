from datetime import timedelta
from io import StringIO
from smtplib import SMTPException

import pytest
from django.core import mail
from django.core.management import call_command

from apps.agenda import notificaciones
from apps.agenda.models import Cita, Notificacion
from apps.agenda.services import cancelar_cita, reagendar_cita, reservar_cita
from apps.clinica.tests.factories import ConsentimientoFactory
from apps.cuentas.tests.factories import CLAVE, PacienteFactory, ProfesionalFactory

from .factories import INICIO_BASE, CitaFactory, DisponibilidadFactory, TratamientoFactory

pytestmark = pytest.mark.django_db

AHORA = INICIO_BASE - timedelta(days=3)
Tipo = Notificacion.Tipo
Estado = Notificacion.Estado


@pytest.fixture(autouse=True)
def reglas(settings):
    settings.AGENDA_ANTICIPACION_MIN_HORAS = 24
    settings.AGENDA_HORIZONTE_DIAS = 30
    settings.AGENDA_CANCELACION_MIN_HORAS = 24
    settings.NOTIFICACIONES_RECORDATORIO_HORAS = 48
    settings.NOTIFICACIONES_MAX_INTENTOS = 3
    settings.CONSULTA_NOMBRE = "Podologia Central"
    settings.CONSULTA_DIRECCION = "Av. Siempre Viva 742"


@pytest.fixture
def cita():
    """Cita reservada por el servicio, con sus notificaciones."""
    profesional = ProfesionalFactory(usuario__nombre="Ana", usuario__apellido="Rojas")
    DisponibilidadFactory(profesional=profesional)
    paciente = PacienteFactory(usuario__nombre="Rosa", usuario__apellido="Pino")
    ConsentimientoFactory(paciente=paciente)
    return reservar_cita(
        paciente=paciente,
        profesional=profesional,
        tratamiento=TratamientoFactory(nombre="Tratamiento de onicomicosis"),
        inicio=INICIO_BASE,
        comentarios_paciente="Tengo hongos en la uña",
        ahora=AHORA,
    )


def _de(cita, tipo, destinatario=None):
    filtro = {"cita": cita, "tipo": tipo}
    if destinatario is not None:
        filtro["destinatario"] = destinatario
    return Notificacion.objects.filter(**filtro)


# --- programación ---


def test_la_reserva_programa_la_confirmacion_y_el_recordatorio(cita):
    confirmacion = _de(cita, Tipo.RESERVA).get()
    assert confirmacion.destinatario == cita.paciente.usuario
    assert confirmacion.estado == Estado.PENDIENTE
    assert "07/01/2030 a las 09:00" in confirmacion.asunto
    assert "Ana Rojas" in confirmacion.cuerpo
    assert "Av. Siempre Viva 742" in confirmacion.cuerpo
    recordatorio = _de(cita, Tipo.RECORDATORIO).get()
    assert recordatorio.programada_para == INICIO_BASE - timedelta(hours=48)


def test_los_correos_no_llevan_datos_clinicos(cita):
    cancelar_cita(cita=cita, usuario=cita.paciente.usuario, motivo="Me operan del pie", ahora=AHORA)
    for notificacion in Notificacion.objects.all():
        texto = notificacion.asunto + notificacion.cuerpo
        assert "onicomicosis" not in texto
        assert "hongos" not in texto
        assert "operan" not in texto


def test_sin_recordatorio_si_la_reserva_es_muy_cercana():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente)
    cita = reservar_cita(
        paciente=paciente,
        profesional=profesional,
        tratamiento=TratamientoFactory(),
        inicio=INICIO_BASE,
        ahora=INICIO_BASE - timedelta(hours=30),
    )
    assert _de(cita, Tipo.RESERVA).exists()
    assert not _de(cita, Tipo.RECORDATORIO).exists()


def test_una_reserva_rechazada_no_programa_correos():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente)
    with pytest.raises(Exception):  # noqa: B017 - basta con que se rechace
        reservar_cita(
            paciente=paciente,
            profesional=profesional,
            tratamiento=TratamientoFactory(),
            inicio=INICIO_BASE.replace(hour=15),
            ahora=AHORA,
        )
    assert not Notificacion.objects.exists()


def test_cancelar_el_paciente_avisa_a_ambos_y_anula_el_recordatorio(cita):
    cancelar_cita(cita=cita, usuario=cita.paciente.usuario, ahora=AHORA)
    assert _de(cita, Tipo.RECORDATORIO).get().estado == Estado.ANULADA
    assert "Cancelaste" in _de(cita, Tipo.CANCELACION, cita.paciente.usuario).get().cuerpo
    aviso = _de(cita, Tipo.CANCELACION, cita.profesional.usuario).get()
    assert "Rosa Pino canceló" in aviso.cuerpo


def test_cancelar_el_profesional_solo_avisa_al_paciente(cita):
    cancelar_cita(cita=cita, usuario=cita.profesional.usuario, ahora=AHORA)
    avisos = _de(cita, Tipo.CANCELACION)
    assert [a.destinatario for a in avisos] == [cita.paciente.usuario]
    assert "cancelada por la consulta" in avisos.get().cuerpo


def test_reagendar_avisa_y_reprograma_el_recordatorio(cita):
    nuevo = INICIO_BASE + timedelta(hours=2)
    reagendar_cita(cita=cita, usuario=cita.paciente.usuario, inicio=nuevo, ahora=AHORA)
    recordatorios = _de(cita, Tipo.RECORDATORIO)
    assert sorted(r.estado for r in recordatorios) == [Estado.ANULADA, Estado.PENDIENTE]
    vigente = recordatorios.get(estado=Estado.PENDIENTE)
    assert vigente.programada_para == nuevo - timedelta(hours=48)
    aviso = _de(cita, Tipo.REAGENDAMIENTO, cita.paciente.usuario).get()
    assert "09:00" in aviso.cuerpo and "11:00" in aviso.cuerpo
    assert _de(cita, Tipo.REAGENDAMIENTO, cita.profesional.usuario).exists()


def test_si_reagenda_el_profesional_no_se_avisa_a_si_mismo(cita):
    nuevo = INICIO_BASE + timedelta(hours=2)
    reagendar_cita(cita=cita, usuario=cita.profesional.usuario, inicio=nuevo, ahora=AHORA)
    assert not _de(cita, Tipo.REAGENDAMIENTO, cita.profesional.usuario).exists()


# --- envío ---


def test_envia_solo_lo_que_ya_corresponde(cita):
    resumen = notificaciones.enviar_pendientes(ahora=AHORA)
    assert resumen["enviadas"] == 1  # la confirmación; el recordatorio es para después
    assert len(mail.outbox) == 1
    correo = mail.outbox[0]
    assert correo.to == [cita.paciente.usuario.email]
    assert correo.subject.startswith("Cita confirmada")
    confirmacion = _de(cita, Tipo.RESERVA).get()
    assert confirmacion.estado == Estado.ENVIADA
    assert confirmacion.enviada_en == AHORA
    assert confirmacion.intentos == 1


def test_el_recordatorio_sale_a_su_hora(cita):
    notificaciones.enviar_pendientes(ahora=AHORA)
    resumen = notificaciones.enviar_pendientes(ahora=INICIO_BASE - timedelta(hours=47))
    assert resumen["enviadas"] == 1
    assert mail.outbox[-1].subject.startswith("Recordatorio")


def test_no_se_envia_dos_veces(cita):
    notificaciones.enviar_pendientes(ahora=AHORA)
    notificaciones.enviar_pendientes(ahora=AHORA)
    assert len(mail.outbox) == 1


@pytest.mark.parametrize(
    ("email", "ficticia"),
    [
        ("ana@example.com", True),
        ("ana@EXAMPLE.org", True),
        ("ana@consulta.test", True),
        ("ana@gmail.com", False),
        ("ana@example.com.cl", False),
    ],
)
def test_reconoce_las_direcciones_de_ejemplo(email, ficticia):
    assert notificaciones.es_direccion_ficticia(email) is ficticia


def test_con_correo_real_no_se_envia_a_direcciones_de_ejemplo(cita, settings):
    settings.NOTIFICACIONES_OMITIR_FICTICIAS = True
    resumen = notificaciones.enviar_pendientes(ahora=AHORA)
    assert resumen["anuladas"] == 1
    assert mail.outbox == []
    confirmacion = _de(cita, Tipo.RESERVA).get()
    assert confirmacion.estado == Estado.ANULADA
    assert "ejemplo" in confirmacion.error


def test_un_fallo_se_reintenta_y_luego_queda_fallida(cita, monkeypatch):
    def falla(*args, **kwargs):
        raise SMTPException("servidor caido")

    monkeypatch.setattr(notificaciones, "send_mail", falla)
    assert notificaciones.enviar_pendientes(ahora=AHORA)["reintentos"] == 1
    confirmacion = _de(cita, Tipo.RESERVA).get()
    assert confirmacion.estado == Estado.PENDIENTE
    assert confirmacion.intentos == 1
    assert "servidor caido" in confirmacion.error
    assert confirmacion.programada_para == AHORA + timedelta(minutes=5)
    notificaciones.enviar_pendientes(ahora=AHORA + timedelta(minutes=5))
    notificaciones.enviar_pendientes(ahora=AHORA + timedelta(minutes=30))
    confirmacion.refresh_from_db()
    assert confirmacion.estado == Estado.FALLIDA
    assert confirmacion.intentos == 3


def test_un_fallo_no_detiene_el_resto(cita, monkeypatch):
    otra = CitaFactory(inicio=INICIO_BASE + timedelta(days=1))
    notificaciones.notificar_reserva(otra, ahora=AHORA)
    enviados = []

    def falla_la_primera(asunto, cuerpo, remitente, destinatarios):
        if not enviados:
            enviados.append("fallo")
            raise SMTPException("una vez")
        enviados.append(destinatarios[0])

    monkeypatch.setattr(notificaciones, "send_mail", falla_la_primera)
    resumen = notificaciones.enviar_pendientes(ahora=AHORA)
    assert resumen == {"enviadas": 1, "reintentos": 1, "fallidas": 0, "anuladas": 0}


def test_el_recordatorio_de_una_cita_que_dejo_de_estar_activa_se_anula(cita):
    Cita.objects.filter(pk=cita.pk).update(estado=Cita.Estado.CANCELADA)
    resumen = notificaciones.enviar_pendientes(ahora=INICIO_BASE - timedelta(hours=47))
    assert resumen["anuladas"] == 1
    assert _de(cita, Tipo.RECORDATORIO).get().estado == Estado.ANULADA


def test_el_comando_envia_las_pendientes(cita):
    salida = StringIO()
    call_command("enviar_notificaciones", stdout=salida)
    # Con la hora real sale la confirmación; el recordatorio de la cita de 2030 todavía no.
    assert "Enviadas: 1" in salida.getvalue()
    assert len(mail.outbox) == 1


# --- API ---


def _entrar(cliente, usuario):
    cliente.post("/api/auth/login/", {"email": usuario.email, "password": CLAVE}, format="json")


def test_cada_usuario_ve_solo_sus_notificaciones(api_client, cita):
    cancelar_cita(cita=cita, usuario=cita.paciente.usuario, ahora=AHORA)
    _entrar(api_client, cita.profesional.usuario)
    datos = api_client.get("/api/notificaciones/").json()
    assert [n["tipo"] for n in datos] == ["cancelacion"]
    assert "error" not in datos[0]


def test_el_paciente_no_ve_los_recordatorios_anulados(api_client, cita):
    cancelar_cita(cita=cita, usuario=cita.paciente.usuario, ahora=AHORA)
    _entrar(api_client, cita.paciente.usuario)
    tipos = sorted(n["tipo"] for n in api_client.get("/api/notificaciones/").json())
    assert tipos == ["cancelacion", "reserva"]


def test_las_notificaciones_exigen_sesion(api_client):
    assert api_client.get("/api/notificaciones/").status_code == 403
