from datetime import timedelta

import pytest
from django.core.exceptions import ValidationError

from apps.agenda.models import Cita
from apps.agenda.services import reservar_cita
from apps.auditoria.models import RegistroAuditoria
from apps.clinica.services import ConsentimientoRequerido
from apps.clinica.tests.factories import ConsentimientoFactory
from apps.cuentas.tests.factories import CLAVE, PacienteFactory, ProfesionalFactory

from .factories import INICIO_BASE, DisponibilidadFactory, TratamientoFactory

pytestmark = pytest.mark.django_db

AHORA = INICIO_BASE - timedelta(days=3)
RESERVAR = RegistroAuditoria.Accion.RESERVAR_CITA


@pytest.fixture(autouse=True)
def reglas_de_reserva(settings):
    settings.AGENDA_ANTICIPACION_MIN_HORAS = 24
    settings.AGENDA_HORIZONTE_DIAS = 3650


@pytest.fixture
def profesional():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    return profesional


@pytest.fixture
def paciente():
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente)
    return paciente


@pytest.fixture
def tratamiento():
    return TratamientoFactory()


def _reservar(paciente, profesional, tratamiento, inicio=INICIO_BASE, **extra):
    return reservar_cita(
        paciente=paciente,
        profesional=profesional,
        tratamiento=tratamiento,
        inicio=inicio,
        ahora=AHORA,
        **extra,
    )


def test_la_reserva_queda_en_la_auditoria(paciente, profesional, tratamiento):
    cita = _reservar(paciente, profesional, tratamiento, ip="10.0.0.7")
    registro = RegistroAuditoria.objects.get(accion=RESERVAR)
    assert registro.usuario == paciente.usuario
    assert registro.recurso_tipo == "cita"
    assert registro.recurso_id == cita.pk
    assert registro.ip == "10.0.0.7"


def test_la_auditoria_no_guarda_los_comentarios(paciente, profesional, tratamiento):
    _reservar(paciente, profesional, tratamiento, comentarios_paciente="Me duele el talón")
    registro = RegistroAuditoria.objects.get(accion=RESERVAR)
    assert "talón" not in str(registro.detalle)


def test_una_reserva_rechazada_no_deja_auditoria(paciente, profesional, tratamiento):
    with pytest.raises(ValidationError):
        _reservar(paciente, profesional, tratamiento, inicio=INICIO_BASE.replace(hour=15))
    assert not RegistroAuditoria.objects.filter(accion=RESERVAR).exists()


def test_sin_consentimiento_no_hay_auditoria(profesional, tratamiento):
    with pytest.raises(ConsentimientoRequerido):
        _reservar(PacienteFactory(), profesional, tratamiento)
    assert not RegistroAuditoria.objects.filter(accion=RESERVAR).exists()


def test_un_choque_en_la_base_no_deja_auditoria(paciente, profesional, tratamiento):
    """Si la restricción de la base rechaza la cita, el registro se deshace con ella."""
    otro = ProfesionalFactory()
    DisponibilidadFactory(profesional=otro)
    _reservar(paciente, profesional, tratamiento)
    with pytest.raises(ValidationError):
        _reservar(paciente, otro, tratamiento)
    assert RegistroAuditoria.objects.filter(accion=RESERVAR).count() == 1
    assert Cita.objects.count() == 1


def test_la_api_registra_la_ip_de_la_solicitud(api_client, paciente, profesional, tratamiento):
    api_client.post(
        "/api/auth/login/", {"email": paciente.usuario.email, "password": CLAVE}, format="json"
    )
    cuerpo = {
        "profesional": str(profesional.pk),
        "tratamiento": str(tratamiento.pk),
        "inicio": INICIO_BASE.isoformat(),
    }
    respuesta = api_client.post("/api/citas/", cuerpo, format="json", REMOTE_ADDR="10.0.0.9")
    assert respuesta.status_code == 201
    registro = RegistroAuditoria.objects.get(accion=RESERVAR)
    assert str(registro.recurso_id) == respuesta.json()["id"]
    assert registro.ip == "10.0.0.9"
