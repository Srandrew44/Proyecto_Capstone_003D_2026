from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo

import factory

from apps.agenda.models import BloqueoHorario, Cita, Disponibilidad, Tratamiento
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory


class TratamientoFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Tratamiento

    nombre = factory.Sequence(lambda n: f"Tratamiento {n}")
    descripcion = "Descripción de prueba"
    duracion_min = 45
    precio = 25000
    activo = True


class DisponibilidadFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Disponibilidad

    profesional = factory.SubFactory(ProfesionalFactory)
    dia_semana = 0
    hora_inicio = time(9, 0)
    hora_fin = time(13, 0)
    activa = True


INICIO_BASE = datetime(2030, 1, 7, 9, 0, tzinfo=ZoneInfo("America/Santiago"))  # un lunes


class CitaFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Cita

    paciente = factory.SubFactory(PacienteFactory)
    profesional = factory.SubFactory(ProfesionalFactory)
    tratamiento = factory.SubFactory(TratamientoFactory)
    inicio = INICIO_BASE
    fin = factory.LazyAttribute(lambda c: c.inicio + timedelta(minutes=c.tratamiento.duracion_min))
    precio = factory.LazyAttribute(lambda c: c.tratamiento.precio)


class BloqueoHorarioFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = BloqueoHorario

    profesional = factory.SubFactory(ProfesionalFactory)
    inicio = INICIO_BASE
    fin = factory.LazyAttribute(lambda b: b.inicio + timedelta(hours=1))
    motivo = ""
