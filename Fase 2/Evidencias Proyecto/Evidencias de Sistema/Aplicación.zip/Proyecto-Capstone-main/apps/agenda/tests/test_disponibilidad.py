from datetime import time

import pytest
from django.db import IntegrityError, transaction

from apps.cuentas.tests.factories import ProfesionalFactory

from .factories import DisponibilidadFactory

pytestmark = pytest.mark.django_db


def test_str_muestra_dia_y_horas():
    tramo = DisponibilidadFactory(dia_semana=2, hora_inicio=time(9, 0), hora_fin=time(13, 30))
    assert str(tramo) == "Miércoles 09:00-13:30"


def test_tramos_solapados_el_mismo_dia_se_rechazan():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional, hora_inicio=time(9), hora_fin=time(13))
    with pytest.raises(IntegrityError), transaction.atomic():
        DisponibilidadFactory(profesional=profesional, hora_inicio=time(12), hora_fin=time(15))


def test_un_tramo_contenido_en_otro_se_rechaza():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional, hora_inicio=time(9), hora_fin=time(18))
    with pytest.raises(IntegrityError), transaction.atomic():
        DisponibilidadFactory(profesional=profesional, hora_inicio=time(11), hora_fin=time(12))


def test_tramos_contiguos_se_permiten():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional, hora_inicio=time(9), hora_fin=time(12))
    DisponibilidadFactory(profesional=profesional, hora_inicio=time(12), hora_fin=time(15))
    assert profesional.disponibilidades.count() == 2


def test_mismo_horario_en_otro_dia_se_permite():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional, dia_semana=0)
    DisponibilidadFactory(profesional=profesional, dia_semana=1)
    assert profesional.disponibilidades.count() == 2


def test_mismo_horario_para_otro_profesional_se_permite():
    DisponibilidadFactory()
    DisponibilidadFactory()


def test_un_tramo_inactivo_no_bloquea_a_otro():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional, activa=False)
    DisponibilidadFactory(profesional=profesional, activa=True)
    assert profesional.disponibilidades.count() == 2


@pytest.mark.parametrize(
    ("inicio", "fin"),
    [(time(13), time(9)), (time(9), time(9))],
)
def test_la_hora_de_fin_debe_ser_posterior_al_inicio(inicio, fin):
    with pytest.raises(IntegrityError), transaction.atomic():
        DisponibilidadFactory(hora_inicio=inicio, hora_fin=fin)


def test_el_dia_debe_estar_entre_0_y_6():
    with pytest.raises(IntegrityError), transaction.atomic():
        DisponibilidadFactory(dia_semana=7)


def test_es_de_compara_con_el_usuario_del_profesional():
    tramo = DisponibilidadFactory()
    ajeno = ProfesionalFactory()
    assert tramo.es_de(tramo.profesional.usuario)
    assert not tramo.es_de(ajeno.usuario)
