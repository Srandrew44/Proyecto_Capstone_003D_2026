from datetime import time, timedelta

import pytest

from apps.agenda.horarios import horarios_libres
from apps.agenda.models import Cita
from apps.cuentas.tests.factories import ProfesionalFactory

from .factories import INICIO_BASE, CitaFactory, DisponibilidadFactory, TratamientoFactory

pytestmark = pytest.mark.django_db

LUNES = INICIO_BASE.date()
AHORA = INICIO_BASE - timedelta(days=3)  # con tiempo de sobra para la anticipación mínima


@pytest.fixture(autouse=True)
def reglas_de_reserva(settings):
    settings.AGENDA_ANTICIPACION_MIN_HORAS = 24
    settings.AGENDA_HORIZONTE_DIAS = 30


@pytest.fixture
def profesional():
    """Profesional con pausa de 15 min y un tramo los lunes de 09:00 a 13:00."""
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    return profesional


def _pedir(profesional, *, tratamiento=None, desde=LUNES, hasta=None, ahora=AHORA):
    return horarios_libres(
        profesional=profesional,
        tratamiento=tratamiento or TratamientoFactory.build(),
        desde=desde,
        hasta=hasta or desde,
        ahora=ahora,
    )


def _horas(horarios):
    return [horario.strftime("%H:%M") for horario in horarios]


def test_los_horarios_se_encadenan_de_a_duracion_mas_pausa(profesional):
    assert _horas(_pedir(profesional)) == ["09:00", "10:00", "11:00", "12:00"]


def test_suma_los_horarios_de_todos_los_tramos_del_dia(profesional):
    DisponibilidadFactory(profesional=profesional, hora_inicio=time(14, 0), hora_fin=time(18, 0))
    assert _horas(_pedir(profesional)) == [
        "09:00",
        "10:00",
        "11:00",
        "12:00",
        "14:00",
        "15:00",
        "16:00",
        "17:00",
    ]


def test_la_cita_debe_terminar_dentro_del_tramo():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional, hora_fin=time(10, 30))
    assert _horas(_pedir(profesional)) == ["09:00"]


def test_la_pausa_de_la_ultima_cita_no_necesita_caber():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional, hora_fin=time(9, 45))
    assert _horas(_pedir(profesional)) == ["09:00"]


def test_una_cita_quita_su_horario_y_deja_los_demas(profesional):
    CitaFactory(profesional=profesional, inicio=INICIO_BASE + timedelta(hours=1))
    assert _horas(_pedir(profesional)) == ["09:00", "11:00", "12:00"]


def test_despues_de_una_cita_se_respeta_la_pausa(profesional):
    CitaFactory(profesional=profesional, inicio=INICIO_BASE)
    assert _horas(_pedir(profesional)) == ["10:00", "11:00", "12:00"]


def test_antes_de_una_cita_tambien_se_respeta_la_pausa(profesional):
    # La cita 09:45-10:30 empieza justo cuando termina el horario de las 09:00, sin pausa.
    CitaFactory(profesional=profesional, inicio=INICIO_BASE + timedelta(minutes=45))
    assert _horas(_pedir(profesional)) == ["10:45", "11:45"]


def test_una_cita_desalineada_reencadena_los_horarios_siguientes(profesional):
    CitaFactory(profesional=profesional, inicio=INICIO_BASE + timedelta(minutes=30))
    assert _horas(_pedir(profesional)) == ["10:30", "11:30"]


def test_una_cita_cancelada_no_quita_horarios(profesional):
    CitaFactory(profesional=profesional, estado=Cita.Estado.CANCELADA)
    assert _horas(_pedir(profesional)) == ["09:00", "10:00", "11:00", "12:00"]


def test_las_citas_de_otro_profesional_no_afectan(profesional):
    CitaFactory(inicio=INICIO_BASE)
    assert _horas(_pedir(profesional)) == ["09:00", "10:00", "11:00", "12:00"]


def test_un_tramo_inactivo_no_ofrece_horarios():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional, activa=False)
    assert _pedir(profesional) == []


def test_un_dia_sin_tramos_no_ofrece_horarios(profesional):
    martes = LUNES + timedelta(days=1)
    assert _pedir(profesional, desde=martes) == []


def test_un_rango_de_dias_junta_los_horarios_de_cada_dia(profesional):
    lunes_siguiente = LUNES + timedelta(days=7)
    horarios = _pedir(profesional, hasta=lunes_siguiente)
    assert [h.date() for h in horarios] == [LUNES] * 4 + [lunes_siguiente] * 4


@pytest.mark.parametrize(
    ("antelacion", "esperados"),
    [
        (timedelta(hours=23), ["10:00", "11:00", "12:00"]),
        (timedelta(hours=23) - timedelta(seconds=1), ["11:00", "12:00"]),
    ],
)
def test_no_ofrece_horarios_antes_de_la_anticipacion_minima(profesional, antelacion, esperados):
    # Con "ahora" 23 h antes del lunes 09:00, el primer horario permitido es el lunes 10:00.
    assert _horas(_pedir(profesional, ahora=INICIO_BASE - antelacion)) == esperados


def test_no_ofrece_horarios_despues_del_horizonte(profesional):
    ahora = INICIO_BASE - timedelta(days=30) + timedelta(hours=2)  # el límite cae a las 11:00
    assert _horas(_pedir(profesional, ahora=ahora)) == ["09:00", "10:00", "11:00"]


def test_un_rango_invertido_no_ofrece_horarios(profesional):
    assert _pedir(profesional, desde=LUNES + timedelta(days=1), hasta=LUNES) == []


def test_usa_la_pausa_del_profesional():
    profesional = ProfesionalFactory(pausa_entre_citas_min=30)
    DisponibilidadFactory(profesional=profesional)
    assert _horas(_pedir(profesional)) == ["09:00", "10:15", "11:30"]


def test_usa_la_duracion_del_tratamiento(profesional):
    tratamiento = TratamientoFactory.build(duracion_min=90)
    assert _horas(_pedir(profesional, tratamiento=tratamiento)) == ["09:00", "10:45"]
