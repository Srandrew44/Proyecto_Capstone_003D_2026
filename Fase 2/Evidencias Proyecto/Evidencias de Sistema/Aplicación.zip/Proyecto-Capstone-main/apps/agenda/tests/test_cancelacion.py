from datetime import timedelta

import pytest
from django.core.exceptions import PermissionDenied, ValidationError

from apps.agenda.models import Cita
from apps.agenda.services import cancelar_cita
from apps.auditoria.models import RegistroAuditoria
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory

from .factories import INICIO_BASE, CitaFactory

pytestmark = pytest.mark.django_db

AHORA = INICIO_BASE - timedelta(days=3)
Accion = RegistroAuditoria.Accion


@pytest.fixture(autouse=True)
def plazo_de_cancelacion(settings):
    settings.AGENDA_CANCELACION_MIN_HORAS = 24


@pytest.fixture
def cita():
    return CitaFactory()


def test_el_paciente_cancela_con_mas_de_24_horas(cita):
    resultado = cancelar_cita(
        cita=cita, usuario=cita.paciente.usuario, motivo="Me surgió un viaje", ahora=AHORA
    )
    cita.refresh_from_db()
    assert resultado.pk == cita.pk
    assert cita.estado == Cita.Estado.CANCELADA
    assert cita.cancelada_en == AHORA
    assert cita.motivo_cancelacion == "Me surgió un viaje"


def test_el_paciente_puede_cancelar_justo_24_horas_antes(cita):
    ahora = INICIO_BASE - timedelta(hours=24)
    cancelar_cita(cita=cita, usuario=cita.paciente.usuario, ahora=ahora)
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CANCELADA


def test_el_paciente_no_cancela_con_menos_de_24_horas(cita):
    ahora = INICIO_BASE - timedelta(hours=24) + timedelta(minutes=1)
    with pytest.raises(ValidationError, match="24 horas"):
        cancelar_cita(cita=cita, usuario=cita.paciente.usuario, ahora=ahora)
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CONFIRMADA
    assert cita.cancelada_en is None


def test_el_profesional_cancela_con_menos_de_24_horas(cita):
    ahora = INICIO_BASE - timedelta(hours=1)
    cancelar_cita(cita=cita, usuario=cita.profesional.usuario, motivo="Imprevisto", ahora=ahora)
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CANCELADA
    assert cita.motivo_cancelacion == "Imprevisto"


@pytest.mark.parametrize("quien", ["paciente", "profesional"])
def test_nadie_cancela_una_cita_que_ya_comenzo(cita, quien):
    with pytest.raises(ValidationError, match="ya comenzó"):
        cancelar_cita(cita=cita, usuario=getattr(cita, quien).usuario, ahora=INICIO_BASE)
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CONFIRMADA


def test_una_cita_cancelada_no_se_cancela_dos_veces(cita):
    cancelar_cita(cita=cita, usuario=cita.paciente.usuario, ahora=AHORA)
    with pytest.raises(ValidationError, match="ya está cancelada"):
        cancelar_cita(cita=cita, usuario=cita.profesional.usuario, ahora=AHORA + timedelta(hours=1))
    cita.refresh_from_db()
    assert cita.cancelada_en == AHORA


@pytest.mark.parametrize("estado", [Cita.Estado.REALIZADA, Cita.Estado.NO_ASISTIO])
def test_una_cita_realizada_o_con_inasistencia_no_se_cancela(estado):
    cita = CitaFactory(estado=estado)
    with pytest.raises(ValidationError, match="ya no se puede cancelar"):
        cancelar_cita(cita=cita, usuario=cita.profesional.usuario, ahora=AHORA)
    cita.refresh_from_db()
    assert cita.estado == estado


def test_una_cita_agendada_se_puede_cancelar():
    cita = CitaFactory(estado=Cita.Estado.AGENDADA)
    cancelar_cita(cita=cita, usuario=cita.paciente.usuario, ahora=AHORA)
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CANCELADA


@pytest.mark.parametrize("factory", [PacienteFactory, ProfesionalFactory])
def test_un_tercero_no_puede_cancelar(cita, factory):
    with pytest.raises(PermissionDenied):
        cancelar_cita(cita=cita, usuario=factory().usuario, ahora=AHORA)
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CONFIRMADA
    assert not RegistroAuditoria.objects.filter(accion=Accion.CANCELAR_CITA).exists()


def test_cancelar_libera_el_horario(cita):
    cancelar_cita(cita=cita, usuario=cita.paciente.usuario, ahora=AHORA)
    nueva = CitaFactory(profesional=cita.profesional, inicio=cita.inicio)
    assert nueva.estado == Cita.Estado.CONFIRMADA


def test_el_plazo_se_puede_configurar(cita, settings):
    settings.AGENDA_CANCELACION_MIN_HORAS = 48
    ahora = INICIO_BASE - timedelta(hours=30)
    with pytest.raises(ValidationError, match="48 horas"):
        cancelar_cita(cita=cita, usuario=cita.paciente.usuario, ahora=ahora)


def test_cancelar_sin_motivo_es_valido(cita):
    cancelar_cita(cita=cita, usuario=cita.paciente.usuario, ahora=AHORA)
    cita.refresh_from_db()
    assert cita.motivo_cancelacion == ""


def test_el_motivo_se_limpia_de_espacios(cita):
    cancelar_cita(cita=cita, usuario=cita.paciente.usuario, motivo="  Me enfermé  ", ahora=AHORA)
    cita.refresh_from_db()
    assert cita.motivo_cancelacion == "Me enfermé"


def test_el_motivo_no_puede_superar_200_caracteres(cita):
    with pytest.raises(ValidationError) as error:
        cancelar_cita(cita=cita, usuario=cita.paciente.usuario, motivo="x" * 201, ahora=AHORA)
    assert "motivo" in error.value.message_dict
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CONFIRMADA


def test_la_cancelacion_queda_en_la_auditoria(cita):
    cancelar_cita(cita=cita, usuario=cita.paciente.usuario, ip="10.0.0.5", ahora=AHORA)
    registro = RegistroAuditoria.objects.get(accion=Accion.CANCELAR_CITA)
    assert registro.usuario == cita.paciente.usuario
    assert registro.recurso_tipo == "cita"
    assert registro.recurso_id == cita.pk
    assert registro.ip == "10.0.0.5"
    assert registro.detalle == {"por": "paciente"}


def test_la_auditoria_indica_si_cancelo_el_profesional(cita):
    cancelar_cita(cita=cita, usuario=cita.profesional.usuario, ahora=AHORA)
    registro = RegistroAuditoria.objects.get(accion=Accion.CANCELAR_CITA)
    assert registro.usuario == cita.profesional.usuario
    assert registro.detalle == {"por": "profesional"}


def test_la_auditoria_no_guarda_el_motivo(cita):
    cancelar_cita(cita=cita, usuario=cita.paciente.usuario, motivo="Me duele el pie", ahora=AHORA)
    registro = RegistroAuditoria.objects.get(accion=Accion.CANCELAR_CITA)
    assert "Me duele" not in str(registro.detalle)


def test_una_cancelacion_rechazada_no_deja_auditoria(cita):
    ahora = INICIO_BASE - timedelta(hours=2)
    with pytest.raises(ValidationError):
        cancelar_cita(cita=cita, usuario=cita.paciente.usuario, ahora=ahora)
    assert not RegistroAuditoria.objects.filter(accion=Accion.CANCELAR_CITA).exists()
