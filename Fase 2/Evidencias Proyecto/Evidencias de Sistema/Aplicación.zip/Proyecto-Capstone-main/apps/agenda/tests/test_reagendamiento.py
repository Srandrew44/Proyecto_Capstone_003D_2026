from datetime import timedelta

import pytest
from django.core.exceptions import PermissionDenied, ValidationError

from apps.agenda.models import Cita
from apps.agenda.services import reagendar_cita
from apps.auditoria.models import RegistroAuditoria
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory

from .factories import INICIO_BASE, CitaFactory, DisponibilidadFactory, TratamientoFactory

pytestmark = pytest.mark.django_db

AHORA = INICIO_BASE - timedelta(days=3)
ONCE = INICIO_BASE + timedelta(hours=2)
REAGENDAR = RegistroAuditoria.Accion.REAGENDAR_CITA


@pytest.fixture(autouse=True)
def reglas_de_agenda(settings):
    settings.AGENDA_ANTICIPACION_MIN_HORAS = 24
    settings.AGENDA_HORIZONTE_DIAS = 30
    settings.AGENDA_CANCELACION_MIN_HORAS = 24


@pytest.fixture
def profesional():
    """Profesional con pausa de 15 min y un tramo los lunes de 09:00 a 13:00."""
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    return profesional


@pytest.fixture
def cita(profesional):
    return CitaFactory(profesional=profesional, tratamiento=TratamientoFactory(precio=25000))


def _reagendar(cita, inicio=ONCE, quien="paciente", ahora=AHORA, **extra):
    usuario = getattr(cita, quien).usuario
    return reagendar_cita(cita=cita, usuario=usuario, inicio=inicio, ahora=ahora, **extra)


def test_el_paciente_mueve_su_cita_a_otro_horario_libre(cita):
    resultado = _reagendar(cita)
    cita.refresh_from_db()
    assert resultado.pk == cita.pk
    assert cita.inicio == ONCE
    assert cita.fin == ONCE + timedelta(minutes=45)
    assert cita.estado == Cita.Estado.CONFIRMADA
    assert Cita.objects.count() == 1


def test_conserva_el_precio_original(cita):
    cita.tratamiento.precio = 99000
    cita.tratamiento.save()
    _reagendar(cita)
    cita.refresh_from_db()
    assert cita.precio == 25000


def test_conserva_la_duracion_original(cita):
    cita.tratamiento.duracion_min = 60
    cita.tratamiento.save()
    _reagendar(cita)
    cita.refresh_from_db()
    assert cita.fin - cita.inicio == timedelta(minutes=45)


def test_la_propia_cita_no_bloquea_el_nuevo_horario(profesional):
    # A las 09:30 la cita desplaza los horarios a 10:30 y 11:30; sin ella, 10:00 queda libre.
    cita = CitaFactory(profesional=profesional, inicio=INICIO_BASE + timedelta(minutes=30))
    _reagendar(cita, inicio=INICIO_BASE + timedelta(hours=1))
    cita.refresh_from_db()
    assert cita.inicio == INICIO_BASE + timedelta(hours=1)


def test_mover_la_cita_libera_el_horario_anterior(cita):
    _reagendar(cita)
    otra = CitaFactory(profesional=cita.profesional, inicio=INICIO_BASE)
    assert otra.estado == Cita.Estado.CONFIRMADA


def test_rechaza_un_horario_que_no_se_ofrece(cita):
    with pytest.raises(ValidationError) as error:
        _reagendar(cita, inicio=ONCE + timedelta(minutes=30))
    assert "inicio" in error.value.message_dict
    cita.refresh_from_db()
    assert cita.inicio == INICIO_BASE


def test_rechaza_un_horario_ocupado_por_otra_cita(cita):
    CitaFactory(profesional=cita.profesional, inicio=ONCE)
    with pytest.raises(ValidationError):
        _reagendar(cita)
    cita.refresh_from_db()
    assert cita.inicio == INICIO_BASE


def test_rechaza_el_mismo_horario(cita):
    with pytest.raises(ValidationError, match="ya está en ese horario"):
        _reagendar(cita, inicio=INICIO_BASE)


def test_el_paciente_no_reagenda_una_cita_que_se_cruza_con_otra_suya(cita):
    otro = ProfesionalFactory()
    CitaFactory(paciente=cita.paciente, profesional=otro, inicio=ONCE)
    with pytest.raises(ValidationError, match="Ya tienes una cita"):
        _reagendar(cita)
    cita.refresh_from_db()
    assert cita.inicio == INICIO_BASE


def test_el_paciente_no_reagenda_con_menos_de_24_horas(cita):
    ahora = INICIO_BASE - timedelta(hours=23)
    siguiente_lunes = INICIO_BASE + timedelta(days=7)
    with pytest.raises(ValidationError, match="reagendar hasta 24 horas"):
        _reagendar(cita, inicio=siguiente_lunes, ahora=ahora)
    cita.refresh_from_db()
    assert cita.inicio == INICIO_BASE


def test_el_profesional_reagenda_con_menos_de_24_horas(cita):
    ahora = INICIO_BASE - timedelta(hours=2)
    siguiente_lunes = INICIO_BASE + timedelta(days=7)
    _reagendar(cita, inicio=siguiente_lunes, quien="profesional", ahora=ahora)
    cita.refresh_from_db()
    assert cita.inicio == siguiente_lunes


def test_el_nuevo_horario_respeta_la_anticipacion_minima(cita):
    # El profesional puede actuar a última hora, pero no ofrecer un horario dentro de 24 h.
    ahora = INICIO_BASE - timedelta(hours=2)
    with pytest.raises(ValidationError) as error:
        _reagendar(cita, quien="profesional", ahora=ahora)
    assert "inicio" in error.value.message_dict


def test_el_nuevo_horario_respeta_el_horizonte(cita):
    lejano = INICIO_BASE + timedelta(days=35)
    with pytest.raises(ValidationError):
        _reagendar(cita, inicio=lejano)


@pytest.mark.parametrize("quien", ["paciente", "profesional"])
def test_nadie_reagenda_una_cita_que_ya_comenzo(cita, quien):
    with pytest.raises(ValidationError, match="ya comenzó"):
        _reagendar(cita, quien=quien, ahora=INICIO_BASE)


def test_una_cita_cancelada_no_se_reagenda(profesional):
    cita = CitaFactory(profesional=profesional, estado=Cita.Estado.CANCELADA)
    with pytest.raises(ValidationError, match="ya está cancelada"):
        _reagendar(cita)


@pytest.mark.parametrize("estado", [Cita.Estado.REALIZADA, Cita.Estado.NO_ASISTIO])
def test_una_cita_realizada_o_con_inasistencia_no_se_reagenda(profesional, estado):
    cita = CitaFactory(profesional=profesional, estado=estado)
    with pytest.raises(ValidationError, match="ya no se puede reagendar"):
        _reagendar(cita, quien="profesional")


@pytest.mark.parametrize("factory", [PacienteFactory, ProfesionalFactory])
def test_un_tercero_no_puede_reagendar(cita, factory):
    with pytest.raises(PermissionDenied):
        reagendar_cita(cita=cita, usuario=factory().usuario, inicio=ONCE, ahora=AHORA)
    cita.refresh_from_db()
    assert cita.inicio == INICIO_BASE
    assert not RegistroAuditoria.objects.filter(accion=REAGENDAR).exists()


def test_exige_una_hora_con_zona_horaria(cita):
    with pytest.raises(ValueError):
        _reagendar(cita, inicio=ONCE.replace(tzinfo=None))


def test_el_reagendamiento_queda_en_la_auditoria(cita):
    _reagendar(cita, ip="10.0.0.5")
    registro = RegistroAuditoria.objects.get(accion=REAGENDAR)
    assert registro.usuario == cita.paciente.usuario
    assert registro.recurso_tipo == "cita"
    assert registro.recurso_id == cita.pk
    assert registro.ip == "10.0.0.5"
    assert registro.detalle["por"] == "paciente"
    assert registro.detalle["inicio_anterior"] == INICIO_BASE.isoformat()


def test_la_auditoria_indica_si_reagendo_el_profesional(cita):
    _reagendar(cita, quien="profesional")
    registro = RegistroAuditoria.objects.get(accion=REAGENDAR)
    assert registro.usuario == cita.profesional.usuario
    assert registro.detalle["por"] == "profesional"


def test_un_reagendamiento_rechazado_no_deja_auditoria(cita):
    with pytest.raises(ValidationError):
        _reagendar(cita, inicio=ONCE + timedelta(minutes=30))
    assert not RegistroAuditoria.objects.filter(accion=REAGENDAR).exists()
