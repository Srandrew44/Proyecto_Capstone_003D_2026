"""Quitar o cambiar un tramo del horario no puede dejar citas reservadas fuera del horario."""

from datetime import time, timedelta

import pytest
from django.core.exceptions import ValidationError

from apps.agenda.models import Cita, Disponibilidad
from apps.agenda.services import actualizar_disponibilidad
from apps.cuentas.models import Usuario
from apps.cuentas.tests.factories import ProfesionalFactory, UsuarioFactory

from .factories import INICIO_BASE, CitaFactory, DisponibilidadFactory, TratamientoFactory

pytestmark = pytest.mark.django_db

AHORA = INICIO_BASE - timedelta(days=3)


@pytest.fixture
def tramo():
    """Los lunes de 09:00 a 13:00."""
    return DisponibilidadFactory(profesional=ProfesionalFactory())


def _cita(tramo, horas=10, estado=Cita.Estado.CONFIRMADA, dias=0):
    inicio = INICIO_BASE.replace(hour=horas) + timedelta(days=dias)
    return CitaFactory(
        profesional=tramo.profesional,
        inicio=inicio,
        tratamiento=TratamientoFactory(duracion_min=45),
        estado=estado,
    )


def test_no_se_desactiva_un_dia_con_citas_futuras_y_dice_cuales(tramo):
    _cita(tramo, 10)
    _cita(tramo, 11, dias=7)
    with pytest.raises(ValidationError) as error:
        actualizar_disponibilidad(tramo=tramo, activa=False, ahora=AHORA)
    mensaje = error.value.messages[0]
    assert "07/01/2030 10:00" in mensaje and "14/01/2030 11:00" in mensaje
    tramo.refresh_from_db()
    assert tramo.activa


@pytest.mark.parametrize(
    "estado", [Cita.Estado.CONFIRMADA, Cita.Estado.AGENDADA, Cita.Estado.PENDIENTE_PAGO]
)
def test_cuentan_todas_las_citas_que_ocupan_la_hora(tramo, estado):
    _cita(tramo, 10, estado=estado)
    with pytest.raises(ValidationError):
        actualizar_disponibilidad(tramo=tramo, activa=False, ahora=AHORA)


@pytest.mark.parametrize("estado", [Cita.Estado.CANCELADA, Cita.Estado.REALIZADA])
def test_las_citas_canceladas_o_realizadas_no_impiden_desactivar(tramo, estado):
    _cita(tramo, 10, estado=estado)
    actualizar_disponibilidad(tramo=tramo, activa=False, ahora=AHORA)
    tramo.refresh_from_db()
    assert not tramo.activa


def test_las_citas_pasadas_no_impiden_desactivar(tramo):
    _cita(tramo, 10)
    actualizar_disponibilidad(tramo=tramo, activa=False, ahora=INICIO_BASE + timedelta(days=1))
    tramo.refresh_from_db()
    assert not tramo.activa


def test_achicar_el_tramo_solo_choca_con_las_citas_que_quedan_fuera(tramo):
    _cita(tramo, 9)  # 09:00-09:45, queda dentro de 09:00-11:00
    actualizar_disponibilidad(tramo=tramo, hora_fin=time(11, 0), ahora=AHORA)
    _cita(tramo, 10, dias=7)  # 10:00-10:45, también dentro
    with pytest.raises(ValidationError, match="14/01/2030 10:00"):
        actualizar_disponibilidad(tramo=tramo, hora_fin=time(10, 30), ahora=AHORA)


def test_cambiar_el_dia_choca_con_las_citas_del_dia_anterior(tramo):
    _cita(tramo, 10)
    with pytest.raises(ValidationError):
        actualizar_disponibilidad(tramo=tramo, dia_semana=1, ahora=AHORA)


def test_si_otro_tramo_activo_cubre_la_cita_se_permite(tramo):
    # Primero se acorta a 09:00-10:00 y se agrega otro tramo 10:00-13:00 que cubre la cita.
    DisponibilidadFactory(
        profesional=tramo.profesional, hora_inicio=time(13, 0), hora_fin=time(18, 0)
    )
    _cita(tramo, 14)  # cae en el tramo de la tarde, no en el de la mañana
    actualizar_disponibilidad(tramo=tramo, activa=False, ahora=AHORA)
    tramo.refresh_from_db()
    assert not tramo.activa


def test_activar_un_tramo_no_revisa_citas(tramo):
    _cita(tramo, 10)
    Disponibilidad.objects.filter(pk=tramo.pk).update(activa=False)
    tramo.refresh_from_db()
    actualizar_disponibilidad(tramo=tramo, activa=True, ahora=AHORA)
    tramo.refresh_from_db()
    assert tramo.activa


# --- sitio y admin ---


def test_el_podologo_ve_el_error_al_desactivar_en_su_pagina(client, tramo):
    _cita(tramo, 10)
    client.force_login(tramo.profesional.usuario)
    respuesta = client.post(f"/podologo/horario/tramos/{tramo.pk}/alternar/")
    assert respuesta.status_code == 200
    assert "Hay citas reservadas en este horario" in respuesta.content.decode()
    tramo.refresh_from_db()
    assert tramo.activa


@pytest.fixture
def cliente_admin(client):
    client.force_login(UsuarioFactory(rol=Usuario.Rol.ADMIN, is_staff=True, is_superuser=True))
    return client


def _datos_admin(tramo, **cambios):
    datos = {
        "dia_semana": tramo.dia_semana,
        "hora_inicio": tramo.hora_inicio.strftime("%H:%M"),
        "hora_fin": tramo.hora_fin.strftime("%H:%M"),
        "activa": "on" if tramo.activa else "",
    }
    datos.update(cambios)
    return {k: v for k, v in datos.items() if v != ""}


def test_el_admin_tampoco_deja_citas_fuera_del_horario(cliente_admin, tramo):
    _cita(tramo, 10)
    url = f"/admin/agenda/disponibilidad/{tramo.pk}/change/"
    respuesta = cliente_admin.post(url, _datos_admin(tramo, activa=""))
    assert respuesta.status_code == 200
    assert "Hay citas reservadas en este horario" in respuesta.content.decode()
    tramo.refresh_from_db()
    assert tramo.activa


def test_el_admin_desactiva_un_tramo_sin_citas(cliente_admin, tramo):
    url = f"/admin/agenda/disponibilidad/{tramo.pk}/change/"
    respuesta = cliente_admin.post(url, _datos_admin(tramo, activa=""))
    assert respuesta.status_code == 302
    tramo.refresh_from_db()
    assert not tramo.activa


def test_el_admin_crea_un_tramo_con_el_servicio(cliente_admin):
    profesional = ProfesionalFactory()
    datos = {
        "profesional": profesional.pk,
        "dia_semana": 2,
        "hora_inicio": "09:00",
        "hora_fin": "12:00",
        "activa": "on",
    }
    respuesta = cliente_admin.post("/admin/agenda/disponibilidad/add/", datos)
    assert respuesta.status_code == 302
    assert Disponibilidad.objects.filter(profesional=profesional, dia_semana=2).exists()


def test_el_admin_no_borra_tramos(cliente_admin, tramo):
    respuesta = cliente_admin.get(f"/admin/agenda/disponibilidad/{tramo.pk}/delete/")
    assert respuesta.status_code == 403
