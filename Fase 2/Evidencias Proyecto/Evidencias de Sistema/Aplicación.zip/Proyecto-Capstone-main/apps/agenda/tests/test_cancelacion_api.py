from datetime import timedelta
from uuid import uuid4

import pytest
from django.utils import timezone

from apps.agenda.models import Cita
from apps.auditoria.models import RegistroAuditoria
from apps.clinica.tests.factories import ConsentimientoFactory
from apps.cuentas.tests.factories import CLAVE, PacienteFactory, ProfesionalFactory

from .factories import INICIO_BASE, CitaFactory, DisponibilidadFactory, TratamientoFactory

pytestmark = pytest.mark.django_db

CITAS = "/api/citas/"
HORARIOS = "/api/horarios-libres/"
LUNES = INICIO_BASE.date().isoformat()


def _entrar(cliente, usuario):
    cliente.post("/api/auth/login/", {"email": usuario.email, "password": CLAVE}, format="json")


def _url(cita):
    return f"{CITAS}{cita.pk}/cancelar/"


def _cita_en(horas, **extra):
    """Cita que empieza dentro de `horas` horas, contadas desde ahora."""
    return CitaFactory(inicio=timezone.now() + timedelta(hours=horas), **extra)


def _estado(cita):
    cita.refresh_from_db()
    return cita.estado


def test_cancelar_exige_sesion(api_client):
    assert api_client.post(_url(CitaFactory())).status_code == 403


def test_el_paciente_cancela_su_cita(api_client):
    cita = _cita_en(100)
    _entrar(api_client, cita.paciente.usuario)
    respuesta = api_client.post(_url(cita), {"motivo": "Me surgió un viaje"}, format="json")
    assert respuesta.status_code == 200
    assert respuesta.json()["estado"] == "cancelada"
    assert respuesta.json()["motivo_cancelacion"] == "Me surgió un viaje"
    assert respuesta.json()["cancelada_en"] is not None
    assert _estado(cita) == Cita.Estado.CANCELADA


def test_el_profesional_cancela_una_cita_de_su_agenda(api_client):
    cita = _cita_en(100)
    _entrar(api_client, cita.profesional.usuario)
    assert api_client.post(_url(cita)).status_code == 200
    assert _estado(cita) == Cita.Estado.CANCELADA


def test_otro_paciente_recibe_404_y_la_cita_sigue_igual(api_client):
    cita = _cita_en(100)
    _entrar(api_client, PacienteFactory().usuario)
    assert api_client.post(_url(cita)).status_code == 404
    assert _estado(cita) == Cita.Estado.CONFIRMADA


def test_otro_profesional_recibe_404_y_la_cita_sigue_igual(api_client):
    cita = _cita_en(100)
    _entrar(api_client, ProfesionalFactory().usuario)
    assert api_client.post(_url(cita)).status_code == 404
    assert _estado(cita) == Cita.Estado.CONFIRMADA


def test_una_cita_inexistente_responde_404(api_client):
    _entrar(api_client, PacienteFactory().usuario)
    assert api_client.post(f"{CITAS}{uuid4()}/cancelar/").status_code == 404


def test_el_paciente_no_cancela_con_menos_de_24_horas(api_client):
    cita = _cita_en(10)
    _entrar(api_client, cita.paciente.usuario)
    respuesta = api_client.post(_url(cita))
    assert respuesta.status_code == 400
    assert "24 horas" in str(respuesta.json())
    assert _estado(cita) == Cita.Estado.CONFIRMADA


def test_el_profesional_cancela_con_menos_de_24_horas(api_client):
    cita = _cita_en(10)
    _entrar(api_client, cita.profesional.usuario)
    assert api_client.post(_url(cita)).status_code == 200
    assert _estado(cita) == Cita.Estado.CANCELADA


def test_una_cita_ya_cancelada_responde_400(api_client):
    cita = _cita_en(100, estado=Cita.Estado.CANCELADA)
    _entrar(api_client, cita.paciente.usuario)
    respuesta = api_client.post(_url(cita))
    assert respuesta.status_code == 400
    assert "ya está cancelada" in str(respuesta.json())


def test_un_motivo_demasiado_largo_responde_400(api_client):
    cita = _cita_en(100)
    _entrar(api_client, cita.paciente.usuario)
    respuesta = api_client.post(_url(cita), {"motivo": "x" * 201}, format="json")
    assert respuesta.status_code == 400
    assert "motivo" in respuesta.json()
    assert _estado(cita) == Cita.Estado.CONFIRMADA


def test_cancelar_solo_acepta_post(api_client):
    cita = _cita_en(100)
    _entrar(api_client, cita.paciente.usuario)
    assert api_client.get(_url(cita)).status_code == 405
    assert api_client.delete(_url(cita)).status_code == 405


def test_la_cancelacion_deja_auditoria_con_la_ip(api_client):
    cita = _cita_en(100)
    _entrar(api_client, cita.paciente.usuario)
    api_client.post(_url(cita))
    registro = RegistroAuditoria.objects.get(accion=RegistroAuditoria.Accion.CANCELAR_CITA)
    assert registro.usuario == cita.paciente.usuario
    assert registro.recurso_id == cita.pk
    assert registro.ip == "127.0.0.1"


def test_la_cita_cancelada_sigue_en_mis_citas(api_client):
    cita = _cita_en(100)
    _entrar(api_client, cita.paciente.usuario)
    api_client.post(_url(cita), {"motivo": "Cambio de planes"}, format="json")
    citas = api_client.get(CITAS).json()
    assert [(c["id"], c["estado"], c["motivo_cancelacion"]) for c in citas] == [
        (str(cita.pk), "cancelada", "Cambio de planes")
    ]


def test_reservar_cancelar_y_ver_el_horario_libre_otra_vez(api_client, settings):
    settings.AGENDA_ANTICIPACION_MIN_HORAS = 24
    settings.AGENDA_HORIZONTE_DIAS = 3650
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    tratamiento = TratamientoFactory(duracion_min=45)
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente)
    _entrar(api_client, paciente.usuario)

    def horas_libres():
        consulta = {
            "profesional": str(profesional.pk),
            "tratamiento": str(tratamiento.pk),
            "desde": LUNES,
            "hasta": LUNES,
        }
        return [h[11:16] for h in api_client.get(HORARIOS, consulta).json()["horarios"]]

    reserva = {
        "profesional": str(profesional.pk),
        "tratamiento": str(tratamiento.pk),
        "inicio": INICIO_BASE.isoformat(),
    }
    creada = api_client.post(CITAS, reserva, format="json")
    assert creada.status_code == 201
    assert "09:00" not in horas_libres()

    cancelada = api_client.post(f"{CITAS}{creada.json()['id']}/cancelar/")
    assert cancelada.status_code == 200
    assert horas_libres() == ["09:00", "10:00", "11:00", "12:00"]
