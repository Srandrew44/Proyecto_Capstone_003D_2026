from io import StringIO

import pytest
from django.core.management import CommandError, call_command

from apps.agenda.models import Tratamiento
from apps.cuentas.tests.factories import ProfesionalFactory

from .factories import DisponibilidadFactory, TratamientoFactory

pytestmark = pytest.mark.django_db


def _ejecutar(*args):
    salida = StringIO()
    call_command("cargar_datos_demo", *args, stdout=salida)
    return salida.getvalue()


def test_carga_los_tratamientos_de_ejemplo():
    _ejecutar()
    assert Tratamiento.objects.count() == 4
    assert Tratamiento.objects.filter(activo=True).count() == 4
    assert Tratamiento.objects.exclude(descripcion_detallada="").count() == 4


def test_completa_el_detalle_de_un_tratamiento_existente_si_esta_vacio():
    tratamiento = TratamientoFactory(nombre="Podología básica", descripcion_detallada="")
    _ejecutar()
    tratamiento.refresh_from_db()
    assert tratamiento.descripcion_detallada


def test_repetirlo_no_duplica_ni_pisa_cambios():
    _ejecutar()
    tratamiento = Tratamiento.objects.get(nombre="Podología básica")
    tratamiento.precio = 1
    tratamiento.descripcion_detallada = "Detalle escrito por el podólogo."
    tratamiento.save()
    _ejecutar()
    assert Tratamiento.objects.count() == 4
    tratamiento.refresh_from_db()
    assert tratamiento.precio == 1
    assert tratamiento.descripcion_detallada == "Detalle escrito por el podólogo."


def test_carga_horario_de_lunes_a_viernes_para_el_profesional():
    profesional = ProfesionalFactory()
    _ejecutar("--profesional", profesional.usuario.email)
    assert profesional.disponibilidades.count() == 10
    assert not profesional.disponibilidades.filter(dia_semana__gte=5).exists()


def test_una_segunda_ejecucion_no_duplica_el_horario():
    profesional = ProfesionalFactory()
    _ejecutar("--profesional", profesional.usuario.email)
    _ejecutar("--profesional", profesional.usuario.email)
    assert profesional.disponibilidades.count() == 10


def test_no_toca_a_un_profesional_que_ya_tiene_horario():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    _ejecutar("--profesional", profesional.usuario.email)
    assert profesional.disponibilidades.count() == 1


def test_un_profesional_inexistente_da_error():
    with pytest.raises(CommandError):
        _ejecutar("--profesional", "nadie@example.com")
