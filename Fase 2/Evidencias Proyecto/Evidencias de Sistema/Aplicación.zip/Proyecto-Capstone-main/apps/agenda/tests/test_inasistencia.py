from datetime import timedelta

import pytest
from django.core.exceptions import PermissionDenied, ValidationError

from apps.agenda import selectors
from apps.agenda.models import Cita
from apps.agenda.services import marcar_inasistencia
from apps.auditoria.models import RegistroAuditoria

from .factories import INICIO_BASE, CitaFactory

pytestmark = pytest.mark.django_db

DESPUES = INICIO_BASE + timedelta(minutes=20)


def test_el_profesional_marca_la_inasistencia():
    cita = CitaFactory()
    marcar_inasistencia(cita=cita, usuario=cita.profesional.usuario, ip="10.0.0.3", ahora=DESPUES)
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.NO_ASISTIO
    registro = RegistroAuditoria.objects.get(accion=RegistroAuditoria.Accion.MARCAR_INASISTENCIA)
    assert registro.recurso_id == cita.pk


def test_el_paciente_no_marca_su_inasistencia():
    cita = CitaFactory()
    with pytest.raises(PermissionDenied):
        marcar_inasistencia(cita=cita, usuario=cita.paciente.usuario, ahora=DESPUES)


def test_no_se_marca_antes_de_que_comience():
    cita = CitaFactory()
    with pytest.raises(ValidationError, match="aún no comienza"):
        marcar_inasistencia(
            cita=cita, usuario=cita.profesional.usuario, ahora=INICIO_BASE - timedelta(hours=1)
        )


def test_se_puede_marcar_desde_la_hora_de_inicio_y_no_un_minuto_antes():
    cita = CitaFactory()
    with pytest.raises(ValidationError):
        marcar_inasistencia(
            cita=cita, usuario=cita.profesional.usuario, ahora=INICIO_BASE - timedelta(minutes=1)
        )
    marcar_inasistencia(cita=cita, usuario=cita.profesional.usuario, ahora=INICIO_BASE)
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.NO_ASISTIO


@pytest.mark.parametrize("estado", [Cita.Estado.CANCELADA, Cita.Estado.REALIZADA])
def test_una_cita_cancelada_o_realizada_no_admite_inasistencia(estado):
    cita = CitaFactory(estado=estado)
    with pytest.raises(ValidationError):
        marcar_inasistencia(cita=cita, usuario=cita.profesional.usuario, ahora=DESPUES)


def test_la_agenda_del_dia_trae_solo_las_citas_propias_de_ese_dia():
    cita = CitaFactory()
    CitaFactory(profesional=cita.profesional, inicio=INICIO_BASE + timedelta(days=1))
    CitaFactory(inicio=INICIO_BASE)
    agenda = selectors.agenda_del_dia(cita.profesional.usuario, INICIO_BASE.date())
    assert list(agenda) == [cita]
