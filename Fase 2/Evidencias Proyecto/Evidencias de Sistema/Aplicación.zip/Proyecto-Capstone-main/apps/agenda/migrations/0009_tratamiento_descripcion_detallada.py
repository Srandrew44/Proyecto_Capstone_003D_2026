from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("agenda", "0008_cita_pendiente_pago"),
    ]

    operations = [
        migrations.AddField(
            model_name="tratamiento",
            name="descripcion_detallada",
            field=models.TextField(blank=True, help_text="Descripción que aparece al seleccionar «Conocer más» en la portada."),
        ),
    ]
