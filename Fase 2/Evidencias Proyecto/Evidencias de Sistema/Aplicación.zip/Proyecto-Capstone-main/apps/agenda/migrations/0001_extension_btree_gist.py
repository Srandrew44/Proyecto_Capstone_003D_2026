"""Activa btree_gist: permite la restricción de exclusión que evita citas solapadas (hito B3)."""

from django.contrib.postgres.operations import BtreeGistExtension
from django.db import migrations


class Migration(migrations.Migration):
    dependencies = []
    operations = [BtreeGistExtension()]
