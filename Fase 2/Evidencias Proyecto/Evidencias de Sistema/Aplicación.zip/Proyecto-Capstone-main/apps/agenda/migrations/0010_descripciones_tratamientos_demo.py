from django.db import migrations

# Copia de los textos de ejemplo para conservar el estado histórico de esta migración.
DESCRIPCIONES_DEMO = {
    "Podología básica": (
        "Esta atención está pensada para quienes necesitan ayuda con el corte de uñas, "
        "tienen durezas que molestan al caminar o buscan un cuidado periódico de sus pies. "
        "Primero conversamos sobre tus molestias y revisamos la piel, las uñas y las zonas "
        "donde el zapato suele apretar o rozar.\n\n"
        "Según lo que encontremos, cortamos y limamos las uñas y rebajamos las callosidades "
        "que se puedan tratar en la consulta. Al terminar te orientamos sobre cómo cuidar "
        "la piel, elegir calzado con espacio para los dedos y evitar cortar las durezas en casa."
    ),
    "Uña encarnada": (
        "Esta atención está pensada para quienes sienten presión o molestia porque un borde "
        "de la uña se clava en la piel. Primero revisamos la uña y el dedo, y conversamos "
        "sobre cuándo empezó la molestia, cómo cortas tus uñas y qué calzado usas habitualmente.\n\n"
        "Si se puede manejar en la consulta, limpiamos la zona y tratamos con cuidado el "
        "borde que presiona la piel. Al terminar te explicamos cómo cuidar el dedo, qué calzado "
        "puede ayudar a evitar el roce y cuándo volver a control. Si vemos signos de infección, "
        "te orientamos para que consultes a un médico."
    ),
    "Tratamiento de hongos": (
        "Esta atención está pensada para quienes han notado que una uña cambió de color, "
        "se engrosó o se quiebra con facilidad. Primero revisamos las uñas y la piel "
        "alrededor, y conversamos sobre cuánto tiempo llevan esos cambios y qué cuidados "
        "has probado.\n\n"
        "Cuando corresponde, limpiamos la uña y rebajamos su grosor para facilitar el "
        "cuidado. El seguimiento puede requerir varias sesiones. Si hay un compromiso "
        "importante de las uñas, te derivamos al médico para evaluación. Al terminar "
        "conversamos sobre cómo secar bien los pies, cambiar los calcetines húmedos y "
        "evitar compartir el cortaúñas."
    ),
    "Control de pie sensible": (
        "Este control preventivo está pensado para personas con diabetes, problemas "
        "de circulación o cambios en la sensibilidad de los pies. Primero conversamos "
        "sobre tus antecedentes y revisamos la piel, las uñas y las zonas de presión. "
        "También revisamos cómo percibes el tacto en distintas partes del pie.\n\n"
        "Según la revisión, realizamos los cuidados de uñas y piel que sean apropiados "
        "para ti. Al terminar te mostramos cómo revisar tus pies a diario y en qué "
        "fijarte al elegir calzado. Si encontramos una herida u otro cambio que requiera "
        "evaluación médica, te orientamos para consultar a tu equipo de salud."
    ),
}


def completar_descripciones(apps, schema_editor):
    tratamiento = apps.get_model("agenda", "Tratamiento")
    for nombre, detalle in DESCRIPCIONES_DEMO.items():
        tratamiento.objects.using(schema_editor.connection.alias).filter(
            nombre=nombre, descripcion_detallada=""
        ).update(descripcion_detallada=detalle)


class Migration(migrations.Migration):
    dependencies = [
        ("agenda", "0009_tratamiento_descripcion_detallada"),
    ]

    operations = [
        migrations.RunPython(completar_descripciones, migrations.RunPython.noop),
    ]
