import logging
import time

from django.contrib.sessions.models import Session
from django.core.management.base import BaseCommand
from django.utils import timezone

from apps.agenda.notificaciones import enviar_pendientes
from apps.chatbot.services import borrar_fotos_vencidas
from apps.cuentas.services import borrar_registros_vencidos
from apps.pagos.services import reintentar_reembolsos, vencer_pendientes, verificar_pagos

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = (
        "Envía los correos pendientes cuya hora llegó, libera las horas cuyo pago venció, "
        "verifica con Transbank los pagos sin respuesta clara, reintenta los reembolsos "
        "fallidos, borra las fotos vencidas del asistente, los registros sin confirmar y las "
        "sesiones vencidas. Con --continuo se repite sin parar."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--continuo",
            action="store_true",
            help="Repite el envío cada --intervalo segundos (lo usa el servicio de Docker).",
        )
        parser.add_argument("--intervalo", type=int, default=60)

    def handle(self, *args, continuo, intervalo, **options):
        while True:
            # Primero los pagos: una hora liberada no debe recibir su recordatorio. Cada tarea
            # va aparte: si una falla, las demás (y el envío de correos) siguen.
            self._tarea("pagos", self._pagos, continuo)
            self._tarea("fotos", self._fotos, continuo)
            self._tarea("limpieza", self._limpieza, continuo)
            self._tarea("correos", self._correos, continuo)
            if not continuo:
                return
            time.sleep(intervalo)

    def _tarea(self, nombre, funcion, continuo):
        try:
            funcion(continuo)
        except Exception:
            if not continuo:
                raise
            logger.exception("Falló la tarea periódica de %s", nombre)

    def _pagos(self, continuo):
        vencidos = vencer_pendientes()
        # Antes que los reembolsos: un pago por verificar puede terminar en uno.
        verificados = verificar_pagos()
        reembolsos = reintentar_reembolsos()
        if vencidos or any(verificados.values()) or any(reembolsos.values()) or not continuo:
            self.stdout.write(
                f"Pagos vencidos: {vencidos}, verificados aprobados: {verificados['aprobados']}, "
                f"verificados rechazados: {verificados['rechazados']}, "
                f"por verificar sin respuesta: {verificados['sin_respuesta']}, "
                f"reembolsos hechos: {reembolsos['reembolsados']}, "
                f"reembolsos fallidos: {reembolsos['fallidos']}"
            )

    def _fotos(self, continuo):
        fotos = borrar_fotos_vencidas()
        if fotos:
            self.stdout.write(f"Fotos del asistente borradas por plazo: {fotos}")

    def _limpieza(self, continuo):
        registros = borrar_registros_vencidos()
        sesiones, _ = Session.objects.filter(expire_date__lt=timezone.now()).delete()
        if registros or sesiones:
            self.stdout.write(
                f"Registros sin confirmar borrados: {registros}, sesiones vencidas: {sesiones}"
            )

    def _correos(self, continuo):
        resumen = enviar_pendientes()
        if any(resumen.values()) or not continuo:
            self.stdout.write(
                "Enviadas: {enviadas}, reintentos: {reintentos}, fallidas: {fallidas}, "
                "anuladas: {anuladas}".format(**resumen)
            )
