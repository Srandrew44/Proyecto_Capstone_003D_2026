"""Carga datos de ejemplo para desarrollo y demostración. Es seguro repetirlo."""

from datetime import time

from django.core.management.base import BaseCommand, CommandError

from apps.agenda import services
from apps.agenda.models import Tratamiento
from apps.agenda.tratamientos_demo import DESCRIPCIONES_DEMO
from apps.cuentas.models import Profesional

# Valores de ejemplo: el precio real lo define el podólogo (pesos chilenos).
TRATAMIENTOS = [
    ("Podología básica", "Corte y limado de uñas, manejo de callosidades y control.", 45, 20000),
    ("Uña encarnada", "Tratamiento de uña encarnada y cuidado posterior.", 30, 25000),
    ("Tratamiento de hongos", "Limpieza y tratamiento de uñas con hongos.", 45, 30000),
    ("Control de pie sensible", "Revisión y cuidado preventivo del pie.", 60, 35000),
]
HORARIO = [(time(9), time(13)), (time(14), time(18))]
DIAS_HABILES = range(5)  # lunes a viernes


class Command(BaseCommand):
    help = "Carga tratamientos de ejemplo y, con --profesional, un horario semanal de ejemplo."

    def add_arguments(self, parser):
        parser.add_argument(
            "--profesional",
            help="Correo de un profesional existente. Recibe lunes a viernes, 09-13 y 14-18.",
        )

    def handle(self, *args, **opciones):
        nuevos = self._cargar_tratamientos()
        self.stdout.write(
            f"Tratamientos: {nuevos} nuevos, {len(TRATAMIENTOS) - nuevos} ya existían."
        )
        correo = opciones["profesional"]
        if correo:
            self._cargar_horario(correo)

    def _cargar_tratamientos(self) -> int:
        nuevos = 0
        for nombre, descripcion, duracion_min, precio in TRATAMIENTOS:
            detalle = DESCRIPCIONES_DEMO[nombre]
            tratamiento, creado = Tratamiento.objects.get_or_create(
                nombre=nombre,
                defaults={
                    "descripcion": descripcion,
                    "descripcion_detallada": detalle,
                    "duracion_min": duracion_min,
                    "precio": precio,
                },
            )
            if not creado and not tratamiento.descripcion_detallada:
                Tratamiento.objects.filter(pk=tratamiento.pk, descripcion_detallada="").update(
                    descripcion_detallada=detalle
                )
            nuevos += creado
        return nuevos

    def _cargar_horario(self, correo: str) -> None:
        try:
            profesional = Profesional.objects.get(usuario__email=correo.strip().lower())
        except Profesional.DoesNotExist as exc:
            raise CommandError(f"No existe un profesional con el correo {correo}.") from exc
        if profesional.disponibilidades.exists():
            self.stdout.write("El profesional ya tiene horario: no se modifica.")
            return
        for dia in DIAS_HABILES:
            for inicio, fin in HORARIO:
                services.crear_disponibilidad(
                    profesional=profesional, dia_semana=dia, hora_inicio=inicio, hora_fin=fin
                )
        total = len(DIAS_HABILES) * len(HORARIO)
        self.stdout.write(f"Horario de ejemplo cargado: {total} tramos.")
