from django.urls import path

from . import views

urlpatterns = [
    path("consulta/", views.ConsultaView.as_view(), name="consulta"),
    path("tratamientos/", views.TratamientosView.as_view(), name="tratamientos"),
    path("profesionales/", views.ProfesionalesView.as_view(), name="profesionales"),
    path("horarios-libres/", views.HorariosLibresView.as_view(), name="horarios-libres"),
    path("citas/", views.CitasView.as_view(), name="citas"),
    path("citas/<uuid:pk>/cancelar/", views.CancelarCitaView.as_view(), name="cancelar-cita"),
    path("citas/<uuid:pk>/reagendar/", views.ReagendarCitaView.as_view(), name="reagendar-cita"),
    path("citas/<uuid:pk>/inasistencia/", views.InasistenciaView.as_view(), name="inasistencia"),
    path("agenda-del-dia/", views.AgendaDelDiaView.as_view(), name="agenda-del-dia"),
    path("notificaciones/", views.NotificacionesView.as_view(), name="notificaciones"),
    path("bloqueos/", views.BloqueosView.as_view(), name="bloqueos"),
    path("bloqueos/<uuid:pk>/", views.BloqueoDetalleView.as_view(), name="bloqueo-detalle"),
    path("disponibilidades/", views.DisponibilidadesView.as_view(), name="disponibilidades"),
    path(
        "disponibilidades/<uuid:pk>/",
        views.DisponibilidadDetalleView.as_view(),
        name="disponibilidad-detalle",
    ),
]
