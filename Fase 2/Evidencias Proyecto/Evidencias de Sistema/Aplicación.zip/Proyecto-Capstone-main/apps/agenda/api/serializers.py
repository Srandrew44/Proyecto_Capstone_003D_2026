from datetime import timedelta

from django.urls import reverse
from django.utils import timezone
from rest_framework import serializers

from apps.agenda import selectors
from apps.agenda.models import BloqueoHorario, Cita, Disponibilidad, Notificacion, Tratamiento
from apps.cuentas.models import Profesional

DIAS_POR_DEFECTO = 7
DIAS_MAXIMOS = 31


class TratamientoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tratamiento
        fields = ["id", "nombre", "descripcion", "duracion_min", "precio", "descripcion_detallada"]
        read_only_fields = fields


class DisponibilidadSerializer(serializers.ModelSerializer):
    class Meta:
        model = Disponibilidad
        fields = ["id", "dia_semana", "hora_inicio", "hora_fin", "activa"]
        read_only_fields = ["id"]

    def validate(self, attrs):
        # En una edición parcial se completa con los valores actuales del tramo.
        inicio = attrs.get("hora_inicio", getattr(self.instance, "hora_inicio", None))
        fin = attrs.get("hora_fin", getattr(self.instance, "hora_fin", None))
        if inicio and fin and fin <= inicio:
            raise serializers.ValidationError(
                {"hora_fin": "Debe ser posterior a la hora de inicio."}
            )
        return attrs


class ProfesionalSerializer(serializers.ModelSerializer):
    """Solo lo necesario para elegir podólogo: sin colegiatura ni datos de la agenda."""

    id = serializers.UUIDField(source="pk", read_only=True)
    nombre = serializers.CharField(source="usuario.nombre", read_only=True)
    apellido = serializers.CharField(source="usuario.apellido", read_only=True)

    class Meta:
        model = Profesional
        fields = ["id", "nombre", "apellido", "especialidad"]
        read_only_fields = fields


class HorariosLibresSerializer(serializers.Serializer):
    """Parámetros de GET /api/horarios-libres/. Sin `desde` y `hasta` se muestra una semana."""

    profesional = serializers.PrimaryKeyRelatedField(queryset=selectors.profesionales_activos())
    tratamiento = serializers.PrimaryKeyRelatedField(queryset=selectors.tratamientos_activos())
    desde = serializers.DateField(required=False)
    hasta = serializers.DateField(required=False)

    def validate(self, attrs):
        hoy = timezone.localdate()
        desde = attrs.get("desde", hoy)
        hasta = attrs.get("hasta", desde + timedelta(days=DIAS_POR_DEFECTO - 1))
        if desde < hoy:
            raise serializers.ValidationError({"desde": "No puede ser una fecha pasada."})
        if hasta < desde:
            raise serializers.ValidationError({"hasta": "No puede ser anterior a `desde`."})
        # Acota el trabajo de una sola consulta.
        if (hasta - desde).days >= DIAS_MAXIMOS:
            raise serializers.ValidationError(
                {"hasta": f"El rango no puede superar {DIAS_MAXIMOS} días."}
            )
        attrs["desde"], attrs["hasta"] = desde, hasta
        return attrs


class ReservaSerializer(serializers.Serializer):
    """Cuerpo de POST /api/citas/. El paciente sale de la sesión, nunca del cuerpo."""

    profesional = serializers.PrimaryKeyRelatedField(queryset=selectors.profesionales_activos())
    tratamiento = serializers.PrimaryKeyRelatedField(queryset=selectors.tratamientos_activos())
    inicio = serializers.DateTimeField()
    comentarios_paciente = serializers.CharField(required=False, allow_blank=True, max_length=1000)


class CitaSerializer(serializers.ModelSerializer):
    profesional = serializers.UUIDField(source="profesional_id", read_only=True)
    tratamiento = serializers.UUIDField(source="tratamiento_id", read_only=True)
    profesional_nombre = serializers.SerializerMethodField()
    tratamiento_nombre = serializers.CharField(source="tratamiento.nombre", read_only=True)
    pago_url = serializers.SerializerMethodField()

    class Meta:
        model = Cita
        fields = [
            "id",
            "profesional",
            "profesional_nombre",
            "tratamiento",
            "tratamiento_nombre",
            "inicio",
            "fin",
            "estado",
            "precio",
            "comentarios_paciente",
            "creada_en",
            "cancelada_en",
            "motivo_cancelacion",
            "pago_url",
        ]
        read_only_fields = fields

    def get_pago_url(self, cita) -> str | None:
        """Página que envía al paciente a Webpay, mientras la cita espera su pago."""
        if cita.estado != Cita.Estado.PENDIENTE_PAGO:
            return None
        return reverse("web:pago-ir", args=[cita.pk])

    def get_profesional_nombre(self, cita) -> str:
        usuario = cita.profesional.usuario
        return f"{usuario.nombre} {usuario.apellido}"


class CancelacionSerializer(serializers.Serializer):
    """Cuerpo de POST /api/citas/<id>/cancelar/. El motivo es opcional."""

    motivo = serializers.CharField(required=False, allow_blank=True, max_length=200)


class ReagendamientoSerializer(serializers.Serializer):
    """Cuerpo de POST /api/citas/<id>/reagendar/: solo el nuevo inicio."""

    inicio = serializers.DateTimeField()


class BloqueoSerializer(serializers.ModelSerializer):
    class Meta:
        model = BloqueoHorario
        fields = ["id", "inicio", "fin", "motivo", "creado_en"]
        read_only_fields = ["id", "creado_en"]


class CitaAgendaSerializer(CitaSerializer):
    """Cita en la agenda del profesional: suma quién es el paciente, para abrir su ficha."""

    paciente = serializers.UUIDField(source="paciente_id", read_only=True)
    paciente_nombre = serializers.SerializerMethodField()
    tiene_atencion = serializers.SerializerMethodField()

    class Meta(CitaSerializer.Meta):
        fields = [*CitaSerializer.Meta.fields, "paciente", "paciente_nombre", "tiene_atencion"]
        read_only_fields = fields

    def get_paciente_nombre(self, cita) -> str:
        usuario = cita.paciente.usuario
        return f"{usuario.nombre} {usuario.apellido}"

    def get_tiene_atencion(self, cita) -> bool:
        return hasattr(cita, "atencion")


class AgendaDelDiaSerializer(serializers.Serializer):
    """Parámetros de GET /api/agenda-del-dia/. Sin fecha, el día de hoy."""

    fecha = serializers.DateField(required=False)


class NotificacionSerializer(serializers.ModelSerializer):
    """Sin el error técnico del envío: eso es para el administrador."""

    class Meta:
        model = Notificacion
        fields = [
            "id",
            "tipo",
            "cita",
            "asunto",
            "cuerpo",
            "programada_para",
            "estado",
            "enviada_en",
        ]
        read_only_fields = fields
