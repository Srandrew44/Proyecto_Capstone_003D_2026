from django.core.exceptions import ValidationError as DjangoValidationError
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.agenda import selectors, services
from apps.agenda.horarios import horarios_libres
from apps.auditoria.services import ip_de
from apps.clinica.services import ConsentimientoRequerido
from apps.cuentas.api.views import a_error_drf
from apps.cuentas.permissions import EsDuenoDelRecurso, EsPaciente, EsProfesional

from .serializers import (
    AgendaDelDiaSerializer,
    BloqueoSerializer,
    CancelacionSerializer,
    CitaAgendaSerializer,
    CitaSerializer,
    DisponibilidadSerializer,
    HorariosLibresSerializer,
    NotificacionSerializer,
    ProfesionalSerializer,
    ReagendamientoSerializer,
    ReservaSerializer,
    TratamientoSerializer,
)


class TratamientosView(APIView):
    """GET: tratamientos activos, para cualquier usuario con sesión."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response(TratamientoSerializer(selectors.tratamientos_activos(), many=True).data)


class ProfesionalesView(APIView):
    """GET: podólogos activos, para que el paciente elija con quién reservar."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        profesionales = selectors.profesionales_para_reservar()
        return Response(ProfesionalSerializer(profesionales, many=True).data)


class ConsultaView(APIView):
    """GET: dónde atienden los podólogos (consulta fija), para cualquier usuario con sesión."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response(selectors.datos_consulta())


class HorariosLibresView(APIView):
    """GET: horarios que se pueden reservar con un profesional y un tratamiento."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        consulta = HorariosLibresSerializer(data=request.query_params)
        consulta.is_valid(raise_exception=True)
        datos = consulta.validated_data
        libres = horarios_libres(
            profesional=datos["profesional"],
            tratamiento=datos["tratamiento"],
            desde=datos["desde"],
            hasta=datos["hasta"],
        )
        return Response({"horarios": [horario.isoformat() for horario in libres]})


class CitasView(APIView):
    """GET: mis citas (como paciente o como profesional). POST: reservar, solo pacientes."""

    def get_permissions(self):
        if self.request.method == "POST":
            return [IsAuthenticated(), EsPaciente()]
        return [IsAuthenticated()]

    def get(self, request):
        return Response(CitaSerializer(selectors.citas_de(request.user), many=True).data)

    def post(self, request):
        serializer = ReservaSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            cita = services.reservar_cita(
                paciente=request.user.paciente, ip=ip_de(request), **serializer.validated_data
            )
        except ConsentimientoRequerido:
            return Response(
                {"detail": "Debes aceptar el consentimiento de datos para reservar."},
                status=status.HTTP_403_FORBIDDEN,
            )
        except DjangoValidationError as exc:
            raise a_error_drf(exc) from exc
        return Response(CitaSerializer(cita).data, status=status.HTTP_201_CREATED)


class CancelarCitaView(APIView):
    """POST: cancela una cita propia. El paciente hasta 24 h antes; el profesional siempre."""

    permission_classes = [IsAuthenticated, EsDuenoDelRecurso]

    def post(self, request, pk):
        # Se busca solo entre las citas propias: la ajena responde 404, no 403, para no
        # confirmar que existe.
        cita = get_object_or_404(selectors.citas_de(request.user), pk=pk)
        self.check_object_permissions(request, cita)
        cuerpo = CancelacionSerializer(data=request.data)
        cuerpo.is_valid(raise_exception=True)
        try:
            cita = services.cancelar_cita(
                cita=cita, usuario=request.user, ip=ip_de(request), **cuerpo.validated_data
            )
        except DjangoValidationError as exc:
            raise a_error_drf(exc) from exc
        return Response(CitaSerializer(cita).data)


class ReagendarCitaView(APIView):
    """POST: mueve una cita propia a otro horario libre del mismo profesional."""

    permission_classes = [IsAuthenticated, EsDuenoDelRecurso]

    def post(self, request, pk):
        # Igual que al cancelar: la cita ajena responde 404.
        cita = get_object_or_404(selectors.citas_de(request.user), pk=pk)
        self.check_object_permissions(request, cita)
        cuerpo = ReagendamientoSerializer(data=request.data)
        cuerpo.is_valid(raise_exception=True)
        try:
            cita = services.reagendar_cita(
                cita=cita, usuario=request.user, ip=ip_de(request), **cuerpo.validated_data
            )
        except DjangoValidationError as exc:
            raise a_error_drf(exc) from exc
        return Response(CitaSerializer(cita).data)


class DisponibilidadesView(APIView):
    """GET: tramos propios. POST: crea un tramo."""

    permission_classes = [IsAuthenticated, EsProfesional]

    def get(self, request):
        tramos = selectors.disponibilidades_de(request.user)
        return Response(DisponibilidadSerializer(tramos, many=True).data)

    def post(self, request):
        serializer = DisponibilidadSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            tramo = services.crear_disponibilidad(
                profesional=request.user.profesional, **serializer.validated_data
            )
        except DjangoValidationError as exc:
            raise a_error_drf(exc) from exc
        return Response(DisponibilidadSerializer(tramo).data, status=status.HTTP_201_CREATED)


class DisponibilidadDetalleView(APIView):
    """PATCH: edita o desactiva un tramo propio. No hay DELETE."""

    permission_classes = [IsAuthenticated, EsProfesional, EsDuenoDelRecurso]

    def patch(self, request, pk):
        # El tramo ajeno responde 404, no 403, para no confirmar que existe.
        tramo = get_object_or_404(selectors.disponibilidades_de(request.user), pk=pk)
        self.check_object_permissions(request, tramo)
        serializer = DisponibilidadSerializer(tramo, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        try:
            tramo = services.actualizar_disponibilidad(tramo=tramo, **serializer.validated_data)
        except DjangoValidationError as exc:
            raise a_error_drf(exc) from exc
        return Response(DisponibilidadSerializer(tramo).data)


class BloqueosView(APIView):
    """GET: bloqueos propios. POST: bloquea un periodo de la agenda propia."""

    permission_classes = [IsAuthenticated, EsProfesional]

    def get(self, request):
        bloqueos = selectors.bloqueos_de(request.user)
        return Response(BloqueoSerializer(bloqueos, many=True).data)

    def post(self, request):
        serializer = BloqueoSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            bloqueo = services.crear_bloqueo(
                profesional=request.user.profesional, **serializer.validated_data
            )
        except DjangoValidationError as exc:
            raise a_error_drf(exc) from exc
        return Response(BloqueoSerializer(bloqueo).data, status=status.HTTP_201_CREATED)


class BloqueoDetalleView(APIView):
    """DELETE: quita un bloqueo propio y libera esos horarios."""

    permission_classes = [IsAuthenticated, EsProfesional, EsDuenoDelRecurso]

    def delete(self, request, pk):
        # El bloqueo ajeno responde 404, no 403, para no confirmar que existe.
        bloqueo = get_object_or_404(selectors.bloqueos_de(request.user), pk=pk)
        self.check_object_permissions(request, bloqueo)
        services.eliminar_bloqueo(bloqueo=bloqueo)
        return Response(status=status.HTTP_204_NO_CONTENT)


class AgendaDelDiaView(APIView):
    """GET: citas del profesional en un día, con el nombre del paciente."""

    permission_classes = [IsAuthenticated, EsProfesional]

    def get(self, request):
        consulta = AgendaDelDiaSerializer(data=request.query_params)
        consulta.is_valid(raise_exception=True)
        fecha = consulta.validated_data.get("fecha", timezone.localdate())
        citas = selectors.agenda_del_dia(request.user, fecha).select_related("atencion")
        return Response(
            {"fecha": fecha.isoformat(), "citas": CitaAgendaSerializer(citas, many=True).data}
        )


class InasistenciaView(APIView):
    """POST: el profesional registra que el paciente no llegó a una cita ya comenzada."""

    permission_classes = [IsAuthenticated, EsProfesional]

    def post(self, request, pk):
        cita = get_object_or_404(
            selectors.citas_de(request.user), pk=pk, profesional=request.user.pk
        )
        try:
            cita = services.marcar_inasistencia(cita=cita, usuario=request.user, ip=ip_de(request))
        except DjangoValidationError as exc:
            raise a_error_drf(exc) from exc
        return Response(CitaSerializer(cita).data)


class NotificacionesView(APIView):
    """GET: correos del propio usuario (paciente o profesional), con su estado de envío."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        notificaciones = selectors.notificaciones_de(request.user)[:100]
        return Response(NotificacionSerializer(notificaciones, many=True).data)
