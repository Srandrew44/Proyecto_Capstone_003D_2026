"""Consultas de lectura de agenda. Todo dato se filtra por el usuario que pregunta."""

from django.conf import settings
from django.db.models import Q

from apps.cuentas.models import Profesional

from .models import BloqueoHorario, Cita, Disponibilidad, Notificacion, Tratamiento


def tratamientos_activos():
    """Catálogo reservable. Es público para cualquier usuario con sesión."""
    return Tratamiento.objects.filter(activo=True)


def profesionales_activos():
    """Podólogos entre los que el paciente puede elegir. Solo datos de presentación."""
    return (
        Profesional.objects.filter(usuario__is_active=True)
        .select_related("usuario")
        .defer("foto")  # la imagen se pide aparte (/podologos/<id>/foto/)
        .order_by("usuario__apellido", "usuario__nombre")
    )


def profesionales_para_reservar():
    """Los activos que tienen al menos un tramo de horario activo: con los demás no hay horas
    que ofrecer (p. ej. un podólogo recién creado que aún no configura su horario)."""
    return profesionales_activos().filter(disponibilidades__activa=True).distinct()


def tiene_horario(profesional) -> bool:
    return profesional.disponibilidades.filter(activa=True).exists()


def disponibilidades_de(usuario):
    """Tramos del propio profesional: nadie ve ni toca los de otro."""
    return Disponibilidad.objects.filter(profesional_id=usuario.pk)


def citas_de(usuario):
    """Citas del propio usuario, como paciente o como profesional: nadie ve las de otro."""
    return Cita.objects.filter(
        Q(paciente_id=usuario.pk) | Q(profesional_id=usuario.pk)
    ).select_related("profesional__usuario", "tratamiento")


def datos_consulta() -> dict:
    """Consulta fija donde atienden los podólogos. Se configura por entorno."""
    return {
        "nombre": settings.CONSULTA_NOMBRE,
        "direccion": settings.CONSULTA_DIRECCION,
        "comuna": settings.CONSULTA_COMUNA,
        "indicaciones": settings.CONSULTA_INDICACIONES,
        "telefono": settings.CONSULTA_TELEFONO,
        "correo": settings.CONSULTA_CORREO,
        "horario": settings.CONSULTA_HORARIO,
    }


def bloqueos_de(usuario):
    """Bloqueos del propio profesional: nadie ve ni borra los de otro."""
    return BloqueoHorario.objects.filter(profesional_id=usuario.pk)


def agenda_del_dia(usuario, fecha):
    """Citas del profesional en un día (hora local), con el paciente para abrir su ficha."""
    return (
        Cita.objects.filter(profesional_id=usuario.pk, inicio__date=fecha)
        .select_related("paciente__usuario", "tratamiento", "profesional__usuario")
        .order_by("inicio")
    )


def notificaciones_de(usuario):
    """Correos dirigidos al propio usuario, del más reciente al más antiguo."""
    return Notificacion.objects.filter(destinatario_id=usuario.pk).exclude(
        estado=Notificacion.Estado.ANULADA
    )
