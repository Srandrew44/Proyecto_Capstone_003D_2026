"""Reglas de negocio de agenda. Las vistas solo traducen la solicitud y la respuesta."""

from contextlib import contextmanager
from datetime import timedelta

from django.conf import settings
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import IntegrityError, transaction
from django.utils import timezone

from apps.auditoria.models import RegistroAuditoria
from apps.auditoria.services import registrar
from apps.clinica.models import Consentimiento
from apps.clinica.services import exigir_consentimiento
from apps.cuentas.models import Paciente, Profesional
from apps.pagos import services as pagos

from . import notificaciones
from .horarios import horarios_libres
from .models import BloqueoHorario, Cita, Disponibilidad

CAMPOS_EDITABLES = {"dia_semana", "hora_inicio", "hora_fin", "activa"}
ESTADOS_CANCELABLES = (Cita.Estado.AGENDADA, Cita.Estado.CONFIRMADA)
# Las que ocupan una hora a futuro y cuentan para el tope de citas por paciente.
ESTADOS_ACTIVOS = (*ESTADOS_CANCELABLES, Cita.Estado.PENDIENTE_PAGO)
MOTIVO_MAX = 200  # largo de Cita.motivo_cancelacion


def _guardar(tramo: Disponibilidad) -> Disponibilidad:
    """Guarda el tramo y traduce el choque con la restricción de no solapamiento."""
    try:
        with transaction.atomic():
            tramo.save()
    except IntegrityError as exc:
        if "disponibilidad_sin_solapamiento" in str(exc):
            raise ValidationError(
                "El tramo se solapa con otro tramo activo del mismo día."
            ) from exc
        raise
    return tramo


def crear_disponibilidad(
    *, profesional, dia_semana, hora_inicio, hora_fin, activa=True
) -> Disponibilidad:
    return _guardar(
        Disponibilidad(
            profesional=profesional,
            dia_semana=dia_semana,
            hora_inicio=hora_inicio,
            hora_fin=hora_fin,
            activa=activa,
        )
    )


def actualizar_disponibilidad(*, tramo: Disponibilidad, ahora=None, **cambios) -> Disponibilidad:
    """Edita o desactiva un tramo. No se borra: se desactiva con activa=False.

    Si el cambio deja fuera del horario citas futuras ya reservadas, no se permite (igual que
    un bloqueo): el error dice cuáles son, para cancelarlas o reagendarlas primero.
    """
    desconocidos = set(cambios) - CAMPOS_EDITABLES
    if desconocidos:
        raise ValueError(f"Campos no editables: {sorted(desconocidos)}")
    with transaction.atomic():
        # Con la agenda tomada, nadie reserva en ese horario mientras se valida el cambio.
        _bloquear_agenda(tramo.profesional)
        pagos.vencer_pendientes(ahora=ahora, profesional=tramo.profesional)
        for campo, valor in cambios.items():
            setattr(tramo, campo, valor)
        validar_cambio_de_tramo(tramo, ahora=ahora)
        return _guardar(tramo)


def validar_cambio_de_tramo(tramo: Disponibilidad, *, ahora=None) -> None:
    """Rechaza el cambio si deja citas futuras fuera de todo tramo activo del profesional.

    `tramo` trae los valores nuevos (sin guardar). Revisa las citas activas que caían en el
    tramo tal como está guardado. La usan el servicio y el formulario del admin.
    """
    if tramo.pk is None:
        return
    original = Disponibilidad.objects.filter(pk=tramo.pk).first()
    if original is None or not original.activa:
        return  # un tramo inactivo no tenía citas que perder
    ahora = ahora or timezone.now()
    otros = list(
        Disponibilidad.objects.filter(profesional_id=tramo.profesional_id, activa=True).exclude(
            pk=tramo.pk
        )
    )
    vigentes = [*otros, tramo] if tramo.activa else otros

    def dentro(tramo_, inicio, fin) -> bool:
        return (
            tramo_.dia_semana == inicio.weekday()
            and tramo_.hora_inicio <= inicio.time()
            and fin.time() <= tramo_.hora_fin
            and fin.date() == inicio.date()
        )

    perdidas = []
    citas = Cita.objects.filter(
        profesional=tramo.profesional, estado__in=ESTADOS_ACTIVOS, fin__gt=ahora
    ).order_by("inicio")
    for cita in citas:
        inicio, fin = timezone.localtime(cita.inicio), timezone.localtime(cita.fin)
        if dentro(original, inicio, fin) and not any(dentro(t, inicio, fin) for t in vigentes):
            perdidas.append(inicio)
    if perdidas:
        horas = ", ".join(f"{inicio:%d/%m/%Y %H:%M}" for inicio in perdidas)
        raise ValidationError(
            f"Hay citas reservadas en este horario ({horas}). Cancélalas o reagéndalas antes "
            "de quitar o cambiar este tramo."
        )


def reservar_cita(
    *,
    paciente,
    profesional,
    tratamiento,
    inicio,
    comentarios_paciente="",
    ip=None,
    ahora=None,
    sin_cobro=False,
) -> Cita:
    """Reserva una cita con el profesional que eligió el paciente.

    Si el tratamiento se paga en línea (`pagos.requiere_pago`), la cita nace pendiente de pago
    con su `Pago`, y la confirmación y el correo llegan cuando Webpay aprueba. Si no, nace
    confirmada.

    Se valida, en este orden: consentimiento `tratamiento_datos` vigente, tratamiento activo,
    profesional activo y que `inicio` sea exactamente uno de los horarios libres (así se
    aplican la anticipación mínima, el horizonte, los tramos y la pausa entre citas).
    Si dos personas reservan a la vez con el mismo profesional, la segunda espera a la primera
    y vuelve a calcular los horarios; las restricciones de la base quedan de respaldo.
    El precio se copia del tratamiento y ya no cambia. La reserva queda en la auditoría en la
    misma transacción, sin los comentarios del paciente.

    Para que nadie retenga la agenda reservando sin pagar, un paciente tiene a lo más una
    reserva esperando pago y `AGENDA_MAX_CITAS_FUTURAS` citas activas a futuro (ver
    `_exigir_cupo_del_paciente`).

    `sin_cobro=True` reserva confirmada sin pasar por Webpay. Solo lo usa el escenario de
    demostración (sus citas no tienen quién las pague); ninguna vista ni la API lo exponen.
    """
    if timezone.is_naive(inicio):
        raise ValueError("`inicio` debe incluir la zona horaria.")

    exigir_consentimiento(paciente, Consentimiento.Tipo.TRATAMIENTO_DATOS)
    if not tratamiento.activo:
        raise ValidationError({"tratamiento": ["El tratamiento no está disponible."]})
    if not profesional.usuario.is_active:
        raise ValidationError({"profesional": ["El profesional no está disponible."]})

    con_pago = not sin_cobro and pagos.requiere_pago(tratamiento)
    with transaction.atomic():
        _bloquear_agenda(profesional)
        _bloquear_paciente(paciente)
        # Las horas retenidas por pagos que vencieron se liberan antes de calcular.
        pagos.vencer_pendientes(ahora=ahora, profesional=profesional)
        pagos.vencer_pendientes(ahora=ahora, paciente=paciente)
        _exigir_cupo_del_paciente(paciente, ahora or timezone.now())
        _exigir_horario_libre(
            profesional=profesional, tratamiento=tratamiento, inicio=inicio, ahora=ahora
        )
        with _choques_como_error():
            cita = Cita.objects.create(
                estado=Cita.Estado.PENDIENTE_PAGO if con_pago else Cita.Estado.CONFIRMADA,
                paciente=paciente,
                profesional=profesional,
                tratamiento=tratamiento,
                inicio=inicio,
                fin=inicio + timedelta(minutes=tratamiento.duracion_min),
                precio=tratamiento.precio,
                comentarios_paciente=comentarios_paciente,
            )
        registrar(
            accion=RegistroAuditoria.Accion.RESERVAR_CITA,
            usuario=paciente.usuario,
            recurso_tipo="cita",
            recurso_id=cita.pk,
            ip=ip,
        )
        if con_pago:
            pagos.crear_pago(cita, ahora=ahora)
        else:
            notificaciones.notificar_reserva(cita, ahora=ahora)
    return cita


def _bloquear_agenda(profesional) -> None:
    """Toma la fila del profesional hasta el fin de la transacción.

    Así dos operaciones sobre la misma agenda (reservar, reagendar, bloquear) no calculan los
    horarios libres a la vez: la base solo impide cruces directos, no la pausa entre citas.
    """
    Profesional.objects.select_for_update().filter(pk=profesional.pk).exists()


def _bloquear_paciente(paciente) -> None:
    """Toma la fila del paciente hasta el fin de la transacción.

    Sin esto, dos reservas a la vez del mismo paciente con profesionales distintos (cada una
    con su agenda bloqueada) podrían pasar las dos el tope de `_exigir_cupo_del_paciente`.
    Se toma después de la agenda, siempre en ese orden, para no cruzar bloqueos.
    """
    Paciente.objects.select_for_update().filter(pk=paciente.pk).exists()


def _exigir_cupo_del_paciente(paciente, ahora) -> None:
    """Límites para que un paciente no retenga la agenda reservando sin pagar.

    - Una sola reserva esperando pago a la vez (las vencidas ya se liberaron antes). Incluye
      la que se está verificando con Transbank: esa hora sigue retenida.
    - A lo más `AGENDA_MAX_CITAS_FUTURAS` citas activas (pendientes de pago, agendadas o
      confirmadas) que aún no comienzan.
    """
    futuras = Cita.objects.filter(paciente=paciente, inicio__gt=ahora)
    if futuras.filter(estado=Cita.Estado.PENDIENTE_PAGO).exists():
        raise ValidationError(
            {
                "inicio": [
                    "Ya tienes una reserva esperando pago. Complétala desde «Mis citas» o "
                    "espera a que venza su plazo antes de reservar otra hora."
                ]
            }
        )
    tope = settings.AGENDA_MAX_CITAS_FUTURAS
    if futuras.filter(estado__in=ESTADOS_ACTIVOS).count() >= tope:
        raise ValidationError(
            {
                "inicio": [
                    "Ya tienes el máximo de citas próximas que se pueden reservar en línea "
                    f"({tope}). Para otra hora, comunícate con la consulta."
                ]
            }
        )


def _exigir_horario_libre(*, profesional, tratamiento, inicio, ahora, excluir=None) -> None:
    dia = timezone.localtime(inicio).date()
    libres = horarios_libres(
        profesional=profesional,
        tratamiento=tratamiento,
        desde=dia,
        hasta=dia,
        ahora=ahora,
        excluir=excluir,
    )
    if inicio not in libres:
        raise ValidationError({"inicio": ["Ese horario no está disponible."]})


@contextmanager
def _choques_como_error():
    """Traduce el choque con las restricciones de no solapamiento de Cita a un error claro."""
    try:
        with transaction.atomic():
            yield
    except IntegrityError as exc:
        if "cita_paciente_sin_solapamiento" in str(exc):
            raise ValidationError(
                {"inicio": ["Ya tienes una cita que se cruza con ese horario."]}
            ) from exc
        if "cita_profesional_sin_solapamiento" in str(exc):
            raise ValidationError(
                {"inicio": ["Ese horario ya fue reservado por otra persona."]}
            ) from exc
        raise


def cancelar_cita(*, cita, usuario, motivo="", ip=None, ahora=None) -> Cita:
    """Cancela una cita propia y libera el horario.

    Solo la cancelan el paciente y el profesional de esa cita (otra persona recibe
    `PermissionDenied`). El paciente puede hasta `AGENDA_CANCELACION_MIN_HORAS` horas antes;
    el profesional, siempre que la cita no haya comenzado. Solo se cancelan citas agendadas o
    confirmadas. Deja registro de auditoría sin el motivo, que es texto libre del usuario.
    Si la cita estaba pagada, se reembolsa (quien cancele y con la anticipación que sea).
    """
    if not cita.es_de(usuario):
        raise PermissionDenied("La cita no pertenece al usuario.")
    motivo = motivo.strip()
    if len(motivo) > MOTIVO_MAX:
        raise ValidationError({"motivo": [f"No puede superar los {MOTIVO_MAX} caracteres."]})
    ahora = ahora or timezone.now()

    with transaction.atomic():
        # Se bloquea solo la fila de la cita: dos cancelaciones simultáneas no se pisan.
        cita = _cita_bloqueada(cita)
        es_profesional = _exigir_modificable(cita, usuario, ahora, verbo="cancelar")

        cita.estado = Cita.Estado.CANCELADA
        cita.cancelada_en = ahora
        cita.motivo_cancelacion = motivo
        cita.save(update_fields=["estado", "cancelada_en", "motivo_cancelacion"])
        registrar(
            accion=RegistroAuditoria.Accion.CANCELAR_CITA,
            usuario=usuario,
            recurso_tipo="cita",
            recurso_id=cita.pk,
            ip=ip,
            detalle={"por": "profesional" if es_profesional else "paciente"},
        )
        pago = pagos.marcar_reembolso(cita)
        notificaciones.notificar_cancelacion(
            cita,
            por="profesional" if es_profesional else "paciente",
            reembolso=pago.monto if pago else None,
        )
    if pago is not None:
        pagos.reembolsar(pago, ahora=ahora)
    return cita


def reagendar_cita(*, cita, usuario, inicio, ip=None, ahora=None) -> Cita:
    """Mueve una cita propia a otro horario libre del mismo profesional.

    Se mueve la misma cita: conserva su id, tratamiento, precio y duración original. Las
    reglas de quién y hasta cuándo son las de la cancelación (el paciente hasta
    `AGENDA_CANCELACION_MIN_HORAS` horas antes de la cita original; el profesional mientras
    no haya comenzado), y el horario nuevo debe ser uno de los horarios libres, con las
    mismas reglas que una reserva. Deja registro de auditoría con la hora anterior.
    """
    if timezone.is_naive(inicio):
        raise ValueError("`inicio` debe incluir la zona horaria.")
    if not cita.es_de(usuario):
        raise PermissionDenied("La cita no pertenece al usuario.")
    ahora = ahora or timezone.now()

    with transaction.atomic():
        _bloquear_agenda(cita.profesional)
        pagos.vencer_pendientes(ahora=ahora, profesional=cita.profesional)
        cita = _cita_bloqueada(cita)
        es_profesional = _exigir_modificable(cita, usuario, ahora, verbo="reagendar")
        if inicio == cita.inicio:
            raise ValidationError({"inicio": ["La cita ya está en ese horario."]})
        _exigir_horario_libre(
            profesional=cita.profesional,
            tratamiento=cita.tratamiento,
            inicio=inicio,
            ahora=ahora,
            excluir=cita,
        )

        anterior = cita.inicio
        cita.fin = inicio + (cita.fin - cita.inicio)
        cita.inicio = inicio
        with _choques_como_error():
            cita.save(update_fields=["inicio", "fin"])
        registrar(
            accion=RegistroAuditoria.Accion.REAGENDAR_CITA,
            usuario=usuario,
            recurso_tipo="cita",
            recurso_id=cita.pk,
            ip=ip,
            detalle={
                "por": "profesional" if es_profesional else "paciente",
                "inicio_anterior": timezone.localtime(anterior).isoformat(),
            },
        )
        notificaciones.notificar_reagendamiento(
            cita,
            anterior=anterior,
            por="profesional" if es_profesional else "paciente",
            ahora=ahora,
        )
    return cita


def _cita_bloqueada(cita) -> Cita:
    return (
        Cita.objects.select_for_update(of=("self",))
        .select_related("profesional__usuario", "tratamiento")
        .get(pk=cita.pk)
    )


def _exigir_modificable(cita, usuario, ahora, *, verbo) -> bool:
    """Reglas comunes de cancelar y reagendar. Devuelve si quien actúa es el profesional."""
    if cita.estado == Cita.Estado.CANCELADA:
        raise ValidationError({"cita": ["La cita ya está cancelada."]})
    if cita.estado == Cita.Estado.PENDIENTE_PAGO:
        raise ValidationError({"cita": ["La cita aún no está pagada."]})
    if cita.estado not in ESTADOS_CANCELABLES:
        raise ValidationError({"cita": [f"Esta cita ya no se puede {verbo}."]})
    if cita.inicio <= ahora:
        raise ValidationError({"cita": ["La cita ya comenzó o ya pasó."]})

    es_profesional = usuario.pk == cita.profesional_id
    horas = settings.AGENDA_CANCELACION_MIN_HORAS
    if not es_profesional and ahora > cita.inicio - timedelta(hours=horas):
        raise ValidationError(
            {
                "cita": [
                    f"Solo puedes {verbo} hasta {horas} horas antes de la cita. "
                    "Comunícate con la consulta."
                ]
            }
        )
    return es_profesional


def validar_bloqueo(*, profesional, inicio, fin, motivo="", ahora=None) -> None:
    """Reglas de un bloqueo de horario. La usan el servicio y el formulario del admin.

    El bloqueo debe terminar en el futuro y no puede cruzar citas activas (agendadas o
    confirmadas) del profesional: el error dice cuáles son, para cancelarlas o reagendarlas.
    """
    if timezone.is_naive(inicio) or timezone.is_naive(fin):
        raise ValueError("`inicio` y `fin` deben incluir la zona horaria.")
    if fin <= inicio:
        raise ValidationError({"fin": ["Debe ser posterior al inicio."]})
    if fin <= (ahora or timezone.now()):
        raise ValidationError({"fin": ["El bloqueo ya terminó."]})
    if len(motivo) > MOTIVO_MAX:
        raise ValidationError({"motivo": [f"No puede superar los {MOTIVO_MAX} caracteres."]})

    cruzadas = Cita.objects.filter(
        profesional=profesional,
        estado__in=(*ESTADOS_CANCELABLES, Cita.Estado.PENDIENTE_PAGO),
        inicio__lt=fin,
        fin__gt=inicio,
    ).order_by("inicio")
    if cruzadas.exists():
        horas = ", ".join(f"{timezone.localtime(c.inicio):%d/%m/%Y %H:%M}" for c in cruzadas)
        raise ValidationError(
            {
                "inicio": [
                    f"El bloqueo cruza citas reservadas ({horas}). "
                    "Cancélalas o reagéndalas antes de bloquear ese horario."
                ]
            }
        )


def crear_bloqueo(*, profesional, inicio, fin, motivo="", ahora=None) -> BloqueoHorario:
    """Bloquea un periodo de la agenda: desde ahí ya no se ofrecen esos horarios."""
    motivo = motivo.strip()
    with transaction.atomic():
        # Con la agenda tomada, nadie reserva dentro del periodo mientras se valida.
        _bloquear_agenda(profesional)
        pagos.vencer_pendientes(ahora=ahora, profesional=profesional)
        validar_bloqueo(profesional=profesional, inicio=inicio, fin=fin, motivo=motivo, ahora=ahora)
        return BloqueoHorario.objects.create(
            profesional=profesional, inicio=inicio, fin=fin, motivo=motivo
        )


def eliminar_bloqueo(*, bloqueo: BloqueoHorario) -> None:
    """Quita un bloqueo y devuelve esos horarios a la agenda. No es un dato histórico."""
    bloqueo.delete()


def marcar_inasistencia(*, cita, usuario, ip=None, ahora=None) -> Cita:
    """El profesional registra que el paciente no llegó. Solo una cita propia ya comenzada."""
    if usuario.pk != cita.profesional_id:
        raise PermissionDenied("Solo el profesional de la cita registra la inasistencia.")
    ahora = ahora or timezone.now()
    with transaction.atomic():
        cita = _cita_bloqueada(cita)
        if cita.estado not in ESTADOS_CANCELABLES:
            raise ValidationError({"cita": ["La cita no admite registrar inasistencia."]})
        if cita.inicio > ahora:
            raise ValidationError({"cita": ["La cita aún no comienza."]})
        cita.estado = Cita.Estado.NO_ASISTIO
        cita.save(update_fields=["estado"])
        registrar(
            accion=RegistroAuditoria.Accion.MARCAR_INASISTENCIA,
            usuario=usuario,
            recurso_tipo="cita",
            recurso_id=cita.pk,
            ip=ip,
        )
    return cita
