from django import forms
from django.contrib import admin
from django.core.exceptions import ValidationError

from .models import BloqueoHorario, Cita, Disponibilidad, Notificacion, Tratamiento
from .services import (
    CAMPOS_EDITABLES,
    actualizar_disponibilidad,
    crear_bloqueo,
    crear_disponibilidad,
)


@admin.register(Tratamiento)
class TratamientoAdmin(admin.ModelAdmin):
    fields = ("nombre", "descripcion", "descripcion_detallada", "duracion_min", "precio", "activo")
    list_display = ("nombre", "duracion_min", "precio", "activo")
    list_filter = ("activo",)
    search_fields = ("nombre",)

    def has_delete_permission(self, request, obj=None):
        return False


class DisponibilidadForm(forms.ModelForm):
    """Muestra en el formulario el error del servicio (p. ej., citas que quedarían fuera)."""

    error_servicio = None

    class Meta:
        model = Disponibilidad
        fields = ["profesional", "dia_semana", "hora_inicio", "hora_fin", "activa"]

    def clean(self):
        datos = super().clean()
        if self.error_servicio is not None:
            self.add_error(None, self.error_servicio.messages)
        return datos


@admin.register(Disponibilidad)
class DisponibilidadAdmin(admin.ModelAdmin):
    """Guarda con los mismos servicios que el sitio y la API, que revisan las citas reservadas.

    Un tramo no se borra (se desactiva) y no cambia de profesional.
    """

    form = DisponibilidadForm
    list_display = ("profesional", "dia_semana", "hora_inicio", "hora_fin", "activa")
    list_filter = ("dia_semana", "activa")
    list_select_related = ("profesional__usuario",)

    def has_delete_permission(self, request, obj=None):
        return False

    def get_readonly_fields(self, request, obj=None):
        return ("profesional",) if obj else ()

    def get_form(self, request, obj=None, change=False, **kwargs):
        formulario = super().get_form(request, obj, change=change, **kwargs)
        error = getattr(request, "_error_tramo", None)
        if error is not None:
            formulario = type(formulario.__name__, (formulario,), {"error_servicio": error})
        return formulario

    def changeform_view(self, request, object_id=None, form_url="", extra_context=None):
        try:
            return super().changeform_view(request, object_id, form_url, extra_context)
        except ValidationError as exc:
            # Lo lanzó el servicio en save_model; la transacción del admin ya se deshizo.
            request._error_tramo = exc
            return super().changeform_view(request, object_id, form_url, extra_context)

    def save_model(self, request, obj, form, change):
        datos = {campo: form.cleaned_data[campo] for campo in CAMPOS_EDITABLES}
        if change:
            tramo = Disponibilidad.objects.get(pk=obj.pk)
            actualizar_disponibilidad(tramo=tramo, **datos)
        else:
            tramo = crear_disponibilidad(profesional=form.cleaned_data["profesional"], **datos)
            obj.pk = tramo.pk
            obj._state.adding = False


@admin.register(Cita)
class CitaAdmin(admin.ModelAdmin):
    """Solo lectura: las citas se crean y cambian por los servicios, que validan las reglas."""

    list_display = ("inicio", "paciente", "profesional", "tratamiento", "estado", "precio")
    list_filter = ("estado", "profesional")
    list_select_related = ("paciente__usuario", "profesional__usuario", "tratamiento")
    date_hierarchy = "inicio"
    ordering = ("-inicio",)
    search_fields = ("paciente__usuario__email", "paciente__usuario__apellido")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


class BloqueoHorarioForm(forms.ModelForm):
    """Formulario del admin. Las reglas no se validan aquí sino en ``crear_bloqueo``.

    Validar aparte (sin tomar la agenda ni vencer los pagos atrasados) rechazaba bloqueos
    válidos y aceptaba otros que una reserva simultánea volvía inválidos. Si el servicio
    rechaza el bloqueo, el admin vuelve a mostrar este formulario con ``error_servicio``.
    """

    error_servicio = None

    class Meta:
        model = BloqueoHorario
        fields = ["profesional", "inicio", "fin", "motivo"]

    def clean(self):
        datos = super().clean()
        inicio, fin = datos.get("inicio"), datos.get("fin")
        if inicio and fin and fin <= inicio:
            # Lo revisa también el servicio, pero la restricción del modelo se comprueba antes
            # que save_model y su mensaje genérico no le dice nada al usuario.
            raise ValidationError({"fin": ["Debe ser posterior al inicio."]})
        if self.error_servicio is not None:
            error = self.error_servicio
            errores = error.message_dict if hasattr(error, "error_dict") else {None: error.messages}
            for campo, mensajes in errores.items():
                self.add_error(campo if campo in self.fields else None, mensajes)
        return datos


@admin.register(BloqueoHorario)
class BloqueoHorarioAdmin(admin.ModelAdmin):
    """Crea los bloqueos con el mismo servicio que la API y el sitio.

    No se editan: ``crear_bloqueo`` solo crea, y cambiar las horas de un bloqueo debe pasar por
    las mismas reglas. Para cambiar uno se borra y se crea otro.
    """

    form = BloqueoHorarioForm
    list_display = ("profesional", "inicio", "fin", "motivo")
    list_filter = ("profesional",)
    list_select_related = ("profesional__usuario",)
    date_hierarchy = "inicio"
    ordering = ("-inicio",)

    def has_change_permission(self, request, obj=None):
        return False

    def get_form(self, request, obj=None, change=False, **kwargs):
        formulario = super().get_form(request, obj, change=change, **kwargs)
        error = getattr(request, "_error_bloqueo", None)
        if error is not None:
            formulario = type(formulario.__name__, (formulario,), {"error_servicio": error})
        return formulario

    def changeform_view(self, request, object_id=None, form_url="", extra_context=None):
        try:
            return super().changeform_view(request, object_id, form_url, extra_context)
        except ValidationError as exc:
            # Lo lanzó crear_bloqueo en save_model. La transacción del admin ya se deshizo;
            # se vuelve a procesar el envío para mostrar el error en el formulario.
            request._error_bloqueo = exc
            return super().changeform_view(request, object_id, form_url, extra_context)

    def save_model(self, request, obj, form, change):
        creado = crear_bloqueo(
            profesional=obj.profesional, inicio=obj.inicio, fin=obj.fin, motivo=obj.motivo
        )
        # El admin sigue con `obj` (historial y redirección): que apunte al bloqueo creado.
        obj.pk = creado.pk
        obj.motivo = creado.motivo
        obj.creado_en = creado.creado_en
        obj._state.adding = False


@admin.register(Notificacion)
class NotificacionAdmin(admin.ModelAdmin):
    """Solo lectura: sirve para revisar envíos fallidos. Los correos no llevan datos clínicos."""

    list_display = ("programada_para", "tipo", "destinatario", "estado", "intentos", "enviada_en")
    list_filter = ("estado", "tipo")
    list_select_related = ("destinatario",)
    search_fields = ("destinatario__email",)
    ordering = ("-programada_para",)

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
