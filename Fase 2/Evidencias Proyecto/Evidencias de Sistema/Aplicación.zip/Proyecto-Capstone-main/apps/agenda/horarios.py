"""Cálculo de horarios libres para reservar. Solo lee: no crea ni modifica citas."""

from datetime import date, datetime, time, timedelta

from django.conf import settings
from django.utils import timezone

from .models import BloqueoHorario, Cita, Disponibilidad


def _aware(dia: date, hora: time) -> datetime:
    return datetime.combine(dia, hora, tzinfo=timezone.get_current_timezone())


def _liberacion(inicio, duracion, pausa, ocupadas, bloqueos=()):
    """Instante desde el que un horario deja de chocar con citas o bloqueos, o None si no choca.

    Una cita ocupa su horario más la pausa que la sigue, y el horario nuevo también
    necesita su pausa antes de la cita siguiente: entre dos citas debe haber al menos `pausa`.
    Un bloqueo no lleva pausa: como el fin de un tramo, la cita solo debe terminar antes.
    """
    choques = [
        cita_fin + pausa
        for cita_inicio, cita_fin in ocupadas
        if inicio < cita_fin + pausa and cita_inicio < inicio + duracion + pausa
    ]
    choques += [
        bloqueo_fin
        for bloqueo_inicio, bloqueo_fin in bloqueos
        if inicio < bloqueo_fin and bloqueo_inicio < inicio + duracion
    ]
    return max(choques, default=None)


def _generar(
    *, tramos_por_dia, ocupadas, desde, hasta, duracion, pausa, primero, ultimo, bloqueos=()
):
    libres = []
    dia = desde
    while dia <= hasta:
        for tramo in tramos_por_dia.get(dia.weekday(), []):
            fin_tramo = _aware(dia, tramo.hora_fin)
            inicio = _aware(dia, tramo.hora_inicio)
            # La cita debe terminar dentro del tramo; la pausa final no necesita caber.
            while inicio + duracion <= fin_tramo:
                liberacion = _liberacion(inicio, duracion, pausa, ocupadas, bloqueos)
                if liberacion is not None:
                    inicio = liberacion
                    continue
                if primero <= inicio <= ultimo:
                    libres.append(timezone.localtime(inicio))
                inicio += duracion + pausa
        dia += timedelta(days=1)
    return libres


def horarios_libres(
    *,
    profesional,
    tratamiento,
    desde: date,
    hasta: date,
    ahora: datetime | None = None,
    excluir: Cita | None = None,
) -> list[datetime]:
    """Inicios de cita que un paciente puede reservar entre `desde` y `hasta` (inclusive).

    - Cada día se recorren los tramos activos del profesional. En cada tramo los horarios
      parten al inicio y avanzan de a duración + pausa; si una cita no cancelada ocupa el
      lugar, el siguiente horario es el fin de esa cita más la pausa. Si lo ocupa un bloqueo,
      el siguiente horario es el fin del bloqueo.
    - No se ofrece nada antes de `ahora` + anticipación mínima ni después de `ahora` + horizonte
      (AGENDA_ANTICIPACION_MIN_HORAS y AGENDA_HORIZONTE_DIAS).
    - `excluir` es la cita que se está reagendando: no ocupa su propio horario y el cálculo
      usa su duración original, no la actual del tratamiento.
    - Devuelve instantes con la zona horaria local, en orden.
    """
    ahora = ahora or timezone.now()
    primero = ahora + timedelta(hours=settings.AGENDA_ANTICIPACION_MIN_HORAS)
    ultimo = ahora + timedelta(days=settings.AGENDA_HORIZONTE_DIAS)
    hasta = min(hasta, timezone.localtime(ultimo).date())
    if hasta < desde:
        return []

    if excluir is not None:
        duracion = excluir.fin - excluir.inicio
    else:
        duracion = timedelta(minutes=tratamiento.duracion_min)
    pausa = timedelta(minutes=profesional.pausa_entre_citas_min)

    tramos_por_dia: dict[int, list[Disponibilidad]] = {}
    tramos = Disponibilidad.objects.filter(profesional=profesional, activa=True)
    for tramo in tramos.order_by("hora_inicio"):
        tramos_por_dia.setdefault(tramo.dia_semana, []).append(tramo)

    citas = Cita.objects.filter(
        profesional=profesional,
        inicio__lt=_aware(hasta + timedelta(days=1), time.min) + pausa,
        fin__gt=_aware(desde, time.min) - pausa,
    ).exclude(estado=Cita.Estado.CANCELADA)
    # Una hora retenida por un pago que ya venció está libre (se cancela al reservar). Solo
    # si el pago sigue pendiente: uno "por verificar" pudo cobrarse y retiene la hora.
    citas = citas.exclude(
        estado=Cita.Estado.PENDIENTE_PAGO, pago__estado="pendiente", pago__vence_en__lte=ahora
    )
    if excluir is not None:
        citas = citas.exclude(pk=excluir.pk)
    ocupadas = list(citas.values_list("inicio", "fin"))
    bloqueos = list(
        BloqueoHorario.objects.filter(
            profesional=profesional,
            inicio__lt=_aware(hasta + timedelta(days=1), time.min),
            fin__gt=_aware(desde, time.min),
        ).values_list("inicio", "fin")
    )

    return _generar(
        tramos_por_dia=tramos_por_dia,
        ocupadas=ocupadas,
        bloqueos=bloqueos,
        desde=desde,
        hasta=hasta,
        duracion=duracion,
        pausa=pausa,
        primero=primero,
        ultimo=ultimo,
    )
