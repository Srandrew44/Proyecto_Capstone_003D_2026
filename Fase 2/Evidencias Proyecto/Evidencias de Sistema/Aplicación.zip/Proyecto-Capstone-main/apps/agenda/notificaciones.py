"""Correos de la agenda: se programan junto con el cambio de la cita y se envían aparte.

Los servicios de agenda llaman a `notificar_*` dentro de su transacción, así el correo queda
registrado solo si el cambio se guardó. `enviar_pendientes` (comando `enviar_notificaciones`)
los manda con reintentos. Los textos nunca llevan datos clínicos: ni el tratamiento, ni los
comentarios del paciente, ni el motivo de cancelación.
"""

import logging
from datetime import timedelta

from django.conf import settings
from django.core.mail import send_mail
from django.db import transaction
from django.utils import timezone

from .models import Cita, Notificacion

logger = logging.getLogger(__name__)

Tipo = Notificacion.Tipo
Estado = Notificacion.Estado
ESPERA_REINTENTO = timedelta(minutes=5)  # se multiplica por el número de intento


# --- textos ---


def _cuando(inicio) -> str:
    local = timezone.localtime(inicio)
    return f"el {local:%d/%m/%Y} a las {local:%H:%M}"


def _nombre(usuario) -> str:
    return f"{usuario.nombre} {usuario.apellido}"


def _lugar() -> str:
    lineas = [settings.CONSULTA_NOMBRE]
    direccion = ", ".join(p for p in (settings.CONSULTA_DIRECCION, settings.CONSULTA_COMUNA) if p)
    if direccion:
        lineas.append(direccion)
    if settings.CONSULTA_INDICACIONES:
        lineas.append(settings.CONSULTA_INDICACIONES)
    return "\n".join(lineas)


def _plazo() -> str:
    horas = settings.AGENDA_CANCELACION_MIN_HORAS
    return f"Puedes cancelar o reagendar desde la aplicación hasta {horas} horas antes."


def _texto_paciente(cita, *lineas) -> str:
    saludo = f"Hola {cita.paciente.usuario.nombre}:"
    profesional = f"Profesional: {_nombre(cita.profesional.usuario)}"
    return "\n\n".join([saludo, *lineas, profesional, f"Lugar:\n{_lugar()}"])


# --- programación ---


def _crear(*, tipo, destinatario, cita, asunto, cuerpo, programada_para=None):
    return Notificacion.objects.create(
        tipo=tipo,
        destinatario=destinatario,
        cita=cita,
        asunto=asunto,
        cuerpo=cuerpo,
        programada_para=programada_para or timezone.now(),
    )


def _anular_recordatorios(cita) -> None:
    Notificacion.objects.filter(cita=cita, tipo=Tipo.RECORDATORIO, estado=Estado.PENDIENTE).update(
        estado=Estado.ANULADA
    )


def _programar_recordatorio(cita, ahora) -> None:
    """Recordatorio unas horas antes; si ese momento ya pasó, basta el correo de la reserva."""
    momento = cita.inicio - timedelta(hours=settings.NOTIFICACIONES_RECORDATORIO_HORAS)
    if momento <= ahora:
        return
    _crear(
        tipo=Tipo.RECORDATORIO,
        destinatario=cita.paciente.usuario,
        cita=cita,
        asunto=f"Recordatorio: tu cita {_cuando(cita.inicio)}",
        cuerpo=_texto_paciente(
            cita, f"Te recordamos tu cita podológica {_cuando(cita.inicio)}.", _plazo()
        ),
        programada_para=momento,
    )


def notificar_reserva(cita, *, ahora=None) -> None:
    ahora = ahora or timezone.now()
    _crear(
        tipo=Tipo.RESERVA,
        destinatario=cita.paciente.usuario,
        cita=cita,
        asunto=f"Cita confirmada {_cuando(cita.inicio)}",
        cuerpo=_texto_paciente(
            cita, f"Tu cita podológica quedó confirmada {_cuando(cita.inicio)}.", _plazo()
        ),
    )
    _programar_recordatorio(cita, ahora)


def notificar_cancelacion(cita, *, por, reembolso=None) -> None:
    """Avisa al paciente siempre, y al profesional si canceló el paciente.

    `reembolso` es el monto pagado en línea que se devuelve, si la cita estaba pagada.
    """
    _anular_recordatorios(cita)
    if por == "profesional":
        detalle = (
            f"Tu cita {_cuando(cita.inicio)} fue cancelada por la consulta. "
            "Lamentamos el inconveniente; puedes reservar otro horario desde la aplicación."
        )
    else:
        detalle = f"Cancelaste tu cita {_cuando(cita.inicio)}. El horario quedó libre."
    if reembolso:
        monto = f"{reembolso:,}".replace(",", ".")
        detalle += (
            f" Te devolveremos ${monto} al mismo medio de pago; según tu banco, puede tardar "
            "algunos días hábiles en verse."
        )
    _crear(
        tipo=Tipo.CANCELACION,
        destinatario=cita.paciente.usuario,
        cita=cita,
        asunto=f"Cita cancelada {_cuando(cita.inicio)}",
        cuerpo=_texto_paciente(cita, detalle),
    )
    if por == "paciente":
        _crear(
            tipo=Tipo.CANCELACION,
            destinatario=cita.profesional.usuario,
            cita=cita,
            asunto=f"Cancelación en tu agenda {_cuando(cita.inicio)}",
            cuerpo=(
                f"Hola {cita.profesional.usuario.nombre}:\n\n"
                f"{_nombre(cita.paciente.usuario)} canceló su cita {_cuando(cita.inicio)}. "
                "El horario quedó libre en tu agenda."
            ),
        )


def notificar_reagendamiento(cita, *, anterior, por, ahora=None) -> None:
    """Avisa al paciente siempre y al profesional si reagendó el paciente."""
    ahora = ahora or timezone.now()
    _anular_recordatorios(cita)
    _crear(
        tipo=Tipo.REAGENDAMIENTO,
        destinatario=cita.paciente.usuario,
        cita=cita,
        asunto=f"Cita reagendada para {_cuando(cita.inicio)}",
        cuerpo=_texto_paciente(
            cita,
            f"Tu cita {_cuando(anterior)} se cambió para {_cuando(cita.inicio)}.",
            _plazo(),
        ),
    )
    if por == "paciente":
        _crear(
            tipo=Tipo.REAGENDAMIENTO,
            destinatario=cita.profesional.usuario,
            cita=cita,
            asunto=f"Cambio en tu agenda: {_cuando(cita.inicio)}",
            cuerpo=(
                f"Hola {cita.profesional.usuario.nombre}:\n\n"
                f"{_nombre(cita.paciente.usuario)} cambió su cita {_cuando(anterior)} "
                f"para {_cuando(cita.inicio)}."
            ),
        )
    _programar_recordatorio(cita, ahora)


# --- envío ---


def enviar_pendientes(*, ahora=None, limite=50) -> dict:
    """Envía las notificaciones pendientes cuya hora llegó. Devuelve un resumen.

    Cada fila se toma con `skip_locked`, así dos procesos de envío no mandan el mismo correo.
    Un fallo se reintenta más tarde hasta `NOTIFICACIONES_MAX_INTENTOS`; después queda
    `fallida`. Un recordatorio de una cita que ya no está activa se anula sin enviarse.
    """
    ahora = ahora or timezone.now()
    resumen = {"enviadas": 0, "reintentos": 0, "fallidas": 0, "anuladas": 0}
    with transaction.atomic():
        pendientes = (
            Notificacion.objects.select_for_update(skip_locked=True, of=("self",))
            .filter(estado=Estado.PENDIENTE, programada_para__lte=ahora)
            .select_related("destinatario", "cita")
            .order_by("programada_para")[:limite]
        )
        for notificacion in pendientes:
            resultado = _enviar(notificacion, ahora)
            resumen[resultado] += 1
    return resumen


# Dominios reservados que nunca reciben correo (RFC 2606 y 6761). Los usan los datos de demo y
# de pruebas: con un servidor real (Gmail), esos envíos rebotarían en la cuenta que envía.
DOMINIOS_FICTICIOS = ("example.com", "example.net", "example.org")
TLD_FICTICIOS = (".example", ".test", ".invalid", ".localhost", ".local")


def es_direccion_ficticia(email: str) -> bool:
    dominio = email.rsplit("@", 1)[-1].lower()
    return dominio in DOMINIOS_FICTICIOS or dominio.endswith(TLD_FICTICIOS)


def _enviar(notificacion, ahora) -> str:
    cita = notificacion.cita
    activa = cita is None or cita.estado in (Cita.Estado.AGENDADA, Cita.Estado.CONFIRMADA)
    if notificacion.tipo == Tipo.RECORDATORIO and not activa:
        notificacion.estado = Estado.ANULADA
        notificacion.save(update_fields=["estado"])
        return "anuladas"
    if settings.NOTIFICACIONES_OMITIR_FICTICIAS and es_direccion_ficticia(
        notificacion.destinatario.email
    ):
        notificacion.estado = Estado.ANULADA
        notificacion.error = "Dirección de ejemplo: no se envía."
        notificacion.save(update_fields=["estado", "error"])
        return "anuladas"

    notificacion.intentos += 1
    try:
        send_mail(
            notificacion.asunto,
            notificacion.cuerpo,
            settings.DEFAULT_FROM_EMAIL,
            [notificacion.destinatario.email],
        )
    except Exception as exc:  # cualquier fallo del servidor de correo se reintenta
        logger.warning("No se pudo enviar la notificación %s: %s", notificacion.pk, exc)
        notificacion.error = str(exc)[:500]
        if notificacion.intentos >= settings.NOTIFICACIONES_MAX_INTENTOS:
            notificacion.estado = Estado.FALLIDA
            resultado = "fallidas"
        else:
            notificacion.programada_para = ahora + ESPERA_REINTENTO * notificacion.intentos
            resultado = "reintentos"
    else:
        notificacion.estado = Estado.ENVIADA
        notificacion.enviada_en = ahora
        notificacion.error = ""
        resultado = "enviadas"
    notificacion.save(
        update_fields=["estado", "enviada_en", "intentos", "error", "programada_para"]
    )
    return resultado
