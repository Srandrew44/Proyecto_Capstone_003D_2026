import uuid

from django.contrib.postgres.constraints import ExclusionConstraint
from django.contrib.postgres.fields import DateTimeRangeField, RangeBoundary, RangeOperators
from django.db import models
from django.db.models import Func
from django.utils import timezone


class Tratamiento(models.Model):
    """Servicio que ofrece el podólogo, con su duración y precio."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    nombre = models.CharField(max_length=120, unique=True)
    descripcion = models.TextField(blank=True)
    descripcion_detallada = models.TextField(
        blank=True, help_text="Descripción que aparece al seleccionar «Conocer más» en la portada."
    )
    duracion_min = models.PositiveIntegerField(help_text="Duración de la atención, en minutos.")
    precio = models.PositiveIntegerField(help_text="Valor en pesos chilenos, sin decimales.")
    activo = models.BooleanField(default=True)

    class Meta:
        verbose_name = "tratamiento"
        verbose_name_plural = "tratamientos"
        ordering = ["nombre"]
        constraints = [
            # precio >= 0 ya lo garantiza PositiveIntegerField en la base.
            models.CheckConstraint(
                condition=models.Q(duracion_min__gt=0),
                name="tratamiento_duracion_positiva",
            ),
        ]

    def __str__(self):
        return self.nombre


class RangoDeHoras(Func):
    """Rango [inicio, fin) de horas sobre un día de referencia.

    PostgreSQL no tiene un rango nativo de horas del día, así que se usa tsrange
    con una fecha fija. Solo se usa en la restricción de exclusión de Disponibilidad.
    """

    arity = 2
    output_field = DateTimeRangeField()

    def as_sql(self, compiler, connection, **extra_context):
        inicio, fin = (compiler.compile(e) for e in self.source_expressions)
        sql = f"tsrange(DATE '2000-01-01' + {inicio[0]}, DATE '2000-01-01' + {fin[0]}, '[)')"
        return sql, [*inicio[1], *fin[1]]


class Disponibilidad(models.Model):
    """Tramo semanal recurrente en que el profesional atiende."""

    class DiaSemana(models.IntegerChoices):
        LUNES = 0, "Lunes"
        MARTES = 1, "Martes"
        MIERCOLES = 2, "Miércoles"
        JUEVES = 3, "Jueves"
        VIERNES = 4, "Viernes"
        SABADO = 5, "Sábado"
        DOMINGO = 6, "Domingo"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    profesional = models.ForeignKey(
        "cuentas.Profesional",
        on_delete=models.PROTECT,
        related_name="disponibilidades",
    )
    dia_semana = models.PositiveSmallIntegerField(choices=DiaSemana.choices)
    hora_inicio = models.TimeField()
    hora_fin = models.TimeField()
    activa = models.BooleanField(default=True)

    class Meta:
        verbose_name = "disponibilidad"
        verbose_name_plural = "disponibilidades"
        ordering = ["profesional", "dia_semana", "hora_inicio"]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(dia_semana__gte=0, dia_semana__lte=6),
                name="disponibilidad_dia_valido",
            ),
            models.CheckConstraint(
                condition=models.Q(hora_fin__gt=models.F("hora_inicio")),
                name="disponibilidad_horas_validas",
            ),
            # Dos tramos activos del mismo profesional no se solapan en un día.
            # Los tramos contiguos (09-12 y 12-15) sí se permiten.
            ExclusionConstraint(
                name="disponibilidad_sin_solapamiento",
                expressions=[
                    ("profesional", RangeOperators.EQUAL),
                    ("dia_semana", RangeOperators.EQUAL),
                    (RangoDeHoras("hora_inicio", "hora_fin"), RangeOperators.OVERLAPS),
                ],
                condition=models.Q(activa=True),
            ),
        ]

    def __str__(self):
        return f"{self.get_dia_semana_display()} {self.hora_inicio:%H:%M}-{self.hora_fin:%H:%M}"

    def es_de(self, usuario) -> bool:
        # La clave del profesional es la del usuario, así que se compara sin consultar la base.
        return usuario.is_authenticated and self.profesional_id == usuario.pk


class RangoDeTiempo(Func):
    """Rango [inicio, fin) de instantes (tstzrange) para la exclusión de Cita."""

    function = "TSTZRANGE"
    output_field = DateTimeRangeField()


class Cita(models.Model):
    """Reserva de un paciente con el profesional."""

    class Estado(models.TextChoices):
        # La hora queda retenida mientras el paciente paga en Webpay (apps/pagos).
        PENDIENTE_PAGO = "pendiente_pago", "Pendiente de pago"
        AGENDADA = "agendada", "Agendada"
        CONFIRMADA = "confirmada", "Confirmada"
        CANCELADA = "cancelada", "Cancelada"
        REALIZADA = "realizada", "Realizada"
        NO_ASISTIO = "no_asistio", "No asistió"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    paciente = models.ForeignKey(
        "cuentas.Paciente",
        on_delete=models.PROTECT,
        related_name="citas",
    )
    profesional = models.ForeignKey(
        "cuentas.Profesional",
        on_delete=models.PROTECT,
        related_name="citas",
    )
    tratamiento = models.ForeignKey(
        Tratamiento,
        on_delete=models.PROTECT,
        related_name="citas",
    )
    inicio = models.DateTimeField()
    fin = models.DateTimeField(help_text="Inicio más la duración del tratamiento, sin la pausa.")
    # Una cita nueva nace confirmada: el podólogo no aprueba las reservas. Si el tratamiento se
    # paga en línea, nace pendiente de pago y se confirma cuando Webpay aprueba el pago.
    estado = models.CharField(
        max_length=20,
        choices=Estado.choices,
        default=Estado.CONFIRMADA,
    )
    precio = models.PositiveIntegerField(
        help_text="Valor del tratamiento al reservar, en pesos chilenos. No cambia después.",
    )
    comentarios_paciente = models.TextField(blank=True)
    creada_en = models.DateTimeField(auto_now_add=True)
    cancelada_en = models.DateTimeField(null=True, blank=True)
    motivo_cancelacion = models.CharField(max_length=200, blank=True)

    class Meta:
        verbose_name = "cita"
        verbose_name_plural = "citas"
        ordering = ["inicio"]
        indexes = [
            models.Index(fields=["profesional", "inicio"], name="cita_profesional_inicio_idx"),
            models.Index(fields=["paciente", "inicio"], name="cita_paciente_inicio_idx"),
        ]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(fin__gt=models.F("inicio")),
                name="cita_fin_posterior_al_inicio",
            ),
            # Solo una cita cancelada libera el horario: realizada y no_asistio lo siguen
            # ocupando, y pendiente_pago también (la hora queda retenida mientras se paga).
            # Las citas contiguas (una termina cuando empieza la otra) se permiten; la pausa
            # de desinfección la aplica el servicio de horarios libres.
            ExclusionConstraint(
                name="cita_profesional_sin_solapamiento",
                expressions=[
                    ("profesional", RangeOperators.EQUAL),
                    (RangoDeTiempo("inicio", "fin", RangeBoundary()), RangeOperators.OVERLAPS),
                ],
                condition=~models.Q(estado="cancelada"),
            ),
            # Un paciente tampoco puede tener dos citas cruzadas, con el mismo profesional
            # o con otro.
            ExclusionConstraint(
                name="cita_paciente_sin_solapamiento",
                expressions=[
                    ("paciente", RangeOperators.EQUAL),
                    (RangoDeTiempo("inicio", "fin", RangeBoundary()), RangeOperators.OVERLAPS),
                ],
                condition=~models.Q(estado="cancelada"),
            ),
        ]

    def __str__(self):
        inicio = timezone.localtime(self.inicio)
        return f"{self.paciente} con {self.profesional} el {inicio:%d/%m/%Y %H:%M}"

    def es_de(self, usuario) -> bool:
        """El paciente y el profesional de la cita son sus únicos dueños."""
        return usuario.is_authenticated and usuario.pk in (self.paciente_id, self.profesional_id)


class BloqueoHorario(models.Model):
    """Periodo puntual en que el profesional no atiende (vacaciones, trámite, imprevisto).

    Se resta de los horarios libres. No puede cruzar citas activas: el servicio lo rechaza y
    el profesional debe cancelar o reagendar esas citas antes.
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    profesional = models.ForeignKey(
        "cuentas.Profesional",
        on_delete=models.PROTECT,
        related_name="bloqueos",
    )
    inicio = models.DateTimeField()
    fin = models.DateTimeField()
    motivo = models.CharField(max_length=200, blank=True)
    creado_en = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "bloqueo de horario"
        verbose_name_plural = "bloqueos de horario"
        ordering = ["inicio"]
        indexes = [
            models.Index(fields=["profesional", "inicio"], name="bloqueo_profesional_inicio_idx"),
        ]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(fin__gt=models.F("inicio")),
                name="bloqueo_fin_posterior_al_inicio",
            ),
        ]

    def __str__(self):
        inicio = timezone.localtime(self.inicio)
        fin = timezone.localtime(self.fin)
        return f"{self.profesional}: {inicio:%d/%m/%Y %H:%M} a {fin:%d/%m/%Y %H:%M}"

    def es_de(self, usuario) -> bool:
        return usuario.is_authenticated and self.profesional_id == usuario.pk


class Notificacion(models.Model):
    """Correo pendiente o enviado. Se crea junto con el cambio de la cita y se envía aparte.

    Funciona como bandeja de salida: si el servidor de correo falla, la reserva no se cae;
    el envío se reintenta. El asunto y el cuerpo nunca llevan datos clínicos.
    """

    class Tipo(models.TextChoices):
        RESERVA = "reserva", "Reserva confirmada"
        CANCELACION = "cancelacion", "Cita cancelada"
        REAGENDAMIENTO = "reagendamiento", "Cita reagendada"
        RECORDATORIO = "recordatorio", "Recordatorio de cita"

    class Canal(models.TextChoices):
        EMAIL = "email", "Correo electrónico"

    class Estado(models.TextChoices):
        PENDIENTE = "pendiente", "Pendiente"
        ENVIADA = "enviada", "Enviada"
        FALLIDA = "fallida", "Fallida"
        ANULADA = "anulada", "Anulada"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    destinatario = models.ForeignKey(
        "cuentas.Usuario",
        on_delete=models.PROTECT,
        related_name="notificaciones",
    )
    cita = models.ForeignKey(
        Cita,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="notificaciones",
    )
    tipo = models.CharField(max_length=20, choices=Tipo.choices)
    canal = models.CharField(max_length=10, choices=Canal.choices, default=Canal.EMAIL)
    asunto = models.CharField(max_length=200)
    cuerpo = models.TextField()
    programada_para = models.DateTimeField(default=timezone.now)
    estado = models.CharField(max_length=10, choices=Estado.choices, default=Estado.PENDIENTE)
    enviada_en = models.DateTimeField(null=True, blank=True)
    intentos = models.PositiveSmallIntegerField(default=0)
    error = models.CharField(max_length=500, blank=True)
    creada_en = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "notificación"
        verbose_name_plural = "notificaciones"
        ordering = ["-programada_para"]
        indexes = [
            models.Index(fields=["estado", "programada_para"], name="notif_estado_programada_idx"),
            models.Index(fields=["destinatario", "programada_para"], name="notif_destinatario_idx"),
        ]

    def __str__(self):
        return f"{self.get_tipo_display()} para {self.destinatario} ({self.estado})"

    def es_de(self, usuario) -> bool:
        return usuario.is_authenticated and self.destinatario_id == usuario.pk
