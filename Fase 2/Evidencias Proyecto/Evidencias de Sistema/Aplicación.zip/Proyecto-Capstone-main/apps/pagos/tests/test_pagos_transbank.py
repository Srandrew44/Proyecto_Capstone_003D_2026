"""Fallos de Transbank: respuestas que no llegan, doble clic, tokens viejos y reembolsos.

La regla de fondo: un error de red o un 5xx no dice si Transbank hizo la operación. Nunca se
trata como un rechazo ni se repite a ciegas: se consulta el estado (status) antes de decidir.
"""

import logging
from datetime import timedelta
from io import StringIO

import pytest
import requests
from django.core.exceptions import ValidationError
from django.core.management import call_command
from transbank.error.transbank_error import TransbankError

from apps.agenda.horarios import horarios_libres
from apps.agenda.models import Cita, Notificacion
from apps.agenda.services import cancelar_cita, reservar_cita
from apps.agenda.tests.factories import INICIO_BASE, DisponibilidadFactory, TratamientoFactory
from apps.clinica.tests.factories import ConsentimientoFactory
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory
from apps.pagos import services as pagos
from apps.pagos.models import Pago
from apps.pagos.tests.conftest import aprobado
from integraciones import webpay

pytestmark = pytest.mark.django_db

AHORA = INICIO_BASE - timedelta(days=3)
RETORNO = "http://testserver/pagos/webpay/retorno/"


@pytest.fixture(autouse=True)
def reglas(settings):
    settings.AGENDA_ANTICIPACION_MIN_HORAS = 24
    settings.AGENDA_HORIZONTE_DIAS = 30
    settings.AGENDA_CANCELACION_MIN_HORAS = 24


@pytest.fixture
def profesional():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    return profesional


@pytest.fixture
def tratamiento():
    return TratamientoFactory(duracion_min=45, precio=25000)


@pytest.fixture
def cita(webpay_falso, profesional, tratamiento):
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente)
    return reservar_cita(
        paciente=paciente,
        profesional=profesional,
        tratamiento=tratamiento,
        inicio=INICIO_BASE,
        ahora=AHORA,
    )


def _abrir(cita, ahora=AHORA):
    _, token = pagos.iniciar_webpay(cita.pago, url_retorno=RETORNO, ahora=ahora)
    return token


def _volver(token, ahora=AHORA):
    return pagos.procesar_retorno({"token_ws": token}, ahora=ahora)


def _hora_libre(profesional, tratamiento, ahora):
    dia = INICIO_BASE.date()
    libres = horarios_libres(
        profesional=profesional, tratamiento=tratamiento, desde=dia, hasta=dia, ahora=ahora
    )
    return INICIO_BASE in libres


# --- 1. commit sin respuesta clara ---


def test_si_el_commit_se_cobro_pero_la_respuesta_se_perdio_se_aprueba(cita, webpay_falso):
    token = _abrir(cita)
    webpay_falso.commit_sin_respuesta = "se_perdio"
    pago = _volver(token)
    cita.refresh_from_db()
    assert pago.estado == Pago.Estado.AUTORIZADO
    assert cita.estado == Cita.Estado.CONFIRMADA
    assert webpay_falso.consultas == [token]
    assert Notificacion.objects.filter(cita=cita, tipo=Notificacion.Tipo.RESERVA).exists()


def test_si_no_se_sabe_si_cobro_queda_por_verificar_y_retiene_la_hora(
    cita, webpay_falso, profesional, tratamiento
):
    token = _abrir(cita)
    webpay_falso.commit_sin_respuesta = "se_perdio"
    webpay_falso.falla_status = "red"
    pago = _volver(token)
    cita.refresh_from_db()
    assert pago.estado == Pago.Estado.POR_VERIFICAR
    assert "Read timed out" in pago.error
    assert cita.estado == Cita.Estado.PENDIENTE_PAGO
    # Pasado el plazo para pagar, la hora sigue retenida y la cita no se cancela.
    despues = AHORA + timedelta(hours=1)
    assert pagos.vencer_pendientes(ahora=despues) == 0
    assert not _hora_libre(profesional, tratamiento, despues)
    # Recargar la vuelta no repite el commit.
    webpay_falso.commit_sin_respuesta = None
    webpay_falso.falla_commit = True
    assert _volver(token).estado == Pago.Estado.POR_VERIFICAR


def test_la_tarea_aprueba_un_pago_por_verificar_que_transbank_cobro(cita, webpay_falso):
    token = _abrir(cita)
    webpay_falso.commit_sin_respuesta = "se_perdio"
    webpay_falso.falla_status = "red"
    _volver(token)
    webpay_falso.falla_status = None
    resumen = pagos.verificar_pagos()
    assert resumen == {"aprobados": 1, "rechazados": 0, "sin_respuesta": 0}
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CONFIRMADA
    assert cita.pago.estado == Pago.Estado.AUTORIZADO
    assert cita.pago.codigo_autorizacion == "1213"


def test_si_el_commit_no_llego_la_tarea_lo_reintenta(cita, webpay_falso):
    token = _abrir(cita)
    webpay_falso.commit_sin_respuesta = "no_llego"
    pago = _volver(token)
    # El status dice INITIALIZED: el commit no llegó. Se deja para la tarea.
    assert pago.estado == Pago.Estado.POR_VERIFICAR
    webpay_falso.commit_sin_respuesta = None
    assert pagos.verificar_pagos()["aprobados"] == 1
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CONFIRMADA


def test_si_transbank_no_cobro_la_tarea_libera_la_hora(cita, webpay_falso):
    token = _abrir(cita)
    webpay_falso.commit_sin_respuesta = "se_perdio"
    webpay_falso.falla_status = "red"
    _volver(token)
    webpay_falso.falla_status = None
    webpay_falso.estados[token] = "FAILED"
    assert pagos.verificar_pagos()["rechazados"] == 1
    cita.refresh_from_db()
    assert cita.pago.estado == Pago.Estado.RECHAZADO
    assert cita.estado == Cita.Estado.CANCELADA


def test_sin_respuesta_la_tarea_lo_deja_para_la_proxima_vuelta(cita, webpay_falso):
    token = _abrir(cita)
    webpay_falso.commit_sin_respuesta = "se_perdio"
    webpay_falso.falla_status = "red"
    _volver(token)
    assert pagos.verificar_pagos()["sin_respuesta"] == 1
    cita.refresh_from_db()
    assert cita.pago.estado == Pago.Estado.POR_VERIFICAR
    assert cita.estado == Cita.Estado.PENDIENTE_PAGO


def test_si_se_aprueba_con_la_hora_ya_liberada_se_reembolsa(cita, webpay_falso):
    token = _abrir(cita)
    webpay_falso.commit_sin_respuesta = "se_perdio"
    webpay_falso.falla_status = "red"
    _volver(token)
    # Mientras se verificaba, la cita se anuló (por ejemplo, desde el admin).
    Cita.objects.filter(pk=cita.pk).update(estado=Cita.Estado.CANCELADA)
    webpay_falso.falla_status = None
    pagos.verificar_pagos()
    pago = Pago.objects.get(pk=cita.pago.pk)
    assert pago.estado == Pago.Estado.REEMBOLSADO
    assert pago.motivo_reembolso == Pago.MotivoReembolso.HORA_LIBERADA
    assert webpay_falso.reembolsos == [(token, 25000)]


def test_no_se_paga_otra_vez_mientras_se_verifica(cita, webpay_falso):
    token = _abrir(cita)
    webpay_falso.commit_sin_respuesta = "se_perdio"
    webpay_falso.falla_status = "red"
    _volver(token)
    with pytest.raises(ValidationError, match="Estamos confirmando tu pago"):
        pagos.iniciar_webpay(Pago.objects.get(pk=cita.pago.pk), url_retorno=RETORNO)


def test_el_notificador_verifica_los_pagos(cita, webpay_falso):
    token = _abrir(cita)
    webpay_falso.commit_sin_respuesta = "se_perdio"
    webpay_falso.falla_status = "red"
    _volver(token)
    webpay_falso.falla_status = None
    salida = StringIO()
    call_command("enviar_notificaciones", stdout=salida)
    assert "verificados aprobados: 1" in salida.getvalue()
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CONFIRMADA


# --- clasificación de errores en integraciones/webpay.py ---


class _TransaccionQueFalla:
    def __init__(self, error=None, respuesta=None):
        self.error, self.respuesta = error, respuesta

    def commit(self, token):
        if self.error:
            raise self.error
        return self.respuesta


@pytest.mark.parametrize(
    ("error", "respuesta"),
    [
        (requests.exceptions.ReadTimeout("read timed out"), None),
        (requests.exceptions.ConnectionError("sin red"), None),
        (TransbankError("Internal error", 500), None),
        (TransbankError("Bad gateway", 502), None),
        (ValueError("Expecting value: line 1 column 1"), None),  # página HTML de un proxy
        (None, 503),  # cuerpo vacío: el SDK devuelve solo el código HTTP
    ],
)
def test_red_5xx_y_respuestas_raras_son_resultado_desconocido(monkeypatch, error, respuesta):
    monkeypatch.setattr(webpay, "_transaccion", lambda: _TransaccionQueFalla(error, respuesta))
    with pytest.raises(webpay.ResultadoDesconocido):
        webpay.confirmar("tok")


@pytest.mark.parametrize("codigo", [0, 400, 401, 404, 422])
def test_un_4xx_es_un_error_definitivo(monkeypatch, codigo):
    error = TransbankError("Invalid status", codigo)
    monkeypatch.setattr(webpay, "_transaccion", lambda: _TransaccionQueFalla(error))
    with pytest.raises(webpay.ErrorWebpay) as info:
        webpay.confirmar("tok")
    assert not isinstance(info.value, webpay.ResultadoDesconocido)
    assert "Invalid status" in str(info.value)


# --- 3. doble clic en "Completar pago" ---


def test_doble_clic_en_pagar_abre_una_sola_transaccion(cita, webpay_falso):
    # Dos peticiones a la vez: ambas leyeron el pago antes de que la otra guardara el token.
    primera = Pago.objects.get(pk=cita.pago.pk)
    segunda = Pago.objects.get(pk=cita.pago.pk)
    _, token1 = pagos.iniciar_webpay(primera, url_retorno=RETORNO, ahora=AHORA)
    _, token2 = pagos.iniciar_webpay(segunda, url_retorno=RETORNO, ahora=AHORA)
    assert token1 == token2
    assert len(webpay_falso.creadas) == 1
    assert _volver(token1).estado == Pago.Estado.AUTORIZADO


# --- 8. token viejo de Webpay ---


def test_un_token_que_sigue_iniciado_se_reutiliza(cita, webpay_falso):
    token = _abrir(cita)
    assert _abrir(cita) == token
    assert webpay_falso.consultas == [token]
    assert len(webpay_falso.creadas) == 1


def test_tras_recargar_webpay_se_abre_otra_transaccion(cita, webpay_falso):
    # Recargó el formulario de Webpay: Transbank la sigue dando por iniciada, pero Webpay ya no
    # deja pagar con ella. Al volver a "Completar pago" debe abrirse otra, no la misma.
    token = _abrir(cita)
    orden = Pago.objects.get(pk=cita.pago.pk).orden_compra
    nuevo = _abrir(cita, ahora=AHORA + pagos.REUTILIZAR_TOKEN)
    pago = Pago.objects.get(pk=cita.pago.pk)
    assert nuevo != token
    assert pago.token == nuevo
    assert pago.tokens_anteriores == [token]
    assert pago.orden_compra != orden
    assert len(webpay_falso.creadas) == 2
    assert _volver(nuevo).estado == Pago.Estado.AUTORIZADO


def test_un_token_sin_fecha_de_creacion_no_se_reutiliza(cita, webpay_falso):
    # Pagos abiertos antes de guardar `token_creado_en`: se tratan como no recientes.
    token = _abrir(cita)
    Pago.objects.filter(pk=cita.pago.pk).update(token_creado_en=None)
    cita.pago.refresh_from_db()
    assert _abrir(cita) != token


def test_si_paga_con_el_formulario_anterior_se_confirma_ese(cita, webpay_falso):
    token = _abrir(cita)
    orden_vieja = Pago.objects.get(pk=cita.pago.pk).orden_compra
    nuevo = _abrir(cita, ahora=AHORA + timedelta(minutes=1))
    webpay_falso.respuesta_commit = aprobado(buy_order=orden_vieja)
    pago = _volver(token, ahora=AHORA + timedelta(minutes=2))
    pago.refresh_from_db()
    assert pago.estado == Pago.Estado.AUTORIZADO
    assert webpay_falso.commits == [token]
    # El token y la orden pasan a ser los de la transacción cobrada: el reembolso usa esos.
    assert pago.token == token
    assert pago.orden_compra == orden_vieja
    assert pago.tokens_anteriores == [nuevo]
    assert Cita.objects.get(pk=cita.pk).estado == Cita.Estado.CONFIRMADA
    # La vuelta tardía con la transacción nueva no confirma nada más.
    _volver(nuevo, ahora=AHORA + timedelta(minutes=3))
    assert webpay_falso.commits == [token]


def test_anular_en_el_formulario_anterior_no_cierra_el_pago(cita, webpay_falso):
    token = _abrir(cita)
    nuevo = _abrir(cita, ahora=AHORA + timedelta(minutes=1))
    pago = pagos.procesar_retorno({"TBK_TOKEN": token}, ahora=AHORA + timedelta(minutes=2))
    pago.refresh_from_db()
    assert pago.estado == Pago.Estado.PENDIENTE
    assert pago.token == nuevo
    assert _volver(nuevo, ahora=AHORA + timedelta(minutes=3)).estado == Pago.Estado.AUTORIZADO


@pytest.mark.parametrize("cerrado", ["FAILED", "desconocido"])
def test_un_token_cerrado_o_desconocido_abre_otra_transaccion(cita, webpay_falso, cerrado):
    token = _abrir(cita)
    orden = cita.pago.orden_compra
    if cerrado == "desconocido":
        webpay_falso.falla_status = "rechazo"  # Transbank ya no reconoce el token
    else:
        webpay_falso.estados[token] = cerrado
    nuevo = _abrir(cita)
    webpay_falso.falla_status = None
    pago = Pago.objects.get(pk=cita.pago.pk)
    assert nuevo != token
    assert pago.token == nuevo
    assert pago.orden_compra != orden
    assert len(pago.orden_compra) <= 26
    assert webpay_falso.creadas[1]["orden"] == pago.orden_compra
    assert _volver(nuevo).estado == Pago.Estado.AUTORIZADO


def test_si_no_se_puede_consultar_el_token_se_reutiliza(cita, webpay_falso):
    token = _abrir(cita)
    webpay_falso.falla_status = "red"
    assert _abrir(cita) == token
    assert len(webpay_falso.creadas) == 1


def test_si_el_token_ya_se_autorizo_no_se_abre_otro(cita, webpay_falso):
    token = _abrir(cita)
    webpay_falso.estados[token] = "AUTHORIZED"  # pagó en otra pestaña; la vuelta no llega
    with pytest.raises(ValidationError, match="ya fue autorizado"):
        _abrir(cita)
    assert len(webpay_falso.creadas) == 1


# --- 4. reembolsos sin duplicar ---


def _pagada_y_cancelada(cita, webpay_falso):
    _volver(_abrir(cita))
    cancelar_cita(cita=cita, usuario=cita.paciente.usuario, ahora=AHORA + timedelta(hours=1))
    return Pago.objects.get(cita=cita)


def test_un_pago_ya_reembolsado_no_se_pide_otra_vez(cita, webpay_falso):
    _volver(_abrir(cita))
    leido_por_la_tarea = Pago.objects.get(cita=cita)
    cancelar_cita(cita=cita, usuario=cita.paciente.usuario, ahora=AHORA + timedelta(hours=1))
    # La tarea periódica tenía una copia vieja del pago; al llegar, ya está reembolsado.
    Pago.objects.filter(pk=leido_por_la_tarea.pk).update(estado=Pago.Estado.REEMBOLSADO)
    leido_por_la_tarea.estado = Pago.Estado.REEMBOLSO_PENDIENTE
    assert pagos.reembolsar(leido_por_la_tarea, ahora=AHORA) is False
    assert len(webpay_falso.reembolsos) == 1


def test_un_reembolso_en_curso_no_se_pide_dos_veces(cita, webpay_falso):
    _volver(_abrir(cita))
    pago = Pago.objects.get(cita=cita)
    # Otra ejecución ya lo pidió y espera la respuesta de Transbank.
    Pago.objects.filter(pk=pago.pk).update(
        estado=Pago.Estado.REEMBOLSANDO, reembolso_iniciado_en=AHORA
    )
    pago.estado = Pago.Estado.REEMBOLSO_PENDIENTE  # copia vieja
    assert pagos.reembolsar(pago, ahora=AHORA + timedelta(minutes=1)) is False
    resumen = pagos.reintentar_reembolsos(ahora=AHORA + timedelta(minutes=1))
    assert resumen == {"reembolsados": 0, "fallidos": 0}
    assert webpay_falso.reembolsos == []


def test_un_reembolso_abandonado_se_retoma_consultando_antes(cita, webpay_falso):
    token = _abrir(cita)
    _volver(token)
    pago = Pago.objects.get(cita=cita)
    # El proceso se cayó después de pedir el refund: Transbank sí lo hizo.
    webpay_falso.estados[token] = "REVERSED"
    Pago.objects.filter(pk=pago.pk).update(
        estado=Pago.Estado.REEMBOLSANDO, reembolso_iniciado_en=AHORA
    )
    resumen = pagos.reintentar_reembolsos(ahora=AHORA + timedelta(minutes=11))
    pago.refresh_from_db()
    assert resumen["reembolsados"] == 1
    assert pago.estado == Pago.Estado.REEMBOLSADO
    assert pago.tipo_reembolso == "REVERSED"
    assert webpay_falso.reembolsos == []  # no se volvió a pedir


def test_si_la_respuesta_del_reembolso_se_pierde_se_consulta_el_estado(cita, webpay_falso):
    webpay_falso.reembolso_sin_respuesta = "se_perdio"
    pago = _pagada_y_cancelada(cita, webpay_falso)
    assert pago.estado == Pago.Estado.REEMBOLSADO
    assert pago.intentos_reembolso == 0
    assert len(webpay_falso.reembolsos) == 1


def test_un_reintento_tras_un_error_de_red_consulta_antes_de_pedir(cita, webpay_falso):
    webpay_falso.reembolso_sin_respuesta = "no_llego"
    pago = _pagada_y_cancelada(cita, webpay_falso)
    assert pago.estado == Pago.Estado.REEMBOLSO_PENDIENTE
    assert pago.intentos_reembolso == 1
    # Mientras no se pueda consultar, no se pide a ciegas.
    webpay_falso.reembolso_sin_respuesta = None
    webpay_falso.falla_status = "red"
    assert pagos.reintentar_reembolsos(ahora=AHORA) == {"reembolsados": 0, "fallidos": 1}
    assert webpay_falso.reembolsos == []
    webpay_falso.falla_status = None
    assert pagos.reintentar_reembolsos(ahora=AHORA) == {"reembolsados": 1, "fallidos": 0}
    assert len(webpay_falso.reembolsos) == 1


def test_al_agotar_los_intentos_queda_un_error_en_el_registro(cita, webpay_falso, caplog):
    webpay_falso.falla_reembolso = True
    pago = _pagada_y_cancelada(cita, webpay_falso)
    with caplog.at_level(logging.ERROR, logger="apps.pagos.services"):
        for _ in range(10):
            pagos.reintentar_reembolsos(ahora=AHORA)
    pago.refresh_from_db()
    assert pago.intentos_reembolso == pagos.MAX_INTENTOS_REEMBOLSO
    errores = [r for r in caplog.records if r.levelno == logging.ERROR]
    assert len(errores) == 1
    assert pago.orden_compra in errores[0].getMessage()
    assert "a mano" in errores[0].getMessage()


# --- AUTHORIZED en el status no asegura el commit (revisión del supervisor) ---


def test_status_autorizado_sin_commit_hecho_se_confirma_antes_de_aprobar(webpay_falso, cita):
    """Si el commit no llegó pero el status ya dice AUTHORIZED, sin commit Transbank anularía
    el cobro: se hace el commit antes de confirmar la cita."""
    token = _abrir(cita)
    webpay_falso.commit_sin_respuesta = "no_llego"
    webpay_falso.estados[token] = "AUTHORIZED"  # autorizado por el banco, sin commit
    pago = _volver(token)
    assert pago.estado == Pago.Estado.POR_VERIFICAR  # el reintento de commit tampoco llegó

    webpay_falso.commit_sin_respuesta = None
    assert pagos.verificar_pagos() == {
        "aprobados": 1,
        "rechazados": 0,
        "sin_respuesta": 0,
    }
    pago.refresh_from_db()
    cita.refresh_from_db()
    assert token in webpay_falso.confirmadas
    assert pago.estado == Pago.Estado.AUTORIZADO
    assert cita.estado == Cita.Estado.CONFIRMADA


def test_status_autorizado_con_commit_ya_hecho_se_aprueba_sin_cobrar_dos_veces(webpay_falso, cita):
    token = _abrir(cita)
    webpay_falso.commit_sin_respuesta = "se_perdio"  # Transbank confirmó; la respuesta se perdió
    pago = _volver(token)
    cita.refresh_from_db()
    assert pago.estado == Pago.Estado.AUTORIZADO
    assert cita.estado == Cita.Estado.CONFIRMADA
    assert webpay_falso.commits.count(token) == 2  # el segundo lo rechaza Transbank (422)


def test_un_pago_por_verificar_retiene_la_hora_aunque_venza_su_plazo(
    webpay_falso, cita, profesional, tratamiento
):
    token = _abrir(cita)
    webpay_falso.commit_sin_respuesta = "no_llego"
    webpay_falso.falla_status = "red"
    pago = _volver(token)
    assert pago.estado == Pago.Estado.POR_VERIFICAR
    Pago.objects.filter(pk=pago.pk).update(vence_en=AHORA - timedelta(minutes=1))
    assert not _hora_libre(profesional, tratamiento, AHORA + timedelta(hours=1))
