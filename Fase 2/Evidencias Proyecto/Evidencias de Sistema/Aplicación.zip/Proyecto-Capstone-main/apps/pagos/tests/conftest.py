import pytest

from integraciones import webpay


class WebpayFalso:
    """Reemplaza a Transbank en las pruebas: registra las llamadas y responde lo indicado.

    Lleva el estado de cada transacción como Transbank (`estados`), para que `consultar`
    responda lo mismo que respondería el status real después de cada operación.
    """

    def __init__(self):
        self.creadas = []
        self.reembolsos = []
        self.consultas = []
        self.estados = {}  # token -> status en Transbank
        self.commits = []  # tokens de cada commit pedido
        self.confirmadas = set()  # tokens con commit hecho en Transbank
        self.respuesta_commit = aprobado()
        self.falla_commit = False
        self.falla_reembolso = False
        self.falla_crear = False
        # Sin respuesta clara (red, 5xx): "no_llego" (Transbank no lo recibió) o
        # "se_perdio" (lo hizo, pero la respuesta no volvió).
        self.commit_sin_respuesta = None
        self.reembolso_sin_respuesta = None
        # Falla del status: "red" (sin respuesta) o "rechazo" (4xx, p. ej. token inválido).
        self.falla_status = None

    def crear(self, *, orden_compra, sesion, monto, url_retorno):
        if self.falla_crear:
            raise webpay.ErrorWebpay("sin conexión")
        token = f"tok{len(self.creadas):061d}"
        self.creadas.append({"orden": orden_compra, "monto": monto, "retorno": url_retorno})
        self.estados[token] = "INITIALIZED"
        return {
            "token": token,
            "url": "https://webpay3gint.transbank.cl/webpayserver/initTransaction",
        }

    def confirmar(self, token):
        self.commits.append(token)
        if self.falla_commit:
            raise webpay.ErrorWebpay("Invalid status (HTTP 422)")
        if token in self.confirmadas:
            # Como Transbank: una transacción ya confirmada no se confirma dos veces.
            raise webpay.ErrorWebpay("Transaction already locked (HTTP 422)")
        if self.commit_sin_respuesta == "no_llego":
            raise webpay.ResultadoDesconocido("Sin respuesta de Transbank: Read timed out")
        self.estados[token] = self.respuesta_commit["status"]
        self.confirmadas.add(token)
        if self.commit_sin_respuesta == "se_perdio":
            raise webpay.ResultadoDesconocido("Sin respuesta de Transbank: Read timed out")
        return self.respuesta_commit

    def consultar(self, token):
        self.consultas.append(token)
        if self.falla_status == "red":
            raise webpay.ResultadoDesconocido("Sin respuesta de Transbank: Read timed out")
        if self.falla_status == "rechazo" or token not in self.estados:
            raise webpay.ErrorWebpay("Invalid token (HTTP 422)")
        estado = self.estados[token]
        if estado == "INITIALIZED":
            return {"status": estado}
        return {**self.respuesta_commit, "status": estado}

    def reembolsar(self, token, monto):
        if self.falla_reembolso:
            raise webpay.ErrorWebpay("Invalid status (HTTP 422)")
        if self.reembolso_sin_respuesta == "no_llego":
            raise webpay.ResultadoDesconocido("Sin respuesta de Transbank: Read timed out")
        self.reembolsos.append((token, monto))
        self.estados[token] = "REVERSED"
        if self.reembolso_sin_respuesta == "se_perdio":
            raise webpay.ResultadoDesconocido("Sin respuesta de Transbank: Read timed out")
        return {"type": "REVERSED"}


def aprobado(**cambios):
    return {
        "status": "AUTHORIZED",
        "response_code": 0,
        "authorization_code": "1213",
        "payment_type_code": "VN",
        "installments_number": 0,
        "card_detail": {"card_number": "6623"},
        "transaction_date": "2030-01-04T12:00:00.000Z",
        **cambios,
    }


@pytest.fixture
def webpay_falso(monkeypatch, settings):
    settings.PAGOS_WEBPAY_ACTIVO = True
    settings.PAGOS_PLAZO_MIN = 15
    falso = WebpayFalso()
    monkeypatch.setattr(webpay, "crear", falso.crear)
    monkeypatch.setattr(webpay, "confirmar", falso.confirmar)
    monkeypatch.setattr(webpay, "consultar", falso.consultar)
    monkeypatch.setattr(webpay, "reembolsar", falso.reembolsar)
    return falso
