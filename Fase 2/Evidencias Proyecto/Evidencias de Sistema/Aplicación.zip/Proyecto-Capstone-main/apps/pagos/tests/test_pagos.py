"""Reglas del pago con Webpay: retener la hora, confirmar, liberar y reembolsar."""

from datetime import timedelta

import pytest
from django.core import mail
from django.core.exceptions import ValidationError

from apps.agenda.horarios import horarios_libres
from apps.agenda.models import Cita, Notificacion
from apps.agenda.services import cancelar_cita, crear_bloqueo, reservar_cita
from apps.agenda.tests.factories import INICIO_BASE, DisponibilidadFactory, TratamientoFactory
from apps.auditoria.models import RegistroAuditoria
from apps.clinica.informes import calcular_informe
from apps.clinica.tests.factories import ConsentimientoFactory
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory
from apps.pagos import services as pagos
from apps.pagos.models import Pago

from .conftest import aprobado

pytestmark = pytest.mark.django_db

AHORA = INICIO_BASE - timedelta(days=3)
RETORNO = "http://testserver/pagos/webpay/retorno/"


@pytest.fixture(autouse=True)
def reglas(settings):
    settings.AGENDA_ANTICIPACION_MIN_HORAS = 24
    settings.AGENDA_HORIZONTE_DIAS = 30
    settings.AGENDA_CANCELACION_MIN_HORAS = 24


@pytest.fixture
def profesional():
    profesional = ProfesionalFactory()
    DisponibilidadFactory(profesional=profesional)
    return profesional


@pytest.fixture
def paciente():
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente)
    return paciente


@pytest.fixture
def tratamiento():
    return TratamientoFactory(duracion_min=45, precio=25000)


def _reservar(paciente, profesional, tratamiento, inicio=INICIO_BASE, ahora=AHORA):
    return reservar_cita(
        paciente=paciente,
        profesional=profesional,
        tratamiento=tratamiento,
        inicio=inicio,
        ahora=ahora,
    )


def _pagar(cita, webpay_falso, ahora=AHORA):
    pago = cita.pago
    _, token = pagos.iniciar_webpay(pago, url_retorno=RETORNO, ahora=ahora)
    return pagos.procesar_retorno({"token_ws": token}, ahora=ahora)


# --- reservar ---


def test_con_pago_activo_la_cita_nace_pendiente_y_retiene_la_hora(
    webpay_falso, paciente, profesional, tratamiento
):
    cita = _reservar(paciente, profesional, tratamiento)
    assert cita.estado == Cita.Estado.PENDIENTE_PAGO
    assert cita.pago.monto == 25000
    assert cita.pago.estado == Pago.Estado.PENDIENTE
    assert cita.pago.vence_en == AHORA + timedelta(minutes=15)
    assert len(cita.pago.orden_compra) <= 26
    # Aún no sale el correo de reserva.
    assert not Notificacion.objects.exists()
    dia = INICIO_BASE.date()
    libres = horarios_libres(
        profesional=profesional, tratamiento=tratamiento, desde=dia, hasta=dia, ahora=AHORA
    )
    assert INICIO_BASE not in libres


def test_un_tratamiento_gratis_no_pasa_por_webpay(webpay_falso, paciente, profesional):
    cita = _reservar(paciente, profesional, TratamientoFactory(precio=0))
    assert cita.estado == Cita.Estado.CONFIRMADA
    assert not Pago.objects.exists()


def test_iniciar_webpay_abre_la_transaccion_una_sola_vez(
    webpay_falso, paciente, profesional, tratamiento
):
    pago = _reservar(paciente, profesional, tratamiento).pago
    url, token = pagos.iniciar_webpay(pago, url_retorno=RETORNO, ahora=AHORA)
    assert url.startswith("https://webpay3gint.transbank.cl/")
    assert pagos.iniciar_webpay(pago, url_retorno=RETORNO, ahora=AHORA) == (url, token)
    esperada = {"orden": pago.orden_compra, "monto": 25000, "retorno": RETORNO}
    assert webpay_falso.creadas == [esperada]


def test_si_webpay_no_responde_se_avisa_y_la_hora_sigue_retenida(
    webpay_falso, paciente, profesional, tratamiento
):
    webpay_falso.falla_crear = True
    pago = _reservar(paciente, profesional, tratamiento).pago
    with pytest.raises(ValidationError, match="No pudimos conectar con Webpay"):
        pagos.iniciar_webpay(pago, url_retorno=RETORNO, ahora=AHORA)
    pago.refresh_from_db()
    assert pago.estado == Pago.Estado.PENDIENTE


# --- vuelta desde Webpay ---


def test_pago_aprobado_confirma_la_cita_y_envia_el_correo(
    webpay_falso, paciente, profesional, tratamiento
):
    cita = _reservar(paciente, profesional, tratamiento)
    pago = _pagar(cita, webpay_falso)
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CONFIRMADA
    assert pago.estado == Pago.Estado.AUTORIZADO
    assert pago.codigo_autorizacion == "1213"
    assert pago.tarjeta_final == "6623"
    assert pago.tipo_pago == "VN"
    assert Notificacion.objects.filter(cita=cita, tipo=Notificacion.Tipo.RESERVA).exists()
    registro = RegistroAuditoria.objects.get(accion=RegistroAuditoria.Accion.PAGAR_CITA)
    assert str(registro.recurso_id) == str(cita.pk)


def test_repetir_la_vuelta_no_confirma_dos_veces(webpay_falso, paciente, profesional, tratamiento):
    cita = _reservar(paciente, profesional, tratamiento)
    pago = _pagar(cita, webpay_falso)
    webpay_falso.falla_commit = True  # un segundo commit en Transbank fallaría
    otra_vez = pagos.procesar_retorno({"token_ws": pago.token}, ahora=AHORA)
    assert otra_vez.estado == Pago.Estado.AUTORIZADO
    assert Notificacion.objects.filter(tipo=Notificacion.Tipo.RESERVA).count() == 1


@pytest.mark.parametrize(
    "respuesta",
    [aprobado(response_code=-1), aprobado(status="FAILED", response_code=-1)],
)
def test_pago_rechazado_cancela_la_cita_y_libera_la_hora(
    webpay_falso, paciente, profesional, tratamiento, respuesta
):
    webpay_falso.respuesta_commit = respuesta
    cita = _reservar(paciente, profesional, tratamiento)
    pago = _pagar(cita, webpay_falso)
    cita.refresh_from_db()
    assert pago.estado == Pago.Estado.RECHAZADO
    assert cita.estado == Cita.Estado.CANCELADA
    assert cita.motivo_cancelacion == "Pago rechazado."
    # Otro paciente puede tomar la misma hora.
    otro = PacienteFactory()
    ConsentimientoFactory(paciente=otro)
    assert _reservar(otro, profesional, tratamiento).inicio == INICIO_BASE


def test_si_el_commit_falla_el_pago_queda_rechazado(
    webpay_falso, paciente, profesional, tratamiento
):
    webpay_falso.falla_commit = True
    pago = _pagar(_reservar(paciente, profesional, tratamiento), webpay_falso)
    assert pago.estado == Pago.Estado.RECHAZADO
    assert "Invalid status" in pago.error


def test_si_el_paciente_anula_en_webpay_la_hora_se_libera(
    webpay_falso, paciente, profesional, tratamiento
):
    cita = _reservar(paciente, profesional, tratamiento)
    _, token = pagos.iniciar_webpay(cita.pago, url_retorno=RETORNO, ahora=AHORA)
    pago = pagos.procesar_retorno(
        {"TBK_TOKEN": token, "TBK_ORDEN_COMPRA": cita.pago.orden_compra}, ahora=AHORA
    )
    cita.refresh_from_db()
    assert pago.estado == Pago.Estado.ABANDONADO
    assert cita.estado == Cita.Estado.CANCELADA


def test_si_se_agota_el_tiempo_en_webpay_la_hora_se_libera(
    webpay_falso, paciente, profesional, tratamiento
):
    cita = _reservar(paciente, profesional, tratamiento)
    pago = pagos.procesar_retorno({"TBK_ORDEN_COMPRA": cita.pago.orden_compra}, ahora=AHORA)
    assert pago.estado == Pago.Estado.ABANDONADO


def test_una_vuelta_sin_datos_conocidos_no_hace_nada(webpay_falso):
    assert pagos.procesar_retorno({}) is None
    assert pagos.procesar_retorno({"token_ws": "no-existe"}) is None


# --- plazo para pagar ---


def test_al_vencer_el_plazo_otro_paciente_puede_reservar_la_hora(
    webpay_falso, paciente, profesional, tratamiento
):
    cita = _reservar(paciente, profesional, tratamiento)
    despues = AHORA + timedelta(minutes=16)
    otro = PacienteFactory()
    ConsentimientoFactory(paciente=otro)
    nueva = _reservar(otro, profesional, tratamiento, ahora=despues)
    cita.refresh_from_db()
    assert nueva.inicio == INICIO_BASE
    assert cita.estado == Cita.Estado.CANCELADA
    assert cita.pago.estado == Pago.Estado.VENCIDO


def test_la_tarea_periodica_vence_los_pagos_atrasados(
    webpay_falso, paciente, profesional, tratamiento
):
    cita = _reservar(paciente, profesional, tratamiento)
    assert pagos.vencer_pendientes(ahora=AHORA + timedelta(minutes=14)) == 0
    assert pagos.vencer_pendientes(ahora=AHORA + timedelta(minutes=15)) == 1
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CANCELADA


def test_no_se_paga_una_reserva_vencida(webpay_falso, paciente, profesional, tratamiento):
    pago = _reservar(paciente, profesional, tratamiento).pago
    with pytest.raises(ValidationError, match="terminó"):
        pagos.iniciar_webpay(pago, url_retorno=RETORNO, ahora=AHORA + timedelta(minutes=20))


def test_si_webpay_aprueba_tras_vencer_el_plazo_se_devuelve_el_pago(
    webpay_falso, paciente, profesional, tratamiento
):
    cita = _reservar(paciente, profesional, tratamiento)
    _, token = pagos.iniciar_webpay(cita.pago, url_retorno=RETORNO, ahora=AHORA)
    pagos.vencer_pendientes(ahora=AHORA + timedelta(minutes=15))
    # El pago venció, pero el paciente terminó de pagar justo después.
    Pago.objects.filter(pk=cita.pago.pk).update(estado=Pago.Estado.PENDIENTE)
    pago = pagos.procesar_retorno({"token_ws": token}, ahora=AHORA + timedelta(minutes=16))
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CANCELADA
    assert pago.estado == Pago.Estado.REEMBOLSADO
    assert webpay_falso.reembolsos == [(token, 25000)]
    assert pago.motivo_reembolso == Pago.MotivoReembolso.HORA_LIBERADA


def test_un_bloqueo_no_puede_cruzar_una_hora_retenida(
    webpay_falso, paciente, profesional, tratamiento
):
    _reservar(paciente, profesional, tratamiento)
    with pytest.raises(ValidationError, match="cruza citas"):
        crear_bloqueo(
            profesional=profesional,
            inicio=INICIO_BASE,
            fin=INICIO_BASE + timedelta(hours=1),
            ahora=AHORA,
        )


def test_una_cita_pendiente_de_pago_no_se_cancela_a_mano(
    webpay_falso, paciente, profesional, tratamiento
):
    cita = _reservar(paciente, profesional, tratamiento)
    with pytest.raises(ValidationError, match="aún no está pagada"):
        cancelar_cita(cita=cita, usuario=paciente.usuario, ahora=AHORA)


# --- reembolso al cancelar ---


@pytest.mark.parametrize("quien", ["paciente", "profesional"])
def test_cancelar_una_cita_pagada_la_reembolsa(
    webpay_falso, paciente, profesional, tratamiento, quien
):
    cita = _reservar(paciente, profesional, tratamiento)
    pago = _pagar(cita, webpay_falso)
    usuario = paciente.usuario if quien == "paciente" else profesional.usuario
    mail.outbox.clear()
    cancelar_cita(cita=cita, usuario=usuario, ahora=AHORA + timedelta(hours=1))
    pago.refresh_from_db()
    assert pago.estado == Pago.Estado.REEMBOLSADO
    assert pago.tipo_reembolso == "REVERSED"
    assert webpay_falso.reembolsos == [(pago.token, 25000)]
    assert pago.motivo_reembolso == Pago.MotivoReembolso.CANCELACION
    aviso = Notificacion.objects.get(
        cita=cita, tipo=Notificacion.Tipo.CANCELACION, destinatario=paciente.usuario
    )
    assert "Te devolveremos $25.000" in aviso.cuerpo
    assert RegistroAuditoria.objects.filter(
        accion=RegistroAuditoria.Accion.REEMBOLSAR_PAGO
    ).exists()


def test_si_el_reembolso_falla_la_cita_se_cancela_y_se_reintenta(
    webpay_falso, paciente, profesional, tratamiento
):
    cita = _reservar(paciente, profesional, tratamiento)
    pago = _pagar(cita, webpay_falso)
    webpay_falso.falla_reembolso = True
    cancelar_cita(cita=cita, usuario=paciente.usuario, ahora=AHORA + timedelta(hours=1))
    cita.refresh_from_db()
    pago.refresh_from_db()
    assert cita.estado == Cita.Estado.CANCELADA
    assert pago.estado == Pago.Estado.REEMBOLSO_PENDIENTE
    assert pago.intentos_reembolso == 1
    webpay_falso.falla_reembolso = False
    assert pagos.reintentar_reembolsos() == {"reembolsados": 1, "fallidos": 0}
    pago.refresh_from_db()
    assert pago.estado == Pago.Estado.REEMBOLSADO


def test_los_reintentos_de_reembolso_tienen_tope(webpay_falso, paciente, profesional, tratamiento):
    cita = _reservar(paciente, profesional, tratamiento)
    pago = _pagar(cita, webpay_falso)
    webpay_falso.falla_reembolso = True
    cancelar_cita(cita=cita, usuario=paciente.usuario, ahora=AHORA + timedelta(hours=1))
    for _ in range(10):
        pagos.reintentar_reembolsos()
    pago.refresh_from_db()
    assert pago.intentos_reembolso == pagos.MAX_INTENTOS_REEMBOLSO


def test_cancelar_una_cita_sin_pago_en_linea_no_llama_a_transbank(
    webpay_falso, paciente, profesional
):
    cita = _reservar(paciente, profesional, TratamientoFactory(precio=0))
    cancelar_cita(cita=cita, usuario=paciente.usuario, ahora=AHORA)
    assert webpay_falso.reembolsos == []


# --- informes ---


def test_las_reservas_no_pagadas_no_cuentan_en_el_informe(
    webpay_falso, paciente, profesional, tratamiento
):
    _reservar(paciente, profesional, tratamiento)  # sigue pendiente
    otro = PacienteFactory()
    ConsentimientoFactory(paciente=otro)
    webpay_falso.respuesta_commit = aprobado(response_code=-1)
    rechazada = _reservar(otro, profesional, tratamiento, inicio=INICIO_BASE + timedelta(hours=2))
    _pagar(rechazada, webpay_falso)
    informe = calcular_informe(
        profesionales=[profesional], desde=INICIO_BASE.date(), hasta=INICIO_BASE.date()
    )
    assert informe["citas"]["total"] == 0
    assert "pendiente_pago" not in informe["citas"]["por_estado"]
