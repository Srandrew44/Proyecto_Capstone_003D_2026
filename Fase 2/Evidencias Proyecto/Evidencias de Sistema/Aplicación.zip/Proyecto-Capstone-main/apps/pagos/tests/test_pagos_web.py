"""Páginas del pago: reservar lleva a Webpay, la vuelta confirma y el comprobante es privado."""

from datetime import timedelta

import pytest
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from apps.agenda.horarios import horarios_libres
from apps.agenda.models import Cita, Notificacion
from apps.agenda.tests.factories import DisponibilidadFactory, TratamientoFactory
from apps.clinica.tests.factories import ConsentimientoFactory
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory
from apps.pagos.models import Pago

pytestmark = pytest.mark.django_db
HTMX = {"HTTP_HX_REQUEST": "true"}


def _cliente(usuario):
    cliente = Client()
    cliente.force_login(usuario)
    return cliente


@pytest.fixture
def reserva(webpay_falso):
    """Un paciente con consentimiento y los datos de una hora libre para reservar."""
    profesional = ProfesionalFactory()
    for dia in range(7):
        DisponibilidadFactory(profesional=profesional, dia_semana=dia)
    tratamiento = TratamientoFactory(precio=25000)
    paciente = PacienteFactory()
    ConsentimientoFactory(paciente=paciente)
    hoy = timezone.localdate()
    inicio = horarios_libres(
        profesional=profesional, tratamiento=tratamiento, desde=hoy, hasta=hoy + timedelta(days=30)
    )[0]
    datos = {
        "profesional": profesional.pk,
        "tratamiento": tratamiento.pk,
        "inicio": inicio.isoformat(),
    }
    return paciente, datos


def _reservar(paciente, datos):
    cliente = _cliente(paciente.usuario)
    respuesta = cliente.post(reverse("web:paciente-reservar"), datos, **HTMX)
    return cliente, respuesta, Cita.objects.get(paciente=paciente)


def test_reservar_lleva_a_la_pagina_de_pago(reserva):
    paciente, datos = reserva
    _, respuesta, cita = _reservar(paciente, datos)
    assert respuesta["HX-Redirect"] == reverse("web:pago-ir", args=[cita.pk])
    assert cita.estado == Cita.Estado.PENDIENTE_PAGO


def test_la_pagina_de_pago_envia_el_token_a_webpay(reserva):
    paciente, datos = reserva
    cliente, _, cita = _reservar(paciente, datos)
    respuesta = cliente.get(reverse("web:pago-ir", args=[cita.pk]))
    html = respuesta.content.decode()
    cita.pago.refresh_from_db()
    assert 'action="https://webpay3gint.transbank.cl/webpayserver/initTransaction"' in html
    assert f'name="token_ws" value="{cita.pago.token}"' in html
    assert "$25.000" in html
    assert "web/js/pago" in html
    # La política de seguridad permite enviar ese formulario a Webpay.
    assert "https://webpay3gint.transbank.cl" in respuesta["Content-Security-Policy"]


def test_el_retorno_url_apunta_a_la_vista_de_retorno(reserva, webpay_falso):
    paciente, datos = reserva
    cliente, _, cita = _reservar(paciente, datos)
    cliente.get(reverse("web:pago-ir", args=[cita.pk]))
    assert webpay_falso.creadas[0]["retorno"] == "http://testserver/pagos/webpay/retorno/"


def test_otro_paciente_no_ve_ni_paga_un_pago_ajeno(reserva):
    paciente, datos = reserva
    _, _, cita = _reservar(paciente, datos)
    intruso = _cliente(PacienteFactory().usuario)
    assert intruso.get(reverse("web:pago-ir", args=[cita.pk])).status_code == 404
    assert intruso.get(reverse("web:pago-resultado", args=[cita.pk])).status_code == 404


def test_la_vuelta_por_post_sin_sesion_ni_csrf_confirma_y_redirige(reserva):
    paciente, datos = reserva
    cliente, _, cita = _reservar(paciente, datos)
    cliente.get(reverse("web:pago-ir", args=[cita.pk]))
    token = Pago.objects.get(cita=cita).token
    # Transbank vuelve desde su dominio: sin cookie de sesión y sin token CSRF.
    webpay = Client(enforce_csrf_checks=True)
    respuesta = webpay.post(reverse("web:pago-retorno"), {"token_ws": token})
    assert respuesta.status_code == 302
    assert respuesta.url == reverse("web:pago-resultado", args=[cita.pk])
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CONFIRMADA
    comprobante = cliente.get(respuesta.url).content.decode()
    assert "¡Pago aprobado y cita confirmada!" in comprobante
    assert "1213" in comprobante
    assert "**** 6623" in comprobante
    assert "Crédito" in comprobante


def test_la_vuelta_por_get_tambien_funciona(reserva):
    paciente, datos = reserva
    cliente, _, cita = _reservar(paciente, datos)
    cliente.get(reverse("web:pago-ir", args=[cita.pk]))
    token = Pago.objects.get(cita=cita).token
    respuesta = Client().get(reverse("web:pago-retorno"), {"token_ws": token})
    assert respuesta.url == reverse("web:pago-resultado", args=[cita.pk])


def test_si_anula_en_webpay_el_comprobante_lo_dice(reserva):
    paciente, datos = reserva
    cliente, _, cita = _reservar(paciente, datos)
    cliente.get(reverse("web:pago-ir", args=[cita.pk]))
    token = Pago.objects.get(cita=cita).token
    respuesta = Client().post(
        reverse("web:pago-retorno"), {"TBK_TOKEN": token, "TBK_ORDEN_COMPRA": "x"}
    )
    html = cliente.get(respuesta.url).content.decode()
    assert "El pago no se completó" in html
    assert "Reservar otra vez" in html


def test_una_vuelta_desconocida_lleva_a_mis_citas():
    respuesta = Client().get(reverse("web:pago-retorno"))
    assert respuesta.url == reverse("web:paciente-citas")


def test_mis_citas_ofrece_completar_el_pago(reserva):
    paciente, datos = reserva
    cliente, _, cita = _reservar(paciente, datos)
    html = cliente.get(reverse("web:paciente-citas")).content.decode()
    assert "Pendiente de pago" in html
    assert reverse("web:pago-ir", args=[cita.pk]) in html


def test_mis_citas_libera_una_reserva_vencida(reserva):
    paciente, datos = reserva
    cliente, _, cita = _reservar(paciente, datos)
    Pago.objects.filter(cita=cita).update(vence_en=timezone.now() - timedelta(minutes=1))
    html = cliente.get(reverse("web:paciente-citas")).content.decode()
    cita.refresh_from_db()
    assert cita.estado == Cita.Estado.CANCELADA
    assert "Completar pago" not in html


def test_la_api_de_reserva_devuelve_donde_pagar(reserva, api_client):
    paciente, datos = reserva
    api_client.force_authenticate(paciente.usuario)
    respuesta = api_client.post("/api/citas/", datos, format="json")
    assert respuesta.status_code == 201
    cita = Cita.objects.get(paciente=paciente)
    assert respuesta.data["estado"] == "pendiente_pago"
    assert respuesta.data["pago_url"] == reverse("web:pago-ir", args=[cita.pk])


def test_el_boton_de_reserva_avisa_que_se_paga_con_webpay(reserva):
    paciente, datos = reserva
    html = (
        _cliente(paciente.usuario)
        .get(reverse("web:paciente-reservar"), datos, **HTMX)
        .content.decode()
    )
    assert "Confirmar y pagar con Webpay" in html


def test_el_modal_de_cancelar_avisa_el_reembolso(reserva):
    paciente, datos = reserva
    cliente, _, cita = _reservar(paciente, datos)
    cliente.get(reverse("web:pago-ir", args=[cita.pk]))
    Client().get(reverse("web:pago-retorno"), {"token_ws": Pago.objects.get(cita=cita).token})
    html = cliente.get(reverse("web:paciente-cancelar", args=[cita.pk]), **HTMX).content.decode()
    assert "Te devolveremos $25.000" in html


def _pagar(cliente, cita):
    cliente.get(reverse("web:pago-ir", args=[cita.pk]))
    token = Pago.objects.get(cita=cita).token
    return cliente.get(Client().get(reverse("web:pago-retorno"), {"token_ws": token}).url)


def test_el_comprobante_promete_el_recordatorio_solo_si_se_programo(reserva, settings):
    paciente, datos = reserva
    settings.NOTIFICACIONES_RECORDATORIO_HORAS = 1
    cliente, _, cita = _reservar(paciente, datos)
    html = _pagar(cliente, cita).content.decode()
    recordatorio = Notificacion.objects.get(cita=cita, tipo=Notificacion.Tipo.RECORDATORIO)
    momento = timezone.localtime(recordatorio.programada_para)
    assert "te recordaremos la cita el" in html
    assert f"{momento:%H:%M} hrs" in html
    assert "48 horas" not in html


def test_si_la_cita_esta_cerca_no_promete_recordatorio(reserva, settings):
    paciente, datos = reserva
    # La cita está a menos de este plazo: no se programa recordatorio.
    settings.NOTIFICACIONES_RECORDATORIO_HORAS = 24 * 60
    cliente, _, cita = _reservar(paciente, datos)
    html = _pagar(cliente, cita).content.decode()
    assert "¡Pago aprobado y cita confirmada!" in html
    assert "Te enviamos la confirmación por correo." in html
    assert "te recordaremos" not in html


def test_la_reserva_sin_pago_promete_el_recordatorio_solo_si_se_programo(reserva, settings):
    paciente, datos = reserva
    settings.PAGOS_WEBPAY_ACTIVO = False
    settings.NOTIFICACIONES_RECORDATORIO_HORAS = 24 * 60
    cliente = _cliente(paciente.usuario)
    html = cliente.post(reverse("web:paciente-reservar"), datos, **HTMX).content.decode()
    assert "¡Reserva confirmada!" in html
    assert "te recordaremos" not in html
    assert "48 horas" not in html


def test_la_reserva_sin_pago_dice_cuando_llega_el_recordatorio(reserva, settings):
    paciente, datos = reserva
    settings.PAGOS_WEBPAY_ACTIVO = False
    settings.NOTIFICACIONES_RECORDATORIO_HORAS = 1
    cliente = _cliente(paciente.usuario)
    html = cliente.post(reverse("web:paciente-reservar"), datos, **HTMX).content.decode()
    assert "te recordaremos la cita el" in html


def test_la_portada_no_promete_un_plazo_fijo():
    html = Client().get(reverse("web:portada")).content.decode()
    # El recuadro de cifras de la consulta ya no dice "48 h" fijo.
    assert ">48 h<" not in html
    assert "por correo antes de tu cita" in html


def test_un_pago_vencido_no_se_muestra_como_reservado(reserva):
    paciente, datos = reserva
    cliente, _, cita = _reservar(paciente, datos)
    Pago.objects.filter(cita=cita).update(vence_en=timezone.now() - timedelta(minutes=1))
    html = cliente.get(reverse("web:pago-resultado", args=[cita.pk])).content.decode()
    assert "sigue reservada" not in html
    assert "Pagar ahora" not in html
    assert "la hora quedó libre" in html
    assert Pago.objects.get(cita=cita).estado == Pago.Estado.VENCIDO


def test_el_comprobante_de_un_pago_por_verificar(reserva, webpay_falso):
    paciente, datos = reserva
    cliente, _, cita = _reservar(paciente, datos)
    cliente.get(reverse("web:pago-ir", args=[cita.pk]))
    token = Pago.objects.get(cita=cita).token
    webpay_falso.commit_sin_respuesta = "se_perdio"
    webpay_falso.falla_status = "red"
    respuesta = Client().get(reverse("web:pago-retorno"), {"token_ws": token})
    html = cliente.get(respuesta.url).content.decode()
    assert "Estamos confirmando tu pago" in html
    assert "Tu hora sigue reservada" in html
    assert "Reservar otra vez" not in html


def test_el_comprobante_explica_una_aprobacion_con_la_hora_liberada(reserva):
    paciente, datos = reserva
    cliente, _, cita = _reservar(paciente, datos)
    cliente.get(reverse("web:pago-ir", args=[cita.pk]))
    token = Pago.objects.get(cita=cita).token
    # La cita dejó de esperar el pago (p. ej. se anuló desde el admin) antes de la vuelta.
    Cita.objects.filter(pk=cita.pk).update(estado=Cita.Estado.CANCELADA)
    respuesta = Client().get(reverse("web:pago-retorno"), {"token_ws": token})
    html = cliente.get(respuesta.url).content.decode()
    assert "El pago se devolvió" in html
    assert "la hora se había liberado" in html
    assert "La cita se canceló." not in html


def test_el_comprobante_de_una_cita_pagada_y_cancelada(reserva, settings):
    paciente, datos = reserva
    settings.AGENDA_CANCELACION_MIN_HORAS = 1
    cliente, _, cita = _reservar(paciente, datos)
    _pagar(cliente, cita)
    cliente.post(reverse("web:paciente-cancelar", args=[cita.pk]), {"motivo": ""}, **HTMX)
    html = cliente.get(reverse("web:pago-resultado", args=[cita.pk])).content.decode()
    assert "El pago se devolvió" in html
    assert "La cita se canceló." in html
    assert "la hora se había liberado" not in html
