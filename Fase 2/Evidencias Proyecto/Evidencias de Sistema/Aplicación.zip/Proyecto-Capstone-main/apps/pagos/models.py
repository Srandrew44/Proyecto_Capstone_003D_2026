import uuid

from django.contrib.postgres.fields import ArrayField
from django.db import models
from django.utils import timezone


class Pago(models.Model):
    """Pago en línea de una cita con Webpay Plus (Transbank).

    Se crea junto con la cita, que queda pendiente de pago y retiene la hora hasta `vence_en`.
    Si Webpay aprueba, la cita se confirma; si se rechaza, se abandona o vence, la cita se
    cancela y la hora se libera. Si después se cancela una cita pagada, se reembolsa.
    Si Transbank no responde al confirmar, no se sabe si cobró: el pago queda "por verificar"
    (la hora sigue retenida) hasta que la tarea periódica consulte su estado.
    No se guarda ningún dato de la tarjeta salvo sus últimos 4 dígitos (para el comprobante).
    """

    class Estado(models.TextChoices):
        PENDIENTE = "pendiente", "Pendiente"
        POR_VERIFICAR = "por_verificar", "Por verificar con Transbank"
        AUTORIZADO = "autorizado", "Autorizado"
        RECHAZADO = "rechazado", "Rechazado"
        ABANDONADO = "abandonado", "Abandonado en Webpay"
        VENCIDO = "vencido", "Vencido sin pagar"
        REEMBOLSO_PENDIENTE = "reembolso_pendiente", "Reembolso pendiente"
        # Ya se pidió a Transbank y no ha vuelto la respuesta: nadie más debe pedirlo.
        REEMBOLSANDO = "reembolsando", "Reembolso en curso"
        REEMBOLSADO = "reembolsado", "Reembolsado"

    class MotivoReembolso(models.TextChoices):
        CANCELACION = "cancelacion", "Se canceló la cita pagada"
        # Transbank aprobó cuando la cita ya no esperaba el pago (se liberó o anuló la hora).
        HORA_LIBERADA = "hora_liberada", "Pago aprobado con la hora ya liberada"

    # Estados de un intento que nunca llegó a cobrarse: la cita no cuenta en los informes.
    SIN_COBRO = (Estado.RECHAZADO, Estado.ABANDONADO, Estado.VENCIDO)

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    cita = models.OneToOneField("agenda.Cita", on_delete=models.PROTECT, related_name="pago")
    monto = models.PositiveIntegerField(help_text="Pesos chilenos. Es el precio de la cita.")
    # Transbank acepta hasta 26 caracteres en la orden de compra.
    orden_compra = models.CharField(max_length=26, unique=True)
    token = models.CharField(max_length=64, unique=True, null=True, blank=True)
    token_creado_en = models.DateTimeField(
        null=True, blank=True, help_text="Cuándo se abrió en Transbank la transacción actual."
    )
    # Transacciones reemplazadas por una nueva (p. ej., el paciente recargó Webpay). Se
    # guardan para reconocer la vuelta si de todos modos pagó en una de ellas.
    tokens_anteriores = ArrayField(models.CharField(max_length=64), default=list, blank=True)
    url_webpay = models.URLField(blank=True)
    estado = models.CharField(max_length=20, choices=Estado.choices, default=Estado.PENDIENTE)
    vence_en = models.DateTimeField(help_text="Hasta cuándo la hora queda retenida sin pagar.")

    codigo_respuesta = models.SmallIntegerField(null=True, blank=True)
    codigo_autorizacion = models.CharField(max_length=10, blank=True)
    tipo_pago = models.CharField(max_length=2, blank=True, help_text="VD débito, VN crédito…")
    cuotas = models.PositiveSmallIntegerField(default=0)
    tarjeta_final = models.CharField(max_length=4, blank=True)
    fecha_transaccion = models.DateTimeField(null=True, blank=True)

    creado_en = models.DateTimeField(auto_now_add=True)
    confirmado_en = models.DateTimeField(null=True, blank=True)
    reembolsado_en = models.DateTimeField(null=True, blank=True)
    tipo_reembolso = models.CharField(max_length=10, blank=True, help_text="REVERSED o NULLIFIED")
    intentos_reembolso = models.PositiveSmallIntegerField(default=0)
    reembolso_iniciado_en = models.DateTimeField(
        null=True, blank=True, help_text="Cuándo se pidió a Transbank el último reembolso."
    )
    motivo_reembolso = models.CharField(max_length=15, choices=MotivoReembolso.choices, blank=True)
    error = models.CharField(max_length=500, blank=True)

    class Meta:
        verbose_name = "pago"
        verbose_name_plural = "pagos"
        ordering = ["-creado_en"]
        indexes = [models.Index(fields=["estado", "vence_en"], name="pago_estado_vence_idx")]
        constraints = [
            models.CheckConstraint(condition=models.Q(monto__gt=0), name="pago_monto_positivo"),
        ]

    def __str__(self):
        return f"{self.orden_compra} ({self.get_estado_display()})"

    def es_de(self, usuario) -> bool:
        return usuario.is_authenticated and self.cita.paciente_id == usuario.pk

    def vencido(self, ahora=None) -> bool:
        return self.estado == self.Estado.PENDIENTE and self.vence_en <= (ahora or timezone.now())
