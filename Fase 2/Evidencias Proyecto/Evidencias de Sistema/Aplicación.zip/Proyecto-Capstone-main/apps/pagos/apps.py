from django.apps import AppConfig


class PagosConfig(AppConfig):
    name = "apps.pagos"
    label = "pagos"
    verbose_name = "Pagos"
