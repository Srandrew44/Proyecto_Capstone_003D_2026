from django.contrib import admin

from .models import Pago


@admin.register(Pago)
class PagoAdmin(admin.ModelAdmin):
    """Solo lectura: los pagos los cambian Webpay y los servicios, nunca a mano."""

    list_display = ["orden_compra", "cita", "monto", "estado", "creado_en", "reembolsado_en"]
    list_filter = ["estado"]
    search_fields = ["orden_compra", "codigo_autorizacion"]
    exclude = ["token"]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
