"""Pago de citas con Webpay Plus.

Flujo:
1. `reservar_cita` (agenda) crea la cita pendiente de pago y su `Pago` (`crear_pago`), en la
   misma transacción. La hora queda retenida hasta `vence_en`.
2. `iniciar_webpay` abre la transacción en Transbank y devuelve a dónde enviar al paciente.
3. Webpay vuelve a la URL de retorno y `procesar_retorno` confirma el pago: si se aprueba, la
   cita se confirma y sale el correo de reserva; si no, la cita se cancela y la hora se libera.
   Si Transbank no responde al confirmar (red, 5xx), no se sabe si cobró: se consulta el
   estado y, si tampoco se sabe, el pago queda "por verificar" con la hora retenida, y la
   tarea periódica (`verificar_pagos`) lo resuelve después.
4. Si una cita pagada se cancela, `reembolsar` devuelve el dinero por la API de Transbank. Si
   Transbank falla, el pago queda "reembolso pendiente" y la tarea periódica lo reintenta.

Este módulo no importa `apps.agenda.services` (que sí lo usa a él).
"""

import logging
import secrets
from datetime import timedelta

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Q
from django.utils import timezone
from django.utils.dateparse import parse_datetime

from apps.agenda import notificaciones
from apps.agenda.models import Cita
from apps.auditoria.models import RegistroAuditoria
from apps.auditoria.services import registrar
from integraciones import webpay

from .models import Pago

logger = logging.getLogger(__name__)

APROBADO = "AUTHORIZED"
INICIADA = "INITIALIZED"  # abierta en Transbank y aún sin confirmar (commit)
ANULADA = ("REVERSED", "NULLIFIED")  # lo que deja un reembolso hecho
MAX_INTENTOS_REEMBOLSO = 5
# Un reembolso que lleva más que esto "reembolsando" quedó a medias (se cayó el proceso):
# la tarea periódica lo retoma, consultando antes a Transbank. Muy por sobre TRANSBANK_TIMEOUT.
REEMBOLSO_ABANDONADO = timedelta(minutes=10)
# Transbank informa el estado de una transacción solo durante 7 días; después, un pago que
# siga por verificar se revisa a mano (aparece filtrando por estado en el admin).
PLAZO_VERIFICACION = timedelta(days=7)
# Una transacción abierta hace menos que esto se reutiliza (doble clic en "Completar pago").
# Una más antigua no: si el paciente recargó el formulario de Webpay, Transbank la sigue
# dando por iniciada, pero Webpay ya no deja pagar con ella y se le mostraría el mismo error.
REUTILIZAR_TOKEN = timedelta(seconds=30)


def requiere_pago(tratamiento) -> bool:
    return settings.PAGOS_WEBPAY_ACTIVO and tratamiento.precio > 0


def crear_pago(cita, *, ahora=None) -> Pago:
    """Pago pendiente de una cita recién reservada. No llama a Transbank."""
    ahora = ahora or timezone.now()
    return Pago.objects.create(
        cita=cita,
        monto=cita.precio,
        orden_compra=_nueva_orden_compra(),
        vence_en=ahora + timedelta(minutes=settings.PAGOS_PLAZO_MIN),
    )


def iniciar_webpay(pago: Pago, *, url_retorno: str, ahora=None) -> tuple[str, str]:
    """Abre (o reutiliza) la transacción de Webpay. Devuelve (url, token) para el formulario.

    La fila del pago se bloquea: con un doble clic en "Completar pago", la segunda petición
    espera a la primera y reutiliza su transacción en vez de abrir otra en Transbank (si no,
    el pago guardaría solo el último token y la vuelta con el primero no se reconocería).
    Un token ya abierto se reutiliza solo si es reciente (`REUTILIZAR_TOKEN`) y Transbank lo
    sigue teniendo como INITIALIZED; si no, se abre una transacción nueva con otra orden de
    compra, y el token anterior se guarda para reconocer la vuelta si pagó con él.
    """
    ahora = ahora or timezone.now()
    with transaction.atomic():
        bloqueado = Pago.objects.select_for_update().select_related("cita").get(pk=pago.pk)
        if bloqueado.estado == Pago.Estado.POR_VERIFICAR:
            raise ValidationError(
                "Estamos confirmando tu pago con Transbank. Revisa tus citas en unos minutos."
            )
        if bloqueado.estado != Pago.Estado.PENDIENTE:
            raise ValidationError("Este pago ya no está pendiente.")
        if bloqueado.vencido(ahora):
            raise ValidationError("El tiempo para pagar terminó y la hora se liberó.")
        token_anterior = bloqueado.token
        if token_anterior and _token_reutilizable(bloqueado, ahora):
            return bloqueado.url_webpay, bloqueado.token
        if token_anterior:
            # Transbank no acepta repetir la orden de compra: la transacción nueva lleva otra.
            bloqueado.orden_compra = _nueva_orden_compra()
        try:
            respuesta = webpay.crear(
                orden_compra=bloqueado.orden_compra,
                sesion=bloqueado.cita.paciente_id.hex,
                monto=bloqueado.monto,
                url_retorno=url_retorno,
            )
        except webpay.ErrorWebpay as exc:
            logger.warning("Webpay no abrió la transacción %s: %s", bloqueado.orden_compra, exc)
            raise ValidationError(
                "No pudimos conectar con Webpay. Inténtalo en un momento."
            ) from exc
        if token_anterior:
            bloqueado.tokens_anteriores = [*bloqueado.tokens_anteriores, token_anterior]
        bloqueado.token = respuesta["token"]
        bloqueado.token_creado_en = ahora
        bloqueado.url_webpay = respuesta["url"]
        bloqueado.save(
            update_fields=[
                "orden_compra",
                "token",
                "token_creado_en",
                "tokens_anteriores",
                "url_webpay",
            ]
        )
    pago.orden_compra = bloqueado.orden_compra
    pago.token = bloqueado.token
    pago.token_creado_en = bloqueado.token_creado_en
    pago.tokens_anteriores = bloqueado.tokens_anteriores
    pago.url_webpay = bloqueado.url_webpay
    return pago.url_webpay, pago.token


def _token_reutilizable(pago: Pago, ahora) -> bool:
    """¿Sirve todavía la transacción abierta? Se pregunta a Transbank por su estado.

    - INITIALIZED y reciente: sí; es el doble clic en "Completar pago".
    - INITIALIZED y no reciente: no. El paciente volvió a pedir pagar, casi siempre porque
      recargó o cerró el formulario de Webpay, que ya no deja seguir con esa transacción.
    - AUTHORIZED: el paciente ya pagó y la vuelta aún no llega; abrir otra arriesga un doble
      cobro, así que se le pide esperar.
    - Otro estado, o Transbank no reconoce el token (4xx): venció o se cerró; se abre otra.
    - Sin respuesta (red): se reutiliza, porque no se puede descartar que ya esté autorizada;
      si venció, Webpay se lo dirá al paciente.
    """
    try:
        estado = webpay.consultar(pago.token).get("status")
    except webpay.ResultadoDesconocido as exc:
        logger.warning("No se pudo consultar la transacción %s: %s", pago.orden_compra, exc)
        return True
    except webpay.ErrorWebpay as exc:
        logger.info("Transbank no reconoce la transacción %s: %s", pago.orden_compra, exc)
        return False
    if estado == APROBADO:
        raise ValidationError(
            "Tu pago ya fue autorizado y lo estamos confirmando. Revisa tus citas en unos minutos."
        )
    reciente = pago.token_creado_en is not None and ahora - pago.token_creado_en < REUTILIZAR_TOKEN
    return estado == INICIADA and reciente


def _nueva_orden_compra() -> str:
    # "MP" + 24 caracteres al azar: única y dentro de los 26 que acepta Transbank.
    return "MP" + secrets.token_hex(12)


def procesar_retorno(datos, *, ip=None, ahora=None) -> Pago | None:
    """Atiende la vuelta desde Webpay. `datos` son los parámetros GET o POST que envía.

    - Solo `token_ws`: flujo normal; se confirma el pago (commit).
    - `TBK_TOKEN` (con o sin `token_ws`): el paciente anuló el pago en el formulario.
    - Solo `TBK_ORDEN_COMPRA`: se agotó el tiempo en Webpay.
    Devuelve el pago, o None si los datos no corresponden a ninguno. Repetir la misma vuelta
    (recargar la página) no vuelve a confirmar: el pago ya no está pendiente.

    Si el commit falla sin respuesta clara (red, 5xx), Transbank pudo haber cobrado: no se
    rechaza, se consulta el estado y, si sigue sin saberse, el pago queda por verificar.

    La vuelta puede traer un token anterior (el paciente pidió pagar de nuevo, pero terminó
    pagando en el formulario viejo). Si pagó con él, se confirma ese y pasa a ser el token del
    pago; si lo anuló, no se cierra nada, porque puede estar pagando con el nuevo.
    """
    ahora = ahora or timezone.now()
    token_ws, tbk_token = datos.get("token_ws"), datos.get("TBK_TOKEN")
    token = tbk_token or token_ws
    if token:
        filtro = Q(token=token) | Q(tokens_anteriores__contains=[token])
    elif datos.get("TBK_ORDEN_COMPRA"):
        filtro = Q(orden_compra=datos["TBK_ORDEN_COMPRA"])
    else:
        return None

    with transaction.atomic():
        pago = (
            Pago.objects.select_for_update(of=("self",))
            .select_related("cita__paciente__usuario", "cita__profesional__usuario")
            .filter(filtro)
            .first()
        )
        if pago is None or pago.estado != Pago.Estado.PENDIENTE:
            return pago
        if token and pago.token != token:
            if tbk_token or not token_ws:
                return pago
            # Pagó con una transacción anterior: esa es la que se confirma (y la que se
            # consulta o reembolsa después). La que la reemplazó queda sin usar.
            pago.tokens_anteriores = [t for t in pago.tokens_anteriores if t != token]
            pago.tokens_anteriores.append(pago.token)
            pago.token = token
            pago.save(update_fields=["token", "tokens_anteriores"])
        if tbk_token or not token_ws:
            _cerrar_sin_cobro(pago, Pago.Estado.ABANDONADO, "Pago no completado.", ahora)
            return pago
        try:
            respuesta = webpay.confirmar(token_ws)
        except webpay.ResultadoDesconocido as exc:
            respuesta = _consultar_tras_commit_fallido(pago, exc)
            if respuesta is None:
                return pago
        except webpay.ErrorWebpay as exc:
            # Transbank respondió que no (4xx): por ejemplo, la tarjeta fue rechazada antes
            # de autorizar o la transacción expiró. No hubo cobro.
            pago.error = str(exc)[:500]
            _cerrar_sin_cobro(pago, Pago.Estado.RECHAZADO, "Pago rechazado.", ahora)
            return pago
        por_devolver = _aplicar_respuesta(pago, respuesta, ahora=ahora, ip=ip)
    if por_devolver:
        reembolsar(pago, ahora=ahora)
    return pago


def _consultar_tras_commit_fallido(pago: Pago, exc) -> dict | None:
    """El commit no tuvo respuesta clara: se pregunta a Transbank cómo quedó la transacción.

    Devuelve la respuesta del status si dice algo definitivo (aprobada o rechazada). Si el
    status tampoco responde, o la transacción sigue INITIALIZED (el commit no llegó), deja el
    pago por verificar y devuelve None: la tarea periódica lo resolverá.
    """
    logger.warning("Commit sin respuesta clara para %s: %s", pago.orden_compra, exc)
    pago.error = str(exc)[:500]
    try:
        respuesta = webpay.consultar(pago.token)
    except webpay.ErrorWebpay as error_status:
        logger.warning("Tampoco se pudo consultar %s: %s", pago.orden_compra, error_status)
        respuesta = None
    if respuesta is None or respuesta.get("status") == INICIADA:
        _dejar_por_verificar(pago)
        return None
    try:
        return _confirmar_si_falta(pago.token, respuesta)
    except webpay.ResultadoDesconocido as error_commit:
        logger.warning("Reintento de commit sin respuesta para %s", pago.orden_compra)
        pago.error = str(error_commit)[:500]
        _dejar_por_verificar(pago)
        return None


def _confirmar_si_falta(token: str, respuesta_status: dict) -> dict:
    """El status dice AUTHORIZED, pero no asegura que el commit se haya hecho: sin commit,
    Transbank anula el cobro y la cita quedaría confirmada sin pago. Se intenta el commit:
    si responde, vale su respuesta; si Transbank lo rechaza (4xx, normalmente porque ya
    estaba confirmada), vale el status. Si no responde, sube `ResultadoDesconocido`."""
    if respuesta_status.get("status") != APROBADO:
        return respuesta_status
    try:
        return webpay.confirmar(token)
    except webpay.ResultadoDesconocido:
        raise
    except webpay.ErrorWebpay:
        return respuesta_status


def _dejar_por_verificar(pago: Pago) -> None:
    """No se sabe si Transbank cobró: no se cancela la cita ni se libera la hora.

    `horarios_libres` da por libre una hora pendiente de pago cuyo `vence_en` pasó, y
    `vencer_pendientes` solo toca pagos pendientes; por eso `vence_en` se estira hasta el fin
    de la cita: la hora queda retenida mientras se verifica.
    """
    pago.estado = Pago.Estado.POR_VERIFICAR
    pago.vence_en = max(pago.vence_en, pago.cita.fin)
    pago.save(update_fields=["estado", "vence_en", "error"])


def _aprobada(respuesta: dict) -> bool:
    return respuesta.get("status") == APROBADO and respuesta.get("response_code") == 0


def _aplicar_respuesta(pago: Pago, respuesta: dict, *, ahora, ip=None) -> bool:
    """Aplica una respuesta definitiva del commit (o del status, que trae los mismos campos).

    Aprobada: el pago queda autorizado y la cita pendiente se confirma. Si la cita ya no
    esperaba el pago (se anuló o se liberó mientras Transbank respondía o se verificaba), el
    pago queda por reembolsar y se devuelve True: quien llama reembolsa fuera de la
    transacción. Rechazada: la cita se cancela y la hora se libera.
    """
    _guardar_respuesta(pago, respuesta)
    if not _aprobada(respuesta):
        _cerrar_sin_cobro(pago, Pago.Estado.RECHAZADO, "Pago rechazado.", ahora)
        return False

    pago.estado = Pago.Estado.AUTORIZADO
    pago.confirmado_en = ahora
    pago.error = ""
    pago.save()
    cita = (
        Cita.objects.select_for_update(of=("self",))
        .select_related("paciente__usuario")
        .get(pk=pago.cita_id)
    )
    registrar(
        accion=RegistroAuditoria.Accion.PAGAR_CITA,
        usuario=cita.paciente.usuario,
        recurso_tipo="cita",
        recurso_id=cita.pk,
        ip=ip,
        detalle={"orden_compra": pago.orden_compra, "monto": pago.monto},
    )
    if cita.estado == Cita.Estado.PENDIENTE_PAGO:
        cita.estado = Cita.Estado.CONFIRMADA
        cita.save(update_fields=["estado"])
        notificaciones.notificar_reserva(cita, ahora=ahora)
        return False
    pago.estado = Pago.Estado.REEMBOLSO_PENDIENTE
    pago.motivo_reembolso = Pago.MotivoReembolso.HORA_LIBERADA
    pago.save(update_fields=["estado", "motivo_reembolso"])
    return True


def _guardar_respuesta(pago: Pago, respuesta: dict) -> None:
    # Si pagó con una transacción anterior, su orden de compra es otra que la actual.
    if respuesta.get("buy_order"):
        pago.orden_compra = respuesta["buy_order"]
    pago.codigo_respuesta = respuesta.get("response_code")
    pago.codigo_autorizacion = respuesta.get("authorization_code") or ""
    pago.tipo_pago = respuesta.get("payment_type_code") or ""
    pago.cuotas = respuesta.get("installments_number") or 0
    tarjeta = (respuesta.get("card_detail") or {}).get("card_number") or ""
    pago.tarjeta_final = tarjeta[-4:]
    fecha = respuesta.get("transaction_date")
    pago.fecha_transaccion = parse_datetime(fecha) if fecha else None


def _cerrar_sin_cobro(pago: Pago, estado, motivo: str, ahora) -> None:
    """El pago no se cobró: se cierra y la cita pendiente se cancela, liberando la hora."""
    pago.estado = estado
    pago.save()
    Cita.objects.filter(pk=pago.cita_id, estado=Cita.Estado.PENDIENTE_PAGO).update(
        estado=Cita.Estado.CANCELADA, cancelada_en=ahora, motivo_cancelacion=motivo
    )


def verificar_pagos(*, ahora=None) -> dict:
    """Tarea periódica: resuelve los pagos por verificar preguntando a Transbank.

    - AUTHORIZED: se da por aprobado (y se reembolsa si la cita ya no lo esperaba).
    - INITIALIZED: el commit nunca llegó; se reintenta ahora.
    - Otro estado, o un "no" de Transbank: no hubo cobro; la cita se cancela y la hora se
      libera.
    - Sin respuesta: se intenta de nuevo en la próxima vuelta (hasta PLAZO_VERIFICACION).
    """
    ahora = ahora or timezone.now()
    resumen = {"aprobados": 0, "rechazados": 0, "sin_respuesta": 0}
    ids = Pago.objects.filter(
        estado=Pago.Estado.POR_VERIFICAR, creado_en__gte=ahora - PLAZO_VERIFICACION
    ).values_list("pk", flat=True)
    for pk in list(ids):
        resultado = _verificar(pk, ahora)
        if resultado:
            resumen[resultado] += 1
    return resumen


def _verificar(pk, ahora) -> str | None:
    with transaction.atomic():
        pago = (
            Pago.objects.select_for_update(of=("self",), skip_locked=True)
            .select_related("cita")
            .filter(pk=pk, estado=Pago.Estado.POR_VERIFICAR)
            .first()
        )
        if pago is None:  # otro proceso lo está resolviendo, o ya se resolvió
            return None
        try:
            respuesta = webpay.consultar(pago.token)
            if respuesta.get("status") == INICIADA:
                respuesta = webpay.confirmar(pago.token)
            else:
                respuesta = _confirmar_si_falta(pago.token, respuesta)
        except webpay.ResultadoDesconocido as exc:
            logger.warning("El pago %s sigue por verificar: %s", pago.orden_compra, exc)
            pago.error = str(exc)[:500]
            pago.save(update_fields=["error"])
            return "sin_respuesta"
        except webpay.ErrorWebpay as exc:
            # Un "no" de Transbank al status o al commit reintentado: no hubo cobro.
            pago.error = str(exc)[:500]
            _cerrar_sin_cobro(pago, Pago.Estado.RECHAZADO, "Pago rechazado.", ahora)
            return "rechazados"
        por_devolver = _aplicar_respuesta(pago, respuesta, ahora=ahora)
    if por_devolver:
        reembolsar(pago, ahora=ahora)
    return "rechazados" if pago.estado == Pago.Estado.RECHAZADO else "aprobados"


def vencer_pendientes(*, ahora=None, profesional=None, paciente=None) -> int:
    """Cancela las citas cuyo plazo para pagar terminó y libera sus horas.

    Se llama al reservar (para la agenda y el paciente involucrados) y en la tarea periódica.
    Los pagos por verificar no se tocan: puede que Transbank sí haya cobrado.
    """
    ahora = ahora or timezone.now()
    pagos = Pago.objects.filter(estado=Pago.Estado.PENDIENTE, vence_en__lte=ahora)
    if profesional is not None:
        pagos = pagos.filter(cita__profesional=profesional)
    if paciente is not None:
        pagos = pagos.filter(cita__paciente=paciente)
    total = 0
    with transaction.atomic():
        for pago in pagos.select_for_update(of=("self",), skip_locked=True):
            _cerrar_sin_cobro(pago, Pago.Estado.VENCIDO, "Pago no completado a tiempo.", ahora)
            total += 1
    return total


def marcar_reembolso(cita) -> Pago | None:
    """Dentro de la cancelación de una cita: si estaba pagada, queda por reembolsar."""
    pago = Pago.objects.select_for_update().filter(cita=cita).first()
    if pago is None or pago.estado != Pago.Estado.AUTORIZADO:
        return None
    pago.estado = Pago.Estado.REEMBOLSO_PENDIENTE
    pago.motivo_reembolso = Pago.MotivoReembolso.CANCELACION
    pago.save(update_fields=["estado", "motivo_reembolso"])
    return pago


# Resultados de un intento de reembolso.
REEMBOLSADO, FALLIDO, OMITIDO = "reembolsado", "fallido", "omitido"


def reembolsar(pago: Pago, *, ahora=None) -> bool:
    """Pide a Transbank la devolución de un pago marcado para reembolso. True si se hizo.

    Se llama fuera de la transacción de la cancelación: si Transbank no responde, la cita
    igual queda cancelada y el reembolso se reintenta después. Deja `pago` al día.
    """
    resultado = _reembolsar(pago.pk, ahora or timezone.now())
    pago.refresh_from_db()
    return resultado == REEMBOLSADO


def _reembolsar(pk, ahora) -> str:
    """Hace un reembolso sin pedirlo dos veces a Transbank.

    1. Con la fila bloqueada, el pago pasa a "reembolsando" y se guarda. Otra ejecución a la
       vez (la cancelación y la tarea periódica) espera el bloqueo, ve ese estado y no hace
       nada. Si el proceso se cae a medio camino, la tarea lo retoma pasado
       REEMBOLSO_ABANDONADO.
    2. Si es un reintento o se retoma, primero se consulta el estado: si Transbank ya lo
       tiene REVERSED/NULLIFIED, se marca reembolsado sin volver a pedirlo.
    3. Si el refund falla sin respuesta clara (red, 5xx), se consulta el estado antes de dar
       el intento por fallido: el refund pudo hacerse aunque la respuesta se perdiera.
    """
    with transaction.atomic():
        pago = Pago.objects.select_for_update().get(pk=pk)
        abandonado = (
            pago.estado == Pago.Estado.REEMBOLSANDO
            and pago.reembolso_iniciado_en is not None
            and pago.reembolso_iniciado_en <= ahora - REEMBOLSO_ABANDONADO
        )
        if pago.estado != Pago.Estado.REEMBOLSO_PENDIENTE and not abandonado:
            return OMITIDO
        consultar_antes = abandonado or pago.intentos_reembolso > 0
        pago.estado = Pago.Estado.REEMBOLSANDO
        pago.reembolso_iniciado_en = ahora
        pago.save(update_fields=["estado", "reembolso_iniciado_en"])

    if consultar_antes:
        try:
            estado = webpay.consultar(pago.token).get("status")
        except webpay.ErrorWebpay as exc:
            return _reembolso_fallido(pago, f"No se pudo consultar antes de reintentar: {exc}")
        if estado in ANULADA:
            return _marcar_reembolsado(pago, ahora, tipo=estado)
    try:
        respuesta = webpay.reembolsar(pago.token, pago.monto)
    except webpay.ResultadoDesconocido as exc:
        try:
            estado = webpay.consultar(pago.token).get("status")
        except webpay.ErrorWebpay:
            estado = None
        if estado in ANULADA:
            return _marcar_reembolsado(pago, ahora, tipo=estado)
        return _reembolso_fallido(pago, str(exc))
    except webpay.ErrorWebpay as exc:
        return _reembolso_fallido(pago, str(exc))
    return _marcar_reembolsado(pago, ahora, tipo=respuesta.get("type") or "")


def _marcar_reembolsado(pago: Pago, ahora, *, tipo: str) -> str:
    with transaction.atomic():
        pago.estado = Pago.Estado.REEMBOLSADO
        pago.reembolsado_en = ahora
        pago.tipo_reembolso = tipo[:10]
        pago.error = ""
        pago.save(update_fields=["estado", "reembolsado_en", "tipo_reembolso", "error"])
        registrar(
            accion=RegistroAuditoria.Accion.REEMBOLSAR_PAGO,
            usuario=None,
            recurso_tipo="cita",
            recurso_id=pago.cita_id,
            detalle={"orden_compra": pago.orden_compra, "monto": pago.monto},
        )
    return REEMBOLSADO


def _reembolso_fallido(pago: Pago, error: str) -> str:
    """Vuelve a "reembolso pendiente" para reintentarlo; al agotar los intentos, avisa."""
    intentos = pago.intentos_reembolso + 1
    Pago.objects.filter(pk=pago.pk).update(
        estado=Pago.Estado.REEMBOLSO_PENDIENTE, intentos_reembolso=intentos, error=error[:500]
    )
    if intentos >= MAX_INTENTOS_REEMBOLSO:
        logger.error(
            "El reembolso de %s (cita %s, $%s) falló %s veces y no se reintentará más: "
            "hay que revisarlo y devolverlo a mano en el portal de Transbank. Último error: %s",
            pago.orden_compra,
            pago.cita_id,
            pago.monto,
            intentos,
            error,
        )
    else:
        logger.warning("Falló el reembolso de %s: %s", pago.orden_compra, error)
    return FALLIDO


def reintentar_reembolsos(*, ahora=None) -> dict:
    """Tarea periódica: reintenta los reembolsos que fallaron, hasta MAX_INTENTOS_REEMBOLSO, y
    retoma los que quedaron a medias ("reembolsando" hace más de REEMBOLSO_ABANDONADO)."""
    ahora = ahora or timezone.now()
    resumen = {"reembolsados": 0, "fallidos": 0}
    pendientes = Pago.objects.filter(
        Q(estado=Pago.Estado.REEMBOLSO_PENDIENTE, intentos_reembolso__lt=MAX_INTENTOS_REEMBOLSO)
        | Q(
            estado=Pago.Estado.REEMBOLSANDO,
            reembolso_iniciado_en__lte=ahora - REEMBOLSO_ABANDONADO,
        )
    ).values_list("pk", flat=True)
    for pk in list(pendientes):
        resultado = _reembolsar(pk, ahora)
        if resultado == REEMBOLSADO:
            resumen["reembolsados"] += 1
        elif resultado == FALLIDO:
            resumen["fallidos"] += 1
    return resumen
