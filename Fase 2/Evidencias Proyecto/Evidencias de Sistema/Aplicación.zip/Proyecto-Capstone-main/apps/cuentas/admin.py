"""Panel de administración de cuentas.

- Usuario es la cuenta para entrar; Paciente y Profesional son sus perfiles (se ven dentro de
  la página del usuario).
- Un podólogo se crea en un solo paso desde "Profesionales → Añadir": cuenta y perfil juntos.
- Nada se borra: las cuentas se dan de baja (no entran ni aparecen para reservar) y su
  historia clínica se conserva, como exige la normativa de fichas clínicas.
- Las certificaciones las sube el podólogo; aquí se revisa el documento y se verifican. Solo
  las verificadas se muestran a los pacientes.
"""

from django import forms
from django.contrib import admin, messages
from django.contrib.admin.exceptions import NotRegistered
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.forms import UserChangeForm, UserCreationForm
from django.contrib.auth.password_validation import validate_password
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404
from django.urls import path, reverse
from django.utils.html import format_html
from django_otp.plugins.otp_totp.admin import TOTPDeviceAdmin
from django_otp.plugins.otp_totp.models import TOTPDevice

from apps.agenda.models import Disponibilidad
from apps.auditoria.services import ip_de

from . import services
from .models import Certificacion, DispositivoVerificacion, Paciente, Profesional, Usuario


class UsuarioCreationForm(UserCreationForm):
    """El formulario por defecto apunta a auth.User, que aquí está reemplazado."""

    class Meta:
        model = Usuario
        fields = ("email", "nombre", "apellido", "telefono", "rol")


class UsuarioChangeForm(UserChangeForm):
    class Meta:
        model = Usuario
        fields = "__all__"


# --- acciones comunes: dar de baja y reactivar ---


def _usuario_de(obj):
    return obj if isinstance(obj, Usuario) else obj.usuario


@admin.action(description="Dar de baja (no podrán entrar; su historia se conserva)")
def dar_de_baja(modeladmin, request, queryset):
    bajas, citas = 0, 0
    for obj in queryset:
        usuario = _usuario_de(obj)
        if usuario.pk == request.user.pk:
            modeladmin.message_user(request, "No puedes darte de baja a ti mismo.", messages.ERROR)
            continue
        if usuario.is_active:
            citas += services.dar_de_baja(usuario=usuario, admin=request.user, ip=ip_de(request))
            bajas += 1
    modeladmin.message_user(request, f"Cuentas dadas de baja: {bajas}.")
    if citas:
        modeladmin.message_user(
            request,
            f"Quedan {citas} citas futuras de esos podólogos: cancélalas o reagéndalas para "
            "avisar a los pacientes.",
            messages.WARNING,
        )


@admin.action(description="Reactivar")
def reactivar(modeladmin, request, queryset):
    total = 0
    for obj in queryset:
        usuario = _usuario_de(obj)
        if not usuario.is_active:
            services.reactivar(usuario=usuario, admin=request.user, ip=ip_de(request))
            total += 1
    modeladmin.message_user(request, f"Cuentas reactivadas: {total}.")


# --- usuarios ---


class PacienteInline(admin.StackedInline):
    model = Paciente
    can_delete = False
    max_num = 1
    readonly_fields = ("edad",)
    verbose_name = "perfil de paciente"


class ProfesionalInline(admin.StackedInline):
    model = Profesional
    can_delete = False
    max_num = 1
    fields = ("especialidad", "numero_colegiado", "titulo", "pausa_entre_citas_min")
    show_change_link = True
    verbose_name = "perfil de podólogo (más datos en Profesionales)"


@admin.register(Usuario)
class UsuarioAdmin(UserAdmin):
    form = UsuarioChangeForm
    add_form = UsuarioCreationForm
    ordering = ("email",)
    list_display = ("email", "nombre", "apellido", "rol", "is_active", "is_staff")
    list_filter = ("rol", "is_active", "is_staff")
    search_fields = ("email", "nombre", "apellido")
    actions = [dar_de_baja, reactivar]
    fieldsets = (
        (None, {"fields": ("email", "password")}),
        ("Datos personales", {"fields": ("nombre", "apellido", "telefono", "rol")}),
        (
            "Permisos",
            {"fields": ("is_active", "is_staff", "is_superuser", "groups", "user_permissions")},
        ),
        ("Fechas", {"fields": ("last_login", "fecha_registro")}),
    )
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "description": (
                    "Para un podólogo usa «Profesionales → Añadir»: crea la cuenta y el perfil "
                    "de una vez. Los pacientes se registran solos en el sitio."
                ),
                "fields": (
                    "email",
                    "nombre",
                    "apellido",
                    "telefono",
                    "rol",
                    "password1",
                    "password2",
                ),
            },
        ),
    )

    def get_inlines(self, request, obj):
        if obj is None:
            return []
        if hasattr(obj, "paciente"):
            return [PacienteInline]
        if hasattr(obj, "profesional"):
            return [ProfesionalInline]
        return []

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(Paciente)
class PacienteAdmin(admin.ModelAdmin):
    list_display = ("usuario", "rut", "comuna", "activo")
    list_filter = ("usuario__is_active",)
    search_fields = ("usuario__email", "usuario__apellido", "rut")
    readonly_fields = ("edad",)
    raw_id_fields = ("usuario",)
    list_select_related = ("usuario",)
    actions = [dar_de_baja, reactivar]

    @admin.display(boolean=True, description="activo")
    def activo(self, obj):
        return obj.usuario.is_active

    def has_delete_permission(self, request, obj=None):
        # Los datos de pacientes no se borran: la cuenta se da de baja.
        return False


# --- profesionales ---


class NuevoPodologoForm(forms.ModelForm):
    """Crea la cuenta y el perfil del podólogo en un solo paso."""

    email = forms.EmailField(label="Correo")
    nombre = forms.CharField(max_length=150)
    apellido = forms.CharField(max_length=150)
    telefono = forms.CharField(label="Teléfono", max_length=20, required=False)
    password1 = forms.CharField(label="Contraseña inicial", widget=forms.PasswordInput)
    password2 = forms.CharField(label="Repite la contraseña", widget=forms.PasswordInput)

    class Meta:
        model = Profesional
        fields = (
            "especialidad",
            "numero_colegiado",
            "titulo",
            "institucion_titulo",
            "anio_titulo",
            "pausa_entre_citas_min",
            "descripcion",
        )

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if Usuario.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("Ya existe una cuenta con ese correo.")
        return email

    def clean(self):
        datos = super().clean()
        clave, repetida = datos.get("password1"), datos.get("password2")
        if clave and repetida and clave != repetida:
            self.add_error("password2", "Las contraseñas no coinciden.")
        elif clave:
            usuario = Usuario(
                email=datos.get("email", ""),
                nombre=datos.get("nombre", ""),
                apellido=datos.get("apellido", ""),
            )
            try:
                validate_password(clave, usuario)
            except forms.ValidationError as exc:
                self.add_error("password1", exc)
        return datos


class DisponibilidadInline(admin.TabularInline):
    """Horario semanal: sin al menos un tramo activo, el podólogo no aparece al reservar."""

    model = Disponibilidad
    extra = 0
    fields = ("dia_semana", "hora_inicio", "hora_fin", "activa")
    verbose_name = "tramo de horario semanal"
    verbose_name_plural = (
        "Horario semanal (sin un tramo activo, los pacientes no pueden reservar con este podólogo)"
    )


class CertificacionInline(admin.TabularInline):
    model = Certificacion
    extra = 0
    can_delete = False
    fields = ("nombre", "institucion", "anio", "ver_documento", "verificada")
    readonly_fields = fields
    show_change_link = True

    def has_add_permission(self, request, obj=None):
        return False

    @admin.display(description="documento")
    def ver_documento(self, obj):
        return _enlace_documento(obj)


def _enlace_documento(certificacion):
    if not certificacion.documento_tipo:
        return "—"
    url = reverse("admin:cuentas_certificacion_documento", args=[certificacion.pk])
    return format_html('<a href="{}" target="_blank" rel="noopener">Abrir</a>', url)


@admin.register(Profesional)
class ProfesionalAdmin(admin.ModelAdmin):
    list_display = (
        "usuario",
        "especialidad",
        "numero_colegiado",
        "titulo",
        "activo",
        "con_horario",
    )
    list_filter = ("usuario__is_active",)
    search_fields = ("usuario__email", "usuario__apellido", "numero_colegiado")
    list_select_related = ("usuario",)
    filter_horizontal = ("tratamientos",)
    inlines = [DisponibilidadInline, CertificacionInline]
    actions = [dar_de_baja, reactivar]
    fieldsets = (
        (None, {"fields": ("usuario", "especialidad", "pausa_entre_citas_min", "descripcion")}),
        (
            "Formación (la ve el paciente)",
            {"fields": ("titulo", "institucion_titulo", "anio_titulo", "numero_colegiado")},
        ),
        ("Tratamientos que realiza", {"fields": ("tratamientos",)}),
    )
    readonly_fields = ("usuario",)

    @admin.display(boolean=True, description="activo")
    def activo(self, obj):
        return obj.usuario.is_active

    @admin.display(boolean=True, description="con horario")
    def con_horario(self, obj):
        # Sin horario no aparece al reservar: así se ve de un vistazo a quién le falta.
        return obj.disponibilidades.filter(activa=True).exists()

    def get_form(self, request, obj=None, **kwargs):
        if obj is None:
            kwargs["form"] = NuevoPodologoForm
        return super().get_form(request, obj, **kwargs)

    def get_fieldsets(self, request, obj=None):
        if obj is not None:
            return self.fieldsets
        return (
            ("Cuenta", {"fields": ("email", "nombre", "apellido", "telefono")}),
            ("Contraseña inicial", {"fields": ("password1", "password2")}),
            (
                "Perfil",
                {"fields": ("especialidad", "pausa_entre_citas_min", "descripcion")},
            ),
            (
                "Formación (la ve el paciente)",
                {"fields": ("titulo", "institucion_titulo", "anio_titulo", "numero_colegiado")},
            ),
        )

    def get_readonly_fields(self, request, obj=None):
        return self.readonly_fields if obj is not None else ()

    def get_inlines(self, request, obj):
        return self.inlines if obj is not None else []

    def save_model(self, request, obj, form, change):
        if not change:
            datos = form.cleaned_data
            obj.usuario = Usuario.objects.create_user(
                datos["email"],
                datos["password1"],
                nombre=datos["nombre"],
                apellido=datos["apellido"],
                telefono=datos.get("telefono", ""),
                rol=Usuario.Rol.PROFESIONAL,
            )
        super().save_model(request, obj, form, change)

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(Certificacion)
class CertificacionAdmin(admin.ModelAdmin):
    list_display = ("nombre", "profesional", "institucion", "anio", "ver_documento", "verificada")
    list_filter = ("verificada",)
    search_fields = ("nombre", "institucion", "profesional__usuario__apellido")
    list_select_related = ("profesional__usuario",)
    readonly_fields = (
        "profesional",
        "nombre",
        "institucion",
        "anio",
        "ver_documento",
        "verificada",
        "verificada_por",
        "verificada_en",
        "creada_en",
    )
    fields = readonly_fields
    actions = ["marcar_verificadas", "quitar_verificacion"]

    @admin.display(description="documento")
    def ver_documento(self, obj):
        return _enlace_documento(obj)

    def has_add_permission(self, request):
        return False  # las sube el podólogo desde «Mi perfil»

    def has_delete_permission(self, request, obj=None):
        return False

    @admin.action(description="Marcar como verificadas (se muestran a los pacientes)")
    def marcar_verificadas(self, request, queryset):
        for certificacion in queryset.filter(verificada=False):
            services.verificar_certificacion(
                certificacion=certificacion, admin=request.user, ip=ip_de(request)
            )
        self.message_user(request, "Certificaciones verificadas.")

    @admin.action(description="Quitar la verificación (dejan de mostrarse)")
    def quitar_verificacion(self, request, queryset):
        for certificacion in queryset.filter(verificada=True):
            services.verificar_certificacion(
                certificacion=certificacion,
                admin=request.user,
                ip=ip_de(request),
                verificada=False,
            )
        self.message_user(request, "Verificación quitada.")

    def get_urls(self):
        propias = [
            path(
                "<uuid:pk>/documento/",
                self.admin_site.admin_view(self.documento),
                name="cuentas_certificacion_documento",
            )
        ]
        return propias + super().get_urls()

    def documento(self, request, pk):
        """El respaldo de una certificación: solo para el panel, nunca para los pacientes."""
        if not self.has_view_permission(request):
            raise Http404
        certificacion = get_object_or_404(Certificacion, pk=pk)
        if not certificacion.documento_tipo:
            raise Http404
        respuesta = HttpResponse(
            bytes(certificacion.documento), content_type=certificacion.documento_tipo
        )
        # Los PDF se descargan (como las derivaciones): la CSP del sitio (object-src 'none')
        # impide que el navegador los muestre dentro de la página. Las imágenes se ven directo.
        if certificacion.documento_tipo == "application/pdf":
            respuesta["Content-Disposition"] = (
                f'attachment; filename="certificado-{certificacion.anio}.pdf"'
            )
        respuesta["Cache-Control"] = "no-store"
        return respuesta


# --- verificación en dos pasos ---

# El plugin de django-otp registra TOTPDevice como "Otp_Totp → TOTP devices". Se reemplaza por
# el proxy DispositivoVerificacion, con el mismo admin del plugin pero con nombres en español.
try:
    admin.site.unregister(TOTPDevice)
except NotRegistered:
    pass

_TITULOS_DISPOSITIVO = {
    "Identity": "Cuenta",
    "Timestamps": "Fechas",
    "Configuration": "Configuración",
    "State": "Estado",
    "Throttling": "Freno de intentos fallidos",
}
_ETIQUETAS_DISPOSITIVO = {
    "user": "cuenta",
    "name": "nombre",
    "confirmed": "confirmado",
    "key": "clave",
    "step": "intervalo (segundos)",
    "t0": "inicio (t0)",
    "digits": "dígitos",
    "tolerance": "tolerancia",
    "drift": "desfase",
    "throttling_failure_timestamp": "último intento fallido",
    "throttling_failure_count": "intentos fallidos seguidos",
}


@admin.register(DispositivoVerificacion)
class DispositivoVerificacionAdmin(TOTPDeviceAdmin):
    """La app de autenticación de cada cuenta. Si alguien perdió el teléfono y sus códigos de
    respaldo, se borra aquí su dispositivo: la próxima vez que entre verá un QR nuevo."""

    list_display = ["user", "name", "creado", "ultimo_uso", "confirmed"]
    readonly_fields = ["creado", "ultimo_uso", "qrcode_link"]

    @admin.display(description="creado", ordering="created_at")
    def creado(self, obj):
        return obj.created_at

    @admin.display(description="último uso", ordering="last_used_at")
    def ultimo_uso(self, obj):
        return obj.last_used_at

    @admin.display(description="código QR")
    def qrcode_link(self, device):
        return super().qrcode_link(device)

    def get_fieldsets(self, request, obj=None):
        propios = {"created_at": "creado", "last_used_at": "ultimo_uso"}
        return [
            (
                _TITULOS_DISPOSITIVO.get(titulo, titulo),
                {**opciones, "fields": [propios.get(c, c) for c in opciones["fields"]]},
            )
            for titulo, opciones in super().get_fieldsets(request, obj)
        ]

    def get_form(self, request, obj=None, change=False, **kwargs):
        kwargs["labels"] = {**_ETIQUETAS_DISPOSITIVO, **kwargs.get("labels", {})}
        return super().get_form(request, obj, change=change, **kwargs)
