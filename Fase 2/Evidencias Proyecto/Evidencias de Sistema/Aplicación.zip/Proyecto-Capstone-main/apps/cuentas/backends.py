"""Autenticación con freno de intentos. Cubre la API y el panel /admin/ por igual."""

from django.contrib.auth.backends import ModelBackend
from django.contrib.auth.signals import user_login_failed
from django.dispatch import receiver

from apps.auditoria.services import ip_de

from .bloqueo import esta_bloqueado, registrar_fallo


def _ip(request):
    return ip_de(request) if request is not None else None


class ModelBackendConFreno(ModelBackend):
    """Igual que ModelBackend, pero no prueba la contraseña si el correo o la IP están frenados."""

    def authenticate(self, request, username=None, password=None, **kwargs):
        if username is not None and esta_bloqueado(email=username, ip=_ip(request)):
            return None
        return super().authenticate(request, username=username, password=password, **kwargs)


@receiver(user_login_failed)
def auditar_login_fallido(sender, credentials, request=None, **kwargs):
    """Todo fallo queda en la auditoría (sin la contraseña). Es lo que cuenta el freno."""
    email = credentials.get("username") or credentials.get("email") or ""
    ip = _ip(request)
    registrar_fallo(email=email, ip=ip, bloqueado=esta_bloqueado(email=email, ip=ip))
