"""Escrituras y casos de uso de cuentas. La lógica de negocio vive aquí, no en las vistas."""

import hashlib
import secrets
from datetime import date, timedelta

from django.conf import settings
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.hashers import make_password
from django.contrib.auth.password_validation import validate_password
from django.contrib.auth.tokens import default_token_generator
from django.core.cache import cache
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import IntegrityError, transaction
from django.urls import reverse
from django.utils import timezone
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from django_otp import login as otp_login

from apps.auditoria.models import RegistroAuditoria
from apps.auditoria.services import ip_de, registrar

from . import correos, dos_pasos
from .bloqueo import esta_bloqueado, registrar_fallo
from .documentos import limpiar_documento, limpiar_foto
from .models import Certificacion, Paciente, Profesional, RegistroPendiente, Usuario
from .rut import normalizar_rut

BACKEND = "apps.cuentas.backends.ModelBackendConFreno"


class AutenticacionFallida(Exception):
    """Credenciales inválidas o cuenta inactiva. No distingue la causa a propósito."""


class DemasiadosIntentos(Exception):
    """El correo o la IP superaron los intentos fallidos permitidos (ver bloqueo.py)."""


class RegistroInvalido(Exception):
    """El enlace para confirmar el registro no sirve: venció, ya se usó o los datos chocan."""


class FaltaSegundoPaso(Exception):
    """La contraseña es correcta, pero la cuenta tiene verificación en dos pasos: falta el
    código. Se lanza antes de abrir la sesión."""

    def __init__(self, usuario):
        super().__init__("Falta el código de verificación en dos pasos.")
        self.usuario = usuario


def _huella(texto: str) -> str:
    return hashlib.sha256(texto.encode()).hexdigest()


# --- registro con confirmación del correo ---
#
# El formulario público nunca dice si un correo o un RUT ya están registrados: siempre
# responde "revisa tu correo", y lo que corresponda se le explica por correo a quien lo
# controla. La cuenta se crea al abrir el enlace (RegistroPendiente).


def solicitar_registro(
    *,
    email,
    password,
    nombre,
    apellido,
    rut,
    fecha_nacimiento,
    direccion,
    comuna,
    telefono,
    actividad,
    telefono_contacto,
    sitio: str,
    siguiente: str = "",
) -> None:
    """Valida el formulario y manda el correo que corresponda. `sitio`: https://dominio."""
    email = email.strip().lower()
    errores: dict[str, list[str]] = {}
    rut_normalizado = None
    try:
        rut_normalizado = normalizar_rut(rut)
    except ValidationError as exc:
        errores["rut"] = exc.messages
    try:
        validate_password(password, user=Usuario(email=email, nombre=nombre, apellido=apellido))
    except ValidationError as exc:
        errores["password"] = exc.messages
    if errores:
        raise ValidationError(errores)

    ahora = timezone.now()
    RegistroPendiente.objects.filter(vence_en__lte=ahora).delete()
    enlace_recuperar = sitio + reverse("web:recuperar")
    if Usuario.objects.filter(email__iexact=email).exists():
        correos.enviar(
            email,
            "Ya tienes una cuenta en MyPodo",
            "ya_tienes_cuenta",
            {"enlace_entrar": sitio + reverse("web:entrar"), "enlace_recuperar": enlace_recuperar},
        )
        return
    if Paciente.objects.filter(rut=rut_normalizado).exists():
        correos.enviar(
            email,
            "No pudimos crear tu cuenta en MyPodo",
            "registro_no_posible",
            {"enlace_recuperar": enlace_recuperar},
        )
        return

    token = secrets.token_urlsafe(32)
    with transaction.atomic():
        # Un registro nuevo con el mismo correo reemplaza al anterior (y su enlace).
        RegistroPendiente.objects.filter(email=email).delete()
        RegistroPendiente.objects.create(
            email=email,
            datos={
                "nombre": nombre,
                "apellido": apellido,
                "rut": rut_normalizado,
                "fecha_nacimiento": fecha_nacimiento.isoformat(),
                "direccion": direccion,
                "comuna": comuna,
                "telefono": telefono,
                "actividad": actividad,
                "telefono_contacto": telefono_contacto,
            },
            password_hash=make_password(password),
            token_hash=_huella(token),
            siguiente=siguiente,
            vence_en=ahora + timedelta(hours=settings.REGISTRO_VIGENCIA_HORAS),
        )
    correos.enviar(
        email,
        "Confirma tu correo para crear tu cuenta en MyPodo",
        "confirmar_registro",
        {
            "nombre": nombre,
            "enlace": sitio + reverse("web:registro-confirmar", args=[token]),
            "horas": settings.REGISTRO_VIGENCIA_HORAS,
        },
    )


def registro_pendiente(token: str) -> RegistroPendiente | None:
    return RegistroPendiente.objects.filter(
        token_hash=_huella(token), vence_en__gt=timezone.now()
    ).first()


def confirmar_registro(request, *, token: str) -> tuple[Usuario, str]:
    """Crea la cuenta del registro pendiente, abre la sesión y devuelve a dónde seguir."""
    pendiente = registro_pendiente(token)
    if pendiente is None:
        raise RegistroInvalido("El enlace no es válido o ya venció. Vuelve a registrarte.")
    datos = pendiente.datos
    try:
        with transaction.atomic():
            paciente = registrar_paciente(
                email=pendiente.email,
                # Provisoria y descartada al tiro: se guarda el hash que eligió la persona.
                password=secrets.token_urlsafe(24),
                nombre=datos["nombre"],
                apellido=datos["apellido"],
                rut=datos["rut"],
                fecha_nacimiento=date.fromisoformat(datos["fecha_nacimiento"]),
                direccion=datos["direccion"],
                comuna=datos["comuna"],
                telefono=datos["telefono"],
                actividad=datos["actividad"],
                telefono_contacto=datos["telefono_contacto"],
                ip=ip_de(request),
            )
            usuario = paciente.usuario
            usuario.password = pendiente.password_hash
            usuario.save(update_fields=["password"])
    except ValidationError as exc:
        # Entre el registro y la confirmación alguien más usó el correo o el RUT.
        pendiente.delete()
        raise RegistroInvalido(
            "Ya existe una cuenta con estos datos. Inicia sesión o recupera tu contraseña."
        ) from exc
    siguiente = pendiente.siguiente
    pendiente.delete()
    abrir_sesion(request, usuario)
    return usuario, siguiente


def abrir_sesion(request, usuario) -> None:
    """Abre la sesión de un usuario ya verificado por otro medio (enlace del correo)."""
    login(request, usuario, backend=BACKEND)
    registrar(
        accion=RegistroAuditoria.Accion.LOGIN,
        usuario=usuario,
        recurso_tipo="usuario",
        recurso_id=usuario.pk,
        ip=ip_de(request),
    )


def borrar_registros_vencidos(*, ahora=None) -> int:
    borrados, _ = RegistroPendiente.objects.filter(vence_en__lte=ahora or timezone.now()).delete()
    return borrados


# --- recuperar la contraseña por correo ---


def solicitar_recuperacion(*, email: str, sitio: str) -> None:
    """Manda el enlace si hay una cuenta activa con ese correo. Responde igual si no la hay."""
    email = (email or "").strip().lower()
    usuario = Usuario.objects.filter(email__iexact=email, is_active=True).first()
    if usuario is None:
        return
    # Un correo cada 5 minutos por cuenta: frena usar el formulario para llenarle la bandeja.
    if not cache.add(f"recuperar:{_huella(email)}", 1, timeout=300):
        return
    uid = urlsafe_base64_encode(force_bytes(usuario.pk))
    token = default_token_generator.make_token(usuario)
    correos.enviar(
        usuario.email,
        "Restablece tu contraseña de MyPodo",
        "recuperar_clave",
        {
            "nombre": usuario.nombre,
            "enlace": sitio + reverse("web:recuperar-confirmar", args=[uid, token]),
            "minutos": settings.PASSWORD_RESET_TIMEOUT // 60,
        },
    )


def usuario_para_recuperar(uidb64: str, token: str) -> Usuario | None:
    """El usuario del enlace, si el enlace sigue sirviendo (vence y es de un solo uso)."""
    try:
        pk = urlsafe_base64_decode(uidb64).decode()
        usuario = Usuario.objects.get(pk=pk, is_active=True)
    except (ValueError, TypeError, OverflowError, ValidationError, Usuario.DoesNotExist):
        return None
    return usuario if default_token_generator.check_token(usuario, token) else None


def restablecer_clave(*, usuario, nueva: str, sitio: str, ip=None) -> None:
    """Pone la contraseña nueva. Al cambiar el hash, se cierran todas las sesiones abiertas
    y el enlace deja de servir."""
    try:
        validate_password(nueva, usuario)
    except ValidationError as exc:
        raise ValidationError({"nueva": exc.messages}) from exc
    with transaction.atomic():
        usuario.set_password(nueva)
        usuario.save(update_fields=["password"])
        registrar(
            accion=RegistroAuditoria.Accion.RESTABLECER_CLAVE,
            usuario=usuario,
            recurso_tipo="usuario",
            recurso_id=usuario.pk,
            ip=ip,
        )
    avisar_clave_cambiada(usuario, sitio=sitio)


def avisar_clave_cambiada(usuario, *, sitio: str) -> None:
    correos.enviar(
        usuario.email,
        "Tu contraseña de MyPodo cambió",
        "clave_cambiada",
        {"nombre": usuario.nombre, "enlace_recuperar": sitio + reverse("web:recuperar")},
    )


def registrar_paciente(
    *,
    email,
    password,
    nombre,
    apellido,
    rut,
    fecha_nacimiento,
    direccion,
    comuna,
    telefono,
    actividad,
    telefono_contacto,
    ip=None,
) -> Paciente:
    """Crea la cuenta y el perfil de un paciente. Todo o nada."""
    email = email.strip().lower()
    errores: dict[str, list[str]] = {}

    rut_normalizado = None
    try:
        rut_normalizado = normalizar_rut(rut)
    except ValidationError as exc:
        errores["rut"] = exc.messages

    try:
        validate_password(password, user=Usuario(email=email, nombre=nombre, apellido=apellido))
    except ValidationError as exc:
        errores["password"] = exc.messages

    if Usuario.objects.filter(email__iexact=email).exists():
        errores["email"] = ["Ya existe una cuenta con este correo."]
    if rut_normalizado and Paciente.objects.filter(rut=rut_normalizado).exists():
        errores["rut"] = ["Ya existe un paciente con este RUT."]

    if errores:
        raise ValidationError(errores)

    try:
        with transaction.atomic():
            usuario = Usuario.objects.create_user(
                email,
                password,
                nombre=nombre,
                apellido=apellido,
                telefono=telefono,
                rol=Usuario.Rol.PACIENTE,
            )
            paciente = Paciente.objects.create(
                usuario=usuario,
                rut=rut_normalizado,
                fecha_nacimiento=fecha_nacimiento,
                direccion=direccion,
                comuna=comuna,
                actividad=actividad,
                telefono_contacto=telefono_contacto,
            )
    except IntegrityError as exc:  # carrera entre dos registros simultáneos
        raise ValidationError("No se pudo completar el registro. Revisa correo y RUT.") from exc

    registrar(
        accion=RegistroAuditoria.Accion.REGISTRO,
        usuario=usuario,
        recurso_tipo="usuario",
        recurso_id=usuario.pk,
        ip=ip,
    )
    return paciente


def crear_profesional(
    *,
    email,
    password,
    nombre,
    apellido,
    especialidad,
    telefono="",
    numero_colegiado="",
    pausa_entre_citas_min=15,
    descripcion="",
) -> Profesional:
    """Alta de un profesional. La hace un administrador; no existe registro público."""
    with transaction.atomic():
        usuario = Usuario.objects.create_user(
            email,
            password,
            nombre=nombre,
            apellido=apellido,
            telefono=telefono,
            rol=Usuario.Rol.PROFESIONAL,
        )
        return Profesional.objects.create(
            usuario=usuario,
            especialidad=especialidad,
            numero_colegiado=numero_colegiado,
            pausa_entre_citas_min=pausa_entre_citas_min,
            descripcion=descripcion,
        )


def iniciar_sesion(request, *, email, password, codigo=None) -> Usuario:
    """Autentica, abre la sesión y deja constancia en la auditoría.

    Si la cuenta tiene verificación en dos pasos, sin `codigo` lanza FaltaSegundoPaso (la web
    lo pide en otra pantalla: completar_segundo_paso); con `codigo`, lo verifica aquí (API).
    """
    email = email.strip().lower()
    ip = ip_de(request)
    if esta_bloqueado(email=email, ip=ip):
        registrar_fallo(email=email, ip=ip, bloqueado=True)
        raise DemasiadosIntentos
    usuario = authenticate(request, username=email, password=password)
    if usuario is None:
        # El fallo ya quedó en la auditoría, sin usuario (Anexo F, sección 4.5): lo registra
        # la señal user_login_failed (backends.py), que también cubre el panel /admin/.
        raise AutenticacionFallida
    if dos_pasos.activa(usuario):
        if not codigo:
            raise FaltaSegundoPaso(usuario)
        return completar_segundo_paso(request, usuario=usuario, codigo=codigo)
    login(request, usuario)
    registrar(
        accion=RegistroAuditoria.Accion.LOGIN,
        usuario=usuario,
        recurso_tipo="usuario",
        recurso_id=usuario.pk,
        ip=ip,
    )
    return usuario


def completar_segundo_paso(request, *, usuario, codigo: str) -> Usuario:
    """Verifica el código (de la app o de respaldo) y recién ahí abre la sesión.

    Un código incorrecto cuenta como inicio de sesión fallido: el freno de 5 por cuenta (y
    30 por IP) también frena a quien prueba códigos.
    """
    ip = ip_de(request)
    if esta_bloqueado(email=usuario.email, ip=ip):
        registrar_fallo(email=usuario.email, ip=ip, bloqueado=True)
        raise DemasiadosIntentos
    disp = dos_pasos.verificar(usuario, codigo, ip=ip)
    if disp is None:
        registrar_fallo(email=usuario.email, ip=ip)
        raise AutenticacionFallida
    abrir_sesion(request, usuario)
    otp_login(request, disp)  # la sesión queda verificada también para el panel /admin/
    return usuario


def cerrar_sesion(request) -> None:
    """Cierra la sesión y lo deja en la auditoría (antes de cerrarla, cuando aún se sabe quién)."""
    usuario = request.user
    if usuario.is_authenticated:
        registrar(
            accion=RegistroAuditoria.Accion.LOGOUT,
            usuario=usuario,
            recurso_tipo="usuario",
            recurso_id=usuario.pk,
            ip=ip_de(request),
        )
    logout(request)


# --- perfil propio (RF-027) ---
#
# Cada usuario corrige sus datos de contacto. Los de identidad (nombre, RUT, fecha de
# nacimiento, correo) y los que afectan la agenda (especialidad, registro, pausa) los cambia
# la consulta desde el panel de administración.

CAMPOS_PACIENTE_USUARIO = ("telefono",)
CAMPOS_PACIENTE = ("telefono_contacto", "direccion", "comuna", "actividad")
CAMPOS_PROFESIONAL_USUARIO = ("telefono",)
CAMPOS_PROFESIONAL = ("descripcion",)


def actualizar_perfil(*, usuario, datos: dict, ip=None) -> list[str]:
    """Guarda los campos editables del perfil propio. Devuelve los que cambiaron.

    La auditoría guarda qué campos cambiaron, no sus valores (son datos de contacto).
    """
    if hasattr(usuario, "paciente") and usuario.rol == Usuario.Rol.PACIENTE:
        perfil, propios, del_usuario = usuario.paciente, CAMPOS_PACIENTE, CAMPOS_PACIENTE_USUARIO
    elif hasattr(usuario, "profesional") and usuario.rol == Usuario.Rol.PROFESIONAL:
        perfil = usuario.profesional
        propios, del_usuario = CAMPOS_PROFESIONAL, CAMPOS_PROFESIONAL_USUARIO
    else:
        raise ValidationError("Esta cuenta no tiene un perfil editable.")

    cambiados = []
    for objeto, campos in ((usuario, del_usuario), (perfil, propios)):
        for campo in campos:
            if campo not in datos:
                continue
            valor = datos[campo].strip()
            if getattr(objeto, campo) != valor:
                setattr(objeto, campo, valor)
                cambiados.append(campo)
    if not cambiados:
        return []
    with transaction.atomic():
        usuario.full_clean(validate_unique=False, validate_constraints=False)
        perfil.full_clean(validate_unique=False, validate_constraints=False)
        for objeto, campos in ((usuario, del_usuario), (perfil, propios)):
            if por_guardar := [c for c in cambiados if c in campos]:
                objeto.save(update_fields=por_guardar)
        registrar(
            accion=RegistroAuditoria.Accion.EDITAR_PERFIL,
            usuario=usuario,
            recurso_tipo="usuario",
            recurso_id=usuario.pk,
            ip=ip,
            detalle={"campos": cambiados},
        )
    return cambiados


def cambiar_clave(request, *, actual: str, nueva: str) -> None:
    """Cambia la contraseña propia. Exige la actual y mantiene abierta esta sesión (las demás
    sesiones de la cuenta se cierran, porque cambia el hash de la sesión)."""
    usuario = request.user
    if not usuario.check_password(actual):
        raise ValidationError({"actual": ["La contraseña actual no es correcta."]})
    if actual == nueva:
        raise ValidationError({"nueva": ["La contraseña nueva debe ser distinta de la actual."]})
    try:
        validate_password(nueva, usuario)
    except ValidationError as exc:
        raise ValidationError({"nueva": exc.messages}) from exc
    with transaction.atomic():
        usuario.set_password(nueva)
        usuario.save(update_fields=["password"])
        registrar(
            accion=RegistroAuditoria.Accion.CAMBIAR_CLAVE,
            usuario=usuario,
            recurso_tipo="usuario",
            recurso_id=usuario.pk,
            ip=ip_de(request),
        )
    update_session_auth_hash(request, usuario)
    avisar_clave_cambiada(usuario, sitio=sitio_de(request))


def sitio_de(request) -> str:
    """https://dominio del sitio, para armar los enlaces que van por correo."""
    return request.build_absolute_uri("/").rstrip("/")


# --- perfil profesional: foto, tratamientos y certificaciones ---


def cambiar_foto(*, profesional, archivo) -> None:
    profesional.foto = limpiar_foto(archivo)
    profesional.foto_actualizada_en = timezone.now()
    profesional.save(update_fields=["foto", "foto_actualizada_en"])


def quitar_foto(*, profesional) -> None:
    # Sin fecha = sin foto: así las listas saben si hay foto sin cargar la imagen.
    profesional.foto = None
    profesional.foto_actualizada_en = None
    profesional.save(update_fields=["foto", "foto_actualizada_en"])


def cambiar_tratamientos(*, profesional, tratamientos) -> None:
    """Los tratamientos que el podólogo dice realizar (se muestran en su perfil público)."""
    profesional.tratamientos.set(tratamientos)


def agregar_certificacion(*, profesional, nombre, institucion, anio, archivo) -> Certificacion:
    """La sube el podólogo. Queda sin verificar hasta que el administrador revise el documento."""
    if not (1950 <= anio <= timezone.localdate().year):
        raise ValidationError({"anio": ["Indica un año válido."]})
    contenido, tipo = limpiar_documento(archivo)
    return Certificacion.objects.create(
        profesional=profesional,
        nombre=nombre.strip(),
        institucion=institucion.strip(),
        anio=anio,
        documento=contenido,
        documento_tipo=tipo,
        documento_nombre=(getattr(archivo, "name", "") or "")[:150],
    )


def eliminar_certificacion(*, certificacion, usuario) -> None:
    """El podólogo quita una certificación propia (por ejemplo, si la subió con un error)."""
    if not certificacion.es_de(usuario):
        raise PermissionDenied("La certificación no es de este usuario.")
    certificacion.delete()


def verificar_certificacion(*, certificacion, admin, ip=None, verificada=True) -> None:
    """El administrador revisa el documento y la publica (o la retira) del perfil público."""
    certificacion.verificada = verificada
    certificacion.verificada_por = admin if verificada else None
    certificacion.verificada_en = timezone.now() if verificada else None
    certificacion.save(update_fields=["verificada", "verificada_por", "verificada_en"])
    registrar(
        accion=RegistroAuditoria.Accion.VERIFICAR_CERTIFICACION,
        usuario=admin,
        recurso_tipo="certificacion",
        recurso_id=certificacion.pk,
        ip=ip,
        detalle={"verificada": verificada},
    )


# --- dar de baja y reactivar (no se borra: la ficha clínica se conserva) ---


def dar_de_baja(*, usuario, admin, ip=None) -> int:
    """Desactiva la cuenta: no puede entrar ni aparece para reservar. Su historia se conserva.

    Devuelve cuántas citas futuras activas quedan (de un podólogo, hay que cancelarlas o
    reagendarlas aparte: dar de baja no avisa a nadie por sí solo).
    """
    from apps.agenda.models import Cita

    if usuario.pk == admin.pk:
        raise ValidationError("No puedes darte de baja a ti mismo.")
    with transaction.atomic():
        usuario.is_active = False
        usuario.save(update_fields=["is_active"])
        registrar(
            accion=RegistroAuditoria.Accion.DAR_DE_BAJA,
            usuario=admin,
            recurso_tipo="usuario",
            recurso_id=usuario.pk,
            ip=ip,
        )
    activos = ("pendiente_pago", "agendada", "confirmada")
    return Cita.objects.filter(
        profesional_id=usuario.pk, estado__in=activos, inicio__gt=timezone.now()
    ).count()


def reactivar(*, usuario, admin, ip=None) -> None:
    with transaction.atomic():
        usuario.is_active = True
        usuario.save(update_fields=["is_active"])
        registrar(
            accion=RegistroAuditoria.Accion.REACTIVAR,
            usuario=admin,
            recurso_tipo="usuario",
            recurso_id=usuario.pk,
            ip=ip,
        )
