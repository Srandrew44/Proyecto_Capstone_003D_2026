from django.apps import AppConfig


class CuentasConfig(AppConfig):
    name = "apps.cuentas"
    label = "cuentas"
    verbose_name = "Cuentas"

    def ready(self):
        from . import backends  # noqa: F401  (conecta la auditoría de los logins fallidos)
