"""Foto de perfil y documentos de certificación del podólogo.

Las imágenes se abren con Pillow (si no son imágenes reales se rechazan), se giran según su
orientación EXIF, se reducen y se guardan como JPEG nuevo, sin metadatos. Los PDF se aceptan
si empiezan como un PDF; no se modifican.
"""

import io

from django.core.exceptions import ValidationError
from PIL import Image, ImageOps, UnidentifiedImageError

MAX_MB = 5
IMAGENES = {"JPEG", "PNG", "WEBP"}


def _revisar_tamano(archivo):
    if archivo.size > MAX_MB * 1024 * 1024:
        raise ValidationError(f"El archivo no puede pesar más de {MAX_MB} MB.")


def _imagen_a_jpeg(archivo, lado_max: int) -> bytes:
    try:
        imagen = Image.open(archivo)
        imagen.verify()
        archivo.seek(0)
        imagen = Image.open(archivo)
        formato = imagen.format
        imagen.load()
    except (UnidentifiedImageError, OSError, SyntaxError) as exc:
        raise ValidationError("El archivo no es una imagen válida.") from exc
    if formato not in IMAGENES:
        raise ValidationError("Sube la imagen en JPG, PNG o WEBP.")
    imagen = ImageOps.exif_transpose(imagen).convert("RGB")
    imagen.thumbnail((lado_max, lado_max))
    salida = io.BytesIO()
    imagen.save(salida, format="JPEG", quality=85)
    return salida.getvalue()


def limpiar_foto(archivo) -> bytes:
    """Foto de presentación: JPEG de hasta 600 px por lado."""
    _revisar_tamano(archivo)
    return _imagen_a_jpeg(archivo, 600)


def limpiar_documento(archivo) -> tuple[bytes, str]:
    """Respaldo de una certificación: PDF o imagen. Devuelve (contenido, tipo MIME)."""
    _revisar_tamano(archivo)
    inicio = archivo.read(5)
    archivo.seek(0)
    if inicio == b"%PDF-":
        return archivo.read(), "application/pdf"
    try:
        return _imagen_a_jpeg(archivo, 2000), "image/jpeg"
    except ValidationError as exc:
        raise ValidationError("Sube el certificado en PDF, JPG, PNG o WEBP.") from exc
