"""Crea la tabla de la caché en la base (CACHES usa DatabaseCache).

Así basta `migrate` para tenerla en cualquier entorno: los límites de registro, login,
recuperación de contraseña y del asistente la necesitan desde la primera solicitud. Con otra
caché (p. ej. en memoria, en las pruebas) no hace nada.
"""

from django.core.management import call_command
from django.db import migrations


def crear_tabla_de_cache(apps, schema_editor):
    call_command("createcachetable", database=schema_editor.connection.alias, verbosity=0)


class Migration(migrations.Migration):
    dependencies = [("cuentas", "0007_registro_pendiente")]

    operations = [migrations.RunPython(crear_tabla_de_cache, migrations.RunPython.noop)]
