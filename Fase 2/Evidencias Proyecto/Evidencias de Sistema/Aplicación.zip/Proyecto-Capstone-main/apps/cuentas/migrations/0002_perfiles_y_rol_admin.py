import django.db.models.deletion
import django.db.models.functions.text
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('cuentas', '0001_initial'),
    ]

    operations = [
        migrations.AlterField(
            model_name='usuario',
            name='rol',
            field=models.CharField(choices=[('paciente', 'Paciente'), ('profesional', 'Profesional'), ('admin', 'Administrador')], default='paciente', max_length=20),
        ),
        migrations.AddField(
            model_name='usuario',
            name='telefono',
            field=models.CharField(blank=True, default='', max_length=20),
        ),
        migrations.AddConstraint(
            model_name='usuario',
            constraint=models.UniqueConstraint(django.db.models.functions.text.Lower('email'), name='usuario_email_ci_unico'),
        ),
        migrations.CreateModel(
            name='Paciente',
            fields=[
                ('usuario', models.OneToOneField(on_delete=django.db.models.deletion.PROTECT, primary_key=True, related_name='paciente', serialize=False, to=settings.AUTH_USER_MODEL)),
                ('rut', models.CharField(max_length=12, unique=True)),
                ('fecha_nacimiento', models.DateField()),
                ('direccion', models.CharField(max_length=255)),
                ('comuna', models.CharField(max_length=100)),
                ('indicaciones_llegada', models.TextField(blank=True)),
            ],
            options={
                'verbose_name': 'paciente',
                'verbose_name_plural': 'pacientes',
            },
        ),
        migrations.CreateModel(
            name='Profesional',
            fields=[
                ('usuario', models.OneToOneField(on_delete=django.db.models.deletion.PROTECT, primary_key=True, related_name='profesional', serialize=False, to=settings.AUTH_USER_MODEL)),
                ('especialidad', models.CharField(max_length=100)),
                ('numero_colegiado', models.CharField(blank=True, max_length=50)),
                ('pausa_entre_citas_min', models.PositiveSmallIntegerField(default=15)),
                ('descripcion', models.TextField(blank=True)),
            ],
            options={
                'verbose_name': 'profesional',
                'verbose_name_plural': 'profesionales',
            },
        ),
    ]
