from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("cuentas", "0002_perfiles_y_rol_admin"),
    ]

    operations = [
        migrations.RemoveField(
            model_name="paciente",
            name="indicaciones_llegada",
        ),
        migrations.AddField(
            model_name="paciente",
            name="actividad",
            field=models.CharField(default="", max_length=100),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name="paciente",
            name="telefono_contacto",
            field=models.CharField(default="", max_length=20),
            preserve_default=False,
        ),
    ]
