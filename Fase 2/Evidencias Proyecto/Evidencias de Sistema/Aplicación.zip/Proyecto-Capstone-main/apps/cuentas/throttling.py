"""Límite de solicitudes por IP con la misma IP que la auditoría y el freno de login."""

from rest_framework.throttling import ScopedRateThrottle

from apps.auditoria.services import ip_de


class LimitePorIp(ScopedRateThrottle):
    """ScopedRateThrottle que identifica al cliente con ``ip_de``.

    El ``get_ident`` de DRF, sin NUM_PROXIES, usa la cabecera X-Forwarded-For entera: basta
    cambiarla en cada solicitud para no topar nunca el límite. ``ip_de`` solo cree en las
    entradas que agregan los proxies de confianza, así que una sola regla decide la IP en
    todo el sistema. Sirve tanto con la Request de DRF como con la HttpRequest de Django.
    """

    def get_ident(self, request):
        return ip_de(request) or "sin-ip"
