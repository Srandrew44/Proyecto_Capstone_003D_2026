import uuid

from django.conf import settings
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models.functions import Lower
from django.utils import timezone
from django_otp.plugins.otp_totp.models import TOTPDevice

from .rut import normalizar_rut


class UsuarioManager(BaseUserManager):
    use_in_migrations = True

    def _crear(self, email, password, **extra):
        if not email:
            raise ValueError("El correo es obligatorio.")
        email = email.strip().lower()
        usuario = self.model(email=email, **extra)
        usuario.set_password(password)
        usuario.save(using=self._db)
        return usuario

    def create_user(self, email, password=None, **extra):
        extra.setdefault("is_staff", False)
        extra.setdefault("is_superuser", False)
        return self._crear(email, password, **extra)

    def create_superuser(self, email, password=None, **extra):
        extra.setdefault("is_staff", True)
        extra.setdefault("is_superuser", True)
        extra.setdefault("rol", "admin")
        if not extra["is_staff"] or not extra["is_superuser"]:
            raise ValueError("Un superusuario debe tener is_staff e is_superuser en True.")
        return self._crear(email, password, **extra)


class Usuario(AbstractBaseUser, PermissionsMixin):
    """Cuenta de acceso. Los datos propios de cada rol viven en Paciente y Profesional."""

    class Rol(models.TextChoices):
        PACIENTE = "paciente", "Paciente"
        PROFESIONAL = "profesional", "Profesional"
        ADMIN = "admin", "Administrador"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email = models.EmailField("correo", unique=True)
    nombre = models.CharField(max_length=150)
    apellido = models.CharField(max_length=150)
    telefono = models.CharField(max_length=20, blank=True, default="")
    rol = models.CharField(max_length=20, choices=Rol.choices, default=Rol.PACIENTE)
    is_active = models.BooleanField("activo", default=True)
    is_staff = models.BooleanField("acceso al panel de administración", default=False)
    fecha_registro = models.DateTimeField(default=timezone.now)

    objects = UsuarioManager()

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["nombre", "apellido"]

    class Meta:
        verbose_name = "usuario"
        verbose_name_plural = "usuarios"
        constraints = [
            # Respaldo en la base: el correo es único sin distinguir mayúsculas.
            models.UniqueConstraint(Lower("email"), name="usuario_email_ci_unico"),
        ]

    def __str__(self):
        return self.email

    def save(self, *args, **kwargs):
        # El correo es el identificador de acceso: siempre se guarda en minúsculas.
        self.email = self.email.strip().lower()
        super().save(*args, **kwargs)


class Paciente(models.Model):
    """Perfil del paciente. Su clave primaria es la del usuario (relación uno a uno).

    Guarda los "Antecedentes personales" de la ficha podológica, que escribe el propio
    paciente al registrarse. La edad no se guarda: se calcula. Estado civil y quién deriva,
    que están en el papel, el podólogo los descartó por irrelevantes (26/10/2026).
    """

    usuario = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        primary_key=True,
        on_delete=models.PROTECT,
        related_name="paciente",
    )
    rut = models.CharField(max_length=12, unique=True)  # dato sensible
    fecha_nacimiento = models.DateField()
    direccion = models.CharField(max_length=255)
    comuna = models.CharField(max_length=100)
    actividad = models.CharField(max_length=100)  # a qué se dedica (ficha podológica)
    telefono_contacto = models.CharField(max_length=20)  # familiar o contacto de emergencia

    class Meta:
        verbose_name = "paciente"
        verbose_name_plural = "pacientes"

    def __str__(self):
        return str(self.usuario)

    def save(self, *args, **kwargs):
        self.rut = normalizar_rut(self.rut)
        super().save(*args, **kwargs)

    def clean(self):
        super().clean()
        errores = {}
        if self.rut:
            try:
                self.rut = normalizar_rut(self.rut)
            except ValidationError as exc:
                errores["rut"] = exc.messages
        if self.usuario_id and self.usuario.rol != Usuario.Rol.PACIENTE:
            errores["usuario"] = "El usuario debe tener rol paciente."
        if errores:
            raise ValidationError(errores)

    def es_de(self, usuario) -> bool:
        return usuario.is_authenticated and self.usuario_id == usuario.pk

    def edad_al(self, fecha) -> int:
        """Años cumplidos en `fecha`. La edad no se guarda: se calcula al pedirla."""
        nacimiento = self.fecha_nacimiento
        ya_cumplio = (fecha.month, fecha.day) >= (nacimiento.month, nacimiento.day)
        return fecha.year - nacimiento.year - (0 if ya_cumplio else 1)

    @property
    def edad(self) -> int:
        return self.edad_al(timezone.localdate())


class Profesional(models.Model):
    """Perfil del podólogo. Su clave primaria es la del usuario (relación uno a uno)."""

    usuario = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        primary_key=True,
        on_delete=models.PROTECT,
        related_name="profesional",
    )
    especialidad = models.CharField(max_length=100)
    numero_colegiado = models.CharField(
        "N° de registro en la Superintendencia de Salud",
        max_length=50,
        blank=True,
        help_text="Registro Nacional de Prestadores Individuales. Lo ingresa el administrador.",
    )
    pausa_entre_citas_min = models.PositiveSmallIntegerField(default=15)
    descripcion = models.TextField(blank=True)
    # Formación (la ingresa el administrador tras revisar el título; el paciente la ve).
    titulo = models.CharField("título profesional", max_length=150, blank=True)
    institucion_titulo = models.CharField("institución que lo otorgó", max_length=150, blank=True)
    anio_titulo = models.PositiveSmallIntegerField("año de titulación", null=True, blank=True)
    tratamientos = models.ManyToManyField(
        "agenda.Tratamiento",
        blank=True,
        related_name="profesionales",
        verbose_name="tratamientos que realiza",
    )
    # Foto de presentación, re-codificada en JPEG sin metadatos. En la base y no en disco:
    # el plan gratis de Render no tiene disco persistente.
    foto = models.BinaryField(null=True, blank=True, editable=False)
    foto_actualizada_en = models.DateTimeField(null=True, blank=True, editable=False)

    class Meta:
        verbose_name = "profesional"
        verbose_name_plural = "profesionales"

    def __str__(self):
        return str(self.usuario)

    def certificaciones_publicas(self):
        """Lo que ve el paciente: solo lo que el administrador verificó."""
        return self.certificaciones.filter(verificada=True)

    def clean(self):
        super().clean()
        if self.usuario_id and self.usuario.rol != Usuario.Rol.PROFESIONAL:
            raise ValidationError({"usuario": "El usuario debe tener rol profesional."})


class Certificacion(models.Model):
    """Curso, diplomado o certificación de un podólogo, con su documento de respaldo.

    El podólogo la sube desde "Mi perfil"; el administrador revisa el documento y la marca
    como verificada. Solo las verificadas se muestran a los pacientes, y sin el documento: el
    archivo lo ven únicamente el administrador y el propio podólogo.
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    profesional = models.ForeignKey(
        Profesional, on_delete=models.CASCADE, related_name="certificaciones"
    )
    nombre = models.CharField(max_length=200, help_text="Ej.: Diplomado en pie diabético.")
    institucion = models.CharField(max_length=150)
    anio = models.PositiveSmallIntegerField("año")
    # PDF tal cual, o imagen re-codificada en JPEG sin metadatos.
    documento = models.BinaryField(null=True, blank=True, editable=False)
    documento_tipo = models.CharField(max_length=30, blank=True, editable=False)
    documento_nombre = models.CharField(max_length=150, blank=True, editable=False)
    verificada = models.BooleanField(default=False)
    verificada_por = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="+",
        editable=False,
    )
    verificada_en = models.DateTimeField(null=True, blank=True, editable=False)
    creada_en = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "certificación"
        verbose_name_plural = "certificaciones"
        ordering = ["-anio", "nombre"]

    def __str__(self):
        return f"{self.nombre} ({self.institucion}, {self.anio})"

    def es_de(self, usuario) -> bool:
        return usuario.is_authenticated and self.profesional_id == usuario.pk


class RegistroPendiente(models.Model):
    """Registro de paciente que espera la confirmación del correo.

    La cuenta (Usuario + Paciente) se crea recién cuando la persona abre el enlace que le
    llega por correo. Así nadie ocupa el correo o el RUT de otra persona, y el formulario
    responde siempre lo mismo sin revelar si alguien ya es paciente. Se guarda el hash de la
    contraseña (nunca la contraseña) y el del token (el token solo viaja en el correo). Vence
    en REGISTRO_VIGENCIA_HORAS y se borra al confirmarse o al vencer.
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email = models.EmailField("correo")
    datos = models.JSONField(help_text="Datos del formulario, sin la contraseña.")
    password_hash = models.CharField(max_length=128)
    token_hash = models.CharField(max_length=64, unique=True)
    siguiente = models.CharField(max_length=500, blank=True)
    creado_en = models.DateTimeField(default=timezone.now)
    vence_en = models.DateTimeField()

    class Meta:
        verbose_name = "registro pendiente"
        verbose_name_plural = "registros pendientes"
        indexes = [models.Index(fields=["vence_en"])]

    def __str__(self):
        return f"{self.email} (vence {self.vence_en:%d/%m %H:%M})"


class CodigoRespaldo(models.Model):
    """Código de un solo uso para entrar si se pierde el teléfono con la app de autenticación.

    Se entregan 10 al activar la verificación en dos pasos y se muestran una sola vez. Se guarda
    su huella (SHA-256), nunca el código: son aleatorios y largos, así que basta.
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="codigos_respaldo"
    )
    huella = models.CharField(max_length=64)
    usado_en = models.DateTimeField(null=True, blank=True)
    creado_en = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = "código de respaldo"
        verbose_name_plural = "códigos de respaldo"
        constraints = [
            models.UniqueConstraint(fields=["usuario", "huella"], name="codigo_respaldo_unico"),
        ]

    def __str__(self):
        return f"Código de {self.usuario} ({'usado' if self.usado_en else 'disponible'})"


class DispositivoVerificacion(TOTPDevice):
    """El dispositivo TOTP de django-otp con nombre en español, para el panel /admin/.

    Es un modelo proxy: usa la misma tabla que TOTPDevice (no guarda nada propio) y django-otp
    lo ignora al buscar dispositivos. Así el nombre se cambia sin tocar el paquete instalado.
    """

    class Meta:
        proxy = True
        verbose_name = "dispositivo de verificación"
        verbose_name_plural = "dispositivos de verificación"

    def __str__(self):
        return f"{self.name} de {self.user}"
