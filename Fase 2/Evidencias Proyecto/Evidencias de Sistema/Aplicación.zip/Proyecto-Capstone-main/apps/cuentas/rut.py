"""RUT chileno: normalización y validación del dígito verificador (módulo 11).

Formato de almacenamiento: cuerpo sin puntos, guion y dígito verificador en mayúscula
(por ejemplo, ``12345678-5`` o ``10000030-K``). Así la unicidad de la columna sirve.
"""

import re

from django.core.exceptions import ValidationError

_PATRON = re.compile(r"^(\d{7,8})-?([\dK])$")


def calcular_dv(cuerpo: int | str) -> str:
    """Dígito verificador de un RUT a partir de su cuerpo numérico."""
    suma = 0
    factor = 2
    for digito in reversed(str(cuerpo)):
        suma += int(digito) * factor
        factor = 2 if factor == 7 else factor + 1
    resto = 11 - (suma % 11)
    if resto == 11:
        return "0"
    if resto == 10:
        return "K"
    return str(resto)


def normalizar_rut(valor: str) -> str:
    """Devuelve el RUT normalizado o lanza ValidationError si el formato o el DV son inválidos."""
    limpio = re.sub(r"[.\s]", "", str(valor or "")).upper()
    coincidencia = _PATRON.match(limpio)
    if coincidencia is None:
        raise ValidationError("El RUT no tiene un formato válido (ejemplo: 12.345.678-5).")
    cuerpo, dv = coincidencia.groups()
    if calcular_dv(cuerpo) != dv:
        raise ValidationError("El dígito verificador del RUT no es correcto.")
    return f"{cuerpo}-{dv}"
