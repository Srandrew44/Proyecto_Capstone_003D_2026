import pytest
from rest_framework.test import APIClient

from apps.auditoria.models import RegistroAuditoria
from apps.cuentas.bloqueo import huella_email

from .factories import CLAVE, PacienteFactory, UsuarioFactory

pytestmark = pytest.mark.django_db
LOGIN = "/api/auth/login/"
LOGOUT = "/api/auth/logout/"
YO = "/api/auth/yo/"


def test_login_correcto_abre_sesion_y_audita(api_client):
    paciente = PacienteFactory()
    respuesta = api_client.post(
        LOGIN, {"email": paciente.usuario.email, "password": CLAVE}, format="json"
    )
    assert respuesta.status_code == 200
    assert respuesta.json()["rol"] == "paciente"
    assert api_client.get(YO).json()["email"] == paciente.usuario.email
    registro = RegistroAuditoria.objects.get(accion=RegistroAuditoria.Accion.LOGIN)
    assert registro.usuario == paciente.usuario
    assert registro.ip == "127.0.0.1"


def test_login_ignora_mayusculas_y_espacios_en_el_correo(api_client):
    PacienteFactory(usuario__email="ana@example.com")
    respuesta = api_client.post(
        LOGIN, {"email": "  ANA@Example.com ", "password": CLAVE}, format="json"
    )
    assert respuesta.status_code == 200


def test_login_fallido_queda_ligado_a_la_cuenta_sin_el_correo_en_texto(api_client):
    paciente = PacienteFactory()
    respuesta = api_client.post(
        LOGIN, {"email": paciente.usuario.email, "password": "incorrecta"}, format="json"
    )
    assert respuesta.status_code == 401
    registro = RegistroAuditoria.objects.get(accion=RegistroAuditoria.Accion.LOGIN_FALLIDO)
    assert registro.usuario == paciente.usuario
    assert registro.detalle == {"correo": huella_email(paciente.usuario.email)}
    assert paciente.usuario.email not in str(registro.detalle)
    assert api_client.get(YO).status_code == 403


def test_login_fallido_con_un_correo_sin_cuenta_no_guarda_nada_legible(api_client):
    api_client.post(LOGIN, {"email": "Nadie@Correo.cl", "password": "x"}, format="json")
    registro = RegistroAuditoria.objects.get(accion=RegistroAuditoria.Accion.LOGIN_FALLIDO)
    assert registro.usuario is None
    assert "nadie" not in str(registro.detalle).lower()
    # La misma huella sin importar mayúsculas ni espacios: el freno los cuenta juntos.
    assert registro.detalle["correo"] == huella_email("  nadie@correo.CL ")


def test_correo_inexistente_da_el_mismo_error_que_clave_incorrecta(api_client):
    paciente = PacienteFactory()
    mal_clave = api_client.post(
        LOGIN, {"email": paciente.usuario.email, "password": "x"}, format="json"
    )
    sin_cuenta = api_client.post(
        LOGIN, {"email": "nadie@example.com", "password": "x"}, format="json"
    )
    assert mal_clave.status_code == sin_cuenta.status_code == 401
    assert mal_clave.json() == sin_cuenta.json()


def test_cuenta_inactiva_no_puede_entrar(api_client):
    usuario = UsuarioFactory(is_active=False)
    respuesta = api_client.post(LOGIN, {"email": usuario.email, "password": CLAVE}, format="json")
    assert respuesta.status_code == 401


def test_logout_cierra_la_sesion(api_client):
    paciente = PacienteFactory()
    api_client.post(LOGIN, {"email": paciente.usuario.email, "password": CLAVE}, format="json")
    assert api_client.post(LOGOUT).status_code == 204
    assert api_client.get(YO).status_code == 403


def test_yo_exige_sesion(api_client):
    assert api_client.get(YO).status_code == 403


def test_login_exige_token_csrf_y_funciona_con_el_token():
    cliente = APIClient(enforce_csrf_checks=True)
    paciente = PacienteFactory()
    datos = {"email": paciente.usuario.email, "password": CLAVE}

    assert cliente.post(LOGIN, datos, format="json").status_code == 403

    cliente.get("/api/auth/csrf/")
    token = cliente.cookies["csrftoken"].value
    respuesta = cliente.post(LOGIN, datos, format="json", HTTP_X_CSRFTOKEN=token)
    assert respuesta.status_code == 200
