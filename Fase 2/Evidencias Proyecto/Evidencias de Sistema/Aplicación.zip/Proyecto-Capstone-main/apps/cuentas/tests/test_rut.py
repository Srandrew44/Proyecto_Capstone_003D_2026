import pytest
from django.core.exceptions import ValidationError

from apps.cuentas.rut import calcular_dv, normalizar_rut


@pytest.mark.parametrize(
    ("entrada", "esperado"),
    [
        ("12.345.678-5", "12345678-5"),
        ("12345678-5", "12345678-5"),
        ("123456785", "12345678-5"),
        ("  11.111.111-1 ", "11111111-1"),
        ("10.000.030-K", "10000030-K"),
        ("10000030-k", "10000030-K"),
        ("10000004-0", "10000004-0"),
    ],
)
def test_normaliza_ruts_validos(entrada, esperado):
    assert normalizar_rut(entrada) == esperado


@pytest.mark.parametrize(
    "entrada",
    ["", "abc", "12.345.678-9", "12345678-K", "1-9", "123456789012-3", "12.345.678", None],
)
def test_rechaza_ruts_invalidos(entrada):
    with pytest.raises(ValidationError):
        normalizar_rut(entrada)


def test_digito_verificador_cubre_0_k_y_numeros():
    assert calcular_dv(10000004) == "0"
    assert calcular_dv(10000030) == "K"
    assert calcular_dv(12345678) == "5"
