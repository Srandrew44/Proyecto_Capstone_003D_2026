import uuid

import pytest
from django.contrib.auth import get_user_model
from django.db import IntegrityError

from .factories import UsuarioFactory

pytestmark = pytest.mark.django_db
Usuario = get_user_model()


def test_la_clave_se_guarda_con_argon2():
    usuario = UsuarioFactory()
    assert usuario.password.startswith("argon2$")
    assert usuario.check_password("ClaveSegura-123")


def test_usa_uuid_como_clave_primaria():
    assert isinstance(UsuarioFactory().pk, uuid.UUID)


def test_el_correo_se_normaliza_a_minusculas():
    usuario = Usuario.objects.create_user("  Ana@Example.COM ", "ClaveSegura-123")
    assert usuario.email == "ana@example.com"


def test_el_correo_es_obligatorio():
    with pytest.raises(ValueError):
        Usuario.objects.create_user("", "ClaveSegura-123")


def test_el_correo_es_unico():
    UsuarioFactory(email="repetido@example.com")
    with pytest.raises(IntegrityError):
        UsuarioFactory(email="repetido@example.com")


def test_el_rol_por_defecto_es_paciente():
    assert UsuarioFactory().rol == Usuario.Rol.PACIENTE


def test_usuario_normal_no_es_staff_ni_superusuario():
    usuario = UsuarioFactory()
    assert not usuario.is_staff
    assert not usuario.is_superuser


def test_superusuario_tiene_acceso_al_panel():
    admin = Usuario.objects.create_superuser("admin@example.com", "ClaveSegura-123")
    assert admin.is_staff
    assert admin.is_superuser
