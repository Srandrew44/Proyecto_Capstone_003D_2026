"""Registro de pacientes con confirmación del correo.

La API (y la página) responden siempre lo mismo ante datos bien escritos: la cuenta se crea
recién al abrir el enlace del correo. Así nadie ocupa el correo o el RUT de otra persona, y
el formulario no sirve para averiguar quién ya es paciente.
"""

import re
from datetime import timedelta

import pytest
from django.contrib.auth import authenticate
from django.core import mail
from django.test import Client
from django.utils import timezone

from apps.auditoria.models import RegistroAuditoria
from apps.cuentas.models import Paciente, RegistroPendiente, Usuario

from .factories import PacienteFactory

pytestmark = pytest.mark.django_db
URL = "/api/auth/registro/"
CLAVE_NUEVA = "Zorro-Azul-4471-xk"
RESPUESTA = {"detail": "Te enviamos un correo para confirmar la cuenta."}


@pytest.fixture
def datos():
    return {
        "email": "Ana.Perez@Example.com",
        "password": CLAVE_NUEVA,
        "nombre": "Ana",
        "apellido": "Pérez",
        "telefono": "+56912345678",
        "rut": "12.345.678-5",
        "fecha_nacimiento": "1985-03-20",
        "direccion": "Av. Providencia 1234",
        "comuna": "Providencia",
        "actividad": "Contadora",
        "telefono_contacto": "+56987654321",
    }


def enlace_de_confirmacion(correo) -> str:
    return re.search(r"https?://testserver(/registro/confirmar/[^/\s]+/)", correo.body).group(1)


def _confirmar(enlace):
    cliente = Client()
    return cliente, cliente.post(enlace)


def test_el_registro_no_crea_la_cuenta_hasta_confirmar_el_correo(api_client, datos):
    respuesta = api_client.post(URL, datos, format="json")
    assert respuesta.status_code == 202
    assert respuesta.json() == RESPUESTA
    assert not Usuario.objects.filter(email="ana.perez@example.com").exists()
    assert len(mail.outbox) == 1
    assert mail.outbox[0].to == ["ana.perez@example.com"]
    assert "Confirma tu correo" in mail.outbox[0].subject


def test_el_registro_pendiente_guarda_el_hash_y_no_la_contrasena(api_client, datos):
    api_client.post(URL, datos, format="json")
    pendiente = RegistroPendiente.objects.get()
    assert pendiente.password_hash.startswith("argon2$")
    assert CLAVE_NUEVA not in str(pendiente.datos)
    token = enlace_de_confirmacion(mail.outbox[0]).split("/")[-2]
    assert token not in pendiente.token_hash  # solo se guarda su huella


def test_al_confirmar_se_crea_la_cuenta_con_la_contrasena_elegida(api_client, datos):
    api_client.post(URL, datos, format="json")
    cliente, respuesta = _confirmar(enlace_de_confirmacion(mail.outbox[0]))
    assert respuesta.status_code == 302
    assert respuesta.url == "/paciente/consentimiento/?nuevo=1"
    usuario = Usuario.objects.get(email="ana.perez@example.com")
    assert usuario.rol == Usuario.Rol.PACIENTE
    assert usuario.paciente.rut == "12345678-5"
    assert usuario.telefono == "+56912345678"
    assert usuario.paciente.actividad == "Contadora"
    assert usuario.paciente.telefono_contacto == "+56987654321"
    assert authenticate(username="ana.perez@example.com", password=CLAVE_NUEVA) == usuario
    assert "_auth_user_id" in cliente.session  # queda con la sesión abierta
    assert not RegistroPendiente.objects.exists()
    registro = RegistroAuditoria.objects.get(accion=RegistroAuditoria.Accion.REGISTRO)
    assert registro.usuario == usuario


def test_abrir_el_enlace_no_crea_la_cuenta_hasta_apretar_el_boton(api_client, datos):
    """Los antivirus de correo abren los enlaces: con un GET no debe pasar nada."""
    api_client.post(URL, datos, format="json")
    respuesta = Client().get(enlace_de_confirmacion(mail.outbox[0]))
    assert respuesta.status_code == 200
    assert "Activar mi cuenta" in respuesta.content.decode()
    assert not Usuario.objects.filter(email="ana.perez@example.com").exists()


def test_el_enlace_sirve_una_sola_vez(api_client, datos):
    api_client.post(URL, datos, format="json")
    enlace = enlace_de_confirmacion(mail.outbox[0])
    _confirmar(enlace)
    _, segunda = _confirmar(enlace)
    assert segunda.status_code == 400
    assert Usuario.objects.filter(email="ana.perez@example.com").count() == 1


def test_el_enlace_vencido_no_crea_la_cuenta(api_client, datos):
    api_client.post(URL, datos, format="json")
    RegistroPendiente.objects.update(vence_en=timezone.now() - timedelta(minutes=1))
    _, respuesta = _confirmar(enlace_de_confirmacion(mail.outbox[0]))
    assert respuesta.status_code == 400
    assert not Usuario.objects.filter(email="ana.perez@example.com").exists()


def test_registrarse_de_nuevo_reemplaza_el_enlace_anterior(api_client, datos):
    api_client.post(URL, datos, format="json")
    api_client.post(URL, datos, format="json")
    assert RegistroPendiente.objects.count() == 1
    _, viejo = _confirmar(enlace_de_confirmacion(mail.outbox[0]))
    assert viejo.status_code == 400
    _, nuevo = _confirmar(enlace_de_confirmacion(mail.outbox[1]))
    assert nuevo.status_code == 302


def test_un_correo_ya_registrado_responde_igual_y_avisa_por_correo(api_client, datos):
    PacienteFactory(usuario__email="ana.perez@example.com")
    respuesta = api_client.post(URL, datos, format="json")
    assert respuesta.status_code == 202
    assert respuesta.json() == RESPUESTA
    assert not RegistroPendiente.objects.exists()
    assert mail.outbox[0].subject == "Ya tienes una cuenta en MyPodo"
    assert "/recuperar/" in mail.outbox[0].body


def test_un_rut_ya_registrado_responde_igual_y_avisa_por_correo(api_client, datos):
    PacienteFactory(rut="12345678-5")
    respuesta = api_client.post(URL, datos, format="json")
    assert respuesta.status_code == 202
    assert respuesta.json() == RESPUESTA
    assert not RegistroPendiente.objects.exists()
    assert mail.outbox[0].to == ["ana.perez@example.com"]
    assert mail.outbox[0].subject == "No pudimos crear tu cuenta en MyPodo"


def test_si_otro_usa_el_rut_antes_de_confirmar_no_se_crea_la_cuenta(api_client, datos):
    api_client.post(URL, datos, format="json")
    PacienteFactory(rut="12345678-5")
    _, respuesta = _confirmar(enlace_de_confirmacion(mail.outbox[0]))
    assert respuesta.status_code == 400
    assert not Usuario.objects.filter(email="ana.perez@example.com").exists()
    assert not RegistroPendiente.objects.exists()


def test_rut_con_digito_verificador_incorrecto(api_client, datos):
    datos["rut"] = "12.345.678-9"
    respuesta = api_client.post(URL, datos, format="json")
    assert respuesta.status_code == 400
    assert "rut" in respuesta.json()


@pytest.mark.parametrize("clave", ["12345678", "corta-1A", "password123"])
def test_clave_debil_o_de_menos_de_10_caracteres(api_client, datos, clave):
    datos["password"] = clave
    respuesta = api_client.post(URL, datos, format="json")
    assert respuesta.status_code == 400
    assert "password" in respuesta.json()


def test_fecha_de_nacimiento_futura(api_client, datos):
    datos["fecha_nacimiento"] = str(timezone.localdate() + timedelta(days=1))
    respuesta = api_client.post(URL, datos, format="json")
    assert respuesta.status_code == 400
    assert "fecha_nacimiento" in respuesta.json()


@pytest.mark.parametrize(
    "campo",
    ["telefono", "direccion", "comuna", "actividad", "telefono_contacto"],
)
def test_faltan_campos_obligatorios(api_client, datos, campo):
    del datos[campo]
    respuesta = api_client.post(URL, datos, format="json")
    assert respuesta.status_code == 400
    assert campo in respuesta.json()


def test_un_registro_con_errores_no_deja_datos_a_medias(api_client, datos):
    datos["rut"] = "12.345.678-9"
    api_client.post(URL, datos, format="json")
    assert not Usuario.objects.filter(email="ana.perez@example.com").exists()
    assert Paciente.objects.count() == 0
    assert not RegistroPendiente.objects.exists()
    assert mail.outbox == []
