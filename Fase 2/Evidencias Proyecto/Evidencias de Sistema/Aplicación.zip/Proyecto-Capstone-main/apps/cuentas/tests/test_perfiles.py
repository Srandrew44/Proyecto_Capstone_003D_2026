import pytest
from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.db.models import ProtectedError

from apps.cuentas.models import Paciente, Profesional, Usuario

from .factories import PacienteFactory, ProfesionalFactory, UsuarioFactory

pytestmark = pytest.mark.django_db


def test_el_rut_se_guarda_normalizado():
    paciente = PacienteFactory(rut="12.345.678-5")
    paciente.refresh_from_db()
    assert paciente.rut == "12345678-5"


def test_no_se_guarda_un_rut_invalido():
    with pytest.raises(ValidationError):
        PacienteFactory(rut="12.345.678-9")


def test_el_rut_es_unico():
    PacienteFactory(rut="12345678-5")
    with pytest.raises(IntegrityError), transaction.atomic():
        PacienteFactory(rut="12.345.678-5")


def test_clean_rechaza_paciente_con_rol_de_profesional():
    usuario = UsuarioFactory(rol=Usuario.Rol.PROFESIONAL)
    paciente = Paciente(
        usuario=usuario,
        rut="12345678-5",
        fecha_nacimiento="1990-01-01",
        direccion="x",
        comuna="y",
    )
    with pytest.raises(ValidationError) as error:
        paciente.full_clean()
    assert "usuario" in error.value.message_dict


def test_clean_rechaza_profesional_con_rol_de_paciente():
    usuario = UsuarioFactory(rol=Usuario.Rol.PACIENTE)
    profesional = Profesional(usuario=usuario, especialidad="Podología")
    with pytest.raises(ValidationError):
        profesional.full_clean()


def test_la_clave_del_perfil_es_la_del_usuario():
    paciente = PacienteFactory()
    assert paciente.pk == paciente.usuario_id
    assert paciente.usuario.paciente == paciente


def test_la_pausa_entre_citas_por_defecto_es_15():
    assert ProfesionalFactory().pausa_entre_citas_min == 15


def test_no_se_puede_borrar_un_usuario_con_perfil():
    paciente = PacienteFactory()
    with pytest.raises(ProtectedError):
        paciente.usuario.delete()


def test_el_correo_se_guarda_en_minusculas_aunque_no_pase_por_el_manager():
    usuario = Usuario(email="  Mixto@Example.COM ", nombre="A", apellido="B")
    usuario.set_password("ClaveSegura-123")
    usuario.save()
    assert Usuario.objects.get(pk=usuario.pk).email == "mixto@example.com"


def test_el_superusuario_recibe_rol_admin():
    admin = Usuario.objects.create_superuser("admin@example.com", "ClaveSegura-123")
    assert admin.rol == Usuario.Rol.ADMIN


def test_es_de_compara_con_el_usuario_dueno():
    a, b = PacienteFactory(), PacienteFactory()
    assert a.es_de(a.usuario)
    assert not a.es_de(b.usuario)
