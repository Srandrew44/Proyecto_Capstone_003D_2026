"""Perfil del podólogo (formación, foto, certificaciones), su página pública y el panel."""

import io
from datetime import timedelta

import pytest
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import Client
from django.urls import reverse
from django.utils import timezone
from PIL import Image

from apps.agenda.tests.factories import CitaFactory, DisponibilidadFactory, TratamientoFactory
from apps.auditoria.models import RegistroAuditoria
from apps.cuentas.models import Certificacion, Profesional, Usuario
from apps.cuentas.tests.factories import PacienteFactory, ProfesionalFactory, UsuarioFactory

pytestmark = pytest.mark.django_db
Accion = RegistroAuditoria.Accion
PDF = b"%PDF-1.4\n%prueba\n"


def _cliente(usuario):
    cliente = Client()
    cliente.force_login(usuario)
    return cliente


def _admin():
    return UsuarioFactory(rol=Usuario.Rol.ADMIN, is_staff=True, is_superuser=True)


def _imagen(nombre="foto.png"):
    salida = io.BytesIO()
    Image.new("RGB", (900, 700), (180, 140, 120)).save(salida, format="PNG")
    return SimpleUploadedFile(nombre, salida.getvalue(), content_type="image/png")


def _pdf():
    return SimpleUploadedFile("titulo.pdf", PDF, content_type="application/pdf")


@pytest.fixture
def podologo():
    return ProfesionalFactory(
        titulo="Podólogo", institucion_titulo="Universidad de Chile", anio_titulo=2015,
        numero_colegiado="123456",
    )  # fmt: skip


# --- panel: nuevo podólogo en un paso ---


def _datos_nuevo(**cambios):
    return {
        "email": "nueva.podologa@correo.cl",
        "nombre": "Valentina",
        "apellido": "Soto",
        "telefono": "+56 9 5555 6666",
        "password1": "Pinguino-Austral-5521-k",
        "password2": "Pinguino-Austral-5521-k",
        "especialidad": "Podología clínica",
        "pausa_entre_citas_min": "15",
        "titulo": "Podóloga",
        "institucion_titulo": "INACAP",
        "anio_titulo": "2019",
        "numero_colegiado": "998877",
        "descripcion": "",
        **cambios,
    }


def test_el_admin_crea_un_podologo_con_cuenta_y_perfil_en_un_paso():
    respuesta = _cliente(_admin()).post(reverse("admin:cuentas_profesional_add"), _datos_nuevo())
    assert respuesta.status_code == 302, respuesta.content.decode()[:500]
    profesional = Profesional.objects.get(usuario__email="nueva.podologa@correo.cl")
    assert profesional.usuario.rol == Usuario.Rol.PROFESIONAL
    assert profesional.usuario.check_password("Pinguino-Austral-5521-k")
    assert (profesional.titulo, profesional.anio_titulo) == ("Podóloga", 2019)
    # Puede entrar de inmediato: tiene cuenta y perfil (sin el bucle de cuenta a medias).
    assert _cliente(profesional.usuario).get(reverse("web:podologo-inicio")).status_code == 200


@pytest.mark.parametrize(
    ("cambio", "error"),
    [
        ({"password2": "Otra-Cosa-1234-zz"}, "no coinciden"),
        ({"password1": "12345678", "password2": "12345678"}, "común"),
    ],
)
def test_el_formulario_de_nuevo_podologo_valida_la_contrasena(cambio, error):
    respuesta = _cliente(_admin()).post(
        reverse("admin:cuentas_profesional_add"), _datos_nuevo(**cambio)
    )
    assert respuesta.status_code == 200
    assert error in respuesta.content.decode()
    assert not Usuario.objects.filter(email="nueva.podologa@correo.cl").exists()


def test_no_se_repite_un_correo_existente(podologo):
    respuesta = _cliente(_admin()).post(
        reverse("admin:cuentas_profesional_add"), _datos_nuevo(email=podologo.usuario.email)
    )
    assert "Ya existe una cuenta con ese correo" in respuesta.content.decode()


def test_la_pagina_del_usuario_muestra_su_perfil(podologo):
    url = reverse("admin:cuentas_usuario_change", args=[podologo.usuario.pk])
    html = _cliente(_admin()).get(url).content.decode()
    assert "perfil de podólogo" in html.lower()


# --- panel: dar de baja y reactivar ---


def _accion(cliente, modelo, accion, ids):
    return cliente.post(
        reverse(f"admin:cuentas_{modelo}_changelist"),
        {"action": accion, "_selected_action": [str(i) for i in ids]},
        follow=True,
    )


def test_dar_de_baja_y_reactivar_un_paciente_conserva_su_historia():
    admin = _admin()
    paciente = PacienteFactory()
    cliente = _cliente(admin)
    _accion(cliente, "paciente", "dar_de_baja", [paciente.pk])
    paciente.usuario.refresh_from_db()
    assert not paciente.usuario.is_active
    assert RegistroAuditoria.objects.filter(accion=Accion.DAR_DE_BAJA, usuario=admin).exists()
    _accion(cliente, "paciente", "reactivar", [paciente.pk])
    paciente.usuario.refresh_from_db()
    assert paciente.usuario.is_active
    assert RegistroAuditoria.objects.filter(accion=Accion.REACTIVAR).exists()


def test_dar_de_baja_un_podologo_avisa_de_sus_citas_futuras(podologo):
    CitaFactory(profesional=podologo, inicio=timezone.now() + timedelta(days=3))
    respuesta = _accion(_cliente(_admin()), "profesional", "dar_de_baja", [podologo.pk])
    assert "Quedan 1 citas futuras" in respuesta.content.decode()
    podologo.usuario.refresh_from_db()
    assert not podologo.usuario.is_active


def test_el_admin_no_se_da_de_baja_a_si_mismo():
    admin = _admin()
    respuesta = _accion(_cliente(admin), "usuario", "dar_de_baja", [admin.pk])
    assert "No puedes darte de baja a ti mismo" in respuesta.content.decode()
    admin.refresh_from_db()
    assert admin.is_active


def test_no_se_puede_borrar_pacientes_ni_podologos(podologo):
    cliente = _cliente(_admin())
    url = reverse("admin:cuentas_profesional_delete", args=[podologo.pk])
    assert cliente.get(url).status_code == 403


# --- «Mi perfil» del podólogo ---


def test_el_podologo_sube_y_quita_su_foto(podologo):
    cliente = _cliente(podologo.usuario)
    cliente.post(reverse("web:podologo-foto"), {"foto": _imagen()})
    podologo.refresh_from_db()
    imagen = Image.open(io.BytesIO(bytes(podologo.foto)))
    assert imagen.format == "JPEG" and max(imagen.size) == 600
    assert Client().get(reverse("web:profesional-foto", args=[podologo.pk])).status_code == 200
    cliente.post(reverse("web:podologo-foto"), {"accion": "quitar"})
    podologo.refresh_from_db()
    assert podologo.foto is None and podologo.foto_actualizada_en is None


def test_el_podologo_elige_sus_tratamientos(podologo):
    uno, otro = TratamientoFactory(), TratamientoFactory()
    _cliente(podologo.usuario).post(
        reverse("web:podologo-mis-tratamientos"), {"tratamientos": [str(uno.pk)]}
    )
    assert list(podologo.tratamientos.all()) == [uno]
    assert otro not in podologo.tratamientos.all()


def test_una_certificacion_subida_queda_en_revision_y_no_es_publica(podologo):
    cliente = _cliente(podologo.usuario)
    datos = {"nombre": "Diplomado en pie diabético", "institucion": "UC", "anio": "2021"}
    cliente.post(reverse("web:podologo-certificacion"), {**datos, "documento": _pdf()})
    certificacion = Certificacion.objects.get()
    assert not certificacion.verificada
    assert certificacion.documento_tipo == "application/pdf"
    html = Client().get(reverse("web:profesional-publico", args=[podologo.pk])).content.decode()
    assert "Diplomado en pie diabético" not in html


def test_un_archivo_que_no_es_pdf_ni_imagen_se_rechaza(podologo):
    falso = SimpleUploadedFile("virus.exe", b"MZ\x90\x00", content_type="application/pdf")
    _cliente(podologo.usuario).post(
        reverse("web:podologo-certificacion"),
        {"nombre": "X", "institucion": "Y", "anio": "2020", "documento": falso},
    )
    assert not Certificacion.objects.exists()


def test_el_documento_solo_lo_ven_su_podologo_y_el_admin(podologo):
    certificacion = Certificacion.objects.create(
        profesional=podologo, nombre="Curso", institucion="UC", anio=2020,
        documento=PDF, documento_tipo="application/pdf",
    )  # fmt: skip
    propia = reverse("web:podologo-certificacion-documento", args=[certificacion.pk])
    assert _cliente(podologo.usuario).get(propia).status_code == 200
    assert _cliente(ProfesionalFactory().usuario).get(propia).status_code == 404
    del_admin = reverse("admin:cuentas_certificacion_documento", args=[certificacion.pk])
    assert _cliente(_admin()).get(del_admin).status_code == 200
    assert _cliente(PacienteFactory().usuario).get(del_admin).status_code == 302  # al login


# --- verificación y perfil público ---


def test_al_verificarla_se_muestra_al_paciente_sin_el_documento(podologo):
    certificacion = Certificacion.objects.create(
        profesional=podologo, nombre="Diplomado en pie diabético", institucion="UC",
        anio=2021, documento=PDF, documento_tipo="application/pdf",
    )  # fmt: skip
    admin = _admin()
    _accion(_cliente(admin), "certificacion", "marcar_verificadas", [certificacion.pk])
    certificacion.refresh_from_db()
    assert certificacion.verificada and certificacion.verificada_por == admin
    assert RegistroAuditoria.objects.filter(accion=Accion.VERIFICAR_CERTIFICACION).exists()
    paciente = PacienteFactory()
    html = (
        _cliente(paciente.usuario)
        .get(reverse("web:profesional-publico", args=[podologo.pk]))
        .content.decode()
    )
    assert "Diplomado en pie diabético" in html
    assert "Verificada por la consulta" in html
    assert "documento" not in html.lower().split("certificaciones y cursos")[1][:2000]


def test_el_perfil_publico_muestra_la_formacion_y_nada_privado(podologo):
    usuario = podologo.usuario
    usuario.telefono = "+56 9 7777 8888"
    usuario.save()
    html = Client().get(reverse("web:profesional-publico", args=[podologo.pk])).content.decode()
    assert "Universidad de Chile" in html and "N° 123456" in html
    assert "rnpi.superdesalud.gob.cl" in html
    assert usuario.email not in html
    assert "7777" not in html


def test_un_podologo_dado_de_baja_no_tiene_perfil_publico(podologo):
    podologo.usuario.is_active = False
    podologo.usuario.save()
    assert Client().get(reverse("web:profesional-publico", args=[podologo.pk])).status_code == 404


def test_la_portada_y_la_reserva_enlazan_al_perfil(podologo):
    # Al reservar solo aparecen los podólogos con horario semanal.
    DisponibilidadFactory(profesional=podologo)
    url = reverse("web:profesional-publico", args=[podologo.pk])
    assert url in Client().get(reverse("web:portada")).content.decode()
    paciente = PacienteFactory()
    html = _cliente(paciente.usuario).get(reverse("web:paciente-reservar")).content.decode()
    assert url in html
