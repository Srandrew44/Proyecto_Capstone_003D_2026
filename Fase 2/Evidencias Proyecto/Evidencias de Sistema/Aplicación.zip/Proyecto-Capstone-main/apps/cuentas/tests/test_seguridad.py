"""Freno de intentos de login, límite de registros, cabeceras de seguridad y sesión."""

from datetime import timedelta
from unittest import mock

import pytest
from django.conf import settings
from django.test import Client
from django.utils import timezone

from apps.auditoria.models import RegistroAuditoria
from apps.cuentas.bloqueo import MAX_POR_CORREO, MAX_POR_IP, VENTANA, huella_email
from apps.cuentas.models import Usuario

from .factories import CLAVE, PacienteFactory, UsuarioFactory

pytestmark = pytest.mark.django_db
LOGIN = "/api/auth/login/"
FALLIDO = RegistroAuditoria.Accion.LOGIN_FALLIDO


def _login(cliente, email, clave):
    return cliente.post(LOGIN, {"email": email, "password": clave}, format="json")


def _fallar(cliente, email, veces):
    for _ in range(veces):
        assert _login(cliente, email, "incorrecta").status_code == 401


def test_tras_varios_fallos_el_correo_queda_frenado_aunque_la_clave_sea_correcta(api_client):
    email = PacienteFactory().usuario.email
    _fallar(api_client, email, MAX_POR_CORREO)
    respuesta = _login(api_client, email, CLAVE)
    assert respuesta.status_code == 429
    assert "15 minutos" in respuesta.json()["detail"]
    assert api_client.get("/api/auth/yo/").status_code == 403
    bloqueado = RegistroAuditoria.objects.filter(accion=FALLIDO, detalle__bloqueado=True)
    assert bloqueado.count() == 1


def test_un_correo_sin_cuenta_se_frena_igual_y_no_revela_que_no_existe(api_client):
    _fallar(api_client, "nadie@example.com", MAX_POR_CORREO)
    assert _login(api_client, "nadie@example.com", "x").status_code == 429


def test_el_freno_vence_al_pasar_la_ventana(api_client):
    email = PacienteFactory().usuario.email
    hace_rato = timezone.now() - VENTANA - timedelta(minutes=1)
    for _ in range(MAX_POR_CORREO):
        RegistroAuditoria.objects.create(
            accion=FALLIDO, detalle={"correo": huella_email(email)}, fecha=hace_rato
        )
    assert _login(api_client, email, CLAVE).status_code == 200


def test_un_login_correcto_reinicia_la_cuenta_de_fallos(api_client):
    email = PacienteFactory().usuario.email
    _fallar(api_client, email, MAX_POR_CORREO - 1)
    assert _login(api_client, email, CLAVE).status_code == 200
    _fallar(api_client, email, MAX_POR_CORREO - 1)
    assert _login(api_client, email, CLAVE).status_code == 200


def test_los_intentos_durante_el_freno_no_lo_alargan(api_client):
    email = PacienteFactory().usuario.email
    ahora = timezone.now()
    for _ in range(MAX_POR_CORREO):
        RegistroAuditoria.objects.create(
            accion=FALLIDO,
            detalle={"correo": huella_email(email)},
            fecha=ahora - VENTANA + timedelta(seconds=10),
        )
    for _ in range(MAX_POR_CORREO):
        assert _login(api_client, email, "incorrecta").status_code == 429
    # Pasada la ventana desde los fallos que lo activaron, se puede entrar de nuevo aunque
    # durante el freno se siguió intentando (esos intentos siguen dentro de la ventana).
    despues = ahora + timedelta(seconds=11)
    with mock.patch("apps.cuentas.bloqueo.timezone.now", return_value=despues):
        assert _login(api_client, email, CLAVE).status_code == 200


def test_una_ip_con_muchos_fallos_queda_frenada(api_client):
    email = PacienteFactory().usuario.email
    for n in range(MAX_POR_IP):
        RegistroAuditoria.objects.create(
            accion=FALLIDO, ip="127.0.0.1", detalle={"correo": huella_email(f"otro{n}@example.com")}
        )
    assert _login(api_client, email, CLAVE).status_code == 429


def test_el_panel_admin_tambien_frena_y_audita_los_fallos():
    admin = UsuarioFactory(rol=Usuario.Rol.ADMIN, is_staff=True, is_superuser=True)
    cliente = Client()
    for _ in range(MAX_POR_CORREO):
        cliente.post("/admin/login/", {"username": admin.email, "password": "incorrecta"})
    assert RegistroAuditoria.objects.filter(accion=FALLIDO).count() == MAX_POR_CORREO
    cliente.post("/admin/login/", {"username": admin.email, "password": CLAVE})
    assert "_auth_user_id" not in cliente.session


def test_el_registro_esta_limitado_por_ip(api_client):
    maximo = int(settings.REST_FRAMEWORK["DEFAULT_THROTTLE_RATES"]["registro"].split("/")[0])
    for _ in range(maximo):
        assert api_client.post("/api/auth/registro/", {}, format="json").status_code == 400
    assert api_client.post("/api/auth/registro/", {}, format="json").status_code == 429


def test_cabeceras_de_seguridad_en_las_paginas(client):
    respuesta = client.get("/")
    assert "frame-ancestors 'none'" in respuesta["Content-Security-Policy"]
    assert "object-src 'none'" in respuesta["Content-Security-Policy"]
    assert "camera=()" in respuesta["Permissions-Policy"]
    assert respuesta["X-Frame-Options"] == "DENY"
    assert respuesta["X-Content-Type-Options"] == "nosniff"


def test_la_api_y_las_paginas_con_sesion_no_quedan_en_cache(client):
    paciente = PacienteFactory()
    client.force_login(paciente.usuario)
    for url in ("/api/auth/yo/", "/paciente/"):
        respuesta = client.get(url)
        assert "no-store" in respuesta["Cache-Control"], url
        assert "private" in respuesta["Cache-Control"], url


def test_la_sesion_dura_una_jornada_y_no_la_lee_javascript():
    assert settings.SESSION_COOKIE_AGE == 8 * 3600
    assert settings.SESSION_COOKIE_HTTPONLY is True


def test_un_correo_sin_cuenta_se_frena_igual_que_uno_con_cuenta(api_client):
    """Si solo se frenaran los correos que existen, probando se sabría cuáles son pacientes.
    Con la huella en vez del correo, los fallos de un correo sin cuenta se siguen contando."""
    existente = PacienteFactory().usuario.email
    _fallar(api_client, existente, MAX_POR_CORREO)
    _fallar(api_client, "nadie@correo.cl", MAX_POR_CORREO)
    assert _login(api_client, existente, "incorrecta").status_code == 429
    assert _login(api_client, "nadie@correo.cl", "incorrecta").status_code == 429
