"""Verificación en dos pasos opcional para pacientes y podólogos (apps/cuentas/dos_pasos.py).

El código TOTP es de un solo uso por intervalo (django-otp rechaza repetirlo): las pruebas que
entran después de activar usan un dispositivo creado aparte o un código de respaldo.
"""

import pytest
from django.contrib.auth import authenticate
from django.core import mail
from django.core.exceptions import ValidationError
from django.test import Client
from django.urls import reverse
from django_otp.oath import totp
from django_otp.plugins.otp_totp.models import TOTPDevice

from apps.auditoria.models import RegistroAuditoria
from apps.cuentas import dos_pasos
from apps.cuentas.bloqueo import MAX_POR_CORREO
from apps.cuentas.models import CodigoRespaldo

from .factories import CLAVE, PacienteFactory, ProfesionalFactory

pytestmark = pytest.mark.django_db
SITIO = "https://mypodo.example"
Accion = RegistroAuditoria.Accion


def _codigo(disp) -> str:
    return str(totp(disp.bin_key, disp.step, disp.t0, disp.digits)).zfill(disp.digits)


def _con_2fa(usuario):
    """Cuenta con la verificación ya activa y sus códigos de respaldo."""
    disp = dos_pasos.preparar(usuario)
    codigos = dos_pasos.confirmar(usuario, codigo=_codigo(disp), sitio=SITIO)
    disp.refresh_from_db()
    disp.last_t = -1  # permite volver a usar el código del intervalo actual en la prueba
    disp.save(update_fields=["last_t"])
    mail.outbox.clear()
    return disp, codigos


def _entrar(email, clave=CLAVE, **extra):
    cliente = Client()
    respuesta = cliente.post(
        reverse("web:entrar"), {"accion": "entrar", "email": email, "password": clave, **extra}
    )
    return cliente, respuesta


# --- servicio ---


def test_un_codigo_incorrecto_no_activa_la_verificacion():
    usuario = PacienteFactory().usuario
    dos_pasos.preparar(usuario)
    with pytest.raises(ValidationError):
        dos_pasos.confirmar(usuario, codigo="000000x", sitio=SITIO)
    assert not dos_pasos.activa(usuario)


def test_activar_entrega_10_codigos_que_no_se_guardan_en_texto():
    usuario = PacienteFactory().usuario
    disp = dos_pasos.preparar(usuario)
    codigos = dos_pasos.confirmar(usuario, codigo=_codigo(disp), sitio=SITIO)
    assert dos_pasos.activa(usuario)
    assert len(codigos) == len(set(codigos)) == 10
    huellas = set(CodigoRespaldo.objects.filter(usuario=usuario).values_list("huella", flat=True))
    assert not huellas & set(codigos)
    assert RegistroAuditoria.objects.filter(accion=Accion.ACTIVAR_2FA, usuario=usuario).exists()
    assert mail.outbox[-1].subject == "Activaste la verificación en dos pasos en MyPodo"


def test_un_codigo_de_respaldo_sirve_una_sola_vez():
    usuario = PacienteFactory().usuario
    _, codigos = _con_2fa(usuario)
    assert dos_pasos.verificar(usuario, codigos[0].upper()) is not None
    assert dos_pasos.verificar(usuario, codigos[0]) is None
    assert dos_pasos.codigos_disponibles(usuario) == 9
    assert RegistroAuditoria.objects.filter(
        accion=Accion.USAR_CODIGO_RESPALDO, usuario=usuario
    ).exists()


def test_generar_codigos_nuevos_invalida_los_anteriores_y_pide_la_clave():
    usuario = PacienteFactory().usuario
    _, viejos = _con_2fa(usuario)
    with pytest.raises(ValidationError):
        dos_pasos.regenerar_codigos(usuario, clave="otra-cosa")
    nuevos = dos_pasos.regenerar_codigos(usuario, clave=CLAVE)
    assert dos_pasos.verificar(usuario, viejos[0]) is None
    assert dos_pasos.verificar(usuario, nuevos[0]) is not None


def test_desactivar_pide_la_clave_y_borra_todo():
    usuario = PacienteFactory().usuario
    _con_2fa(usuario)
    with pytest.raises(ValidationError):
        dos_pasos.desactivar(usuario, clave="otra-cosa", sitio=SITIO)
    assert dos_pasos.activa(usuario)
    dos_pasos.desactivar(usuario, clave=CLAVE, sitio=SITIO)
    assert not dos_pasos.activa(usuario)
    assert not TOTPDevice.objects.filter(user=usuario).exists()
    assert not CodigoRespaldo.objects.filter(usuario=usuario).exists()
    assert mail.outbox[-1].subject == "Desactivaste la verificación en dos pasos en MyPodo"


# --- login web ---


def test_sin_verificacion_se_entra_como_siempre():
    paciente = PacienteFactory()
    _, respuesta = _entrar(paciente.usuario.email)
    assert respuesta.url == reverse("web:paciente-inicio")


def test_con_verificacion_la_clave_sola_no_abre_la_sesion():
    paciente = PacienteFactory()
    _con_2fa(paciente.usuario)
    cliente, respuesta = _entrar(paciente.usuario.email)
    assert respuesta.url == reverse("web:entrar-codigo")
    assert cliente.get(reverse("web:paciente-inicio")).status_code == 302
    assert "Escribe tu código" in cliente.get(reverse("web:entrar-codigo")).content.decode()


def test_con_el_codigo_de_la_app_entra_y_vuelve_a_la_pagina_pedida():
    paciente = PacienteFactory()
    disp, _ = _con_2fa(paciente.usuario)
    cliente, _ = _entrar(paciente.usuario.email, next="/paciente/citas/")
    respuesta = cliente.post(reverse("web:entrar-codigo"), {"codigo": _codigo(disp)})
    assert respuesta.url == "/paciente/citas/"
    assert cliente.get(reverse("web:paciente-inicio")).status_code == 200
    assert RegistroAuditoria.objects.filter(accion=Accion.LOGIN, usuario=paciente.usuario).exists()


def test_con_un_codigo_de_respaldo_tambien_entra():
    profesional = ProfesionalFactory()
    _, codigos = _con_2fa(profesional.usuario)
    cliente, _ = _entrar(profesional.usuario.email)
    respuesta = cliente.post(reverse("web:entrar-codigo"), {"codigo": codigos[3]})
    assert respuesta.url == reverse("web:podologo-inicio")


def test_un_codigo_incorrecto_no_entra_y_cuenta_como_intento_fallido():
    paciente = PacienteFactory()
    _con_2fa(paciente.usuario)
    cliente, _ = _entrar(paciente.usuario.email)
    respuesta = cliente.post(reverse("web:entrar-codigo"), {"codigo": "zzzzz-zzzzz"})
    assert respuesta.status_code == 400
    assert cliente.get(reverse("web:paciente-inicio")).status_code == 302
    assert RegistroAuditoria.objects.filter(
        accion=Accion.LOGIN_FALLIDO, usuario=paciente.usuario
    ).exists()


def test_los_codigos_incorrectos_activan_el_freno_de_la_cuenta():
    paciente = PacienteFactory()
    disp, _ = _con_2fa(paciente.usuario)
    for _ in range(MAX_POR_CORREO):
        cliente, _ = _entrar(paciente.usuario.email)
        cliente.post(reverse("web:entrar-codigo"), {"codigo": "zzzzz-zzzzz"})
    # Ya frenada: ni la contraseña correcta deja pasar al segundo paso.
    _, respuesta = _entrar(paciente.usuario.email)
    assert respuesta.status_code == 400
    assert "Demasiados intentos" in respuesta.content.decode()


def test_sin_haber_puesto_la_clave_no_se_puede_pedir_el_codigo():
    respuesta = Client().get(reverse("web:entrar-codigo"))
    assert respuesta.url == reverse("web:entrar")


# --- API ---


def test_la_api_pide_el_codigo_y_lo_acepta(api_client):
    paciente = PacienteFactory()
    disp, _ = _con_2fa(paciente.usuario)
    datos = {"email": paciente.usuario.email, "password": CLAVE}
    sin_codigo = api_client.post("/api/auth/login/", datos, format="json")
    assert sin_codigo.status_code == 401
    assert sin_codigo.json()["requiere_codigo"] is True
    con_codigo = api_client.post(
        "/api/auth/login/", {**datos, "codigo": _codigo(disp)}, format="json"
    )
    assert con_codigo.status_code == 200


# --- Mi perfil ---


def test_activar_desde_el_perfil_muestra_el_qr_y_luego_los_codigos():
    paciente = PacienteFactory()
    cliente = Client()
    cliente.force_login(paciente.usuario)
    pagina = cliente.get(reverse("web:dos-pasos-activar")).content.decode()
    assert "Código QR para registrar MyPodo" in pagina
    disp = TOTPDevice.objects.get(user=paciente.usuario, confirmed=False)
    respuesta = cliente.post(reverse("web:dos-pasos-activar"), {"codigo": _codigo(disp)})
    assert respuesta.status_code == 200
    contenido = respuesta.content.decode()
    assert "no se volverán a mostrar" in contenido
    assert contenido.count("<li>") >= 10
    perfil = cliente.get(reverse("web:paciente-perfil")).content.decode()
    assert "Te quedan <strong>10</strong> códigos de respaldo" in perfil


def test_desactivar_desde_el_perfil_con_la_clave_equivocada_no_hace_nada():
    paciente = PacienteFactory()
    _con_2fa(paciente.usuario)
    cliente = Client()
    cliente.force_login(paciente.usuario)
    cliente.post(reverse("web:dos-pasos-desactivar"), {"clave": "otra-cosa"})
    assert dos_pasos.activa(paciente.usuario)
    cliente.post(reverse("web:dos-pasos-desactivar"), {"clave": CLAVE})
    assert not dos_pasos.activa(paciente.usuario)
    assert authenticate(username=paciente.usuario.email, password=CLAVE) == paciente.usuario


def test_el_inicio_del_podologo_recomienda_activarla_hasta_que_lo_hace():
    profesional = ProfesionalFactory()
    cliente = Client()
    cliente.force_login(profesional.usuario)
    assert 'id="aviso-dos-pasos"' in cliente.get(reverse("web:podologo-inicio")).content.decode()
    _con_2fa(profesional.usuario)
    assert (
        'id="aviso-dos-pasos"' not in cliente.get(reverse("web:podologo-inicio")).content.decode()
    )
