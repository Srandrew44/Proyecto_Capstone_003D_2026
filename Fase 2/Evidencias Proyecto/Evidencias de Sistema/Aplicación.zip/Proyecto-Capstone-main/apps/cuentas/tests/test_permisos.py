from types import SimpleNamespace

import pytest

from apps.clinica.models import Consentimiento
from apps.cuentas.permissions import EsDuenoDelRecurso, EsPaciente, EsProfesional

from .factories import PacienteFactory, ProfesionalFactory, UsuarioFactory

pytestmark = pytest.mark.django_db


def _peticion(usuario):
    return SimpleNamespace(user=usuario)


def test_es_paciente_acepta_solo_pacientes_con_perfil():
    paciente = PacienteFactory()
    profesional = ProfesionalFactory()
    sin_perfil = UsuarioFactory(rol="paciente")
    permiso = EsPaciente()
    assert permiso.has_permission(_peticion(paciente.usuario), None)
    assert not permiso.has_permission(_peticion(profesional.usuario), None)
    assert not permiso.has_permission(_peticion(sin_perfil), None)


def test_es_profesional_acepta_solo_al_profesional():
    paciente = PacienteFactory()
    profesional = ProfesionalFactory()
    permiso = EsProfesional()
    assert permiso.has_permission(_peticion(profesional.usuario), None)
    assert not permiso.has_permission(_peticion(paciente.usuario), None)


def test_usuario_inactivo_pierde_el_acceso():
    paciente = PacienteFactory(usuario__is_active=False)
    assert not EsPaciente().has_permission(_peticion(paciente.usuario), None)


def test_es_dueno_del_recurso_distingue_pacientes():
    a, b = PacienteFactory(), PacienteFactory()
    consentimiento = Consentimiento(paciente=a, tipo="uso_chatbot", version_texto="v1")
    permiso = EsDuenoDelRecurso()
    assert permiso.has_object_permission(_peticion(a.usuario), None, consentimiento)
    assert not permiso.has_object_permission(_peticion(b.usuario), None, consentimiento)
