from datetime import date
from functools import cache

import factory
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password

from apps.cuentas.models import Paciente, Profesional
from apps.cuentas.rut import calcular_dv

CLAVE = "ClaveSegura-123"


@cache
def _hash_de_la_clave() -> str:
    """Argon2 es lento a propósito: se calcula una sola vez y se reutiliza en todas las pruebas."""
    return make_password(CLAVE)


def _rut_valido(n: int) -> str:
    cuerpo = 10_000_000 + n
    return f"{cuerpo}-{calcular_dv(cuerpo)}"


class UsuarioFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = get_user_model()

    email = factory.Sequence(lambda n: f"usuario{n}@example.com")
    nombre = "Nombre"
    apellido = "Apellido"
    # El hash va como atributo normal: así se guarda en la base y el login de las pruebas funciona.
    password = factory.LazyFunction(_hash_de_la_clave)


class PacienteFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Paciente

    usuario = factory.SubFactory(UsuarioFactory, rol="paciente")
    rut = factory.Sequence(_rut_valido)
    fecha_nacimiento = date(1980, 5, 17)
    direccion = "Av. Providencia 1234, depto 56"
    comuna = "Providencia"
    actividad = "Contadora"
    telefono_contacto = "+56987654321"


class ProfesionalFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Profesional

    usuario = factory.SubFactory(UsuarioFactory, rol="profesional")
    especialidad = "Podología clínica"
