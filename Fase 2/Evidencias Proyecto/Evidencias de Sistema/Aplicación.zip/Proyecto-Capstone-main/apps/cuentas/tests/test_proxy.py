"""Freno de login y límite de registros detrás del proxy de Render (PROXIES_DE_CONFIANZA).

Detrás del proxy todos llegan con la misma REMOTE_ADDR. Si el freno contara esa IP, 30
fallos de cualquiera dejarían sin entrar a todos; si contara la cabecera completa, bastaría
cambiarla para evadirlo. Ambos usan ip_de: la IP que agregó el proxy.
"""

import pytest
from django.conf import settings as ajustes
from django.test import Client
from django.urls import reverse

from apps.auditoria.models import RegistroAuditoria
from apps.cuentas.bloqueo import MAX_POR_IP

from .factories import CLAVE, PacienteFactory

pytestmark = pytest.mark.django_db
PROXY = "10.0.0.5"
LOGIN = "/api/auth/login/"
REGISTRO = "/api/auth/registro/"
FALLIDO = RegistroAuditoria.Accion.LOGIN_FALLIDO
MAXIMO_REGISTROS = int(ajustes.REST_FRAMEWORK["DEFAULT_THROTTLE_RATES"]["registro"].split("/")[0])


@pytest.fixture
def detras_de_render(settings):
    settings.PROXIES_DE_CONFIANZA = 1


def _login(cliente, email, clave, xff):
    return cliente.post(
        LOGIN,
        {"email": email, "password": clave},
        format="json",
        REMOTE_ADDR=PROXY,
        HTTP_X_FORWARDED_FOR=xff,
    )


# --- freno de login ---


def test_fallos_de_otros_clientes_no_frenan_a_un_usuario_legitimo(detras_de_render, api_client):
    email = PacienteFactory().usuario.email
    for n in range(MAX_POR_IP):
        respuesta = _login(api_client, f"atacante{n}@example.com", "nada", f"203.0.113.{n}")
        assert respuesta.status_code == 401
    assert _login(api_client, email, CLAVE, "198.51.100.20").status_code == 200


def test_un_atacante_no_evade_el_freno_por_ip_falseando_la_cabecera(detras_de_render, api_client):
    email = PacienteFactory().usuario.email
    for n in range(MAX_POR_IP):
        # Lo que el cliente escribe queda a la izquierda; el proxy agrega su IP real al final.
        _login(api_client, f"otro{n}@example.com", "nada", f"6.6.6.{n}, 198.51.100.7")
    assert _login(api_client, email, CLAVE, "1.1.1.1, 198.51.100.7").status_code == 429
    # Otro cliente detrás del mismo proxy sigue entrando.
    assert _login(api_client, email, CLAVE, "198.51.100.8").status_code == 200


def test_la_auditoria_guarda_la_ip_real_y_no_la_del_proxy(detras_de_render, api_client):
    _login(api_client, "nadie@example.com", "nada", "6.6.6.6, 198.51.100.7")
    assert RegistroAuditoria.objects.get(accion=FALLIDO).ip == "198.51.100.7"


def test_el_login_del_sitio_tambien_usa_la_ip_real(detras_de_render):
    cliente = Client(REMOTE_ADDR=PROXY)
    for n in range(MAX_POR_IP):
        cliente.post(
            reverse("web:entrar"),
            {"email": f"atacante{n}@example.com", "password": "nada"},
            HTTP_X_FORWARDED_FOR=f"203.0.113.{n}",
        )
    email = PacienteFactory().usuario.email
    respuesta = cliente.post(
        reverse("web:entrar"),
        {"email": email, "password": CLAVE},
        HTTP_X_FORWARDED_FOR="198.51.100.20",
    )
    assert respuesta.status_code == 302
    assert "_auth_user_id" in cliente.session


# --- límite de registros (API) ---


def _registrar_api(cliente, xff=None, remota="192.0.2.1"):
    extra = {"REMOTE_ADDR": remota}
    if xff is not None:
        extra["HTTP_X_FORWARDED_FOR"] = xff
    return cliente.post(REGISTRO, {}, format="json", **extra)


def test_en_local_cambiar_la_cabecera_no_evade_el_limite_de_registros(api_client):
    """Sin proxies de confianza cuenta REMOTE_ADDR, diga lo que diga X-Forwarded-For."""
    for n in range(MAXIMO_REGISTROS):
        assert _registrar_api(api_client, f"7.7.7.{n}").status_code == 400
    assert _registrar_api(api_client, "7.7.7.250").status_code == 429


def test_en_local_el_limite_de_registros_sigue_funcionando(api_client):
    for _ in range(MAXIMO_REGISTROS):
        assert _registrar_api(api_client).status_code == 400
    assert _registrar_api(api_client).status_code == 429
    assert _registrar_api(api_client, remota="192.0.2.2").status_code == 400


def test_detras_del_proxy_el_limite_cuenta_la_ip_real(detras_de_render, api_client):
    for n in range(MAXIMO_REGISTROS):
        respuesta = _registrar_api(api_client, f"7.7.7.{n}, 198.51.100.7", remota=PROXY)
        assert respuesta.status_code == 400
    assert _registrar_api(api_client, "8.8.8.8, 198.51.100.7", remota=PROXY).status_code == 429
    # Otro cliente real, detrás del mismo proxy, tiene su propio cupo.
    assert _registrar_api(api_client, "198.51.100.8", remota=PROXY).status_code == 400


# --- límite de registros (sitio) ---

DEMASIADOS = "demasiados registros"


def _registrar_web(cliente, xff):
    return cliente.post(reverse("web:entrar"), {"accion": "registro"}, HTTP_X_FORWARDED_FOR=xff)


def test_el_registro_del_sitio_no_se_evade_rotando_la_cabecera_en_local():
    cliente = Client(REMOTE_ADDR="192.0.2.1")
    for n in range(MAXIMO_REGISTROS):
        assert DEMASIADOS not in _registrar_web(cliente, f"7.7.7.{n}").content.decode()
    assert DEMASIADOS in _registrar_web(cliente, "7.7.7.250").content.decode()


def test_el_registro_del_sitio_cuenta_la_ip_real_detras_del_proxy(detras_de_render):
    cliente = Client(REMOTE_ADDR=PROXY)
    for n in range(MAXIMO_REGISTROS):
        respuesta = _registrar_web(cliente, f"7.7.7.{n}, 198.51.100.7")
        assert DEMASIADOS not in respuesta.content.decode()
    assert DEMASIADOS in _registrar_web(cliente, "1.1.1.1, 198.51.100.7").content.decode()
    assert DEMASIADOS not in _registrar_web(cliente, "198.51.100.8").content.decode()


def test_el_login_por_api_tiene_un_limite_por_ip_aunque_las_claves_sean_correctas(api_client):
    """Además del freno por fallos: nadie prueba cuentas en masa desde una misma conexión."""
    maximo = int(ajustes.REST_FRAMEWORK["DEFAULT_THROTTLE_RATES"]["login"].split("/")[0])
    email = PacienteFactory().usuario.email
    for _ in range(maximo):
        assert _login(api_client, email, CLAVE, "198.51.100.30").status_code == 200
    assert _login(api_client, email, CLAVE, "198.51.100.30").status_code == 429
