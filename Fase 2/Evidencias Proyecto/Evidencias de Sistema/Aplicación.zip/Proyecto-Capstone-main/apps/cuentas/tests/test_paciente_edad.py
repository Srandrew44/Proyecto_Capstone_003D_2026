from datetime import date

import pytest
from django.utils import timezone

from .factories import PacienteFactory

pytestmark = pytest.mark.django_db


@pytest.mark.parametrize(
    ("nacimiento", "fecha", "esperada"),
    [
        (date(1980, 5, 17), date(2030, 5, 16), 49),  # un día antes del cumpleaños
        (date(1980, 5, 17), date(2030, 5, 17), 50),  # el día del cumpleaños
        (date(1980, 5, 17), date(2030, 12, 31), 50),
        (date(1980, 5, 17), date(1980, 5, 17), 0),
        (date(2000, 2, 29), date(2001, 2, 28), 0),  # nacido un 29 de febrero
        (date(2000, 2, 29), date(2001, 3, 1), 1),
    ],
)
def test_la_edad_se_calcula_desde_la_fecha_de_nacimiento(nacimiento, fecha, esperada):
    paciente = PacienteFactory(fecha_nacimiento=nacimiento)
    assert paciente.edad_al(fecha) == esperada


def test_la_edad_de_quien_nacio_hoy_es_cero():
    paciente = PacienteFactory(fecha_nacimiento=timezone.localdate())
    assert paciente.edad == 0
