"""Recuperar la contraseña por correo: enlace de un solo uso, sin revelar si la cuenta existe."""

import re

import pytest
from django.contrib.auth import authenticate
from django.core import mail
from django.test import Client
from django.urls import reverse

from apps.auditoria.models import RegistroAuditoria

from .factories import CLAVE, PacienteFactory, ProfesionalFactory

pytestmark = pytest.mark.django_db
NUEVA = "Hojas-de-Otono-2026"
AVISO = "Si el correo tiene una cuenta en MyPodo, te enviamos un enlace"


def _pedir(email, cliente=None):
    return (cliente or Client()).post(reverse("web:recuperar"), {"email": email})


def _enlace(correo) -> str:
    return re.search(r"https?://testserver(/recuperar/[^/\s]+/[^/\s]+/)", correo.body).group(1)


def test_entrar_ofrece_recuperar_la_contrasena():
    assert reverse("web:recuperar") in Client().get(reverse("web:entrar")).content.decode()


def test_un_correo_sin_cuenta_recibe_la_misma_respuesta_y_ningun_correo():
    respuesta = _pedir("nadie@example.com")
    assert respuesta.status_code == 200
    assert AVISO in respuesta.content.decode()
    assert mail.outbox == []


def test_una_cuenta_activa_recibe_el_enlace():
    paciente = PacienteFactory()
    respuesta = _pedir(paciente.usuario.email.upper())
    assert AVISO in respuesta.content.decode()
    assert len(mail.outbox) == 1
    assert mail.outbox[0].to == [paciente.usuario.email]
    assert "60 minutos" in mail.outbox[0].body


def test_una_cuenta_dada_de_baja_no_recibe_el_enlace():
    paciente = PacienteFactory(usuario__is_active=False)
    _pedir(paciente.usuario.email)
    assert mail.outbox == []


def test_no_se_manda_mas_de_un_enlace_cada_5_minutos():
    paciente = PacienteFactory()
    _pedir(paciente.usuario.email)
    _pedir(paciente.usuario.email)
    assert len(mail.outbox) == 1


def test_el_enlace_cambia_la_contrasena_y_avisa_por_correo():
    paciente = PacienteFactory()
    _pedir(paciente.usuario.email)
    enlace = _enlace(mail.outbox[0])
    assert Client().get(enlace).status_code == 200
    respuesta = Client().post(enlace, {"nueva": NUEVA, "repetir": NUEVA})
    assert respuesta.status_code == 302
    assert respuesta.url == reverse("web:entrar")
    usuario = paciente.usuario
    assert authenticate(username=usuario.email, password=NUEVA) == usuario
    assert authenticate(username=usuario.email, password=CLAVE) is None
    assert RegistroAuditoria.objects.filter(
        accion=RegistroAuditoria.Accion.RESTABLECER_CLAVE, usuario=usuario
    ).exists()
    assert mail.outbox[-1].subject == "Tu contraseña de MyPodo cambió"


def test_el_enlace_sirve_una_sola_vez():
    paciente = PacienteFactory()
    _pedir(paciente.usuario.email)
    enlace = _enlace(mail.outbox[0])
    Client().post(enlace, {"nueva": NUEVA, "repetir": NUEVA})
    otra = "Otra-Clave-Segura-77"
    respuesta = Client().post(enlace, {"nueva": otra, "repetir": otra})
    assert respuesta.status_code == 400
    assert authenticate(username=paciente.usuario.email, password=otra) is None


def test_un_enlace_inventado_no_sirve():
    paciente = PacienteFactory()
    respuesta = Client().get(f"/recuperar/{paciente.usuario.pk}/token-falso/")
    assert respuesta.status_code == 400


def test_las_contrasenas_deben_coincidir_y_ser_seguras():
    paciente = PacienteFactory()
    _pedir(paciente.usuario.email)
    enlace = _enlace(mail.outbox[0])
    distintas = Client().post(enlace, {"nueva": NUEVA, "repetir": NUEVA + "x"})
    assert distintas.status_code == 400
    assert "no coinciden" in distintas.content.decode()
    corta = Client().post(enlace, {"nueva": "corta-123", "repetir": "corta-123"})
    assert corta.status_code == 400
    assert authenticate(username=paciente.usuario.email, password=CLAVE) == paciente.usuario


def test_al_restablecerla_se_cierran_las_sesiones_abiertas():
    profesional = ProfesionalFactory()
    abierta = Client()
    abierta.force_login(profesional.usuario)
    assert abierta.get(reverse("web:podologo-inicio")).status_code == 200
    _pedir(profesional.usuario.email)
    Client().post(_enlace(mail.outbox[0]), {"nueva": NUEVA, "repetir": NUEVA})
    assert abierta.get(reverse("web:podologo-inicio")).status_code == 302


def test_cambiar_la_contrasena_desde_el_perfil_tambien_avisa_por_correo():
    paciente = PacienteFactory()
    cliente = Client()
    cliente.force_login(paciente.usuario)
    datos = {"accion": "clave", "actual": CLAVE, "nueva": NUEVA, "repetida": NUEVA}
    cliente.post(reverse("web:paciente-perfil"), datos)
    assert authenticate(username=paciente.usuario.email, password=NUEVA) == paciente.usuario
    assert mail.outbox[-1].subject == "Tu contraseña de MyPodo cambió"
