"""Permisos de acceso por rol y por propiedad del recurso.

Convención: un modelo que pertenece a un usuario implementa ``es_de(usuario) -> bool``.
EsDuenoDelRecurso lo usa; así cada app decide qué significa "ser dueño" de sus datos.
"""

from rest_framework.permissions import BasePermission

from .models import Paciente, Profesional, Usuario


def _usuario_activo(request):
    usuario = request.user
    return usuario if usuario and usuario.is_authenticated and usuario.is_active else None


class EsPaciente(BasePermission):
    message = "Solo disponible para pacientes."

    def has_permission(self, request, view):
        usuario = _usuario_activo(request)
        return bool(
            usuario
            and usuario.rol == Usuario.Rol.PACIENTE
            and Paciente.objects.filter(pk=usuario.pk).exists()
        )


class EsProfesional(BasePermission):
    message = "Solo disponible para el profesional."

    def has_permission(self, request, view):
        usuario = _usuario_activo(request)
        return bool(
            usuario
            and usuario.rol == Usuario.Rol.PROFESIONAL
            and Profesional.objects.filter(pk=usuario.pk).exists()
        )


class EsDuenoDelRecurso(BasePermission):
    message = "No tienes acceso a este recurso."

    def has_object_permission(self, request, view, obj):
        usuario = _usuario_activo(request)
        return bool(usuario and obj.es_de(usuario))


class EsProfesionalOAdministrador(BasePermission):
    """Para vistas de gestión: el profesional ve lo suyo y el administrador, todo."""

    message = "Solo disponible para profesionales y administradores."

    def has_permission(self, request, view):
        usuario = _usuario_activo(request)
        if usuario and usuario.rol == Usuario.Rol.ADMIN:
            return True
        return EsProfesional().has_permission(request, view)
