"""Verificación en dos pasos (código de una app de autenticación) para cualquier cuenta.

Obligatoria para entrar al panel /admin/ (config/admin.py) y opcional, desde "Mi perfil", para
pacientes y podólogos. Usa el dispositivo TOTP de django-otp; además entrega 10 códigos de
respaldo de un solo uso por si se pierde el teléfono.
"""

import base64
import hashlib
import secrets

import qrcode
import qrcode.image.svg
from django.core.exceptions import ValidationError
from django.db import transaction
from django.urls import reverse
from django.utils import timezone
from django_otp.plugins.otp_totp.models import TOTPDevice

from apps.auditoria.models import RegistroAuditoria
from apps.auditoria.services import registrar

from . import correos
from .models import CodigoRespaldo

CANTIDAD_CODIGOS = 10
# Sin letras que se confundan (0/o, 1/l/i): se escriben a mano desde un papel.
ALFABETO = "abcdefghjkmnpqrstuvwxyz23456789"
NOMBRE_DISPOSITIVO = "App de autenticación"


def dispositivo(usuario) -> TOTPDevice | None:
    """El dispositivo confirmado de la cuenta, si la verificación está activa."""
    return TOTPDevice.objects.filter(user=usuario, confirmed=True).first()


def activa(usuario) -> bool:
    return usuario.is_authenticated and dispositivo(usuario) is not None


def preparar(usuario) -> TOTPDevice:
    """Dispositivo sin confirmar para mostrar el QR (el mismo si se recarga la página)."""
    return TOTPDevice.objects.filter(
        user=usuario, confirmed=False
    ).first() or TOTPDevice.objects.create(user=usuario, name=NOMBRE_DISPOSITIVO, confirmed=False)


def qr_svg(disp: TOTPDevice) -> str:
    imagen = qrcode.make(disp.config_url, image_factory=qrcode.image.svg.SvgPathImage, box_size=8)
    return imagen.to_string(encoding="unicode")


def clave_texto(disp: TOTPDevice) -> str:
    """La clave en base32, para escribirla a mano en la app si no se puede escanear el QR."""
    return base64.b32encode(disp.bin_key).decode()


def _normalizar(codigo: str) -> str:
    return "".join(str(codigo or "").split()).lower()


def _huella(codigo: str) -> str:
    return hashlib.sha256(_normalizar(codigo).replace("-", "").encode()).hexdigest()


def _nuevos_codigos(usuario) -> list[str]:
    CodigoRespaldo.objects.filter(usuario=usuario).delete()
    codigos = []
    for _ in range(CANTIDAD_CODIGOS):
        crudo = "".join(secrets.choice(ALFABETO) for _ in range(10))
        codigos.append(f"{crudo[:5]}-{crudo[5:]}")
    CodigoRespaldo.objects.bulk_create(
        CodigoRespaldo(usuario=usuario, huella=_huella(c)) for c in codigos
    )
    return codigos


def codigos_disponibles(usuario) -> int:
    return CodigoRespaldo.objects.filter(usuario=usuario, usado_en__isnull=True).count()


def _exigir_clave(usuario, clave: str) -> None:
    if not usuario.check_password(clave or ""):
        raise ValidationError({"clave": ["La contraseña no es correcta."]})


def confirmar(usuario, *, codigo: str, sitio: str, ip=None) -> list[str]:
    """Confirma la app con un código y devuelve los códigos de respaldo (se muestran una vez)."""
    disp = TOTPDevice.objects.filter(user=usuario, confirmed=False).first()
    codigo = _normalizar(codigo)
    if disp is None or not codigo.isdigit() or not disp.verify_token(codigo):
        raise ValidationError(
            {"codigo": ["El código no es correcto o ya cambió. Escribe el que muestra la app."]}
        )
    with transaction.atomic():
        TOTPDevice.objects.filter(user=usuario).exclude(pk=disp.pk).delete()
        disp.confirmed = True
        disp.save(update_fields=["confirmed"])
        codigos = _nuevos_codigos(usuario)
        registrar(
            accion=RegistroAuditoria.Accion.ACTIVAR_2FA,
            usuario=usuario,
            recurso_tipo="usuario",
            recurso_id=usuario.pk,
            ip=ip,
        )
    _avisar(
        usuario, "Activaste la verificación en dos pasos en MyPodo", "dos_pasos_activada", sitio
    )
    return codigos


def regenerar_codigos(usuario, *, clave: str) -> list[str]:
    """Códigos nuevos (los anteriores dejan de servir). Pide la contraseña."""
    _exigir_clave(usuario, clave)
    if not activa(usuario):
        raise ValidationError({"clave": ["La verificación en dos pasos no está activa."]})
    with transaction.atomic():
        return _nuevos_codigos(usuario)


def desactivar(usuario, *, clave: str, sitio: str, ip=None) -> None:
    _exigir_clave(usuario, clave)
    with transaction.atomic():
        TOTPDevice.objects.filter(user=usuario).delete()
        CodigoRespaldo.objects.filter(usuario=usuario).delete()
        registrar(
            accion=RegistroAuditoria.Accion.DESACTIVAR_2FA,
            usuario=usuario,
            recurso_tipo="usuario",
            recurso_id=usuario.pk,
            ip=ip,
        )
    _avisar(
        usuario,
        "Desactivaste la verificación en dos pasos en MyPodo",
        "dos_pasos_desactivada",
        sitio,
    )


def verificar(usuario, codigo: str, *, ip=None) -> TOTPDevice | None:
    """El dispositivo si el código (de la app o de respaldo) es válido; si no, None.

    Un código de respaldo se gasta al usarlo. verify_token aplica además el freno propio de
    django-otp (tras cada fallo hay que esperar más).
    """
    disp = dispositivo(usuario)
    codigo = _normalizar(codigo)
    if disp is None or not codigo:
        return None
    if codigo.isdigit():
        return disp if disp.verify_token(codigo) else None
    gastados = CodigoRespaldo.objects.filter(
        usuario=usuario, huella=_huella(codigo), usado_en__isnull=True
    ).update(usado_en=timezone.now())
    if not gastados:
        return None
    registrar(
        accion=RegistroAuditoria.Accion.USAR_CODIGO_RESPALDO,
        usuario=usuario,
        recurso_tipo="usuario",
        recurso_id=usuario.pk,
        ip=ip,
        detalle={"quedan": codigos_disponibles(usuario)},
    )
    return disp


def _avisar(usuario, asunto, plantilla, sitio) -> None:
    correos.enviar(
        usuario.email,
        asunto,
        plantilla,
        {"nombre": usuario.nombre, "enlace_recuperar": sitio + reverse("web:recuperar")},
    )
