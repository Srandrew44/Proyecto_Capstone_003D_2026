"""Freno a quien intenta adivinar contraseñas, en la API y en el panel /admin/.

Cuenta los inicios de sesión fallidos que ya guarda la auditoría, así que no necesita caché
ni tablas nuevas y funciona igual con varios procesos. Un correo se bloquea tras
MAX_POR_CORREO fallos en VENTANA (exista o no la cuenta, para no revelar cuáles existen) y
una IP tras MAX_POR_IP. Los intentos hechos durante el bloqueo no lo alargan: así nadie
puede dejar a otra persona sin entrar indefinidamente.

Privacidad (decisión de Matías, 09/11/2026): la auditoría no guarda el correo escrito en
texto, porque acumulaba correos de personas sin cuenta. Guarda su huella (HMAC con la
SECRET_KEY), que sirve para contar los fallos de un mismo correo pero no se puede leer, y si
el correo es de una cuenta, el fallo queda ligado a esa cuenta (visible en el admin).
"""

import hashlib
import hmac
from datetime import timedelta

from django.conf import settings
from django.utils import timezone

from apps.auditoria.models import RegistroAuditoria

VENTANA = timedelta(minutes=15)
MAX_POR_CORREO = 5
MAX_POR_IP = 30


def normalizar_email(email) -> str:
    return str(email or "").strip().lower()[:254]


def huella_email(email) -> str:
    """Identifica un correo sin guardarlo: HMAC-SHA256 con la SECRET_KEY (32 caracteres)."""
    clave = settings.SECRET_KEY.encode()
    return hmac.new(clave, normalizar_email(email).encode(), hashlib.sha256).hexdigest()[:32]


def _fallos_desde(desde):
    # has_key y no `bloqueado=True`: en SQL, NOT sobre una clave ausente da NULL y excluiría
    # todos los fallos normales.
    return RegistroAuditoria.objects.filter(
        accion=RegistroAuditoria.Accion.LOGIN_FALLIDO, fecha__gte=desde
    ).exclude(detalle__has_key="bloqueado")


def esta_bloqueado(*, email, ip) -> bool:
    from .models import Usuario  # evita una importación circular con models

    email = normalizar_email(email)
    desde = timezone.now() - VENTANA
    if email:
        # Un inicio de sesión correcto reinicia la cuenta de fallos de ese correo.
        ultimo_login = (
            Usuario.objects.filter(email__iexact=email).values_list("last_login", flat=True).first()
        )
        desde_correo = max(desde, ultimo_login) if ultimo_login else desde
        fallos = _fallos_desde(desde_correo).filter(detalle__correo=huella_email(email))
        if fallos.count() >= MAX_POR_CORREO:
            return True
    return bool(ip) and _fallos_desde(desde).filter(ip=ip).count() >= MAX_POR_IP


def registrar_fallo(*, email, ip, bloqueado=False) -> None:
    from apps.auditoria.services import registrar

    from .models import Usuario

    email = normalizar_email(email)
    detalle = {"correo": huella_email(email)}
    if bloqueado:
        detalle["bloqueado"] = True
    cuenta = Usuario.objects.filter(email__iexact=email).first() if email else None
    registrar(accion=RegistroAuditoria.Accion.LOGIN_FALLIDO, usuario=cuenta, ip=ip, detalle=detalle)
