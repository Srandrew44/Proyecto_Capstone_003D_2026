"""Quita la verificación en dos pasos de una cuenta (p. ej. si perdió el teléfono).

La próxima vez que entre al panel se le mostrará un QR nuevo para registrar la app.
"""

from django.core.management.base import BaseCommand, CommandError
from django_otp.plugins.otp_totp.models import TOTPDevice

from apps.cuentas.models import CodigoRespaldo, Usuario


class Command(BaseCommand):
    help = "Quita la verificación en dos pasos de una cuenta (dispositivo y códigos de respaldo)."

    def add_arguments(self, parser):
        parser.add_argument("email")

    def handle(self, *args, email, **opciones):
        usuario = Usuario.objects.filter(email__iexact=email.strip()).first()
        if usuario is None:
            raise CommandError("No hay una cuenta con ese correo.")
        borrados, _ = TOTPDevice.objects.filter(user=usuario).delete()
        CodigoRespaldo.objects.filter(usuario=usuario).delete()
        self.stdout.write(
            self.style.SUCCESS(
                f"Listo: {borrados} dispositivo(s) quitados. La próxima vez verá un QR nuevo."
            )
        )
