"""Correos de la propia cuenta: confirmar el registro, recuperar la contraseña y avisos.

Salen al momento y no por la cola de notificaciones (apps.agenda.notificaciones), porque la
persona está esperando el enlace. Si el envío falla, queda en el registro de errores y la
pantalla dice lo mismo de siempre: nunca se revela si una cuenta existe.
"""

import logging

from django.conf import settings
from django.core.mail import send_mail
from django.template.loader import render_to_string

logger = logging.getLogger(__name__)


def enviar(destino: str, asunto: str, plantilla: str, contexto: dict) -> bool:
    contexto = {"consulta": settings.CONSULTA_NOMBRE, **contexto}
    cuerpo = render_to_string(f"cuentas/correos/{plantilla}.txt", contexto)
    try:
        send_mail(asunto, cuerpo, settings.DEFAULT_FROM_EMAIL, [destino])
    except Exception:  # cualquier fallo del proveedor: se registra, no se muestra
        logger.exception("No se pudo enviar el correo de cuenta «%s»", plantilla)
        return False
    return True
