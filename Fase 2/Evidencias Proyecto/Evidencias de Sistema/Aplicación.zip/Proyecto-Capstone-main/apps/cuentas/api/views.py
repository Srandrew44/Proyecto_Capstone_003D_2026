from django.core.exceptions import ValidationError as DjangoValidationError
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_protect, ensure_csrf_cookie
from rest_framework import serializers, status
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.cuentas import services
from apps.cuentas.throttling import LimitePorIp

from .serializers import LoginSerializer, RegistroPacienteSerializer, UsuarioSerializer


def a_error_drf(exc: DjangoValidationError) -> serializers.ValidationError:
    """Traduce un error de validación del servicio al formato de errores de la API."""
    detalle = exc.message_dict if hasattr(exc, "error_dict") else exc.messages
    return serializers.ValidationError(detalle)


# Las vistas sin sesión previa (CSRF, registro, login) quedan fuera de la comprobación CSRF
# automática de DRF, que solo actúa con usuarios autenticados. csrf_protect la exige igualmente.


@method_decorator(ensure_csrf_cookie, name="dispatch")
class CsrfView(APIView):
    """GET: entrega la cookie CSRF que el cliente debe reenviar en el encabezado X-CSRFToken."""

    authentication_classes = []
    permission_classes = [AllowAny]

    def get(self, request):
        return Response({"detail": "Cookie CSRF establecida."})


@method_decorator(csrf_protect, name="dispatch")
class RegistroPacienteView(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]
    # Limita los registros por IP: frena la creación masiva de cuentas y que se use el
    # formulario para averiguar qué correos o RUT ya son pacientes.
    throttle_classes = [LimitePorIp]
    throttle_scope = "registro"

    def post(self, request):
        serializer = RegistroPacienteSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            services.solicitar_registro(
                **serializer.validated_data, sitio=services.sitio_de(request)
            )
        except DjangoValidationError as exc:
            raise a_error_drf(exc) from exc
        # La cuenta se crea al abrir el enlace del correo. La respuesta es siempre la misma:
        # no revela si el correo o el RUT ya estaban registrados.
        return Response(
            {"detail": "Te enviamos un correo para confirmar la cuenta."},
            status=status.HTTP_202_ACCEPTED,
        )


@method_decorator(csrf_protect, name="dispatch")
class LoginView(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]
    # Por IP, además del freno por cuenta: frena probar muchas cuentas desde un mismo lugar.
    throttle_classes = [LimitePorIp]
    throttle_scope = "login"

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            usuario = services.iniciar_sesion(request, **serializer.validated_data)
        except services.AutenticacionFallida:
            # Mensaje único: no revela si el correo existe ni si la cuenta está inactiva.
            return Response(
                {"detail": "Correo o contraseña incorrectos."},
                status=status.HTTP_401_UNAUTHORIZED,
            )
        except services.DemasiadosIntentos:
            # El freno aplica igual a correos sin cuenta, así que tampoco revela si existe.
            return Response(
                {"detail": "Demasiados intentos fallidos. Espera 15 minutos y vuelve a intentar."},
                status=status.HTTP_429_TOO_MANY_REQUESTS,
            )
        except services.FaltaSegundoPaso:
            # Solo se sabe con la contraseña correcta: no revela nada a quien no la tiene.
            return Response(
                {
                    "detail": "Falta el código de verificación en dos pasos.",
                    "requiere_codigo": True,
                },
                status=status.HTTP_401_UNAUTHORIZED,
            )
        return Response(UsuarioSerializer(usuario).data)


class LogoutView(APIView):
    """POST con sesión: DRF exige el token CSRF por ser un usuario autenticado."""

    def post(self, request):
        services.cerrar_sesion(request)
        return Response(status=status.HTTP_204_NO_CONTENT)


class YoView(APIView):
    def get(self, request):
        return Response(UsuarioSerializer(request.user).data)
