from django.utils import timezone
from rest_framework import serializers

from apps.cuentas.models import Usuario


class UsuarioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Usuario
        fields = ["id", "email", "nombre", "apellido", "telefono", "rol"]
        read_only_fields = fields


class RegistroPacienteSerializer(serializers.Serializer):
    """Valida forma y tipos. Las reglas de negocio (RUT, clave, duplicados) van en el servicio."""

    email = serializers.EmailField(max_length=254)
    password = serializers.CharField(
        write_only=True, trim_whitespace=False, max_length=128, style={"input_type": "password"}
    )
    nombre = serializers.CharField(max_length=150)
    apellido = serializers.CharField(max_length=150)
    telefono = serializers.CharField(max_length=20)
    rut = serializers.CharField(max_length=15)
    fecha_nacimiento = serializers.DateField()
    direccion = serializers.CharField(max_length=255)
    comuna = serializers.CharField(max_length=100)
    actividad = serializers.CharField(max_length=100)
    telefono_contacto = serializers.CharField(max_length=20)

    def validate_fecha_nacimiento(self, valor):
        if valor > timezone.localdate():
            raise serializers.ValidationError("La fecha de nacimiento no puede ser futura.")
        return valor


class LoginSerializer(serializers.Serializer):
    email = serializers.CharField(max_length=254)
    password = serializers.CharField(write_only=True, trim_whitespace=False, max_length=128)
    # Solo para cuentas con verificación en dos pasos: el código de la app o uno de respaldo.
    codigo = serializers.CharField(required=False, allow_blank=True, max_length=20)


class PerfilPacienteSerializer(serializers.Serializer):
    """Datos de contacto que el paciente corrige él mismo (RF-027)."""

    telefono = serializers.CharField(max_length=20)
    telefono_contacto = serializers.CharField(max_length=20)
    direccion = serializers.CharField(max_length=255)
    comuna = serializers.CharField(max_length=100)
    actividad = serializers.CharField(max_length=100)


class PerfilProfesionalSerializer(serializers.Serializer):
    """Lo que el podólogo corrige él mismo: su teléfono y la presentación que ven los pacientes."""

    telefono = serializers.CharField(max_length=20, required=False, allow_blank=True)
    descripcion = serializers.CharField(max_length=1000, required=False, allow_blank=True)


class CambioClaveSerializer(serializers.Serializer):
    actual = serializers.CharField(trim_whitespace=False, max_length=128)
    nueva = serializers.CharField(trim_whitespace=False, max_length=128)
    repetida = serializers.CharField(trim_whitespace=False, max_length=128)

    def validate(self, datos):
        if datos["nueva"] != datos["repetida"]:
            raise serializers.ValidationError({"repetida": ["Las contraseñas no coinciden."]})
        return datos
