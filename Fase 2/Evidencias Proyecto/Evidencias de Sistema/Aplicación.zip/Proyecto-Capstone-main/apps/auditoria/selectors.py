"""Consultas de lectura de la app. Toda consulta debe filtrarse según el usuario que pregunta."""
