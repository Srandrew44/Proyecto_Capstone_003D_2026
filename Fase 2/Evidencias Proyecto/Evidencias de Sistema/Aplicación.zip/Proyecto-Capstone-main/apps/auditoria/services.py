"""Escritura del registro de auditoría. Es la capa más baja: no depende de otras apps."""

import ipaddress

from django.conf import settings

from .models import RegistroAuditoria


def ip_de(request) -> str | None:
    """IP real del cliente. La usan la auditoría, el freno de login y el límite de registros.

    Sin proxies de confianza (PROXIES_DE_CONFIANZA=0, el caso local) es REMOTE_ADDR: así nadie
    falsea su IP mandando X-Forwarded-For. Detrás de N proxies (Render: 3), REMOTE_ADDR es la
    del último proxy y la compartirían todos los usuarios, así que se toma la entrada N
    contando desde la DERECHA de X-Forwarded-For: cada proxy agrega ahí la IP que lo
    contactó, y esas entradas no las controla el cliente. La entrada más a la izquierda sí
    la escribe el cliente y nunca se usa. Si la cabecera no tiene las entradas que agregan
    los proxies, o la elegida no es una IP, se vuelve a REMOTE_ADDR: en el peor caso todos
    comparten la IP del proxy (como antes), pero nunca se confía en una IP inventada.
    """
    remota = request.META.get("REMOTE_ADDR") or None
    proxies = getattr(settings, "PROXIES_DE_CONFIANZA", 0)
    if proxies <= 0:
        return remota
    cabecera = request.META.get("HTTP_X_FORWARDED_FOR", "")
    entradas = [entrada.strip() for entrada in cabecera.split(",") if entrada.strip()]
    if len(entradas) < proxies:
        return remota
    try:
        return str(ipaddress.ip_address(entradas[-proxies]))
    except ValueError:
        return remota


def registrar(
    *,
    accion,
    usuario=None,
    recurso_tipo="",
    recurso_id=None,
    ip=None,
    detalle=None,
) -> RegistroAuditoria:
    """Agrega un registro. ``detalle`` no debe incluir datos clínicos ni credenciales."""
    if usuario is not None and not getattr(usuario, "is_authenticated", False):
        usuario = None
    return RegistroAuditoria.objects.create(
        usuario=usuario,
        accion=accion,
        recurso_tipo=recurso_tipo,
        recurso_id=recurso_id,
        ip=ip,
        detalle=detalle or {},
    )
