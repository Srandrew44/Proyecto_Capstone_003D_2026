import uuid

from django.conf import settings
from django.db import models
from django.utils import timezone


class RegistroAuditoria(models.Model):
    """Registro de accesos y acciones sensibles. Solo escritura: no se modifica ni se borra.

    ``detalle`` nunca debe contener datos clínicos.
    """

    class Accion(models.TextChoices):
        REGISTRO = "registro", "Registro de usuario"
        LOGIN = "login", "Inicio de sesión"
        LOGIN_FALLIDO = "login_fallido", "Inicio de sesión fallido"
        ACEPTAR_CONSENTIMIENTO = "aceptar_consentimiento", "Aceptación de consentimiento"
        REVOCAR_CONSENTIMIENTO = "revocar_consentimiento", "Revocación de consentimiento"
        VER_FICHA = "ver_ficha", "Consulta de ficha"
        CREAR_FICHA = "crear_ficha", "Creación de ficha"
        EDITAR_FICHA = "editar_ficha", "Edición de ficha"
        VER_ATENCION = "ver_atencion", "Consulta de atención"
        EMITIR_DERIVACION = "emitir_derivacion", "Emisión de derivación"
        CONSULTA_CHATBOT = "consulta_chatbot", "Consulta al chatbot"
        CANCELAR_CITA = "cancelar_cita", "Cancelación de cita"
        RESERVAR_CITA = "reservar_cita", "Reserva de cita"
        REAGENDAR_CITA = "reagendar_cita", "Reagendamiento de cita"
        MARCAR_INASISTENCIA = "marcar_inasistencia", "Inasistencia a una cita"
        CREAR_ATENCION = "crear_atencion", "Registro de atención"
        CORREGIR_ATENCION = "corregir_atencion", "Corrección de atención"
        ACCESO_DENEGADO = "acceso_denegado", "Intento de acceso a un dato clínico ajeno"
        DESCARGAR_DERIVACION = "descargar_derivacion", "Descarga de derivación en PDF"
        PAGAR_CITA = "pagar_cita", "Pago de cita con Webpay"
        REEMBOLSAR_PAGO = "reembolsar_pago", "Reembolso de pago"
        LOGOUT = "logout", "Cierre de sesión"
        EDITAR_PERFIL = "editar_perfil", "Edición del propio perfil"
        CAMBIAR_CLAVE = "cambiar_clave", "Cambio de la propia contraseña"
        RESTABLECER_CLAVE = "restablecer_clave", "Restablecimiento de contraseña por correo"
        ACTIVAR_2FA = "activar_2fa", "Activación de la verificación en dos pasos"
        DESACTIVAR_2FA = "desactivar_2fa", "Desactivación de la verificación en dos pasos"
        USAR_CODIGO_RESPALDO = "usar_codigo_respaldo", "Inicio de sesión con un código de respaldo"
        DAR_DE_BAJA = "dar_de_baja", "Baja de una cuenta"
        REACTIVAR = "reactivar", "Reactivación de una cuenta"
        VERIFICAR_CERTIFICACION = "verificar_certificacion", "Verificación de una certificación"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.PROTECT,
        related_name="registros_auditoria",
    )
    accion = models.CharField(max_length=40, choices=Accion.choices)
    recurso_tipo = models.CharField(max_length=40, blank=True)
    recurso_id = models.UUIDField(null=True, blank=True)
    ip = models.GenericIPAddressField(null=True, blank=True)
    detalle = models.JSONField(default=dict, blank=True)
    fecha = models.DateTimeField(default=timezone.now, editable=False)

    class Meta:
        verbose_name = "registro de auditoría"
        verbose_name_plural = "registros de auditoría"
        indexes = [
            models.Index(fields=["usuario", "fecha"], name="audit_usuario_fecha_idx"),
            models.Index(fields=["recurso_tipo", "recurso_id"], name="audit_recurso_idx"),
            # Para contar rápido los logins fallidos recientes (freno de intentos).
            models.Index(fields=["accion", "fecha"], name="audit_accion_fecha_idx"),
        ]

    def __str__(self):
        return f"{self.fecha:%Y-%m-%d %H:%M} {self.accion}"

    def save(self, *args, **kwargs):
        if not self._state.adding:
            raise RuntimeError("Los registros de auditoría no se modifican.")
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise RuntimeError("Los registros de auditoría no se borran.")
