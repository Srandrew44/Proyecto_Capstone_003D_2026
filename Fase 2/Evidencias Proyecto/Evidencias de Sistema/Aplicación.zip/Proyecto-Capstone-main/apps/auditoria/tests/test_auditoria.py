import pytest
from django.contrib.auth.models import AnonymousUser
from django.db import DatabaseError, transaction
from django.test import RequestFactory

from apps.auditoria.models import RegistroAuditoria
from apps.auditoria.services import ip_de, registrar
from apps.cuentas.tests.factories import UsuarioFactory

pytestmark = pytest.mark.django_db
Accion = RegistroAuditoria.Accion


def test_registrar_guarda_los_campos():
    usuario = UsuarioFactory()
    registro = registrar(
        accion=Accion.LOGIN,
        usuario=usuario,
        recurso_tipo="usuario",
        recurso_id=usuario.pk,
        ip="10.0.0.5",
        detalle={"origen": "prueba"},
    )
    registro.refresh_from_db()
    assert registro.usuario == usuario
    assert registro.ip == "10.0.0.5"
    assert registro.detalle == {"origen": "prueba"}


def test_registrar_acepta_usuario_nulo():
    registro = registrar(accion=Accion.LOGIN_FALLIDO)
    assert registro.usuario is None
    assert registro.detalle == {}


def test_un_usuario_anonimo_se_guarda_como_nulo():
    assert registrar(accion=Accion.LOGIN_FALLIDO, usuario=AnonymousUser()).usuario is None


def test_la_aplicacion_no_modifica_ni_borra_registros():
    registro = registrar(accion=Accion.LOGIN)
    registro.accion = Accion.VER_FICHA
    with pytest.raises(RuntimeError):
        registro.save()
    with pytest.raises(RuntimeError):
        registro.delete()


def test_la_base_rechaza_update_y_delete_directos():
    registro = registrar(accion=Accion.LOGIN)
    consulta = RegistroAuditoria.objects.filter(pk=registro.pk)
    with pytest.raises(DatabaseError), transaction.atomic():
        consulta.update(accion=Accion.VER_FICHA)
    with pytest.raises(DatabaseError), transaction.atomic():
        consulta.delete()
    registro.refresh_from_db()
    assert registro.accion == Accion.LOGIN


def test_ip_de_usa_remote_addr_y_no_x_forwarded_for():
    peticion = RequestFactory().get("/", HTTP_X_FORWARDED_FOR="6.6.6.6", REMOTE_ADDR="10.1.1.1")
    assert ip_de(peticion) == "10.1.1.1"
