"""IP del cliente detrás de proxies de confianza (PROXIES_DE_CONFIANZA)."""

import pytest
from django.test import RequestFactory

from apps.auditoria.services import ip_de

PROXY = "10.0.0.5"  # el balanceador: con proxy, todos llegan con esta REMOTE_ADDR


def _peticion(xff=None, remota=PROXY):
    extra = {"REMOTE_ADDR": remota}
    if xff is not None:
        extra["HTTP_X_FORWARDED_FOR"] = xff
    return RequestFactory().get("/", **extra)


def test_sin_proxies_de_confianza_usa_remote_addr(settings):
    settings.PROXIES_DE_CONFIANZA = 0
    assert ip_de(_peticion("203.0.113.7")) == PROXY


def test_con_un_proxy_usa_la_ip_que_agrego_el_proxy(settings):
    settings.PROXIES_DE_CONFIANZA = 1
    assert ip_de(_peticion("203.0.113.7")) == "203.0.113.7"


def test_con_un_proxy_ignora_lo_que_el_cliente_escribio_a_la_izquierda(settings):
    settings.PROXIES_DE_CONFIANZA = 1
    assert ip_de(_peticion("6.6.6.6, 1.2.3.4, 203.0.113.7")) == "203.0.113.7"


def test_con_dos_proxies_cuenta_dos_desde_la_derecha(settings):
    settings.PROXIES_DE_CONFIANZA = 2
    assert ip_de(_peticion("6.6.6.6, 203.0.113.7, 10.0.0.9")) == "203.0.113.7"


@pytest.mark.parametrize("xff", [None, "", " , ", "203.0.113.7"])
def test_si_faltan_entradas_de_los_proxies_vuelve_a_remote_addr(settings, xff):
    settings.PROXIES_DE_CONFIANZA = 2
    assert ip_de(_peticion(xff)) == PROXY


@pytest.mark.parametrize("xff", ["no-es-ip", "203.0.113.7:4431", "unknown"])
def test_una_entrada_que_no_es_ip_vuelve_a_remote_addr(settings, xff):
    """La auditoría guarda la IP en un GenericIPAddressField: nunca texto arbitrario."""
    settings.PROXIES_DE_CONFIANZA = 1
    assert ip_de(_peticion(xff)) == PROXY


def test_acepta_ipv6(settings):
    settings.PROXIES_DE_CONFIANZA = 1
    assert ip_de(_peticion("2001:db8::1")) == "2001:db8::1"


def test_sin_remote_addr_ni_cabecera_devuelve_none(settings):
    settings.PROXIES_DE_CONFIANZA = 1
    assert ip_de(_peticion(remota="")) is None
