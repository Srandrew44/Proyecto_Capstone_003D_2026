from django.apps import AppConfig


class AuditoriaConfig(AppConfig):
    name = "apps.auditoria"
    label = "auditoria"
    verbose_name = "Auditoría"
