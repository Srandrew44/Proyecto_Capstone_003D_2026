"""Solo escritura a nivel de base de datos: un trigger rechaza UPDATE y DELETE.

Respalda la regla del Anexo F (sección 4.5): la auditoría no se modifica ni se borra, ni
siquiera con consultas directas. No bloquea TRUNCATE, que usa la limpieza entre pruebas.
Las sentencias van en lista (no en un solo texto) para no depender de cómo se divide el $$.
"""

from django.db import migrations

CREAR = [
    """
    CREATE FUNCTION auditoria_bloquear_modificacion() RETURNS trigger AS $$
    BEGIN
        RAISE EXCEPTION 'auditoria_registroauditoria es de solo escritura';
    END;
    $$ LANGUAGE plpgsql
    """,
    """
    CREATE TRIGGER auditoria_solo_escritura
    BEFORE UPDATE OR DELETE ON auditoria_registroauditoria
    FOR EACH ROW EXECUTE FUNCTION auditoria_bloquear_modificacion()
    """,
]

ELIMINAR = [
    "DROP TRIGGER auditoria_solo_escritura ON auditoria_registroauditoria",
    "DROP FUNCTION auditoria_bloquear_modificacion()",
]


class Migration(migrations.Migration):

    dependencies = [
        ('auditoria', '0001_initial'),
    ]

    operations = [
        migrations.RunSQL(sql=CREAR, reverse_sql=ELIMINAR),
    ]
