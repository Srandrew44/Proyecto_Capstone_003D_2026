from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("auditoria", "0007_correcciones_y_accesos_denegados"),
    ]

    operations = [
        migrations.AddIndex(
            model_name="registroauditoria",
            index=models.Index(fields=["accion", "fecha"], name="audit_accion_fecha_idx"),
        ),
    ]
