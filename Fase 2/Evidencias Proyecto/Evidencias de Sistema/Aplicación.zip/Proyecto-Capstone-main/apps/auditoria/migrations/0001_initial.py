import django.db.models.deletion
import django.utils.timezone
import uuid
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='RegistroAuditoria',
            fields=[
                ('id', models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ('accion', models.CharField(choices=[('registro', 'Registro de usuario'), ('login', 'Inicio de sesión'), ('login_fallido', 'Inicio de sesión fallido'), ('aceptar_consentimiento', 'Aceptación de consentimiento'), ('revocar_consentimiento', 'Revocación de consentimiento'), ('ver_ficha', 'Consulta de ficha'), ('crear_ficha', 'Creación de ficha'), ('editar_ficha', 'Edición de ficha'), ('ver_atencion', 'Consulta de atención'), ('emitir_derivacion', 'Emisión de derivación'), ('consulta_chatbot', 'Consulta al chatbot')], max_length=40)),
                ('recurso_tipo', models.CharField(blank=True, max_length=40)),
                ('recurso_id', models.UUIDField(blank=True, null=True)),
                ('ip', models.GenericIPAddressField(blank=True, null=True)),
                ('detalle', models.JSONField(blank=True, default=dict)),
                ('fecha', models.DateTimeField(default=django.utils.timezone.now, editable=False)),
                ('usuario', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='registros_auditoria', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name': 'registro de auditoría',
                'verbose_name_plural': 'registros de auditoría',
                'indexes': [models.Index(fields=['usuario', 'fecha'], name='audit_usuario_fecha_idx'), models.Index(fields=['recurso_tipo', 'recurso_id'], name='audit_recurso_idx')],
            },
        ),
    ]
