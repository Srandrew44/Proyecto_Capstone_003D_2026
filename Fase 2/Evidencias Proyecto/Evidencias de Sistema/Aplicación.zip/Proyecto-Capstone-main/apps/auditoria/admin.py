from django.contrib import admin

from .models import RegistroAuditoria


@admin.register(RegistroAuditoria)
class RegistroAuditoriaAdmin(admin.ModelAdmin):
    """Solo lectura: la auditoría no se edita ni se borra desde el panel."""

    list_display = ("fecha", "accion", "usuario", "recurso_tipo", "ip")
    list_filter = ("accion",)
    search_fields = ("usuario__email", "recurso_tipo")
    date_hierarchy = "fecha"
    list_select_related = ("usuario",)

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
