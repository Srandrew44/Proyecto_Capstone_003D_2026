"""Cliente de Webpay Plus (Transbank). Es la única pieza que habla con Transbank.

En ambiente de integración usa el código de comercio y la llave públicos de Transbank (no se
mueve dinero real). En producción se necesitan los del comercio, por variables de entorno.
Las pruebas reemplazan estas funciones: nunca llaman a Transbank.
"""

import requests
from django.conf import settings
from transbank.common.integration_api_keys import IntegrationApiKeys
from transbank.common.integration_commerce_codes import IntegrationCommerceCodes
from transbank.common.integration_type import IntegrationType
from transbank.common.options import WebpayOptions
from transbank.error.transbank_error import TransbankError
from transbank.webpay.webpay_plus.transaction import Transaction

PRODUCCION = "produccion"


class ErrorWebpay(Exception):
    """Transbank respondió con un error (4xx o validación del SDK): la operación no se hizo."""


class ResultadoDesconocido(ErrorWebpay):
    """No se sabe si Transbank hizo la operación: error de red, tiempo agotado, error 5xx o
    respuesta ilegible. La petición pudo llegar y procesarse aunque la respuesta se perdiera,
    así que no se puede tratar como un rechazo: hay que consultar el estado (`consultar`).
    Hereda de `ErrorWebpay` para que quien no distinga los casos lo siga capturando.
    """


def _transaccion() -> Transaction:
    if settings.TRANSBANK_AMBIENTE == PRODUCCION:
        opciones = WebpayOptions(
            settings.TRANSBANK_CODIGO_COMERCIO,
            settings.TRANSBANK_API_KEY,
            IntegrationType.LIVE,
            settings.TRANSBANK_TIMEOUT,
        )
    else:
        opciones = WebpayOptions(
            settings.TRANSBANK_CODIGO_COMERCIO or IntegrationCommerceCodes.WEBPAY_PLUS,
            settings.TRANSBANK_API_KEY or IntegrationApiKeys.WEBPAY,
            IntegrationType.TEST,
            settings.TRANSBANK_TIMEOUT,
        )
    return Transaction(opciones)


def _llamar(metodo, *args) -> dict:
    try:
        respuesta = getattr(_transaccion(), metodo)(*args)
    except requests.RequestException as exc:
        raise ResultadoDesconocido(f"Sin respuesta de Transbank: {exc}"[:500]) from exc
    except TransbankError as exc:
        # El SDK pone en `code` el estado HTTP (0 si falló su propia validación). `str(exc)`
        # sale vacío porque el SDK no pasa el mensaje a Exception.
        codigo = getattr(exc, "code", 0) or 0
        mensaje = f"{getattr(exc, 'message', exc)} (HTTP {codigo})"[:500]
        if codigo >= 500:
            raise ResultadoDesconocido(mensaje) from exc
        raise ErrorWebpay(mensaje) from exc
    except ValueError as exc:
        # El SDK lee el cuerpo como JSON: una página de error HTML (proxy caído) no se lee.
        raise ResultadoDesconocido(f"Respuesta ilegible de Transbank: {exc}"[:500]) from exc
    if not isinstance(respuesta, dict):
        # Con el cuerpo vacío el SDK devuelve solo el código HTTP, incluso si es un 5xx.
        raise ResultadoDesconocido(f"Respuesta inesperada de Transbank: {respuesta!r}"[:500])
    return respuesta


def crear(*, orden_compra: str, sesion: str, monto: int, url_retorno: str) -> dict:
    """Abre una transacción. Devuelve {"token", "url"}: el navegador se envía a esa url."""
    return _llamar("create", orden_compra, sesion, monto, url_retorno)


def confirmar(token: str) -> dict:
    """Confirma (commit) la transacción al volver de Webpay. Solo así queda cobrada."""
    return _llamar("commit", token)


def consultar(token: str) -> dict:
    """Estado actual de la transacción (status). Trae los mismos campos que `confirmar`, con
    "status" INITIALIZED, AUTHORIZED, FAILED, REVERSED, NULLIFIED… Transbank solo lo
    informa hasta 7 días después de creada la transacción."""
    return _llamar("status", token)


def reembolsar(token: str, monto: int) -> dict:
    """Anula o reversa un pago confirmado. Devuelve {"type": "REVERSED" | "NULLIFIED", ...}."""
    return _llamar("refund", token, monto)
