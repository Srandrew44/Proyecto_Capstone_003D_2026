"""Cliente de Claude (Anthropic) para el asistente. Es la única pieza que habla con la API.

Las pruebas lo reemplazan: nunca llaman a Anthropic.
"""

import json

import anthropic
from django.conf import settings


class ErrorModelo(Exception):
    """Claude no respondió, tardó demasiado, rechazó o devolvió algo inutilizable."""


def disponible() -> bool:
    return bool(settings.ANTHROPIC_API_KEY)


def consultar(*, sistema: list[dict], mensajes: list[dict], esquema: dict) -> dict:
    """Una llamada a Messages con salida JSON validada por `esquema`. Devuelve el dict."""
    cliente = anthropic.Anthropic(
        api_key=settings.ANTHROPIC_API_KEY,
        timeout=settings.CHATBOT_TIMEOUT_S,
        # Sin reintentos: si falla, responde el clasificador por reglas al instante.
        max_retries=0,
    )
    try:
        respuesta = cliente.messages.create(
            model=settings.CHATBOT_MODELO,
            max_tokens=4000,
            system=sistema,
            messages=mensajes,
            output_config={"format": {"type": "json_schema", "schema": esquema}},
        )
    except anthropic.APIConnectionError as exc:  # incluye el tiempo agotado
        raise ErrorModelo(f"Sin conexión con Claude: {exc}") from exc
    except anthropic.RateLimitError as exc:
        raise ErrorModelo("Límite de uso de Claude alcanzado.") from exc
    except anthropic.APIStatusError as exc:
        raise ErrorModelo(f"Claude respondió {exc.status_code}: {exc.message}") from exc

    if respuesta.stop_reason != "end_turn":
        # refusal, max_tokens u otro corte: la respuesta no es confiable.
        raise ErrorModelo(f"Respuesta incompleta de Claude ({respuesta.stop_reason}).")
    texto = next((b.text for b in respuesta.content if b.type == "text"), "")
    try:
        return json.loads(texto)
    except ValueError as exc:
        raise ErrorModelo("Claude devolvió un JSON inválido.") from exc
