# MyPodo · Design System (MASTER)

Fuente de verdad del diseño del front. Decidido con el dueño del producto el 2026-11-12.
Las páginas pueden tener ajustes en `pages/<pagina>.md`, que prevalecen sobre este archivo.

## Estilo
**Clínico limpio**: fondo claro, superficies blancas, bordes suaves, mucho aire, color usado con
moderación (el color marca estado y acción, no decora). Nada de degradados morados, neumorfismo
ni emojis como íconos (usar SVG en línea, estilo Lucide, trazo 1.75px).

## Paleta (tokens)
| Token | Hex | Uso |
|---|---|---|
| `--mp-primary` | `#0F766E` | Botones secundarios, enlaces, ítem activo, foco |
| `--mp-primary-hover` | `#115E59` | Hover de primario |
| `--mp-primary-dark` | `#134E4A` | Títulos, texto de ítem activo |
| `--mp-primary-soft` | `#E6F2F0` | Fondo de ítem activo / seleccionado |
| `--mp-accent` | `#C2410C` | Acción principal (Guardar, Entrar, Verificar). Texto blanco: 5.2:1 |
| `--mp-accent-hover` | `#9A3412` | Hover de acción principal |
| `--mp-accent-logo` | `#EA580C` | Solo decorativo (logo, puntos). NUNCA de fondo con texto blanco |
| `--mp-bg` | `#F6FAF9` | Fondo de página |
| `--mp-surface` | `#FFFFFF` | Tarjetas, menú lateral, barra superior |
| `--mp-text` | `#1F2937` | Texto principal |
| `--mp-text-muted` | `#5B6B73` | Texto secundario, etiquetas de sección (5.3:1 sobre fondo) |
| `--mp-border` | `#DCE7E5` | Bordes y separadores |
| `--mp-border-strong` | `#B8CBC8` | Bordes de campos |
| `--mp-success` | `#15803D` / fondo `#ECFDF3` | Mensajes de éxito |
| `--mp-warning` | `#B45309` / fondo `#FFFBEB` | Avisos |
| `--mp-danger` | `#B91C1C` / fondo `#FEF2F2` | Errores, eliminar |

### Dónde viven estos colores
- Admin de Django: variables `--mp-*` en `apps/web/static/web/css/admin.css`.
- Sitio y paneles (Tailwind): tokens en `frontend/tailwind.config.js` con nombres heredados:
  `primario` = teal (#0F766E / oscuro #134E4A / claro #E6F2F0), `acento` = naranja (#C2410C;
  `acento-vivo` #EA580C solo decorativo), `fondo`, `borde`, `texto`. Tras cambiar el config o
  `frontend/estilos.css`, compilar con `npm run build` en `frontend/` (genera `app.css`).
- Menú lateral de los paneles: fondo sólido `primario-oscuro`; el logo usa cuadro naranja sobre
  fondo oscuro y teal sobre fondo claro.

## Tipografía
- Títulos: **Figtree** 600/700. Cuerpo: **Noto Sans** 400/500/600. Autoalojadas en
  `apps/web/static/web/fuentes/` (la CSP solo permite `font-src 'self'`: nada de Google Fonts por URL).
- Base 15–16px, interlineado 1.5. Títulos de página 1.5rem/700, de tarjeta 1rem/600.
- Monoespaciada (claves, códigos): `ui-monospace, "Cascadia Mono", Consolas, monospace`.

## Forma y espaciado
- Radios: campos y botones 8px, tarjetas 12px, chips/etiquetas 999px.
- Sombra de tarjeta: `0 1px 2px rgba(16,40,38,.06), 0 4px 12px rgba(16,40,38,.05)`.
- Espaciado en múltiplos de 4px (8 / 12 / 16 / 24 / 32).

## Accesibilidad (obligatorio)
- Contraste de texto ≥ 4.5:1 (los tokens de arriba ya cumplen en sus usos indicados).
- Foco visible: `outline: 2px solid #0F766E; outline-offset: 2px` en todo lo interactivo.
- Objetivos táctiles ≥ 44px de alto en botones y campos principales.
- Transiciones 150–200ms y desactivadas con `prefers-reduced-motion: reduce`.
- Sin modo oscuro por ahora.
