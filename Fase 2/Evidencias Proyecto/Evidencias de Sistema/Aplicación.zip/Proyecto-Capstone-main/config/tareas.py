"""Tareas periódicas por HTTP, para el plan gratis de Render (no tiene tareas programadas).

Un flujo de GitHub Actions (.github/workflows/tareas.yml) llama cada hora a
POST /tareas/ejecutar/ con el encabezado "Authorization: Bearer <TAREAS_TOKEN>", y aquí se
corre lo mismo que `manage.py enviar_notificaciones`: pagos, fotos vencidas, limpieza y
correos. Sin TAREAS_TOKEN (o con uno corto) la dirección no existe (404).
"""

import hmac
import io

from django.conf import settings
from django.core.cache import cache
from django.core.management import call_command
from django.http import Http404, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

LARGO_MINIMO_TOKEN = 32


@csrf_exempt  # no hay sesión ni cookie: la protege el token
@require_POST
def ejecutar(request):
    token = settings.TAREAS_TOKEN
    recibido = request.headers.get("Authorization", "").removeprefix("Bearer ").strip()
    if len(token) < LARGO_MINIMO_TOKEN or not hmac.compare_digest(recibido, token):
        raise Http404  # no revela que la dirección existe
    # Si una ejecución anterior sigue corriendo (p. ej. el sitio despertaba), no se pisan.
    if not cache.add("tareas:en-curso", 1, timeout=300):
        return JsonResponse({"estado": "ocupado"}, status=409)
    salida = io.StringIO()
    try:
        call_command("enviar_notificaciones", stdout=salida)
    finally:
        cache.delete("tareas:en-curso")
    return JsonResponse({"estado": "ok", "detalle": salida.getvalue().splitlines()})
