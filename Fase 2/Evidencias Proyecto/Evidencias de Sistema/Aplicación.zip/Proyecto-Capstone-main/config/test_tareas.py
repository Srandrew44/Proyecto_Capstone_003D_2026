"""Tareas periódicas por HTTP (config/tareas.py), las que llama GitHub Actions."""

from datetime import timedelta

import pytest
from django.core import mail
from django.core.cache import cache
from django.test import Client
from django.utils import timezone

from apps.cuentas.models import RegistroPendiente

pytestmark = pytest.mark.django_db
URL = "/tareas/ejecutar/"
TOKEN = "t" * 40


@pytest.fixture(autouse=True)
def con_token(settings):
    settings.TAREAS_TOKEN = TOKEN


def _llamar(token=TOKEN, metodo="post"):
    return getattr(Client(), metodo)(URL, HTTP_AUTHORIZATION=f"Bearer {token}")


def test_con_el_token_corre_las_tareas():
    respuesta = _llamar()
    assert respuesta.status_code == 200
    datos = respuesta.json()
    assert datos["estado"] == "ok"
    assert any(linea.startswith("Enviadas:") for linea in datos["detalle"])


def test_sin_token_o_con_otro_no_existe():
    assert Client().post(URL).status_code == 404
    assert _llamar("otro" * 10).status_code == 404


def test_sin_token_configurado_la_direccion_no_existe(settings):
    settings.TAREAS_TOKEN = ""
    assert _llamar("").status_code == 404


def test_un_token_corto_no_se_acepta(settings):
    settings.TAREAS_TOKEN = "corto"
    assert _llamar("corto").status_code == 404


def test_solo_acepta_post():
    assert _llamar(metodo="get").status_code == 405


def test_dos_ejecuciones_a_la_vez_no_se_pisan():
    cache.add("tareas:en-curso", 1, timeout=60)
    assert _llamar().status_code == 409


def test_borra_los_registros_sin_confirmar_vencidos():
    RegistroPendiente.objects.create(
        email="viejo@example.com",
        datos={},
        password_hash="x",
        token_hash="a" * 64,
        vence_en=timezone.now() - timedelta(hours=1),
    )
    _llamar()
    assert not RegistroPendiente.objects.exists()
    assert mail.outbox == []
