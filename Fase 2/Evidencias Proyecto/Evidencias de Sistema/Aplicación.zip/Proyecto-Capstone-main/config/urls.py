from django.contrib import admin
from django.db import DatabaseError, connection
from django.http import JsonResponse
from django.urls import include, path

from config import tareas

# El panel es config.admin.SitioAdmin (textos y verificación en dos pasos); su apariencia está
# en templates/admin/base_site.html.


def salud(request):
    """Comprobación simple de que la aplicación responde. No toca la base: así el chequeo de
    Render no despierta a Neon."""
    return JsonResponse({"estado": "ok"})


def salud_bd(request):
    """Para un monitor externo: además comprueba que la base responde."""
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
    except DatabaseError:
        return JsonResponse({"estado": "sin base de datos"}, status=503)
    return JsonResponse({"estado": "ok"})


urlpatterns = [
    path("admin/", admin.site.urls),
    path("salud/", salud, name="salud"),
    path("salud/bd/", salud_bd, name="salud-bd"),
    path("tareas/ejecutar/", tareas.ejecutar, name="tareas-ejecutar"),
    path("api/", include("apps.cuentas.api.urls")),
    path("api/", include("apps.clinica.api.urls")),
    path("api/", include("apps.agenda.api.urls")),
    path("", include("apps.web.urls")),
]
