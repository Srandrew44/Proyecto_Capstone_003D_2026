"""Panel de administración con verificación en dos pasos (código de una app de autenticación).

Quien tiene acceso al panel ve datos de todos los pacientes: además de la contraseña, se le pide
un código de 6 dígitos de una app como Google Authenticator (o un código de respaldo). La
primera vez se le muestra un QR para registrar la app y se le entregan 10 códigos de respaldo;
desde entonces, el código en cada sesión nueva. La lógica está en apps.cuentas.dos_pasos, la
misma de la verificación opcional de pacientes y podólogos. Si alguien pierde el teléfono y los
códigos: otro administrador borra su dispositivo en el panel, o `manage.py quitar_2fa <correo>`.
"""

from urllib.parse import urlencode

from django.conf import settings
from django.contrib import admin
from django.core.exceptions import ValidationError
from django.shortcuts import redirect
from django.template.response import TemplateResponse
from django.urls import path, reverse
from django.utils.http import url_has_allowed_host_and_scheme
from django.utils.safestring import mark_safe
from django_otp import login as otp_login

from apps.auditoria.services import ip_de
from apps.cuentas import dos_pasos
from apps.cuentas.bloqueo import esta_bloqueado, registrar_fallo
from apps.cuentas.services import sitio_de


class SitioAdmin(admin.AdminSite):
    site_header = "MyPodo · Administración"
    site_title = "MyPodo"
    index_title = "Panel de administración"
    site_url = "/mi-panel/"  # "Ver el sitio" lleva al panel del rol, no a la portada

    def _falta_2fa(self, request) -> bool:
        usuario = request.user
        return (
            settings.ADMIN_EXIGE_2FA
            and usuario.is_authenticated
            and usuario.is_active
            and usuario.is_staff
            and not usuario.is_verified()
        )

    def has_permission(self, request):
        return super().has_permission(request) and not self._falta_2fa(request)

    def login(self, request, extra_context=None):
        # Con la contraseña ya puesta (aquí o en /entrar/), falta el código.
        if self._falta_2fa(request):
            destino = request.GET.get("next") or reverse("admin:index")
            return redirect(f"{reverse('admin:verificar-2fa')}?{urlencode({'next': destino})}")
        return super().login(request, extra_context)

    def get_urls(self):
        return [path("verificar/", self.verificar_2fa, name="verificar-2fa"), *super().get_urls()]

    def verificar_2fa(self, request):
        usuario = request.user
        if not (usuario.is_authenticated and usuario.is_active and usuario.is_staff):
            return redirect("admin:login")
        destino = request.POST.get("next") or request.GET.get("next") or ""
        if not url_has_allowed_host_and_scheme(
            destino, allowed_hosts={request.get_host()}, require_https=request.is_secure()
        ):
            destino = reverse("admin:index")
        if not self._falta_2fa(request):
            return redirect(destino)

        registrar = not dos_pasos.activa(usuario)
        ip = ip_de(request)
        error = ""
        if request.method == "POST":
            codigo = request.POST.get("codigo", "")
            if esta_bloqueado(email=usuario.email, ip=ip):
                error = "Demasiados intentos fallidos. Espera 15 minutos y vuelve a intentar."
            elif registrar:
                try:
                    codigos = dos_pasos.confirmar(
                        usuario, codigo=codigo, sitio=sitio_de(request), ip=ip
                    )
                except ValidationError as exc:
                    error = exc.message_dict["codigo"][0]
                else:
                    otp_login(request, dos_pasos.dispositivo(usuario))
                    return self._mostrar_codigos(request, codigos, destino)
            else:
                disp = dos_pasos.verificar(usuario, codigo, ip=ip)
                if disp is not None:
                    otp_login(request, disp)
                    return redirect(destino)
                error = "El código no es correcto o ya cambió. Escribe el que muestra la app ahora."
            if error and not error.startswith("Demasiados"):
                # Cuenta para el freno de intentos, igual que una contraseña equivocada.
                registrar_fallo(email=usuario.email, ip=ip)

        contexto = {**self.each_context(request), "title": "Verificación en dos pasos"}
        if registrar:
            disp = dos_pasos.preparar(usuario)
            contexto.update(
                qr=mark_safe(dos_pasos.qr_svg(disp)),  # noqa: S308 (SVG generado aquí)
                clave=dos_pasos.clave_texto(disp),
            )
        contexto.update(registrar=registrar, error=error, next=destino)
        return TemplateResponse(
            request, "admin/verificar_2fa.html", contexto, status=400 if error else 200
        )

    def _mostrar_codigos(self, request, codigos, destino):
        contexto = {
            **self.each_context(request),
            "title": "Tus códigos de respaldo",
            "codigos": codigos,
            "next": destino,
        }
        return TemplateResponse(request, "admin/codigos_respaldo.html", contexto)
