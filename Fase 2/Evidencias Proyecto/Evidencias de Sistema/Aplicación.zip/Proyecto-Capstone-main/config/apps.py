from django.contrib.admin.apps import AdminConfig
from django_otp.plugins.otp_totp.apps import DefaultConfig as OtpTotpConfig


class AdminMyPodo(AdminConfig):
    """El panel /admin/ con verificación en dos pasos (config.admin.SitioAdmin)."""

    default_site = "config.admin.SitioAdmin"


class VerificacionDosPasosConfig(OtpTotpConfig):
    """La app de django-otp con su nombre en español ("Otp_Totp" no le dice nada a nadie).

    Mantiene la etiqueta `otp_totp`: las tablas, migraciones y permisos siguen siendo los mismos.
    Sus dispositivos se administran en "Cuentas → Dispositivos de verificación"
    (apps.cuentas.admin), pero este nombre sigue apareciendo, p. ej., en la lista de permisos.
    """

    label = "otp_totp"
    verbose_name = "Verificación en dos pasos"
