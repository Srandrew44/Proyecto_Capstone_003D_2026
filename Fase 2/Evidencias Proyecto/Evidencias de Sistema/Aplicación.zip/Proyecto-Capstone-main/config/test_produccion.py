"""Ajustes de producción. Se cargan en otro proceso: las pruebas corren con config.settings.test."""

import json
import os
import subprocess
import sys

CLAVE_LARGA = "x" * 50
LEER_AJUSTES = """
import json
from django.conf import settings as s
print(json.dumps({
    "hosts": s.ALLOWED_HOSTS,
    "origenes": s.CSRF_TRUSTED_ORIGINS,
    "middleware": s.MIDDLEWARE,
    "estaticos": s.STORAGES["staticfiles"]["BACKEND"],
    "proxy": s.SECURE_PROXY_SSL_HEADER,
    "verificar_conexion": s.DATABASES["default"]["CONN_HEALTH_CHECKS"],
    "debug": s.DEBUG,
    "proxies": s.PROXIES_DE_CONFIANZA,
    "num_proxies": s.REST_FRAMEWORK["NUM_PROXIES"],
    "correo": s.EMAIL_BACKEND,
    "sslmode": s.DATABASES["default"].get("OPTIONS", {}).get("sslmode"),
}))
"""


def _cargar(**entorno):
    variables = {
        **os.environ,
        "DJANGO_SETTINGS_MODULE": "config.settings.prod",
        "SECRET_KEY": CLAVE_LARGA,
        "ALLOWED_HOSTS": "",
        **entorno,
    }
    return subprocess.run(
        [sys.executable, "-c", LEER_AJUSTES], env=variables, capture_output=True, text=True
    )


def test_produccion_acepta_el_dominio_de_render_y_sirve_los_estaticos():
    resultado = _cargar(
        RENDER_EXTERNAL_HOSTNAME="mypodo.onrender.com",
        DETRAS_DE_PROXY_HTTPS="True",
        PROXIES_DE_CONFIANZA="1",
    )
    assert resultado.returncode == 0, resultado.stderr
    ajustes = json.loads(resultado.stdout)
    assert ajustes["debug"] is False
    assert ajustes["hosts"] == ["mypodo.onrender.com"]
    assert ajustes["origenes"] == ["https://mypodo.onrender.com"]
    assert ajustes["middleware"][1] == "whitenoise.middleware.WhiteNoiseMiddleware"
    assert ajustes["estaticos"].endswith("CompressedManifestStaticFilesStorage")
    assert ajustes["proxy"] == ["HTTP_X_FORWARDED_PROTO", "https"]
    assert ajustes["verificar_conexion"] is True
    assert ajustes["proxies"] == ajustes["num_proxies"] == 1


def test_sin_la_variable_no_se_confia_en_ningun_proxy():
    """Por defecto la IP es REMOTE_ADDR: X-Forwarded-For solo cuenta si se declara el proxy."""
    entorno = {k: v for k, v in os.environ.items() if k != "PROXIES_DE_CONFIANZA"}
    resultado = subprocess.run(
        [sys.executable, "-c", LEER_AJUSTES],
        env={
            **entorno,
            "DJANGO_SETTINGS_MODULE": "config.settings.prod",
            "SECRET_KEY": CLAVE_LARGA,
        },
        capture_output=True,
        text=True,
    )
    assert resultado.returncode == 0, resultado.stderr
    assert json.loads(resultado.stdout)["proxies"] == 0


def test_produccion_no_arranca_con_una_clave_debil():
    resultado = _cargar(SECRET_KEY="cambia-esta-clave-en-tu-entorno-local")
    assert resultado.returncode != 0
    assert "SECRET_KEY" in resultado.stderr


def test_database_url_pegada_con_espacios_o_comillas_funciona():
    """Al pegarla en el panel de Render se pueden colar espacios, saltos de línea o comillas."""
    url = os.environ["DATABASE_URL"]
    resultado = _cargar(DATABASE_URL=f"  '{url}'\n")
    assert resultado.returncode == 0, resultado.stderr


def test_database_url_sin_esquema_da_un_error_claro():
    """El 08/11/2026 se pegó sin el comienzo «postgresql» y el error de Django no lo decía."""
    url = os.environ["DATABASE_URL"]
    resultado = _cargar(DATABASE_URL=url[url.index("://") :])
    assert resultado.returncode != 0
    assert "DATABASE_URL debe empezar con postgresql://" in resultado.stderr


def test_con_clave_de_brevo_el_correo_sale_por_su_api():
    resultado = _cargar(BREVO_API_KEY="xkeysib-prueba")
    assert resultado.returncode == 0, resultado.stderr
    assert json.loads(resultado.stdout)["correo"] == "anymail.backends.brevo.EmailBackend"


def test_sin_clave_de_brevo_se_usa_smtp():
    resultado = _cargar(BREVO_API_KEY="")
    assert resultado.returncode == 0, resultado.stderr
    assert json.loads(resultado.stdout)["correo"] == "django.core.mail.backends.smtp.EmailBackend"


def test_la_conexion_a_la_base_exige_ssl():
    resultado = _cargar()
    assert resultado.returncode == 0, resultado.stderr
    assert json.loads(resultado.stdout)["sslmode"] == "require"
