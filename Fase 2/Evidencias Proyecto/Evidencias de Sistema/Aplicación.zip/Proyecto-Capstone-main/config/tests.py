import pytest
from django.conf import settings
from django.db import connection


def test_zona_horaria_e_idioma_de_chile():
    assert settings.TIME_ZONE == "America/Santiago"
    assert settings.LANGUAGE_CODE == "es-cl"
    assert settings.USE_TZ is True


def test_argon2_es_el_hasher_principal():
    assert settings.PASSWORD_HASHERS[0].endswith("Argon2PasswordHasher")


def test_se_usa_el_usuario_personalizado():
    assert settings.AUTH_USER_MODEL == "cuentas.Usuario"


@pytest.mark.django_db
def test_btree_gist_esta_activa():
    with connection.cursor() as cursor:
        cursor.execute("SELECT 1 FROM pg_extension WHERE extname = 'btree_gist'")
        assert cursor.fetchone() is not None


@pytest.mark.django_db
def test_endpoint_de_salud(client):
    respuesta = client.get("/salud/")
    assert respuesta.status_code == 200
    assert respuesta.json() == {"estado": "ok"}


@pytest.mark.django_db
def test_salud_bd_comprueba_la_base():
    from django.test import Client

    respuesta = Client().get("/salud/bd/")
    assert respuesta.status_code == 200
    assert respuesta.json() == {"estado": "ok"}
