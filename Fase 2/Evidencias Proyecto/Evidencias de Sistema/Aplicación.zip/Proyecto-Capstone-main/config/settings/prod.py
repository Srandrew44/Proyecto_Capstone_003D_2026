"""Producción o demo expuesta: endurecimiento de seguridad.

Las opciones de HTTPS se pueden relajar por variable de entorno SOLO para una demo local
sin certificado (SECURE_HTTPS=False).
"""

from django.core.exceptions import ImproperlyConfigured

from .base import *  # noqa: F403
from .base import ALLOWED_HOSTS, DATABASES, MIDDLEWARE, SECRET_KEY, env

DEBUG = False
# Correo: Render gratis bloquea el SMTP, así que se envía por la API HTTPS de Brevo cuando hay
# clave. El remitente (DEFAULT_FROM_EMAIL) debe estar verificado en Brevo. Sin clave, SMTP.
if BREVO_API_KEY := env("BREVO_API_KEY", default=""):
    EMAIL_BACKEND = "anymail.backends.brevo.EmailBackend"
    ANYMAIL = {"BREVO_API_KEY": BREVO_API_KEY}
else:
    EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"

# No arranca con la clave de ejemplo ni con una corta: con ella se pueden falsificar sesiones.
if SECRET_KEY.startswith("cambia-esta-clave") or len(SECRET_KEY) < 40:
    raise ImproperlyConfigured(
        'SECRET_KEY de producción insegura. Genera una con: python -c "from '
        'django.core.management.utils import get_random_secret_key as g; print(g())"'
    )

SECURE_HTTPS = env.bool("SECURE_HTTPS", default=True)
SECURE_SSL_REDIRECT = SECURE_HTTPS
# El chequeo de salud de la plataforma no pasa por la redirección a HTTPS.
SECURE_REDIRECT_EXEMPT = [r"^salud/$", r"^salud/bd/$"]
SESSION_COOKIE_SECURE = SECURE_HTTPS
CSRF_COOKIE_SECURE = SECURE_HTTPS
SECURE_HSTS_SECONDS = 31536000 if SECURE_HTTPS else 0
# Sin includeSubDomains ni preload: el sitio vive en un subdominio de onrender.com (no se
# controla el dominio ni sus subdominios, y la lista de preload exige un dominio propio). Con un
# dominio propio se pueden activar y quitar estas dos excepciones.
SILENCED_SYSTEM_CHECKS = ["security.W005", "security.W021"]
SECURE_CONTENT_TYPE_NOSNIFF = True
X_FRAME_OPTIONS = "DENY"

# Detrás de un proxy que termina el HTTPS (Render, Railway, Nginx): activar SOLO si ese proxy
# siempre reescribe X-Forwarded-Proto; si no, un cliente podría fingir que usa HTTPS.
if env.bool("DETRAS_DE_PROXY_HTTPS", default=False):
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
# Orígenes desde los que se aceptan formularios con CSRF, p. ej. https://mypodo.cl
CSRF_TRUSTED_ORIGINS = env.list("CSRF_TRUSTED_ORIGINS", default=[])

# Render entrega el dominio del servicio en esta variable.
HOST_RENDER = env("RENDER_EXTERNAL_HOSTNAME", default="")
if HOST_RENDER:
    ALLOWED_HOSTS = [*ALLOWED_HOSTS, HOST_RENDER]
    CSRF_TRUSTED_ORIGINS = [*CSRF_TRUSTED_ORIGINS, f"https://{HOST_RENDER}"]

# Sin servidor web delante, WhiteNoise entrega el CSS y los scripts. El manifiesto agrega un
# hash al nombre de cada archivo: por eso `collectstatic` debe correr en cada despliegue.
MIDDLEWARE.insert(1, "whitenoise.middleware.WhiteNoiseMiddleware")
STORAGES = {
    "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
    "staticfiles": {"BACKEND": "whitenoise.storage.CompressedManifestStaticFilesStorage"},
}

# Neon apaga la base cuando no se usa: se reutiliza la conexión, pero se revisa antes de usarla.
DATABASES["default"]["CONN_MAX_AGE"] = env.int("CONN_MAX_AGE", default=60)
DATABASES["default"]["CONN_HEALTH_CHECKS"] = True
# La conexión a la base va cifrada aunque la DATABASE_URL pegada no traiga ?sslmode=require.
# Solo una demo local sin certificado lo baja (BD_SSLMODE=disable).
DATABASES["default"].setdefault("OPTIONS", {}).setdefault(
    "sslmode", env("BD_SSLMODE", default="require")
)

# Webpay en producción cobra dinero real: sin el comercio y la llave propios no arranca.
if env("TRANSBANK_AMBIENTE", default="integracion") == "produccion" and not (
    env("TRANSBANK_CODIGO_COMERCIO", default="") and env("TRANSBANK_API_KEY", default="")
):
    raise ImproperlyConfigured(
        "TRANSBANK_AMBIENTE=produccion exige TRANSBANK_CODIGO_COMERCIO y TRANSBANK_API_KEY."
    )
