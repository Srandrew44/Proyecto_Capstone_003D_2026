"""Pruebas: correo en memoria y clave fija (nunca usar fuera de pruebas)."""

from .base import *  # noqa: F403

SECRET_KEY = "clave-solo-para-pruebas"  # noqa: S105
DEBUG = False
ALLOWED_HOSTS = ["testserver", "localhost"]
EMAIL_BACKEND = "django.core.mail.backends.locmem.EmailBackend"
# Las pruebas del panel entran sin código; las de config/test_admin_2fa.py lo activan.
ADMIN_EXIGE_2FA = False
# En pruebas basta la caché en memoria (sin tabla que crear).
CACHES = {"default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache"}}
# Las cuentas de las pruebas usan @example.com: aquí sí se "envían" (a la bandeja en memoria).
NOTIFICACIONES_OMITIR_FICTICIAS = False
# Las pruebas de agenda reservan sin pago; las de apps/pagos lo activan.
PAGOS_WEBPAY_ACTIVO = False
# Las pruebas nunca llaman a Claude: sin clave responde el clasificador por reglas.
ANTHROPIC_API_KEY = ""
