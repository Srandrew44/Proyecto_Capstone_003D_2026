"""Desarrollo local: correo capturado por Mailpit, sin enviar nada real."""

from .base import *  # noqa: F403

DEBUG = True
ALLOWED_HOSTS = ["localhost", "127.0.0.1", "[::1]", "web"]
EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"
