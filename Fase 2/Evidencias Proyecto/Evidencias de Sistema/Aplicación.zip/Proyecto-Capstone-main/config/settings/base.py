"""Ajustes comunes a todos los entornos. Los secretos vienen solo de variables de entorno."""

from pathlib import Path

import environ
from django.core.exceptions import ImproperlyConfigured

BASE_DIR = Path(__file__).resolve().parent.parent.parent

env = environ.Env()

SECRET_KEY = env("SECRET_KEY")
DEBUG = env.bool("DEBUG", default=False)
ALLOWED_HOSTS = env.list("ALLOWED_HOSTS", default=[])

INSTALLED_APPS = [
    "config.apps.AdminMyPodo",  # django.contrib.admin con verificación en dos pasos
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "rest_framework",
    "django_otp",
    "config.apps.VerificacionDosPasosConfig",  # django_otp.plugins.otp_totp, con nombre propio
    "apps.cuentas",
    "apps.agenda",
    "apps.clinica",
    "apps.chatbot",
    "apps.auditoria",
    "apps.pagos",
    "apps.web",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django_otp.middleware.OTPMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "config.seguridad.CabecerasDeSeguridad",
]

ROOT_URLCONF = "config.urls"
WSGI_APPLICATION = "config.wsgi.application"
ASGI_APPLICATION = "config.asgi.application"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]


# Base de datos: PostgreSQL (se necesita para la restricción de exclusión de citas).
def _url_base_de_datos() -> str:
    """DATABASE_URL sin espacios, saltos de línea ni comillas de más (pasa al pegarla en un
    panel como el de Render). Sin el esquema postgresql:// avisa claro: si no, Django falla
    con un "Please supply the ENGINE value" que no dice qué está mal."""
    url = env.str("DATABASE_URL").strip().strip("'\"").strip()
    if not url.startswith(("postgres://", "postgresql://")):
        raise ImproperlyConfigured(
            "DATABASE_URL debe empezar con postgresql:// (revisa que se haya copiado completa)."
        )
    return url


DATABASES = {"default": env.db_url_config(_url_base_de_datos())}
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# Usuario personalizado: debe existir desde la primera migración.
AUTH_USER_MODEL = "cuentas.Usuario"
# Frena los intentos de adivinar contraseñas, también en /admin/ (apps/cuentas/bloqueo.py).
AUTHENTICATION_BACKENDS = ["apps.cuentas.backends.ModelBackendConFreno"]
# Las páginas que piden sesión mandan aquí (la API responde 403 en su lugar).
LOGIN_URL = "web:entrar"

# Contraseñas: Argon2 es el primero, así que es el que se usa para guardar.
PASSWORD_HASHERS = [
    "django.contrib.auth.hashers.Argon2PasswordHasher",
    "django.contrib.auth.hashers.PBKDF2PasswordHasher",
]
AUTH_PASSWORD_VALIDATORS = [
    {
        # Los nombres de campo del usuario propio (no los de auth.User por defecto).
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator",
        "OPTIONS": {"user_attributes": ("email", "nombre", "apellido")},
    },
    {
        # 10 y no 12: equilibrio para pacientes mayores (decisión del 11/11/2026). Junto con el
        # bloqueo de contraseñas comunes y el freno de intentos.
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
        "OPTIONS": {"min_length": 10},
    },
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# Sesión: dura una jornada (8 h por defecto) y no las dos semanas de Django, porque abre
# fichas clínicas. La cookie no la lee JavaScript y no viaja en peticiones de otros sitios.
SESSION_COOKIE_AGE = env.int("SESION_HORAS", default=8) * 3600
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"
# La cookie CSRF sí la lee el frontend (mypodo.js la reenvía en X-CSRFToken).
CSRF_COOKIE_SAMESITE = "Lax"
X_FRAME_OPTIONS = "DENY"
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_REFERRER_POLICY = "same-origin"

# Idioma y zona horaria: agenda y recordatorios dependen de esto.
LANGUAGE_CODE = "es-cl"
TIME_ZONE = "America/Santiago"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"

# Correo
EMAIL_HOST = env("EMAIL_HOST", default="localhost")
EMAIL_PORT = env.int("EMAIL_PORT", default=25)
EMAIL_HOST_USER = env("EMAIL_HOST_USER", default="")
EMAIL_HOST_PASSWORD = env("EMAIL_HOST_PASSWORD", default="")
EMAIL_USE_TLS = env.bool("EMAIL_USE_TLS", default=False)
DEFAULT_FROM_EMAIL = env("DEFAULT_FROM_EMAIL", default="MyPodo <no-reply@mypodo.local>")
# Si el servidor de correo no responde, el envío falla y se reintenta (no se queda colgado).
EMAIL_TIMEOUT = env.int("EMAIL_TIMEOUT", default=20)

# Proxies de confianza entre internet y Gunicorn (Render: 3, medido;
# ver docs/DESPLIEGUE_RENDER.md, paso 4). Con 0, la IP del cliente es
# REMOTE_ADDR; con N, la entrada N desde la derecha de X-Forwarded-For (ver
# apps.auditoria.services.ip_de). Un número mayor que el real deja falsear la IP: ante la duda,
# uno menor (en el peor caso todos comparten la IP del proxy, pero nadie inventa la suya).
PROXIES_DE_CONFIANZA = env.int("PROXIES_DE_CONFIANZA", default=0)

# Caché en la base de datos: la comparten todos los procesos y sobrevive a los reinicios y a
# la suspensión del plan gratis. La usan los límites de registros, de recuperación y del
# asistente. La tabla la crea una migración (cuentas 0008), así que basta `migrate`.
CACHES = {
    "default": {
        "BACKEND": "django.core.cache.backends.db.DatabaseCache",
        "LOCATION": "cache_mypodo",
    }
}

# Token de las tareas periódicas por HTTP (config/tareas.py). Vacío: la dirección no existe.
TAREAS_TOKEN = env("TAREAS_TOKEN", default="")

# Verificación en dos pasos para entrar al panel /admin/ (config/admin.py).
ADMIN_EXIGE_2FA = env.bool("ADMIN_EXIGE_2FA", default=True)
OTP_TOTP_ISSUER = "MyPodo"

# Enlaces que llegan por correo. El de recuperar la contraseña sirve una vez y vence en 1 hora
# (además deja de servir apenas la contraseña cambia); el de confirmar el registro, en 24 horas.
PASSWORD_RESET_TIMEOUT = env.int("RECUPERAR_CLAVE_SEGUNDOS", default=3600)
REGISTRO_VIGENCIA_HORAS = env.int("REGISTRO_VIGENCIA_HORAS", default=24)

REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": ["rest_framework.authentication.SessionAuthentication"],
    "DEFAULT_PERMISSION_CLASSES": ["rest_framework.permissions.IsAuthenticated"],
    # Solo las vistas que lo piden (throttle_scope) quedan limitadas.
    "DEFAULT_THROTTLE_RATES": {
        "registro": env("LIMITE_REGISTROS", default="10/hour"),
        # Por IP, además del freno por cuenta (bloqueo.py): frena probar muchas cuentas.
        "login": env("LIMITE_LOGIN", default="30/minute"),
        "recuperar": env("LIMITE_RECUPERAR", default="10/hour"),
    },
    # Sin esto DRF identifica por la cabecera X-Forwarded-For completa, que el cliente cambia
    # a voluntad. El límite de registros usa además ip_de (apps.cuentas.throttling).
    "NUM_PROXIES": PROXIES_DE_CONFIANZA,
}

# Reglas de reserva acordadas con el podólogo (25/10/2026). Se pueden cambiar por entorno.
AGENDA_ANTICIPACION_MIN_HORAS = env.int("AGENDA_ANTICIPACION_MIN_HORAS", default=24)
AGENDA_HORIZONTE_DIAS = env.int("AGENDA_HORIZONTE_DIAS", default=30)
# Hasta cuántas horas antes de la cita el paciente puede cancelar (el profesional siempre).
AGENDA_CANCELACION_MIN_HORAS = env.int("AGENDA_CANCELACION_MIN_HORAS", default=24)

# Correos de la agenda (B5). El recordatorio va antes del plazo para cancelar o reagendar,
# así el paciente todavía puede hacerlo al recibirlo.
NOTIFICACIONES_RECORDATORIO_HORAS = env.int("NOTIFICACIONES_RECORDATORIO_HORAS", default=48)
NOTIFICACIONES_MAX_INTENTOS = env.int("NOTIFICACIONES_MAX_INTENTOS", default=3)
# Los correos a dominios de ejemplo (@example.com de la demo y las pruebas) se anulan sin
# enviarse: no existen y, con Gmail, rebotarían en la cuenta que envía.
NOTIFICACIONES_OMITIR_FICTICIAS = env.bool("NOTIFICACIONES_OMITIR_FICTICIAS", default=True)

# Pago en línea con Webpay Plus (apps/pagos). Si está activo, un tratamiento con precio se
# paga al reservar: la hora queda retenida PAGOS_PLAZO_MIN minutos mientras se paga.
PAGOS_WEBPAY_ACTIVO = env.bool("PAGOS_WEBPAY_ACTIVO", default=True)
PAGOS_PLAZO_MIN = env.int("PAGOS_PLAZO_MIN", default=15)
# "integracion" usa el comercio de prueba público de Transbank (sin dinero real);
# "produccion" exige el código de comercio y la llave del podólogo.
TRANSBANK_AMBIENTE = env("TRANSBANK_AMBIENTE", default="integracion")
TRANSBANK_CODIGO_COMERCIO = env("TRANSBANK_CODIGO_COMERCIO", default="")
TRANSBANK_API_KEY = env("TRANSBANK_API_KEY", default="")
TRANSBANK_TIMEOUT = env.int("TRANSBANK_TIMEOUT", default=30)
# Tope de citas activas a futuro (pendientes de pago, agendadas o confirmadas) que un paciente
# puede tener reservadas en línea, para que nadie retenga la agenda. 3 está por confirmar con el
# podólogo. Además, solo se permite una reserva esperando pago a la vez.
AGENDA_MAX_CITAS_FUTURAS = env.int("AGENDA_MAX_CITAS_FUTURAS", default=3)

# Asistente virtual (B7, apps/chatbot). Con ANTHROPIC_API_KEY responde Claude (multimodal: lee
# fotos de los pies); sin clave, o si Claude falla o tarda, responde el clasificador por reglas.
ANTHROPIC_API_KEY = env("ANTHROPIC_API_KEY", default="")
CHATBOT_MODELO = env("CHATBOT_MODELO", default="claude-haiku-5-5")
CHATBOT_TIMEOUT_S = env.float("CHATBOT_TIMEOUT_S", default=20.0)
# Mensajes por hora: pacientes (con fotos) y visitantes (solo preguntas frecuentes).
CHATBOT_LIMITE_PACIENTE_HORA = env.int("CHATBOT_LIMITE_PACIENTE_HORA", default=40)
CHATBOT_LIMITE_VISITANTE_HORA = env.int("CHATBOT_LIMITE_VISITANTE_HORA", default=15)
# Visitantes por IP (una sesión nueva por mensaje no se salta el límite). Más alto que el de
# sesión porque varias personas pueden compartir IP (una red de casa, un celular).
CHATBOT_LIMITE_IP_HORA = env.int("CHATBOT_LIMITE_IP_HORA", default=40)
# Las fotos son datos de salud: se borran a los N días (la conversación en texto queda).
CHATBOT_RETENCION_FOTOS_DIAS = env.int("CHATBOT_RETENCION_FOTOS_DIAS", default=7)
CHATBOT_FOTO_MAX_MB = env.int("CHATBOT_FOTO_MAX_MB", default=8)

# Consulta fija donde atiende el podólogo (no hay atención a domicilio). La ve el paciente.
CONSULTA_NOMBRE = env("CONSULTA_NOMBRE", default="Consulta podológica")
CONSULTA_DIRECCION = env("CONSULTA_DIRECCION", default="")
CONSULTA_COMUNA = env("CONSULTA_COMUNA", default="")
CONSULTA_INDICACIONES = env("CONSULTA_INDICACIONES", default="")
CONSULTA_TELEFONO = env("CONSULTA_TELEFONO", default="")
CONSULTA_CORREO = env("CONSULTA_CORREO", default="")
# Texto libre, p. ej. "Lunes a viernes de 9:00 a 18:00".
CONSULTA_HORARIO = env("CONSULTA_HORARIO", default="")

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "estandar": {"format": "%(asctime)s %(levelname)s %(name)s %(message)s"},
    },
    "handlers": {
        "consola": {"class": "logging.StreamHandler", "formatter": "estandar"},
    },
    "root": {"handlers": ["consola"], "level": env("LOG_LEVEL", default="INFO")},
}
