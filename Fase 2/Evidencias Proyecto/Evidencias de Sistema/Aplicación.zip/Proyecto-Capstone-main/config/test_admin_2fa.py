"""Verificación en dos pasos para entrar al panel /admin/ (config/admin.py)."""

from io import StringIO

import pytest
from django.core.management import call_command
from django.test import Client
from django.urls import reverse
from django_otp.oath import totp
from django_otp.plugins.otp_totp.models import TOTPDevice

from apps.cuentas.tests.factories import CLAVE, PacienteFactory, UsuarioFactory

pytestmark = pytest.mark.django_db
VERIFICAR = "/admin/verificar/"


@pytest.fixture(autouse=True)
def con_2fa(settings):
    settings.ADMIN_EXIGE_2FA = True


@pytest.fixture
def admin_usuario():
    return UsuarioFactory(rol="admin", is_staff=True, is_superuser=True)


def _codigo(dispositivo) -> str:
    valor = totp(dispositivo.bin_key, dispositivo.step, dispositivo.t0, dispositivo.digits)
    return str(valor).zfill(dispositivo.digits)


def _entrar(usuario) -> Client:
    cliente = Client()
    assert cliente.login(username=usuario.email, password=CLAVE)
    return cliente


def test_con_solo_la_contrasena_no_se_entra_al_panel(admin_usuario):
    cliente = _entrar(admin_usuario)
    assert cliente.get("/admin/").status_code == 302
    login = cliente.get(reverse("admin:login"), {"next": "/admin/cuentas/usuario/"})
    assert login.status_code == 302
    assert login.url.startswith(VERIFICAR)


def test_la_primera_vez_muestra_el_qr_y_al_confirmar_entra(admin_usuario):
    cliente = _entrar(admin_usuario)
    pagina = cliente.get(VERIFICAR, {"next": "/admin/cuentas/usuario/"})
    assert pagina.status_code == 200
    assert "Código QR para registrar" in pagina.content.decode()
    dispositivo = TOTPDevice.objects.get(user=admin_usuario)
    assert not dispositivo.confirmed
    respuesta = cliente.post(
        VERIFICAR, {"codigo": _codigo(dispositivo), "next": "/admin/cuentas/usuario/"}
    )
    # Al registrar la app se muestran los códigos de respaldo y un enlace para seguir.
    assert respuesta.status_code == 200
    assert "Tus códigos de respaldo" in respuesta.content.decode()
    assert 'href="/admin/cuentas/usuario/"' in respuesta.content.decode()
    dispositivo.refresh_from_db()
    assert dispositivo.confirmed
    assert cliente.get("/admin/").status_code == 200


def test_un_codigo_incorrecto_no_deja_entrar(admin_usuario):
    cliente = _entrar(admin_usuario)
    cliente.get(VERIFICAR)
    respuesta = cliente.post(VERIFICAR, {"codigo": "000000"})
    if respuesta.status_code == 302:  # justo era el código vigente: probabilidad 1 en un millón
        pytest.skip("El código de prueba coincidió con el real.")
    assert respuesta.status_code == 400
    assert cliente.get("/admin/").status_code == 302


def test_en_una_sesion_nueva_pide_el_codigo_sin_mostrar_el_qr(admin_usuario):
    dispositivo = TOTPDevice.objects.create(user=admin_usuario, name="app", confirmed=True)
    cliente = _entrar(admin_usuario)
    pagina = cliente.get(VERIFICAR).content.decode()
    assert "Código QR para registrar" not in pagina
    assert TOTPDevice.objects.filter(user=admin_usuario).count() == 1
    cliente.post(VERIFICAR, {"codigo": _codigo(dispositivo)})
    assert cliente.get("/admin/").status_code == 200


def test_no_redirige_a_otro_sitio_despues_del_codigo(admin_usuario):
    dispositivo = TOTPDevice.objects.create(user=admin_usuario, name="app", confirmed=True)
    cliente = _entrar(admin_usuario)
    respuesta = cliente.post(
        VERIFICAR, {"codigo": _codigo(dispositivo), "next": "https://otro.example.com/"}
    )
    assert respuesta.url == reverse("admin:index")


def test_el_panel_acepta_un_codigo_de_respaldo(admin_usuario):
    from apps.cuentas import dos_pasos

    disp = dos_pasos.preparar(admin_usuario)
    codigos = dos_pasos.confirmar(admin_usuario, codigo=_codigo(disp), sitio="https://x.example")
    cliente = _entrar(admin_usuario)
    respuesta = cliente.post(VERIFICAR, {"codigo": codigos[0]})
    assert respuesta.status_code == 302
    assert cliente.get("/admin/").status_code == 200


def test_un_paciente_no_llega_a_la_verificacion():
    paciente = PacienteFactory()
    cliente = _entrar(paciente.usuario)
    assert cliente.get(VERIFICAR).status_code == 302
    assert not TOTPDevice.objects.exists()


def test_quitar_2fa_borra_el_dispositivo(admin_usuario):
    TOTPDevice.objects.create(user=admin_usuario, name="app", confirmed=True)
    call_command("quitar_2fa", admin_usuario.email, stdout=StringIO())
    assert not TOTPDevice.objects.filter(user=admin_usuario).exists()


# --- nombres en el panel: "Verificación en dos pasos" y "Dispositivos de verificación" ---

DISPOSITIVOS = "/admin/cuentas/dispositivoverificacion/"
NOMBRES_VIEJOS = ("Otp_Totp", "Otp_totp", "TOTP device", "TOTP Device")


def _verificado(usuario) -> Client:
    """Un administrador que ya pasó la verificación en dos pasos."""
    dispositivo = TOTPDevice.objects.create(user=usuario, name="app", confirmed=True)
    cliente = _entrar(usuario)
    assert cliente.post(VERIFICAR, {"codigo": _codigo(dispositivo)}).status_code == 302
    return cliente


@pytest.mark.parametrize("url", ["/admin/", "/admin/cuentas/", DISPOSITIVOS, f"{DISPOSITIVOS}add/"])
def test_el_panel_nombra_los_dispositivos_en_espanol(admin_usuario, url):
    cliente = _verificado(admin_usuario)
    respuesta = cliente.get(url)
    html = respuesta.content.decode()
    assert respuesta.status_code == 200
    assert "ispositivos de verificación" in html or "ispositivo de verificación" in html
    for viejo in NOMBRES_VIEJOS:
        assert viejo not in html


def test_la_ficha_del_dispositivo_y_sus_migas_estan_en_espanol(admin_usuario):
    cliente = _verificado(admin_usuario)
    dispositivo = TOTPDevice.objects.get(user=admin_usuario)
    html = cliente.get(f"{DISPOSITIVOS}{dispositivo.pk}/change/").content.decode()
    assert 'href="/admin/cuentas/">Cuentas</a>' in html
    assert "Dispositivos de verificación" in html
    assert "Freno de intentos fallidos" in html
    for viejo in NOMBRES_VIEJOS:
        assert viejo not in html


def test_la_app_del_plugin_tiene_nombre_propio_y_no_tiene_pagina_aparte(admin_usuario):
    from django.apps import apps

    assert apps.get_app_config("otp_totp").verbose_name == "Verificación en dos pasos"
    cliente = _verificado(admin_usuario)
    assert cliente.get("/admin/otp_totp/totpdevice/").status_code == 404


def test_otro_administrador_borra_el_dispositivo_de_quien_perdio_el_telefono(admin_usuario):
    perdido = UsuarioFactory(rol="admin", is_staff=True, is_superuser=True)
    dispositivo = TOTPDevice.objects.create(user=perdido, name="app", confirmed=True)
    cliente = _verificado(admin_usuario)
    borrar = f"{DISPOSITIVOS}{dispositivo.pk}/delete/"
    assert cliente.get(borrar).status_code == 200
    assert cliente.post(borrar, {"post": "yes"}).status_code == 302
    assert not TOTPDevice.objects.filter(user=perdido).exists()
    assert TOTPDevice.objects.filter(user=admin_usuario).exists()
    # La próxima vez que entre se le pide registrar la app de nuevo, con un QR nuevo.
    otro = _entrar(perdido)
    assert "Código QR para registrar" in otro.get(VERIFICAR).content.decode()
