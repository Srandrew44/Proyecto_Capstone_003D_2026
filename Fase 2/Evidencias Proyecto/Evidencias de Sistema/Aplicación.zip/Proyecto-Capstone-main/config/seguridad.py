"""Cabeceras de seguridad que Django 5.2 no pone por sí solo.

- Content-Security-Policy: el navegador solo ejecuta scripts y carga estilos, fuentes y
  datos de este mismo sitio. El sitio no tiene scripts en línea (htmx y static/web/js), así
  que aunque se colara HTML ajeno en una página, su código no correría. El panel /admin/ es
  de Django y usa algo de JavaScript en línea: ahí se permite, solo ahí.
- Cache-Control en la API y en las páginas con sesión: la ficha clínica y los datos del
  paciente no quedan guardados en la caché del navegador ni de un proxy (importa en un
  computador compartido, como el de la consulta).
"""

from django.conf import settings
from django.utils.cache import add_never_cache_headers

_COMUN = [
    "default-src 'self'",
    "img-src 'self' data:",
    "font-src 'self'",
    "connect-src 'self'",
    "object-src 'none'",
    "base-uri 'self'",
    # El pago envía al paciente, con un formulario, a Webpay (integración y producción).
    "form-action 'self' https://webpay3gint.transbank.cl https://webpay3g.transbank.cl",
    "frame-ancestors 'none'",
]
POLITICA_CSP = "; ".join([*_COMUN, "script-src 'self'", "style-src 'self'"])
POLITICA_CSP_ADMIN = "; ".join(
    [*_COMUN, "script-src 'self' 'unsafe-inline'", "style-src 'self' 'unsafe-inline'"]
)
POLITICA_PERMISOS = "camera=(), microphone=(), geolocation=(), payment=(), usb=()"


class CabecerasDeSeguridad:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        respuesta = self.get_response(request)
        politica = POLITICA_CSP_ADMIN if request.path.startswith("/admin/") else POLITICA_CSP
        respuesta.setdefault("Content-Security-Policy", politica)
        respuesta.setdefault("Permissions-Policy", POLITICA_PERMISOS)
        if not request.path.startswith("/" + settings.STATIC_URL.lstrip("/")):
            usuario = getattr(request, "user", None)
            con_sesion = usuario is not None and usuario.is_authenticated
            # Si la vista ya fijó su propia política (los PDF: no-store), se respeta.
            if (request.path.startswith("/api/") or con_sesion) and not respuesta.has_header(
                "Cache-Control"
            ):
                add_never_cache_headers(respuesta)
        return respuesta
