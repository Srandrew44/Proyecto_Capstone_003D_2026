# Despliegue en Render y Neon

La aplicación corre en Render (plan gratis) y la base PostgreSQL en Neon (plan gratis). `render.yaml` crea un solo servicio, `mypodo-web`, con Gunicorn y WhiteNoise.

**Usa solo datos ficticios.** Para datos reales de pacientes, el cliente debe autorizar antes que se guarden en estos servicios, y el asistente envía fotos de salud a Anthropic.

## Cómo se resuelve lo que no trae el plan gratis

Render gratis no tiene tareas programadas y bloquea el correo SMTP (decisiones del 11/11/2026):

- **Correo por API (Brevo).** Los correos salen por la API HTTPS de Brevo, que Render no bloquea. Los de la cuenta (confirmar el registro, recuperar la contraseña, "tu contraseña cambió") salen al momento. Ver el paso 3.
- **Tareas cada hora con GitHub Actions** (`.github/workflows/tareas.yml`). Llama a `POST /tareas/ejecutar/` con un token secreto, y el sitio corre lo mismo que `manage.py enviar_notificaciones`:
  - correos y recordatorios pendientes;
  - pagos "por verificar" y reembolsos que fallaron;
  - borrar las fotos del asistente a los 7 días;
  - borrar los registros sin confirmar y las sesiones vencidas.
- **Cada hora y no más seguido:** cada llamada despierta la base de Neon unos 5 minutos, y Neon gratis da 100 horas de cómputo al mes. Por eso un correo de reserva puede tardar hasta una hora. GitHub puede atrasar unos minutos las ejecuciones, y las pausa si el repositorio pasa 60 días sin actividad (se reactivan en la pestaña Actions).
- **Sin los secretos de GitHub (paso 3)**, nada de esto corre solo: hay que correr las tareas a mano (paso 5).
- **Lo que funciona solo de todos modos:** las reservas impagas se liberan al reservar y al abrir "Mis citas".

## 1. Antes de empezar

- El código que se despliega es la rama `main` de `Srandrew44/Proyecto-Capstone`. Lo que no esté subido ahí no se publica.
- Quien lo hace debe tener acceso de dueño al repositorio en GitHub (Sebastián).

## 2. Crear la base en Neon

> **Hecho el 08/11/2026.** El proyecto existe: **Mypodo** (`little-voice-96394216`, rama `production`, AWS us-east-2), en la cuenta de Sebastián. Usa **PostgreSQL 18**, no 16: Django 5.2 funcionó sin cambios (migraciones, `btree_gist` 1.8, restricciones y trigger de auditoría verificados). Ya tiene las migraciones y el escenario demo; falta el administrador.
>
> La cadena de conexión se obtiene con el CLI de Neon, sin escribirla en ningún archivo:
>
> ```bash
> npm i -g neon@latest
> neon login
> neon cs production --project-id little-voice-96394216
> ```

1. Crea una cuenta en https://neon.com (se puede entrar con GitHub).
2. Crea un proyecto:
   - **Postgres version:** la del proyecto actual es 18. Docker y la CI usan 16, y Django 5.2 funciona igual con las dos.
   - **Región:** AWS US East 2 (Ohio), cerca de Render.
   - **Nombre de la base:** `mypodo` (cualquiera sirve).
3. En **Connect**, copia la cadena de conexión:
   - Elige la **directa**: desactiva "Connection pooling", que pone `-pooler` en el nombre del servidor.
   - Debe terminar con `sslmode=require`.
   - Tiene esta forma: `postgresql://usuario:clave@ep-xxxx.us-east-2.aws.neon.tech/mypodo?sslmode=require`.
   - Guárdala en un lugar seguro: da acceso total a la base.

Neon gratis incluye 1 GB de datos y 100 horas de cómputo al mes. La base se apaga tras 5 minutos sin uso; la primera visita después tarda unos segundos más. Ya soporta la extensión `btree_gist`, que usa la agenda. La crea la primera migración.

## 3. Crear el sitio en Render

1. Crea una cuenta en https://dashboard.render.com con GitHub y autoriza el acceso a `Proyecto-Capstone`.
2. Elige **New → Blueprint**, selecciona el repositorio y la rama `main`. Render lee `render.yaml`.
3. Render pide los valores marcados como secretos. Se escriben solo en su panel:

| Variable | Valor |
|---|---|
| `DATABASE_URL` | La cadena de Neon del paso 2. Aunque no traiga `sslmode=require`, la conexión va cifrada igual. |
| `ANTHROPIC_API_KEY` | La clave de Anthropic para el asistente. Si aún no hay, déjala vacía: el asistente responde por reglas. |
| `BREVO_API_KEY` | La clave de API de Brevo (ver abajo). Sin ella no sale ningún correo. |
| `DEFAULT_FROM_EMAIL` | El remitente verificado en Brevo, p. ej. `MyPodo <citas@dominio.cl>`. |

Opcionales, para la portada y la política de privacidad: `CONSULTA_DIRECCION`, `CONSULTA_COMUNA`, `CONSULTA_TELEFONO`, `CONSULTA_CORREO` y `CONSULTA_HORARIO` (p. ej. "Lunes a viernes de 9:00 a 18:00").

4. Presiona **Apply**. La primera compilación tarda unos minutos.
   - `SECRET_KEY` y `TAREAS_TOKEN` los genera Render.
   - Las migraciones corren cada vez que arranca el sitio (una de ellas crea la tabla de caché).
   - El dominio queda como `https://mypodo-web.onrender.com` (o parecido).

**Correo con Brevo (una vez).**

1. Crea una cuenta gratis en https://www.brevo.com. El plan gratis envía unos 300 correos al día.
2. En **Senders, Domains & Dedicated IPs**, verifica el remitente:
   - lo ideal es un dominio propio, autenticado con los registros DNS que indica Brevo, para no caer en spam;
   - para probar basta un correo verificado.
3. En **SMTP & API → API Keys → Generar nueva clave API**, crea la clave:
   - **Nombre:** `mypodo-render`.
   - **Acceso:** **Restringido**, con **Emails transaccionales: Todos** y todo lo demás en
     **Ninguno**. Si la clave se filtrara, solo serviría para enviar correos.
   - Brevo la muestra una sola vez: pégala directo en `BREVO_API_KEY` en Render (nunca en un chat
     ni en un archivo) y guarda con **Save, rebuild, and deploy**.
   - **Vence al año, o antes si pasa 90 días sin usarse** (por ejemplo, unas vacaciones sin
     reservas). Si dejan de llegar los correos, revisa en Brevo si venció y crea otra igual.
     La creada el 12/11/2026 vence el 12/11/2027.
4. Prueba: en el sitio, "¿Olvidaste tu contraseña?" con tu correo de administrador.

**Tareas cada hora (una vez).** En GitHub, **Settings → Secrets and variables → Actions → New repository secret**, crea dos secretos:

| Secreto | Valor |
|---|---|
| `TAREAS_URL` | `https://<sitio>.onrender.com/tareas/ejecutar/` |
| `TAREAS_TOKEN` | El valor de `TAREAS_TOKEN` en el panel de Render (Environment). |

Para probar sin esperar una hora: pestaña **Actions → Tareas periódicas → Run workflow**. Debe terminar en verde y mostrar `{"estado": "ok", ...}`.

## 4. Comprobar

1. Abre `https://<sitio>.onrender.com/salud/`: debe responder `{"estado": "ok"}`.
2. Carga los datos iniciales (paso 5) y entra con una cuenta.
3. Reserva una hora y paga con la tarjeta de prueba de Webpay (abajo). Revisa la vuelta al comprobante.
4. **IP real detrás del proxy.** El bloqueo de intentos de login y la auditoría necesitan la IP del visitante, no la del proxy de Render:
   1. Busca tu IP pública en https://ifconfig.me.
   2. Haz un login fallido en el sitio publicado.
   3. Desde tu equipo (paso 5), revisa la IP guardada:

      ```powershell
      docker compose run --rm -e DATABASE_URL web python manage.py shell -c "from apps.auditoria.models import RegistroAuditoria as R; print(R.objects.filter(accion='login_fallido').order_by('-fecha').values_list('ip', flat=True)[:3])"
      ```

   4. Si sale tu IP, está bien. Si sale otra, ajusta `PROXIES_DE_CONFIANZA` en el panel y repite:
      - una `10.x` (interna de Render) significa que falta un proxy;
      - una de Cloudflare (por ejemplo `104.x`) significa que falta otro.

   **Medido el 08/11/2026:** el valor correcto es **3** (Cloudflare, el balanceador de Render y un proxy interno). Con 3 se guardó la IP real, y una IP inventada en `X-Forwarded-For` se ignoró.

**Panel de administración con verificación en dos pasos.**

1. Al entrar a `/admin/` por primera vez, después de la contraseña aparece un código QR.
2. Escanéalo con una app de autenticación (Google Authenticator, Microsoft Authenticator u otra) y escribe el código de 6 dígitos.
3. Desde entonces, cada sesión nueva pide el código.

Si alguien pierde el teléfono, hay dos formas de quitarle el dispositivo; la próxima vez verá un QR nuevo:

- **Desde el panel**, otro administrador ya verificado: **Cuentas → Dispositivos de verificación**, borra el de esa cuenta. Por eso conviene que haya al menos dos administradores con 2FA.
- **Desde un equipo** (paso 5), si no hay otro administrador:

```powershell
docker compose run --rm -e DATABASE_URL web python manage.py quitar_2fa <correo>
```

Para un monitor externo (por ejemplo UptimeRobot, gratis): usa `https://<sitio>.onrender.com/salud/bd/`, que además comprueba la base. El chequeo de Render usa `/salud/`, que no la toca, para no despertar a Neon.

## 5. Tareas desde un equipo del equipo (sin consola en Render)

Se corren desde la raíz del repositorio, en PowerShell, con Docker corriendo, apuntando a la base de Neon:

```powershell
$env:DATABASE_URL = "<cadena de conexión de Neon>"
```

**Datos iniciales (una vez):**

```powershell
docker compose run --rm -e DATABASE_URL web python manage.py migrate
docker compose run --rm -e DATABASE_URL web python manage.py cargar_escenario_demo
```

**Administrador**, con una contraseña nueva y segura:

```powershell
$env:DJANGO_SUPERUSER_PASSWORD = "<contraseña nueva>"
docker compose run --rm -e DATABASE_URL -e DJANGO_SUPERUSER_PASSWORD web python manage.py createsuperuser --noinput --email <correo> --nombre <nombre> --apellido <apellido>
```

**Tareas del notificador** (correos, pagos por verificar, reembolsos, fotos vencidas, limpieza). Normalmente las corre GitHub Actions cada hora; a mano, por ejemplo antes de una demo:

```powershell
docker compose run --rm -e DATABASE_URL web python manage.py enviar_notificaciones
```

Los correos salen por el servidor que tenga tu `.env`: Mailpit en local o Gmail si lo configuraste (ver `.env.example`). Los correos a `@example.com` de la demo se anulan sin enviarse.

**Al terminar**, borra la cadena de la sesión:

```powershell
Remove-Item Env:DATABASE_URL, Env:DJANGO_SUPERUSER_PASSWORD -ErrorAction SilentlyContinue
```

**Proteger las cuentas demo (obligatorio en el sitio público).** El escenario demo crea las cuentas `@example.com` con una contraseña que está escrita en el código. Para cambiarla por una que solo conozca el equipo (no se ve al escribirla ni queda en el historial):

```powershell
$s = Read-Host "Clave nueva de las cuentas demo" -AsSecureString; $env:DEMO_CLAVE_NUEVA = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s))
docker compose run --rm -e DATABASE_URL -e DEMO_CLAVE_NUEVA web python manage.py cambiar_claves_demo
Remove-Item Env:DEMO_CLAVE_NUEVA; Remove-Variable s
```

O para bloquearlas del todo: `docker compose run --rm -e DATABASE_URL web python manage.py cambiar_claves_demo --desactivar`. No afecta al administrador ni a cuentas reales.

## Pago con Webpay Plus (Transbank)

- Se usa el **ambiente de integración** (`TRANSBANK_AMBIENTE=integracion`): no se cobra dinero real ni se necesitan claves.
- La URL de retorno se arma sola con el dominio de Render.
- **Datos de prueba:**
  - Tarjeta VISA 4051 8856 0044 6623, CVV 123 y cualquier fecha futura.
  - En el banco simulado: RUT 11.111.111-1 y clave 123.
- **Para cobrar de verdad:**
  - El podólogo debe contratar Webpay Plus con Transbank y pasar su validación.
  - Después se agregan en el panel `TRANSBANK_AMBIENTE=produccion`, `TRANSBANK_CODIGO_COMERCIO` y `TRANSBANK_API_KEY`. Si falta alguno, la aplicación no arranca.
  - Con dinero real, las tareas de GitHub Actions deben estar activas: sin ellas, un reembolso que falla queda en `/admin/` → Pagos ("Reembolso pendiente") hasta que alguien corra las tareas.

## Límites conocidos

- **Primera visita:** el sitio gratis se duerme tras 15 minutos sin visitas y tarda cerca de un minuto en despertar. Neon suma unos segundos.
- **Región:** Render no tiene región en Sudamérica.
- **Fotos del asistente:** se guardan en la base (Render gratis no tiene disco persistente). Cuentan para el 1 GB de Neon hasta que se borran.
- **Correos:** el plan gratis de Brevo envía unos 300 al día.

## Respaldos y recuperación

La base tiene datos de salud y una auditoría que no se puede modificar: perderla no tiene arreglo. **Por confirmar en el panel de Neon:** cuántos días hacia atrás permite restaurar el plan gratis.

**Antes de cada cambio importante y una vez por semana**, saca un respaldo desde un equipo. Usa la imagen de PostgreSQL de Docker, así no hay que instalar nada:

```powershell
$env:DATABASE_URL = "<cadena de conexión de Neon>"
docker run --rm -e DATABASE_URL -v "${PWD}:/respaldo" postgres:18 sh -c 'pg_dump "$DATABASE_URL" -Fc -f /respaldo/mypodo-$(date +%Y%m%d).dump'
Remove-Item Env:DATABASE_URL
```

- El archivo `.dump` tiene datos de salud. Guárdalo **cifrado** (por ejemplo en un archivo 7-Zip con contraseña, AES-256) y fuera del repositorio. Nunca lo subas a GitHub ni a un servicio sin cifrar.
- **Para restaurar sin pisar la base actual:**
  1. En Neon, crea una rama nueva (Branches → New branch) o una base vacía.
  2. Restaura en ella con `pg_restore --no-owner -d "<cadena de la rama>" mypodo-AAAAMMDD.dump`.
  3. Revisa los datos y cambia `DATABASE_URL` en Render a esa rama.
- **Prueba la restauración una vez:** un respaldo que nunca se restauró no está comprobado.

## Rotación de secretos

Rota un secreto si pudo quedar a la vista (en un chat, una captura o un archivo subido) o si alguien con acceso deja el equipo.

| Secreto | Cómo rotarlo | Qué pasa al rotarlo |
|---|---|---|
| Contraseña de Neon | En Neon, **Roles → Reset password**. Copia la cadena nueva a `DATABASE_URL` en Render. | El sitio se reinicia con la cadena nueva. |
| `SECRET_KEY` | En Render, borra el valor y genera uno nuevo. | Se cierran todas las sesiones, y los enlaces de recuperar la contraseña y de confirmar el registro dejan de servir. |
| `TAREAS_TOKEN` | Genera uno nuevo en Render y cópialo al secreto de GitHub. | Hasta copiarlo, las tareas fallan con 404. |
| `BREVO_API_KEY`, `ANTHROPIC_API_KEY` | Crea una clave nueva en su panel, cámbiala en Render y borra la vieja. | Nada, si se cambia en orden. |
| Transbank (producción) | La entrega Transbank al comercio. | Pagos en pausa mientras no esté. |
