# MyPodo — citas y ficha clínica podológica

Sistema web para una consulta podológica: los pacientes reservan y pagan su hora en línea, y los
podólogos llevan la agenda, la ficha clínica y las derivaciones. Incluye un asistente virtual que
orienta a los pacientes, también a partir de fotos de sus pies.

Proyecto APT de Ingeniería en Informática, Duoc UC, desarrollado por **Sebastián González** y
**Matías Pino**, con un podólogo real como cliente.

**Sitio publicado:** https://mypodo-web.onrender.com (plan gratis de Render: la primera visita tras
un rato sin uso puede tardar cerca de un minuto en despertar).

## Qué hace

| Rol | Funcionalidades |
|---|---|
| **Visitante** | Portada con tratamientos, precios y equipo; registro de paciente; asistente virtual para preguntas frecuentes. |
| **Paciente** | Consentimiento informado; reserva en tres pasos (podólogo, tratamiento, hora) con **pago en Webpay**; cancelar y reagendar hasta 24 h antes con **reembolso automático**; ficha clínica y derivaciones en PDF; correos de confirmación y recordatorio; **asistente virtual** con orientación por síntomas y fotos; editar su perfil y su contraseña. |
| **Podólogo** | Agenda del día, atender citas e inasistencias; fichas clínicas con antecedentes, atenciones con corrección enlazada y dibujo de los pies; derivaciones en PDF; horario semanal y bloqueos; informe de gestión con PDF; editar su perfil. |
| **Administrador** | Panel `/admin/` con el diseño de MyPodo (podólogos, tratamientos, pagos, auditoría); informes de toda la consulta. |

Seguridad y privacidad: contraseñas con Argon2 (mínimo 10 caracteres), registro que se confirma
por correo sin revelar quién ya es paciente, recuperación de contraseña con enlace de un solo uso,
verificación en dos pasos para el panel `/admin/`, sesiones de 8 h, freno de intentos de login,
auditoría de solo escritura de cada acceso a datos de salud, política de seguridad de contenido
(CSP) sin scripts en línea, y ningún dato de identificación enviado al modelo de lenguaje.

## Tecnología

- Python 3.12, **Django 5.2**, Django REST Framework, **PostgreSQL 16** (restricciones de exclusión
  con `btree_gist` para que nunca haya citas cruzadas).
- Plantillas de Django con **htmx** y **Tailwind** (el CSS compilado se versiona: Docker no necesita Node).
- **Webpay Plus** (Transbank) para los pagos, **Claude** (Anthropic) para el asistente, ReportLab para los PDF.
- Docker Compose en desarrollo; **Render** + **Neon** en producción.
- Calidad: pytest (más de 800 pruebas), Playwright (40 pruebas de punta a punta), ruff, CI en GitHub Actions y gitleaks.

## Arranque local (Windows)

Requisitos: **Git para Windows** y **Docker Desktop** (con WSL2). No hace falta instalar Python ni
PostgreSQL. En PowerShell:

```powershell
git clone https://github.com/Srandrew44/Proyecto-Capstone.git
cd Proyecto-Capstone
.\tasks.ps1 up      # crea .env desde .env.example, construye y levanta todo, y migra
.\tasks.ps1 demo    # carga datos ficticios para recorrer el sitio
```

Si PowerShell bloquea el script: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.
Revisa `.env` y cambia `SECRET_KEY` por un valor propio.

| Qué | Dónde |
|---|---|
| Sitio | http://localhost:8000/ |
| Panel de administración | http://localhost:8000/admin/ |
| Correos de desarrollo (Mailpit) | http://localhost:8025 |
| Comprobación | http://localhost:8000/salud/ |

**Datos de demostración:** `.\tasks.ps1 demo` crea 2 podólogos y 5 pacientes `@example.com` con
citas, fichas y atenciones. La contraseña de todos está en la constante `CLAVE` de
`apps/web/management/commands/cargar_escenario_demo.py`. Solo para desarrollo: en el sitio
publicado esas cuentas están desactivadas.

**Administrador local** (el `createsuperuser` interactivo no acepta la contraseña dentro de Docker
en Windows; así sí funciona):

```powershell
$env:DJANGO_SUPERUSER_PASSWORD = "<contraseña>"
docker compose run --rm -e DJANGO_SUPERUSER_PASSWORD web python manage.py createsuperuser --noinput --email <correo> --nombre <nombre> --apellido <apellido>
```

## Comandos

`.\tasks.ps1` sin argumentos muestra la lista completa.

```powershell
.\tasks.ps1 up          # levanta todo (Django, PostgreSQL, Mailpit y el notificador de correos)
.\tasks.ps1 down        # detiene los contenedores
.\tasks.ps1 test        # pruebas (acepta argumentos de pytest)
.\tasks.ps1 lint        # revisa el estilo con ruff
.\tasks.ps1 format      # corrige el estilo
.\tasks.ps1 migrate     # aplica migraciones
.\tasks.ps1 demo        # datos de demostración
.\tasks.ps1 css         # recompila Tailwind tras cambiar plantillas (necesita Node)
.\tasks.ps1 logs        # registros de Django
.\tasks.ps1 shell       # consola de Django
.\tasks.ps1 reset-db    # borra la base local (pide confirmación)
```

## Pagos con Webpay

Al reservar, la cita queda **pendiente de pago** y la hora retenida 15 minutos mientras el paciente
paga en Webpay. Si se aprueba, se confirma y sale el correo; si se rechaza, se abandona o vence, la
hora se libera. Al cancelar una cita pagada, el reembolso es automático.

En desarrollo y en el sitio publicado se usa el **ambiente de integración** de Transbank: no se
cobra dinero real. Datos de prueba públicos de Transbank:

- Tarjeta VISA `4051 8856 0044 6623`, CVV `123`, cualquier fecha futura.
- Banco simulado: RUT `11.111.111-1`, clave `123`.

Para cobrar de verdad, el podólogo debe contratar Webpay Plus y configurar `TRANSBANK_AMBIENTE=produccion`,
`TRANSBANK_CODIGO_COMERCIO` y `TRANSBANK_API_KEY`.

## Asistente virtual

`/asistente/` responde preguntas frecuentes a cualquiera. Un paciente que acepta el consentimiento
"uso del asistente" puede además describir síntomas y adjuntar fotos de sus pies para recibir una
**orientación preliminar** (podología, traumatología, dermatología o urgencia). **No diagnostica.**

- Con `ANTHROPIC_API_KEY` en `.env` responde Claude (multimodal); sin clave, o si Claude falla,
  responde un clasificador por reglas. Las señales de alarma se revisan siempre.
- Al modelo no se envían nombre, RUT ni contacto. Las fotos se guardan sin metadatos y se borran a
  los 7 días.
- La base de conocimientos (`apps/chatbot/conocimiento.py`) está **pendiente de validación por el
  podólogo**; la página lo indica.

## Estructura

```
config/            ajustes (base, dev, test, prod), urls, seguridad (CSP y cabeceras)
apps/
  cuentas/         usuario, paciente y profesional; registro, login, freno de intentos, perfil
  agenda/          tratamientos, horarios, citas, bloqueos, notificaciones por correo
  clinica/         consentimientos, ficha, atenciones, derivaciones en PDF, informes de gestión
  pagos/           pagos y reembolsos con Webpay
  chatbot/         asistente virtual: conversaciones, triaje, fotos, base de conocimientos
  auditoria/       registro de accesos y acciones sensibles (solo escritura, con trigger en la base)
  web/             páginas del sitio (vistas, plantillas htmx, estáticos y comandos de demo)
integraciones/     clientes externos: Webpay (Transbank) y Claude (Anthropic)
templates/admin/   diseño del panel de administración
frontend/          fuentes de Tailwind (estilos.css) y su compilación
pruebas_e2e/       pruebas de punta a punta con Playwright (ver su README)
docs/              guía de despliegue en Render y Neon
```

Cada app sigue la misma plantilla: `models.py`, `services.py` (reglas de negocio y escrituras),
`selectors.py` (consultas filtradas por el usuario que pregunta), `api/` y `tests/`.

## API REST

Autenticación por sesión con cookie; los POST necesitan el token CSRF (`GET /api/auth/csrf/` y el
encabezado `X-CSRFToken`). Sin sesión responde 403, y un recurso ajeno responde 404.

| Grupo | Rutas principales |
|---|---|
| Cuentas | `auth/csrf/`, `auth/registro/`, `auth/login/`, `auth/logout/`, `auth/yo/` |
| Agenda | `consulta/`, `tratamientos/`, `profesionales/`, `horarios-libres/`, `citas/` (y `cancelar/`, `reagendar/`, `inasistencia/`), `agenda-del-dia/`, `notificaciones/`, `bloqueos/`, `disponibilidades/` |
| Clínica | `consentimientos/`, `pacientes/`, `pacientes/<id>/ficha/`, `mi-ficha/`, `atenciones/<id>/`, `derivaciones/<id>/pdf/`, `informes/`, `informes/pdf/` |

Todas cuelgan de `/api/`. Reservar por API devuelve la cita pendiente de pago con su `pago_url`.

## Pruebas

```powershell
.\tasks.ps1 test                 # pytest: modelos, servicios, API, vistas y seguridad
cd pruebas_e2e; npm install; npm test   # Playwright: recorre el sitio en un navegador real
```

Las pruebas E2E usan su propia base (`mypodo_e2e`) y un servidor en el puerto 8001: no tocan tu
base de desarrollo. Detalle en [pruebas_e2e/README.md](pruebas_e2e/README.md).

## Despliegue

El sitio corre en **Render** (plan gratis) con la base en **Neon** (PostgreSQL). Render despliega
solo cada cambio que entra a `main`. La guía paso a paso, incluidas las variables de entorno, las
tareas que se corren a mano (no hay cron en el plan gratis) y la verificación de la IP real detrás
del proxy, está en [docs/DESPLIEGUE_RENDER.md](docs/DESPLIEGUE_RENDER.md).

## Reglas de trabajo

- Una rama por cambio (idealmente por tarjeta de Trello: `tarjeta-<n>-descripcion`).
- Nada entra a `main` sin pull request; la CI debe pasar (lint, formato, migraciones al día,
  pruebas y escaneo de secretos).
- Nunca subas `.env`, claves ni datos reales de pacientes.
