# Comandos cortos para trabajar en Windows (PowerShell). Uso: .\tasks.ps1 <comando>
# Todo corre dentro de Docker: no hace falta instalar Python ni PostgreSQL.
param(
    [Parameter(Position = 0)]
    [string]$Comando = "ayuda",
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$Resto
)

$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

function Invoke-Docker {
    docker @args
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}

function Initialize-Env {
    if (-not (Test-Path ".env")) {
        Copy-Item ".env.example" ".env"
        Write-Host "Se creo .env a partir de .env.example. Revisalo antes de seguir."
    }
}

switch ($Comando) {
    "setup" {
        Initialize-Env
    }
    "up" {
        Initialize-Env
        Invoke-Docker compose up --build -d
        Write-Host ""
        Write-Host "Sitio:       http://localhost:8000/"
        Write-Host "Admin:       http://localhost:8000/admin/"
        Write-Host "Correos dev: http://localhost:8025"
    }
    "down" {
        Invoke-Docker compose down
    }
    "logs" {
        Invoke-Docker compose logs -f web
    }
    "migrate" {
        Invoke-Docker compose run --rm web python manage.py migrate
    }
    "makemigrations" {
        Invoke-Docker compose run --rm web python manage.py makemigrations @Resto
    }
    "test" {
        Initialize-Env
        Invoke-Docker compose run --rm -e DJANGO_SETTINGS_MODULE=config.settings.test web python -m pytest @Resto
    }
    "lint" {
        Invoke-Docker compose run --rm web sh -c "ruff check . && ruff format --check ."
    }
    "format" {
        Invoke-Docker compose run --rm web sh -c "ruff check --fix . && ruff format ."
    }
    "shell" {
        Invoke-Docker compose run --rm web python manage.py shell
    }
    "css" {
        # Recompila Tailwind tras cambiar plantillas o frontend/estilos.css (necesita Node).
        Push-Location frontend
        if (-not (Test-Path node_modules)) { npm install }
        npm run build
        Pop-Location
    }
    "superuser" {
        Invoke-Docker compose run --rm web python manage.py createsuperuser
    }
    "demo" {
        Invoke-Docker compose run --rm web python manage.py cargar_escenario_demo
    }
    "psql" {
        Invoke-Docker compose exec db sh -c 'psql -U $POSTGRES_USER -d $POSTGRES_DB'
    }
    "reset-db" {
        $r = Read-Host "Esto BORRA la base de datos local. Escribe SI para continuar"
        if ($r -eq "SI") {
            Invoke-Docker compose down -v
        } else {
            Write-Host "Cancelado."
        }
    }
    default {
        Write-Host "Comandos disponibles:"
        Write-Host "  setup           Crea .env desde .env.example"
        Write-Host "  up              Construye y levanta todo (Django, Postgres, Mailpit)"
        Write-Host "  down            Detiene los contenedores"
        Write-Host "  logs            Muestra los registros de Django"
        Write-Host "  migrate         Aplica las migraciones"
        Write-Host "  makemigrations  Genera migraciones (acepta argumentos de Django)"
        Write-Host "  test            Corre pytest (acepta argumentos de pytest)"
        Write-Host "  lint            Revisa estilo con ruff"
        Write-Host "  format          Corrige estilo con ruff"
        Write-Host "  shell           Abre la consola de Django"
        Write-Host "  css             Recompila el CSS de Tailwind (necesita Node)"
        Write-Host "  superuser       Crea un administrador"
        Write-Host "  demo            Carga datos ficticios para recorrer el sitio (solo desarrollo)"
        Write-Host "  psql            Abre la consola de PostgreSQL"
        Write-Host "  reset-db        Borra la base de datos local"
    }
}
