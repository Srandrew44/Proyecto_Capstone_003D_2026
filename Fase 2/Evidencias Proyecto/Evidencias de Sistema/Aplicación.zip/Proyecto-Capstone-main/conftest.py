"""Configuración compartida de pytest."""

import pytest
from django.core.cache import cache
from rest_framework.test import APIClient


@pytest.fixture(autouse=True)
def _cache_limpia():
    """Los límites de solicitudes (throttling) viven en la caché: cada prueba parte de cero."""
    cache.clear()
    yield
    cache.clear()


@pytest.fixture
def api_client():
    return APIClient()
