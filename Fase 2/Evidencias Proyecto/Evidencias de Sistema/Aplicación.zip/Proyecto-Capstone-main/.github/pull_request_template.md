## Qué cambia
<!-- Resumen breve y enlace a la tarjeta de Trello -->

## Checklist
- [ ] La rama sigue el formato `tarjeta-<n>-descripcion`
- [ ] Las pruebas pasan (`.\tasks.ps1 test`) y el lint está limpio (`.\tasks.ps1 lint`)
- [ ] Las consultas nuevas filtran por el usuario que pregunta
- [ ] Hay pruebas para la lógica nueva (permisos o casos límite, si aplica)
- [ ] No hay claves, contraseñas ni datos reales en el código
- [ ] Lo revisó la otra persona del equipo (obligatorio para entrar a `main`)
