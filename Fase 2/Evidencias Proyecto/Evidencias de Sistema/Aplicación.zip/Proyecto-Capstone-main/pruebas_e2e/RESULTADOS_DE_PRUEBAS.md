# Resultados de las pruebas del sistema — MyPodo

| | |
|---|---|
| **Fecha de ejecución** | 27/10/2026, entre las 05:01 y las 05:05 (hora de Chile) |
| **Ejecutado por** | Claude Code en el equipo de Matías Pino |
| **Plan y casos** | [PLAN_DE_PRUEBAS.md](PLAN_DE_PRUEBAS.md) · [CASOS_DE_PRUEBA.md](CASOS_DE_PRUEBA.md) |
| **Evidencia** | `reporte-html/` (abrir con `npm run reporte`) · `resultados/resultados.json` |

## 1. Resumen

| Ejecutados | Aprobados | Fallidos | Omitidos | Inestables | Duración |
|---|---|---|---|---|---|
| 40 | **40 (100 %)** | 0 | 0 | 0 | 1 min 47 s |

**Veredicto: aprobado.** Se cumplen todos los criterios de salida del plan (sección 6):

| Criterio | Exigido | Obtenido |
|---|---|---|
| Casos de prioridad alta aprobados | 100 % | 25 de 25 (100 %) |
| Total de casos aprobados | ≥ 95 % | 40 de 40 (100 %) |
| Defectos de severidad alta abiertos | 0 | 0 |
| Ejecuciones seguidas con el mismo resultado | 2 | 2 (40/40 en ambas) |

**Por módulo:**

| Módulo | Casos | Aprobados | Fallidos |
|---|---|---|---|
| AUT · Autenticación y acceso | 9 | 9 | 0 |
| REG · Registro | 4 | 4 | 0 |
| CON · Consentimiento | 3 | 3 | 0 |
| RES · Reserva | 4 | 4 | 0 |
| CIT · Mis citas | 3 | 3 | 0 |
| FIC · Ficha del paciente | 2 | 2 | 0 |
| POD · Podólogo | 9 | 9 | 0 |
| HOR · Horario y bloqueos | 3 | 3 | 0 |
| INF · Informes | 2 | 2 | 0 |
| RSP · Diseño adaptable | 1 | 1 | 0 |
| **Total** | **40** | **40** | **0** |

**Por prioridad:**

| Prioridad | Casos | Aprobados |
|---|---|---|
| Alta | 25 | 25 |
| Media | 14 | 14 |
| Baja | 1 | 1 |

## 2. Entorno de ejecución

| Componente | Versión |
|---|---|
| Sistema operativo | Windows 11 Home Single Language |
| Navegador | Microsoft Edge 156.0.4314.42, sin ventana, `es-CL`, zona `America/Santiago` |
| Herramienta | Playwright 1.56.1 sobre Node.js 24.22.1 |
| Aplicación | Django 5.2 y PostgreSQL 16 en Docker (Docker 29.9.2, Compose 5.6.1) |
| Base de pruebas | `mypodo_e2e`, recreada en cada ejecución (escenario demo + semilla E2E) |
| Servidor de pruebas | `http://localhost:8001`, contenedor `mypodo-e2e` |

## 3. Detalle por caso (ejecución oficial)

| ID | Caso | Resultado | Duración (s) |
|---|---|---|---|
| AUT-01 | La portada pública carga y lleva a iniciar sesión | ✅ Aprobado | 1,1 |
| AUT-02 | Un paciente inicia sesión y llega a su panel | ✅ Aprobado | 1,2 |
| AUT-03 | Un podólogo inicia sesión y llega a su panel | ✅ Aprobado | 1,3 |
| AUT-04 | El administrador inicia sesión y llega a informes | ✅ Aprobado | 1,1 |
| AUT-05 | Con una contraseña incorrecta no entra y ve un aviso | ✅ Aprobado | 1,2 |
| AUT-06 | Una página protegida pide sesión y después vuelve a ella | ✅ Aprobado | 0,8 |
| AUT-07 | Cada rol solo entra a sus páginas | ✅ Aprobado | 4,2 |
| AUT-08 | Cerrar sesión impide volver a las páginas privadas | ✅ Aprobado | 6,2 |
| AUT-09 | El parámetro `next` no puede llevar a otro sitio | ✅ Aprobado | 1,1 |
| REG-01 | Una contraseña débil se rechaza junto al campo | ✅ Aprobado | 1,0 |
| REG-02 | Un RUT con dígito verificador incorrecto se rechaza | ✅ Aprobado | 1,0 |
| REG-03 | Un correo ya registrado se rechaza | ✅ Aprobado | 1,0 |
| REG-04 | Un registro válido crea la cuenta y lleva al consentimiento | ✅ Aprobado | 1,8 |
| CON-01 | Sin marcar la casilla no se acepta | ✅ Aprobado | 1,0 |
| CON-02 | El paciente acepta el consentimiento | ✅ Aprobado | 1,3 |
| CON-03 | Al revocarlo ya no puede reservar | ✅ Aprobado | 3,0 |
| RES-01 | Sin consentimiento se avisa y la reserva se rechaza | ✅ Aprobado | 1,8 |
| RES-02 | El paciente reserva en tres pasos y la cita aparece en Mis citas | ✅ Aprobado | 2,5 |
| RES-03 | Solo se ofrecen horas con al menos 24 horas de anticipación | ✅ Aprobado | 1,6 |
| RES-04 | La reserva programa el correo de confirmación | ✅ Aprobado | 3,3 |
| CIT-01 | El paciente cancela su cita con un motivo | ✅ Aprobado | 2,6 |
| CIT-02 | El paciente cambia la hora de su cita | ✅ Aprobado | 2,6 |
| CIT-03 | Una cita a menos de 24 horas no se puede cambiar en línea | ✅ Aprobado | 1,4 |
| FIC-01 | El paciente ve su ficha y descarga el PDF de su derivación | ✅ Aprobado | 1,7 |
| FIC-02 | Un paciente sin ficha ve un aviso en vez de un error | ✅ Aprobado | 1,4 |
| POD-01 | La agenda del día muestra las citas, sus cifras y se navega por días | ✅ Aprobado | 1,6 |
| POD-02 | Registra que un paciente no asistió | ✅ Aprobado | 1,5 |
| POD-03 | Cancela una cita futura indicando el motivo | ✅ Aprobado | 1,6 |
| POD-04 | Crea la ficha de un paciente nuevo | ✅ Aprobado | 2,1 |
| POD-05 | No crea la ficha de un paciente sin consentimiento | ✅ Aprobado | 2,4 |
| POD-06 | Atiende una cita de la agenda: valida y la deja realizada | ✅ Aprobado | 2,4 |
| POD-07 | Corrige una atención y la original queda reemplazada | ✅ Aprobado | 2,7 |
| POD-08 | Emite una derivación y su PDF se puede descargar | ✅ Aprobado | 2,9 |
| POD-09 | Edita los antecedentes mórbidos de la ficha | ✅ Aprobado | 2,5 |
| HOR-01 | Agrega un tramo semanal y lo desactiva | ✅ Aprobado | 1,7 |
| HOR-02 | Bloquea un período y después lo quita | ✅ Aprobado | 1,7 |
| HOR-03 | Rechaza un bloqueo que termina antes de empezar | ✅ Aprobado | 1,5 |
| INF-01 | El podólogo ve su informe, cambia el período y descarga el PDF | ✅ Aprobado | 1,7 |
| INF-02 | El administrador compara podólogos y filtra por uno | ✅ Aprobado | 1,3 |
| RSP-01 | En el celular el menú se abre con el botón y permite navegar | ✅ Aprobado | 1,3 |

## 4. Historial de ejecuciones

| # | Hora | Preparación del entorno | Resultado | Observación |
|---|---|---|---|---|
| 1 | Antes de las 05:01 | Reutilizado | 35 de 40 | Fallaron 5 casos por errores **del script**, no del sistema (ver sección 5). |
| 2 | 05:01 | Desde cero | **40 de 40** | Ejecución oficial (secciones 1 y 3). |
| 3 | 05:03 | Desde cero | **40 de 40** | Repetición para confirmar que los resultados son estables. |

## 5. Defectos e incidencias

**Defectos del sistema: ninguno.** Ningún caso encontró un comportamiento distinto al esperado en MyPodo.

**Defectos del script** (corregidos en la ejecución 2):

| ID | Casos | Causa | Corrección |
|---|---|---|---|
| INC-01 | AUT-03 | El enlace "Agenda del día" aparece dos veces: en el menú y en la página de inicio. Playwright exige un elemento único. | El enlace se busca solo dentro del menú lateral. |
| INC-02 | AUT-06 | La prueba esperaba `next=%2Fpaciente%2F…`, pero Django deja las barras sin codificar (`next=/paciente/…`). Las dos formas son válidas. | La expectativa acepta ambas formas. |
| INC-03 | POD-07, POD-08, POD-09 | El listado de pacientes muestra "Apellido, Nombre" y la prueba buscaba "Elena Atender". | Se busca "Atender, Elena". |

## 6. Observaciones y recomendaciones

1. **Cobertura combinada.** Estas 40 pruebas de sistema se suman a las 566 pruebas del backend (pytest): las del backend cubren cada regla por separado y estas, los recorridos completos.
2. **Ventana horaria.** La semilla crea citas relativas al momento de la ejecución. Hay que ejecutar las pruebas entre las 03:00 y las 23:59, hora de Chile.
3. **Fuera del alcance de esta ejecución:**
   - La entrega real de correos: se verificó que el correo queda programado.
   - El chatbot (B7, en espera).
   - Rendimiento.
   - Otros navegadores.
4. **Mejoras posibles:**
   - Agregar Firefox y WebKit en `playwright.config.js` (`projects`).
   - Ejecutar las pruebas en integración continua cuando exista el repositorio.
   - Revisar en Mailpit el contenido de los correos.

## 7. Nueva ejecución tras rehacer el frontend (30/10/2026)

El frontend se rehízo con Tailwind CSS y htmx: Django arma cada página y htmx actualiza solo las partes que cambian. Las URL y las reglas no cambiaron, así que se mantuvieron los mismos 40 casos y solo se adaptaron sus selectores.

| # | Hora | Resultado | Observación |
|---|---|---|---|
| 4 | 30/10, tarde | 39 de 40 | REG-01 falló por un error **del script** (INC-04). |
| 5 | 30/10, tarde | **40 de 40** | Desde cero, después de corregir INC-04. El reporte HTML y el JSON corresponden a esta ejecución. |

**Defectos del sistema: ninguno.**

| ID | Caso | Causa | Corrección |
|---|---|---|---|
| INC-04 | REG-01 | Ahora todos los errores de la contraseña aparecen junto al campo (son dos), y la prueba esperaba uno solo. | La prueba revisa el primero. |

**Cambios de los scripts:**
- Los diálogos se buscan en `#modal`.
- Los avisos se buscan en `[data-avisos]`.
- El registro se abre con `/entrar/?modo=registro`.
- `nuevoPaciente` usa la API con `page.request`, porque ya no existe el cliente `window.MyPodo.api`.
- Los errores de un campo se buscan en `.form-error`.
- Pendiente: el dibujo de los pies no tiene caso E2E. Sí lo cubren las pruebas del backend.
