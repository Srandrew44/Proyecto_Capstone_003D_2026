# Plan de pruebas del sistema — MyPodo

| | |
|---|---|
| **Proyecto** | MyPodo: sistema de citas y ficha clínica podológica |
| **Versión del sistema** | Hitos B0 a B6 y frontend web (B7, chatbot, en espera) |
| **Tipo de prueba** | Pruebas de sistema de punta a punta (E2E), por la interfaz web |
| **Herramienta** | Playwright 1.56.1 (`@playwright/test`), navegador Microsoft Edge |
| **Fecha** | 27/10/2026 |
| **Documentos relacionados** | [CASOS_DE_PRUEBA.md](CASOS_DE_PRUEBA.md) · [RESULTADOS_DE_PRUEBAS.md](RESULTADOS_DE_PRUEBAS.md) · [README.md](README.md) |

## 1. Objetivo

Comprobar que el sistema completo funciona como lo usará la gente: un navegador real abre las páginas, llena los formularios y presiona los botones. Cada acción pasa por el frontend, la API de Django y la base de datos PostgreSQL, igual que en producción.

Las pruebas deben confirmar cuatro cosas:
- Cada rol (paciente, podólogo y administrador) puede hacer lo que le corresponde.
- Cada rol queda bloqueado en lo que no le corresponde.
- Las reglas del negocio se aplican también desde la interfaz:
  - Reservar con 24 horas de anticipación.
  - Tener el consentimiento vigente para reservar y para crear la ficha.
  - Que las atenciones no se editen: se corrigen con una corrección enlazada.
- Los documentos que entrega el sistema (derivación e informe de gestión en PDF) se generan y se pueden descargar.

## 2. Alcance

### 2.1 Dentro del alcance

| Módulo | Código | Qué se prueba |
|---|---|---|
| Autenticación y acceso | AUT | Portada, inicio de sesión, contraseña incorrecta, redirección a la página pedida, acceso por rol, cierre de sesión y redirección segura (`next`). |
| Registro | REG | Alta de pacientes y validaciones de contraseña, RUT y correo duplicado. |
| Consentimiento | CON | Aceptar y revocar el consentimiento de datos, y su efecto en la reserva. |
| Reserva | RES | Reserva en tres pasos, regla de 24 horas, bloqueo sin consentimiento y correo de confirmación programado. |
| Mis citas | CIT | Cancelar con motivo, cambiar la hora y bloqueo de cambios a menos de 24 horas. |
| Ficha del paciente | FIC | Lectura de la ficha y descarga del PDF de derivación, y paciente sin ficha. |
| Podólogo | POD | Agenda del día, inasistencia, cancelación, creación y edición de la ficha, atención ligada a una cita, corrección y derivación. |
| Horario | HOR | Tramos semanales, bloqueos y validación de fechas. |
| Informes | INF | Informe del podólogo y del administrador, filtros y PDF. |
| Diseño adaptable | RSP | Menú y navegación en un celular (390 px). |

### 2.2 Fuera del alcance (y por qué)

- **Chatbot (B7):** está en espera.
- **Entrega real de correos:** las pruebas verifican que el sistema programa el correo (la notificación). El envío por SMTP ya tiene pruebas automáticas propias en el backend y se probó a mano contra Mailpit.
- **Rendimiento y carga:** no se definieron metas de rendimiento. Corresponde a otro tipo de prueba.
- **Pruebas de penetración:** los permisos y la auditoría están cubiertos por las pruebas del backend. Aquí solo se prueba lo visible para el usuario (acceso por rol y `next`).
- **Panel de administración de Django (`/admin/`):** es una herramienta interna estándar de Django.
- **Otros navegadores:** solo se usa Edge (motor Chromium). Firefox y Safari quedan como mejora: Playwright los soporta con un cambio en la configuración.

## 3. Estrategia

Las pruebas de MyPodo tienen dos niveles que se complementan:

| Nivel | Herramienta | Cantidad | Qué cubre |
|---|---|---|---|
| Unitarias y de integración (backend) | pytest + Django | 616 | Reglas de negocio, permisos, API, auditoría, correos y PDF, cada uno por separado. |
| **Sistema (E2E)**, este plan | **Playwright** | **40** | Recorridos completos por la interfaz, con el sistema integrado. |

**Diseño de los casos:**
- Los casos salen de los flujos principales de cada rol y de las reglas del negocio acordadas con el cliente.
- Para cada regla hay al menos un caso **positivo** (el camino esperado) y, donde aplica, uno **negativo**: datos inválidos, falta de permiso o fuera de plazo.
- Se usan particiones de equivalencia en el registro (contraseña débil, RUT inválido, correo repetido y datos válidos) y valores límite en la regla de 24 horas (ninguna hora ofrecida antes de 24 horas).

**Prioridades:**
- **Alta:** si falla, el sistema no sirve para su propósito (entrar, reservar, atender, consentimiento, permisos).
- **Media:** funciones importantes con alternativa manual (cancelar, reagendar, bloqueos, informes).
- **Baja:** comodidad (navegación por días, celular).

**Independencia:**
- Cada caso crea los datos que necesita: por ejemplo, un paciente nuevo con un correo único.
- Los casos que usan datos compartidos los toman de una semilla fija, preparada para ese caso.
- Los casos corren en orden y de a uno (un solo *worker*), porque algunos cambian la agenda compartida.

## 4. Entorno de pruebas

```
Playwright (Node 24)  ──►  Microsoft Edge (sin ventana)  ──►  http://localhost:8001
                                                                     │
                                Docker Compose ─ contenedor "mypodo-e2e" (Django runserver)
                                                                     │
                                Docker Compose ─ PostgreSQL 16, base "mypodo_e2e"
```

- **Aislado del desarrollo:**
  - Las pruebas usan su propia base (`mypodo_e2e`) y su propio servidor (puerto 8001).
  - La base de desarrollo (`mypodo`, puerto 8000) no se modifica.
  - No se leen ni copian claves del `.env`: el servidor de pruebas reutiliza la conexión configurada y solo cambia el nombre de la base.
- **Reproducible:** cada ejecución empieza desde cero. El `global-setup` hace esto:
  1. Borra y vuelve a crear la base.
  2. Aplica las migraciones.
  3. Carga el escenario demo (`cargar_escenario_demo`).
  4. Carga la semilla E2E (`soporte/semilla_e2e.py`).
  5. Levanta el servidor.

  Al terminar, el `global-teardown` detiene el servidor.
- **Configuración del navegador:**
  - Idioma `es-CL`.
  - Zona horaria `America/Santiago`.
  - Ventana de 1366×800 (390×844 en la prueba de celular).
- **Evidencia:**
  - Reporte HTML (`reporte-html/`) y resultados en JSON (`resultados/resultados.json`).
  - Ante una falla se guardan una captura de pantalla y una traza navegable (`npx playwright show-trace`).

## 5. Datos de prueba

Todos los datos son ficticios y usan correos `@example.com`. La clave de las cuentas sembradas es la misma del escenario demo: está en `soporte/ayuda.js`.

| Cuenta | Rol | Para qué se usa |
|---|---|---|
| `maria.gonzalez@example.com` | Paciente (demo) | Inicio de sesión, ficha con corrección y derivación a dermatología. |
| `podologa.demo@example.com` (Camila Rojas) | Podóloga (demo) | Inicio de sesión, horario para reservas e informe con historia. |
| `podologo.demo@example.com` (Tomás Fuentes) | Podólogo (demo) | Agenda, fichas, atenciones, horario y bloqueos. |
| `admin.e2e@example.com` | Administrador (semilla) | Informe de toda la consulta. |
| `elena.e2e@example.com` | Paciente (semilla) | Tiene ficha y tres citas con Tomás: una que ya empezó (para atenderla), una a menos de 24 horas y una dentro de 5 días. |
| `felipe.e2e@example.com` | Paciente (semilla) | Sin ficha. Su cita ya empezó (para la inasistencia). |
| `sofia.e2e@example.com` | Paciente (semilla) | Con consentimiento y sin ficha (para crear la ficha). |
| `gonzalo.e2e@example.com` | Paciente (semilla) | Sin consentimiento (no se le puede crear la ficha). |
| `prueba.<único>@example.com` | Paciente (creado por cada caso) | Registro, consentimiento, reserva y gestión de citas. |

## 6. Criterios

**Criterios de entrada:**
- Docker Desktop corriendo y la imagen `web` construida (`.\tasks.ps1 up` al menos una vez).
- Microsoft Edge instalado.
- Node 18 o superior, con `npm install` hecho en `pruebas_e2e/`.
- Las 616 pruebas del backend pasando.
- Ejecutar entre las 03:00 y las 23:59, hora de Chile. Algunas citas de la semilla se crean unas horas antes o después del momento de la ejecución y tienen que caer en el mismo día que muestra la agenda.

**Criterios de salida (aprobación):**
- El 100 % de los casos de prioridad alta aprobados.
- Al menos el 95 % del total aprobados.
- Ningún defecto abierto de severidad alta.
- Resultados repetibles: dos ejecuciones seguidas con el mismo resultado.

**Criterio de suspensión:** se suspende la ejecución si el entorno no se puede preparar (Docker caído o migraciones con error). Se reanuda cuando el problema se corrige.

## 7. Gestión de defectos

Cada falla se analiza con su captura y su traza, y se clasifica así:

| Clasificación | Qué significa | Qué se hace |
|---|---|---|
| **Defecto del sistema** | El sistema no cumple lo esperado. | Se registra con su ID, severidad (alta, media o baja), pasos y evidencia. Se corrige y se vuelve a probar. |
| **Defecto del script** | La prueba estaba mal escrita: selector o expectativa incorrectos. | Se corrige la prueba y se deja constancia en los resultados. |
| **Falla del entorno** | Docker, la red o la hora del equipo. | Se repite la ejecución después de corregir el entorno. |

## 8. Roles

| Rol | Responsable |
|---|---|
| Diseño y automatización de casos | Matías Pino, con apoyo de Claude Code |
| Ejecución y registro de resultados | Matías Pino |
| Revisión de los resultados | Sebastián (equipo APT) |

## 9. Riesgos

| Riesgo | Mitigación |
|---|---|
| Pruebas que dependen de la hora del día (citas "de hoy"). | Una semilla relativa al momento de la ejecución y una ventana horaria documentada (criterios de entrada). |
| Interferencia entre casos que comparten la agenda. | Un solo *worker*, datos propios por caso y base limpia en cada ejecución. |
| Que se modifique por error la base de desarrollo. | Una base y un servidor separados. El nombre de la base está fijo en `soporte/entorno.js`. |
| Selectores frágiles si cambia el diseño. | Selectores por rol, texto visible e `id` estables del HTML, no por posición. |

## 10. Cómo ejecutar

Ver [README.md](README.md). En resumen, desde `página web/pruebas_e2e`:

```bash
npm install
```

```bash
npm test
```

```bash
npm run reporte
```
