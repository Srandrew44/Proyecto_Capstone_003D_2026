// Módulos HOR, INF y RSP: horario y bloqueos, informes de gestión y vista en celular.
const { test, expect } = require('@playwright/test');
const { U, entrarYEsperar, diaChile, toast } = require('../soporte/ayuda');

test.describe('HOR · Horario y bloqueos', () => {
  test.beforeEach(async ({ page }) => {
    await entrarYEsperar(page, U.tomas, /\/podologo\/$/);
    await page.goto('/podologo/horario/');
  });

  test('HOR-01 Agrega un tramo semanal y lo desactiva', async ({ page }) => {
    await page.selectOption('#t-dia', '5'); // sábado
    await page.fill('#t-inicio', '09:00');
    await page.fill('#t-fin', '11:00');
    await page.click('#form-tramo button[type=submit]');
    await toast(page, 'Tramo agregado.');
    const sabado = page.locator('.dia-semana', { hasText: 'Sábado' });
    const tramo = sabado.locator('.tramo', { hasText: '09:00 – 11:00' });
    await expect(tramo).toBeVisible();
    await tramo.getByRole('button', { name: 'Desactivar' }).click();
    await expect(tramo).toHaveClass(/inactivo/);
    await expect(tramo.getByRole('button', { name: 'Activar' })).toBeVisible();
  });

  test('HOR-02 Bloquea un período y después lo quita', async ({ page }) => {
    const dia = diaChile(20);
    await page.fill('#b-inicio', `${dia}T10:00`);
    await page.fill('#b-fin', `${dia}T12:00`);
    await page.fill('#b-motivo', 'Trámite personal E2E');
    await page.click('#form-bloqueo button[type=submit]');
    await toast(page, 'Horario bloqueado');
    const bloqueo = page.locator('#bloqueos .tramo', { hasText: 'Trámite personal E2E' });
    await expect(bloqueo).toBeVisible();
    await bloqueo.getByRole('button', { name: 'Quitar' }).click();
    await page.locator('#modal').getByRole('button', { name: 'Quitar', exact: true }).click();
    await toast(page, 'Bloqueo quitado.');
    await expect(bloqueo).toHaveCount(0);
  });

  test('HOR-03 Rechaza un bloqueo que termina antes de empezar', async ({ page }) => {
    const dia = diaChile(21);
    await page.fill('#b-inicio', `${dia}T12:00`);
    await page.fill('#b-fin', `${dia}T10:00`);
    await page.click('#form-bloqueo button[type=submit]');
    await expect(page.locator('#form-bloqueo .form-error')).toContainText('posterior al inicio');
  });
});

test.describe('INF · Informes de gestión', () => {
  test('INF-01 El podólogo ve su informe, cambia el período y descarga el PDF', async ({ page }) => {
    await entrarYEsperar(page, U.camila, /\/podologo\/$/);
    await page.goto('/informes/');
    await expect(page.locator('.stat-card', { hasText: 'Citas del período' })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Citas realizadas por semana' })).toBeVisible();
    const periodo = page.locator('#informe p', { hasText: 'Período:' });
    const antes = await periodo.textContent();
    await page.locator('[data-rango="anterior"]').click();
    await expect(periodo).not.toHaveText(antes);
    // En el mes anterior el escenario demo tiene citas realizadas.
    await expect(page.locator('.stat-card', { hasText: 'Citas del período' }).locator('.stat-value')).not.toHaveText('0');
    const href = await page.locator('#descargar-pdf').getAttribute('href');
    expect(href).toContain('desde=');
    const pdf = await page.request.get(href);
    expect(pdf.status()).toBe(200);
    expect(pdf.headers()['content-type']).toContain('application/pdf');
  });

  test('INF-02 El administrador compara podólogos y filtra por uno', async ({ page }) => {
    await entrarYEsperar(page, U.admin, /\/informes\/$/);
    await page.locator('[data-rango="anterior"]').click();
    const porPodologo = page.locator('.card', { has: page.getByRole('heading', { name: 'Por podólogo' }) });
    await expect(porPodologo).toContainText('Camila Rojas');
    await expect(porPodologo).toContainText('Tomás Fuentes');
    await expect(page.locator('#profesional option')).toHaveCount(3);
    await page.selectOption('#profesional', { label: 'Tomás Fuentes' });
    await expect(page.locator('#descargar-pdf')).toHaveAttribute('href', /profesional=/);
    await expect(page.locator('.stat-card', { hasText: 'Citas del período' })).toBeVisible();
  });
});

test.describe('RSP · Diseño adaptable', () => {
  test.use({ viewport: { width: 390, height: 844 } });

  test('RSP-01 En el celular el menú se abre con el botón y permite navegar', async ({ page }) => {
    await entrarYEsperar(page, U.maria, /\/paciente\/$/);
    const misCitas = page.locator('.sidebar').getByRole('link', { name: /Mis citas/ });
    await expect(misCitas).not.toBeInViewport();
    await page.click('[data-menu]');
    await expect(page.locator('[data-menu]')).toHaveAttribute('aria-expanded', 'true');
    await expect(misCitas).toBeInViewport();
    await misCitas.click();
    await expect(page).toHaveURL(/\/paciente\/citas\/$/);
    const ancho = await page.evaluate(() => document.documentElement.scrollWidth);
    expect(ancho).toBeLessThanOrEqual(390);
  });
});
