// Módulos REG y CON: registro de pacientes y consentimiento informado.
const { test, expect } = require('@playwright/test');
const { U, dv, datosRegistro, nuevoPaciente, enlaceDelCorreo } = require('../soporte/ayuda');

async function llenarRegistro(page, datos) {
  await page.goto('/entrar/?modo=registro');
  await expect(page.locator('#form-registro')).toBeVisible();
  const campos = {
    '#reg-nombre': datos.nombre, '#reg-apellido': datos.apellido, '#reg-rut': datos.rut,
    '#reg-nacimiento': datos.fecha_nacimiento, '#reg-telefono': datos.telefono,
    '#reg-contacto': datos.telefono_contacto, '#reg-direccion': datos.direccion,
    '#reg-comuna': datos.comuna, '#reg-actividad': datos.actividad, '#reg-email': datos.email,
    '#reg-clave': datos.password,
  };
  for (const [selector, valor] of Object.entries(campos)) await page.fill(selector, valor);
  await page.click('#form-registro button[type=submit]');
}

const errorDe = (page, selector) => page.locator(`.form-group:has(${selector}) .form-error`);

test.describe('REG · Registro de pacientes', () => {
  test('REG-01 Una contraseña débil se rechaza junto al campo', async ({ page }) => {
    await llenarRegistro(page, datosRegistro({ password: '12345678' }));
    await expect(errorDe(page, '#reg-clave').first()).toBeVisible();
    await expect(page.locator('#reg-clave')).toHaveAttribute('aria-invalid', 'true');
    await expect(page).toHaveURL(/\/entrar\//);
  });

  test('REG-02 Un RUT con dígito verificador incorrecto se rechaza', async ({ page }) => {
    const cuerpo = 22333444;
    const malo = dv(cuerpo) === '1' ? '2' : '1';
    await llenarRegistro(page, datosRegistro({ rut: `${cuerpo}-${malo}` }));
    await expect(errorDe(page, '#reg-rut')).toBeVisible();
  });

  test('REG-03 Un correo ya registrado no se delata: responde igual y avisa por correo', async ({ page }) => {
    await llenarRegistro(page, datosRegistro({ email: U.maria }));
    await expect(page.getByRole('heading', { name: 'Revisa tu correo' })).toBeVisible();
    await expect(page.locator('.form-error')).toHaveCount(0);
    expect(await enlaceDelCorreo(U.maria, '/recuperar/')).toBe('/recuperar/');
  });

  test('REG-04 Un registro válido pide confirmar el correo y luego lleva al consentimiento', async ({ page }) => {
    const datos = datosRegistro();
    await llenarRegistro(page, datos);
    await expect(page.getByRole('heading', { name: 'Revisa tu correo' })).toBeVisible();
    await page.goto(await enlaceDelCorreo(datos.email, '/registro/confirmar/'));
    await page.getByRole('button', { name: 'Activar mi cuenta' }).click();
    await expect(page).toHaveURL(/\/paciente\/consentimiento\/\?nuevo=1$/);
    await expect(page.getByText('Tu cuenta está creada.')).toBeVisible();
    await expect(page.locator('.sidebar-footer')).toContainText(datos.email);
  });
});

test.describe('CON · Consentimiento informado', () => {
  test('CON-01 Sin marcar la casilla no se acepta', async ({ page }) => {
    await nuevoPaciente(page, { consentimiento: false });
    await page.goto('/paciente/consentimiento/');
    await page.click('#form-consentimiento button[type=submit]');
    await expect(page.locator('#form-consentimiento [data-error]')).toHaveText('Marca la casilla para aceptar.');
  });

  test('CON-02 El paciente acepta el consentimiento', async ({ page }) => {
    await nuevoPaciente(page, { consentimiento: false });
    await page.goto('/paciente/consentimiento/');
    await page.check('#form-consentimiento input[name=leido]');
    await page.click('#form-consentimiento button[type=submit]');
    await expect(page.locator('#estado')).toContainText('Aceptaste el consentimiento (versión v1)');
    await expect(page.locator('#form-consentimiento')).toBeHidden();
  });

  test('CON-03 Al revocarlo ya no puede reservar', async ({ page }) => {
    await nuevoPaciente(page);
    await page.goto('/paciente/consentimiento/');
    await page.getByRole('button', { name: 'Revocar consentimiento' }).click();
    await page.locator('#modal').getByRole('button', { name: 'Revocar', exact: true }).click();
    await expect(page.locator('#form-consentimiento')).toBeVisible();
    await page.goto('/paciente/reservar/');
    await expect(page.locator('#aviso-consentimiento')).toContainText('consentimiento informado');
  });
});
