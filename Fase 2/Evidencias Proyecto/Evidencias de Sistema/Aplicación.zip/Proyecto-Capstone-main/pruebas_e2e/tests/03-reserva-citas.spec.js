// Módulos RES y CIT: reserva de horas y gestión de las citas por el paciente.
const { test, expect } = require('@playwright/test');
const { U, entrarYEsperar, nuevoPaciente, elegirHorario, reservar, unico } = require('../soporte/ayuda');

test.describe('RES · Reserva de horas', () => {
  test('RES-01 Sin consentimiento se avisa y la reserva se rechaza', async ({ page }) => {
    await nuevoPaciente(page, { consentimiento: false });
    await elegirHorario(page);
    await expect(page.locator('#aviso-consentimiento')).toContainText('consentimiento informado');
    await page.click('#paso-confirmar button[type=submit]');
    const error = page.locator('#paso-confirmar [data-error]');
    await expect(error).toBeVisible();
    await expect(error.getByRole('link', { name: 'Ir al consentimiento' })).toBeVisible();
  });

  test('RES-02 El paciente reserva en tres pasos y la cita aparece en Mis citas', async ({ page }) => {
    await nuevoPaciente(page);
    const comentario = `Dolor en el pie derecho ${unico()}`;
    const hora = await reservar(page, { comentario });
    await expect(page.locator('#reserva-lista')).toContainText('Camila Rojas');
    await page.getByRole('link', { name: 'Ver mis citas' }).click();
    const cita = page.locator('#citas-proximas .cita-item', { hasText: comentario });
    await expect(cita).toContainText(`${hora} hrs`);
    await expect(cita).toContainText('Podología básica');
  });

  test('RES-03 Solo se ofrecen horas con al menos 24 horas de anticipación', async ({ page }) => {
    await nuevoPaciente(page);
    await elegirHorario(page);
    const horas = await page.locator('#selector-horario [data-hora]').evaluateAll(
      (botones) => botones.map((b) => new Date(b.dataset.hora).getTime())
    );
    expect(horas.length).toBeGreaterThan(0);
    const limite = Date.now() + 24 * 3600 * 1000 - 60 * 1000;
    for (const h of horas) expect(h).toBeGreaterThanOrEqual(limite);
    // Los días sin horas libres quedan deshabilitados en el calendario.
    await expect(page.locator('#selector-horario .calendar-day:not(.has-slots)').first()).toBeDisabled();
  });

  test('RES-04 La reserva programa el correo de confirmación', async ({ page }) => {
    await nuevoPaciente(page);
    await reservar(page);
    await page.goto('/notificaciones/');
    const correos = page.locator('.notif-item');
    await expect(correos.first()).toBeVisible();
    expect(await correos.count()).toBeGreaterThanOrEqual(1);
    await page.locator('[data-filtro="pendiente"]').click();
    await expect(page.locator('.notif-item .badge', { hasText: 'Programado' }).first()).toBeVisible();
  });
});

test.describe('CIT · Mis citas', () => {
  test('CIT-01 El paciente cancela su cita con un motivo', async ({ page }) => {
    await nuevoPaciente(page);
    const comentario = `Para cancelar ${unico()}`;
    await reservar(page, { comentario });
    await page.goto('/paciente/citas/');
    await page.locator('#citas-proximas .cita-item', { hasText: comentario }).getByRole('button', { name: 'Cancelar' }).click();
    await page.fill('#modal #motivo', 'Viaje de trabajo');
    await page.locator('#modal').getByRole('button', { name: 'Sí, cancelar' }).click();
    const cancelada = page.locator('#citas-pasadas .cita-item', { hasText: comentario });
    await expect(cancelada).toContainText('Cancelada');
    await expect(cancelada).toContainText('Motivo de cancelación: Viaje de trabajo');
  });

  test('CIT-02 El paciente cambia la hora de su cita', async ({ page }) => {
    await nuevoPaciente(page);
    const comentario = `Para reagendar ${unico()}`;
    const horaOriginal = await reservar(page, { comentario });
    await page.goto('/paciente/citas/');
    await page.locator('#citas-proximas .cita-item', { hasText: comentario }).getByRole('button', { name: 'Cambiar hora' }).click();
    const horas = page.locator('#calendario-reagendar .time-slot');
    await expect(horas.first()).toBeVisible();
    const nueva = horas.last();
    const horaNueva = (await nueva.textContent()).trim();
    expect(horaNueva).not.toBe(horaOriginal);
    await nueva.click();
    await expect(page.locator('#nueva-hora')).toContainText(horaNueva);
    await page.locator('#modal').getByRole('button', { name: 'Confirmar cambio' }).click();
    await expect(page.locator('#citas-proximas .cita-item', { hasText: comentario })).toContainText(`${horaNueva} hrs`);
  });

  test('CIT-03 Una cita a menos de 24 horas no se puede cambiar en línea', async ({ page }) => {
    await entrarYEsperar(page, U.elena, /\/paciente\/$/);
    await page.goto('/paciente/citas/');
    const cercana = page.locator('#citas-proximas .cita-item', { hasText: 'Faltan menos de 24 horas' });
    await expect(cercana).toHaveCount(1);
    await expect(cercana.getByRole('button')).toHaveCount(0);
    // La cita de dentro de 5 días sí tiene sus botones.
    await expect(page.locator('#citas-proximas').getByRole('button', { name: 'Cambiar hora' })).toHaveCount(1);
  });
});
