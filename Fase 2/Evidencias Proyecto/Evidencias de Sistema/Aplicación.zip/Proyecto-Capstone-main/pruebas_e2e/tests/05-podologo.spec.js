// Módulo POD: agenda del día, fichas, atenciones, correcciones y derivaciones del podólogo.
// Usa a Tomás Fuentes y los pacientes de la semilla E2E (Elena, Felipe, Sofía y Gonzalo).
const { test, expect } = require('@playwright/test');
const { U, entrarYEsperar, diaChile, toast, unico } = require('../soporte/ayuda');

test.beforeEach(async ({ page }) => {
  await entrarYEsperar(page, U.tomas, /\/podologo\/$/);
});

const tarjeta = (page, paciente) => page.locator('#cronograma .timeline-item', { hasText: paciente });

// El listado muestra "Apellido, Nombre".
async function abrirFicha(page, paciente) {
  await page.goto('/podologo/pacientes/');
  await page.locator('#filas tr', { hasText: paciente }).getByRole('link').click();
  await expect(page.locator('#ficha')).toBeVisible();
}

// Registra una atención fuera de agenda con una observación única y devuelve su tarjeta.
async function registrarAtencion(page, observacion) {
  await page.selectOption('#a-cita', '');
  await page.fill('#form-atencion #a-observacion', observacion);
  await page.fill('#form-atencion #a-tratamiento', 'Corte y limado de uñas');
  await page.fill('#form-atencion #a-diagnostico', 'Onicocriptosis leve');
  await page.click('#form-atencion button[type=submit]');
  await toast(page, 'Atención registrada.');
  const atencion = page.locator('#historial article', { hasText: observacion });
  await expect(atencion).toBeVisible();
  return atencion;
}

test.describe('POD · Podólogo', () => {
  test('POD-01 La agenda del día muestra las citas, sus cifras y se navega por días', async ({ page }) => {
    await page.goto('/podologo/agenda/');
    await expect(tarjeta(page, 'Felipe Ausente')).toBeVisible();
    await expect(tarjeta(page, 'Elena Atender').first()).toBeVisible();
    expect(Number(await page.locator('[data-kpi="total"]').textContent())).toBeGreaterThanOrEqual(2);
    await expect(page.locator('#fecha')).toHaveValue(diaChile(0));
    await page.locator('[data-mover="1"]').click();
    await expect(page.locator('#fecha')).toHaveValue(diaChile(1));
    await expect(page).toHaveURL(new RegExp(`fecha=${diaChile(1)}`));
    await page.locator('[data-hoy]').click();
    await expect(page.locator('#fecha')).toHaveValue(diaChile(0));
  });

  test('POD-02 Registra que un paciente no asistió', async ({ page }) => {
    await page.goto('/podologo/agenda/');
    await tarjeta(page, 'Felipe Ausente').getByRole('button', { name: 'No asistió' }).click();
    await page.locator('#modal').getByRole('button', { name: 'Sí, no asistió' }).click();
    await toast(page, 'Inasistencia registrada.');
    await expect(tarjeta(page, 'Felipe Ausente').locator('.badge')).toHaveText('No asistió');
  });

  test('POD-03 Cancela una cita futura indicando el motivo', async ({ page }) => {
    const dia = diaChile(5);
    await page.goto(`/podologo/agenda/?fecha=${dia}`);
    await tarjeta(page, 'Elena Atender').getByRole('button', { name: 'Cancelar' }).click();
    await page.fill('#modal #motivo', 'El podólogo tiene un congreso');
    await page.locator('#modal').getByRole('button', { name: 'Cancelar cita' }).click();
    await toast(page, 'Cita cancelada y paciente avisado.');
    const cita = tarjeta(page, 'Elena Atender');
    await expect(cita).toContainText('Cancelada');
    await expect(cita).toContainText('Motivo: El podólogo tiene un congreso');
  });

  test('POD-04 Crea la ficha de un paciente nuevo', async ({ page }) => {
    await page.goto('/podologo/pacientes/');
    await expect(page.locator('#filas tr', { hasText: 'Sinficha' })).toContainText('Sin ficha');
    await abrirFicha(page, 'Sinficha');
    await expect(page.locator('#ficha')).toContainText('aún no tiene ficha');
    await page.selectOption('#form-crear #f-diabetes', 'true');
    await page.fill('#form-crear #f-presion_arterial', '130/85');
    await page.click('#form-crear button[type=submit]');
    await toast(page, 'Ficha creada.');
    await expect(page.locator('#form-atencion')).toBeVisible();
    await expect(page.locator('#antecedentes')).toContainText('130/85');
  });

  test('POD-05 No crea la ficha de un paciente sin consentimiento', async ({ page }) => {
    await abrirFicha(page, 'Sinconsentimiento');
    await page.click('#form-crear button[type=submit]');
    await expect(page.locator('#form-crear [data-error]')).toContainText('no tiene vigente el consentimiento');
  });

  test('POD-06 Atiende una cita de la agenda: valida y la deja realizada', async ({ page }) => {
    await page.goto('/podologo/agenda/');
    await tarjeta(page, 'Elena Atender').first().getByRole('link', { name: 'Atender' }).click();
    await expect(page).toHaveURL(/\/podologo\/pacientes\/.+\?cita=/);
    await expect(page.locator('#a-cita')).not.toHaveValue('');
    // Sin observación ni tratamiento se rechaza, con el error junto al campo.
    await page.click('#form-atencion button[type=submit]');
    await expect(page.locator('#form-atencion .form-error').first()).toContainText('al menos la observación o el tratamiento');
    await page.fill('#form-atencion #a-observacion', 'Hiperqueratosis en talón derecho');
    await page.fill('#form-atencion #a-tratamiento', 'Desbridamiento e hidratación');
    await page.click('#form-atencion button[type=submit]');
    await toast(page, 'Atención registrada.');
    await page.goto('/podologo/agenda/');
    await expect(tarjeta(page, 'Elena Atender').first()).toContainText('Realizada');
  });

  test('POD-07 Corrige una atención y la original queda reemplazada', async ({ page }) => {
    await abrirFicha(page, 'Atender, Elena');
    const observacion = `Observación original ${unico()}`;
    const original = await registrarAtencion(page, observacion);
    await original.getByRole('button', { name: 'Corregir' }).click();
    const modal = page.locator('#modal');
    await modal.locator('#c-motivo').fill('Se registró el pie equivocado');
    await modal.locator('#c-pie_izquierdo').fill('Heloma plantar');
    await modal.getByRole('button', { name: 'Guardar corrección' }).click();
    await toast(page, 'Corrección registrada.');
    await expect(page.locator('#historial article', { hasText: 'Se registró el pie equivocado' })).toContainText('Corrección');
    await expect(page.locator('#historial article', { hasText: observacion }).filter({ hasText: 'Reemplazada' })).toHaveCount(1);
  });

  test('POD-08 Emite una derivación y su PDF se puede descargar', async ({ page }) => {
    await abrirFicha(page, 'Atender, Elena');
    const atencion = await registrarAtencion(page, `Para derivar ${unico()}`);
    await atencion.getByRole('button', { name: 'Derivar' }).click();
    const modal = page.locator('#modal');
    await modal.locator('#d-esp').selectOption('traumatologia');
    await modal.locator('#d-motivo').fill('Dolor persistente en el tobillo que requiere evaluación');
    await modal.getByRole('button', { name: 'Emitir derivación' }).click();
    await toast(page, 'Derivación a Traumatología emitida');
    const derivacion = page.locator('#historial .derivacion-item', { hasText: 'Traumatología' }).first();
    const href = await derivacion.getByRole('link', { name: 'Descargar PDF' }).getAttribute('href');
    const pdf = await page.request.get(href);
    expect(pdf.status()).toBe(200);
    expect(pdf.headers()['content-type']).toContain('application/pdf');
  });

  test('POD-09 Edita los antecedentes mórbidos de la ficha', async ({ page }) => {
    await abrirFicha(page, 'Atender, Elena');
    await page.click('#editar-antecedentes');
    await page.locator('#modal #f-varices').selectOption('true');
    await page.locator('#modal #f-alergias').fill('Penicilina');
    await page.locator('#modal').getByRole('button', { name: 'Guardar cambios' }).click();
    await toast(page, 'Antecedentes actualizados.');
    await expect(page.locator('#antecedentes')).toContainText('Penicilina');
    await page.reload();
    await page.click('#editar-antecedentes');
    await expect(page.locator('#modal #f-varices')).toHaveValue('true');
  });
});
