// Módulo AUT: portada, inicio de sesión, acceso por rol y cierre de sesión.
const { test, expect } = require('@playwright/test');
const { U, entrar, entrarYEsperar } = require('../soporte/ayuda');

test.describe('AUT · Autenticación y acceso', () => {
  test('AUT-01 La portada pública carga y lleva a iniciar sesión', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Cuidado podológico');
    await page.getByRole('link', { name: 'Ya tengo cuenta' }).click();
    await expect(page).toHaveURL(/\/entrar\/$/);
    await expect(page.locator('#form-entrar')).toBeVisible();
  });

  test('AUT-02 Un paciente inicia sesión y llega a su panel', async ({ page }) => {
    await entrarYEsperar(page, U.maria, /\/paciente\/$/);
    await expect(page.locator('.sidebar-role')).toHaveText('Paciente');
    await expect(page.locator('.sidebar-footer')).toContainText('María González');
  });

  test('AUT-03 Un podólogo inicia sesión y llega a su panel', async ({ page }) => {
    await entrarYEsperar(page, U.camila, /\/podologo\/$/);
    await expect(page.locator('.sidebar-role')).toHaveText('Podólogo');
    await expect(page.locator('.sidebar').getByRole('link', { name: /Agenda del día/ })).toBeVisible();
  });

  test('AUT-04 El administrador inicia sesión y llega a informes', async ({ page }) => {
    await entrarYEsperar(page, U.admin, /\/informes\/$/);
    await expect(page.locator('.sidebar-role')).toHaveText('Administrador');
    await expect(page.locator('#profesional')).toBeVisible();
  });

  test('AUT-05 Con una contraseña incorrecta no entra y ve un aviso', async ({ page }) => {
    await entrar(page, U.maria, 'clave-equivocada');
    const error = page.locator('#form-entrar [data-error]');
    await expect(error).toBeVisible();
    await expect(error).not.toBeEmpty();
    await expect(page).toHaveURL(/\/entrar\/$/);
  });

  test('AUT-06 Una página protegida pide sesión y después vuelve a ella', async ({ page }) => {
    await page.goto('/paciente/citas/');
    await expect(page).toHaveURL(/\/entrar\/\?next=(%2F|\/)paciente(%2F|\/)citas(%2F|\/)/);
    await page.fill('#entrar-email', U.maria);
    await page.fill('#entrar-clave', 'demo-mypodo-2026');
    await page.click('#form-entrar button[type=submit]');
    await expect(page).toHaveURL(/\/paciente\/citas\/$/);
  });

  test('AUT-07 Cada rol solo entra a sus páginas', async ({ browser }) => {
    const paciente = await (await browser.newContext()).newPage();
    await entrarYEsperar(paciente, U.maria, /\/paciente\/$/);
    await paciente.goto('/podologo/agenda/');
    await expect(paciente).toHaveURL(/\/paciente\/$/);
    await paciente.goto('/informes/');
    await expect(paciente).toHaveURL(/\/paciente\/$/);

    const podologo = await (await browser.newContext()).newPage();
    await entrarYEsperar(podologo, U.camila, /\/podologo\/$/);
    await podologo.goto('/paciente/citas/');
    await expect(podologo).toHaveURL(/\/podologo\/$/);
  });

  test('AUT-08 Cerrar sesión impide volver a las páginas privadas', async ({ page }) => {
    await entrarYEsperar(page, U.maria, /\/paciente\/$/);
    await page.locator('[data-salir]').click();
    await expect(page).toHaveURL(/\/entrar\/$/);
    await page.goto('/paciente/');
    await expect(page).toHaveURL(/\/entrar\/\?next=/);
  });

  test('AUT-09 El parámetro next no puede llevar a otro sitio', async ({ page }) => {
    await page.goto('/entrar/?next=//sitio-externo.example.com/');
    await page.fill('#entrar-email', U.maria);
    await page.fill('#entrar-clave', 'demo-mypodo-2026');
    await page.click('#form-entrar button[type=submit]');
    await expect(page).toHaveURL(/localhost:8001\/paciente\/$/);
  });
});
