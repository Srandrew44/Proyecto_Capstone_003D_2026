// Módulo FIC: la ficha clínica vista por el paciente (solo lectura).
const { test, expect } = require('@playwright/test');
const { U, entrarYEsperar } = require('../soporte/ayuda');

test.describe('FIC · Ficha del paciente', () => {
  test('FIC-01 El paciente ve su ficha y descarga el PDF de su derivación', async ({ page }) => {
    await entrarYEsperar(page, U.maria, /\/paciente\/$/);
    await page.goto('/paciente/ficha/');
    await expect(page.getByRole('heading', { name: 'Antecedentes mórbidos' })).toBeVisible();
    await expect(page.locator('article').first()).toBeVisible();
    // Solo lectura: el paciente no tiene botones para corregir ni derivar.
    await expect(page.getByRole('button', { name: 'Corregir' })).toHaveCount(0);
    const derivacion = page.locator('.derivacion-item', { hasText: 'Dermatología' }).first();
    await expect(derivacion).toBeVisible();
    const href = await derivacion.getByRole('link', { name: 'Descargar PDF' }).getAttribute('href');
    const pdf = await page.request.get(href);
    expect(pdf.status()).toBe(200);
    expect(pdf.headers()['content-type']).toContain('application/pdf');
  });

  test('FIC-02 Un paciente sin ficha ve un aviso en vez de un error', async ({ page }) => {
    await entrarYEsperar(page, U.felipe, /\/paciente\/$/);
    await page.goto('/paciente/ficha/');
    await expect(page.locator('#ficha')).toContainText('Todavía no tienes ficha');
  });
});
