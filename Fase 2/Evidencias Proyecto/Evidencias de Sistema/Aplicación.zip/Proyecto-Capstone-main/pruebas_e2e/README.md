# Pruebas de sistema de MyPodo (Playwright)

Hay 40 casos E2E que recorren el sitio con un navegador real. Corren contra un entorno propio: la base `mypodo_e2e` y un servidor en el puerto 8001. Tu base de desarrollo no se toca.

| Documento | Contenido |
|---|---|
| [PLAN_DE_PRUEBAS.md](PLAN_DE_PRUEBAS.md) | Objetivo, alcance, estrategia, entorno, datos, criterios y riesgos. |
| [CASOS_DE_PRUEBA.md](CASOS_DE_PRUEBA.md) | Los 40 casos, con sus pasos y el resultado esperado. |
| [RESULTADOS_DE_PRUEBAS.md](RESULTADOS_DE_PRUEBAS.md) | Resultado de la ejecución, detalle por caso e incidencias. |

## Requisitos

- Docker Desktop corriendo, y haber levantado el proyecto al menos una vez (`.\tasks.ps1 up` en la raíz del repositorio).
- Microsoft Edge instalado. Las pruebas lo usan directamente, así que no hace falta descargar navegadores.
- Node.js 18 o superior.

## Cómo ejecutar

Desde esta carpeta (`pruebas_e2e/`). Solo la primera vez:

```bash
npm install
```

Para ejecutar todo (prepara el entorno, corre los 40 casos y detiene el servidor de pruebas):

```bash
npm test
```

Para ver el reporte HTML con el detalle, las capturas y las trazas de cada caso:

```bash
npm run reporte
```

Otras formas útiles:
- Un solo módulo: `npx playwright test tests/05-podologo.spec.js`.
- Un solo caso: `npx playwright test -g "POD-06"`.
- Viendo el navegador: `npx playwright test --headed`.
- Para no rehacer la base en cada corrida mientras ajustas una prueba, usa las variables `E2E_SIN_PREPARAR=1` y `E2E_MANTENER_SERVIDOR=1`. Ojo: los datos que una prueba ya cambió no vuelven a su estado inicial.

Ejecútalas entre las 03:00 y las 23:59, hora de Chile: la semilla crea citas de "hoy" relativas a la hora de la ejecución.

## Estructura

```
playwright.config.js       Configuración: Edge, es-CL, hora de Chile, 1 worker, reportes
soporte/entorno.js         Prepara y detiene el entorno aislado (Docker)
soporte/semilla_e2e.py     Datos propios de las pruebas (pacientes y citas de la semilla)
soporte/ayuda.js           Funciones comunes: entrar, crear paciente, reservar, fechas
tests/01-…06-*.spec.js     Los 40 casos, cada uno con su ID en el título
reporte-html/              Reporte de la última ejecución (generado)
resultados/                JSON, capturas y trazas de la última ejecución (generado)
```
