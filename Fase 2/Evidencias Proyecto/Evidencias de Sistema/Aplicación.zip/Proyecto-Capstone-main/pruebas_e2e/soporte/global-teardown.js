const { detener } = require('./entorno');

module.exports = async () => {
  if (process.env.E2E_MANTENER_SERVIDOR) return;
  detener();
};
