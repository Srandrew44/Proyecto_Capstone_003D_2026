// Entorno aislado de pruebas: una base propia (mypodo_e2e) en el mismo PostgreSQL de Docker y
// un servidor Django aparte en el puerto 8001. La base de desarrollo (mypodo, puerto 8000) no
// se toca. Cada ejecución parte de cero: borra la base, migra, carga el escenario demo y la
// semilla E2E.
const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const PROYECTO = path.resolve(__dirname, '../..');
const CONTENEDOR = 'mypodo-e2e';
const BASE = 'mypodo_e2e';
const PUERTO = 8001;
// Misma conexión del .env, pero apuntando a la base de pruebas (no se leen ni copian claves).
const USAR_BASE = `export DATABASE_URL="\${DATABASE_URL%/*}/${BASE}"`;

// Sin shell de Windows de por medio: los argumentos llegan tal cual a docker.
function docker(args, opciones = {}) {
  return execFileSync('docker', args, { cwd: PROYECTO, stdio: ['pipe', 'pipe', 'pipe'], encoding: 'utf8', ...opciones });
}
const enWeb = (orden) => `${USAR_BASE}; ${orden}`;

async function esperarServidor(url, segundos = 90) {
  const limite = Date.now() + segundos * 1000;
  while (Date.now() < limite) {
    try {
      const r = await fetch(url);
      if (r.ok) return;
    } catch { /* aún no responde */ }
    await new Promise((ok) => setTimeout(ok, 1000));
  }
  throw new Error(`El servidor de pruebas no respondió en ${url}`);
}

async function preparar() {
  detener();
  docker(['compose', 'up', '-d', 'db', 'mailpit']);
  docker(['compose', 'exec', '-T', 'db', 'sh', '-c',
    `dropdb -U "$POSTGRES_USER" --if-exists ${BASE} && createdb -U "$POSTGRES_USER" ${BASE}`]);
  docker(['compose', 'run', '--rm', '-T', 'web', 'sh', '-c',
    enWeb('python manage.py migrate -v 0 && python manage.py cargar_escenario_demo')]);
  const semilla = fs.readFileSync(path.join(__dirname, 'semilla_e2e.py'), 'utf8');
  docker(['compose', 'run', '--rm', '-T', 'web', 'sh', '-c', enWeb('python manage.py shell')], { input: semilla });
  // Las pruebas registran muchos pacientes desde la misma IP: se sube el límite de registros.
  // El pago con Webpay se prueba aparte (apps/pagos y a mano en integración): aquí se reserva
  // sin pago para no depender de Transbank.
  docker(['compose', 'run', '-d', '--name', CONTENEDOR, '-p', `127.0.0.1:${PUERTO}:8000`,
    '-e', 'LIMITE_REGISTROS=1000/hour', '-e', 'PAGOS_WEBPAY_ACTIVO=False', 'web', 'sh', '-c',
    enWeb('python manage.py runserver 0.0.0.0:8000')]);
  await esperarServidor(`http://localhost:${PUERTO}/`);
}

function detener() {
  try { docker(['rm', '-f', CONTENEDOR]); } catch { /* ya estaba detenido */ }
}

module.exports = { preparar, detener, PUERTO };
