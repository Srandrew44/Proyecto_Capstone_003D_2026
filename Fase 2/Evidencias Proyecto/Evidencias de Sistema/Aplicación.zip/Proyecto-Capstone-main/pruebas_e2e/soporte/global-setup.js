const { preparar } = require('./entorno');

module.exports = async () => {
  if (process.env.E2E_SIN_PREPARAR) return; // reutiliza el entorno de la ejecución anterior
  await preparar();
};
