# Datos propios de las pruebas E2E. Se ejecuta con `manage.py shell` sobre la base mypodo_e2e,
# después de `cargar_escenario_demo`. Todo es ficticio (correos @example.com).
#
# Las citas se crean directo en la base (como en el escenario demo) para tener casos que la
# reserva normal no permite: citas que ya comenzaron hoy y una cita a menos de 24 horas.
from datetime import timedelta

from django.utils import timezone

from apps.agenda.models import Cita, Tratamiento
from apps.clinica import services as clinica
from apps.clinica.models import Consentimiento
from apps.cuentas import services as cuentas
from apps.cuentas.models import Profesional, Usuario
from apps.cuentas.rut import calcular_dv

CLAVE = "demo-mypodo-2026"

Usuario.objects.create_superuser("admin.e2e@example.com", CLAVE, nombre="Admin", apellido="Pruebas")

tomas = Profesional.objects.get(usuario__email="podologo.demo@example.com")
tratamiento = Tratamiento.objects.get(nombre="Podología básica")


def paciente(nombre, apellido, cuerpo_rut, consentimiento=True):
    p = cuentas.registrar_paciente(
        email=f"{nombre.lower()}.e2e@example.com",
        password=CLAVE,
        nombre=nombre,
        apellido=apellido,
        rut=f"{cuerpo_rut}-{calcular_dv(cuerpo_rut)}",
        fecha_nacimiento="1980-05-10",
        direccion="Calle de prueba 123",
        comuna="Santiago",
        telefono="+56 9 1111 2222",
        actividad="Prueba",
        telefono_contacto="+56 9 3333 4444",
    )
    if consentimiento:
        clinica.aceptar_consentimiento(paciente=p, tipo=Consentimiento.Tipo.TRATAMIENTO_DATOS)
    return p


def cita(p, inicio, duracion=None):
    return Cita.objects.create(
        paciente=p,
        profesional=tomas,
        tratamiento=tratamiento,
        inicio=inicio,
        fin=inicio + (duracion or timedelta(minutes=tratamiento.duracion_min)),
        estado=Cita.Estado.CONFIRMADA,
        precio=tratamiento.precio,
    )


ahora = timezone.now().replace(second=0, microsecond=0)

# La agenda del día (POD-01, POD-02 y POD-06) necesita dos citas que YA comenzaron HOY: la de
# Elena y la de Felipe. Con horas fijas relativas a "ahora" (3 h y 90 min antes), si las
# pruebas corrían de madrugada esas citas caían en el día anterior y no aparecían en la agenda.
# Si desde la medianoche pasaron menos de 3 h, las dos parten a las 00:00, una tras otra y
# acortadas para caber (un profesional no puede tener citas cruzadas).
medianoche = timezone.localtime(ahora).replace(hour=0, minute=0)
desde_medianoche = ahora - medianoche
if desde_medianoche >= timedelta(hours=3):
    inicio_elena, inicio_felipe, duracion_hoy = (
        ahora - timedelta(hours=3),
        ahora - timedelta(minutes=90),
        None,
    )
else:
    minutos = max(1, min(tratamiento.duracion_min, int(desde_medianoche.total_seconds()) // 120))
    duracion_hoy = timedelta(minutes=minutos)
    inicio_elena, inicio_felipe = medianoche, medianoche + duracion_hoy

# Elena: tiene ficha, una cita que ya comenzó (para atenderla), una a menos de 24 h (no se
# puede cancelar en línea) y una futura (la cancela el podólogo).
elena = paciente("Elena", "Atender", 20111222)
cita(elena, inicio_elena, duracion_hoy)
cita(elena, ahora + timedelta(hours=3))
futura = timezone.localtime(ahora + timedelta(days=5)).replace(hour=7, minute=0)
cita(elena, futura)
clinica.crear_ficha(profesional=tomas, paciente=elena, diabetes=False, hta=True)

# Felipe: sin ficha, con una cita que ya comenzó (para registrar la inasistencia).
cita(paciente("Felipe", "Ausente", 20222333), inicio_felipe, duracion_hoy)

# Sofía: con consentimiento y sin ficha (el podólogo se la crea).
cita(paciente("Sofia", "Sinficha", 20333444), ahora - timedelta(hours=7))

# Gonzalo: sin consentimiento (no se le puede crear ficha).
cita(
    paciente("Gonzalo", "Sinconsentimiento", 20444555, consentimiento=False),
    ahora - timedelta(hours=5),
)

print("Semilla E2E cargada.")
