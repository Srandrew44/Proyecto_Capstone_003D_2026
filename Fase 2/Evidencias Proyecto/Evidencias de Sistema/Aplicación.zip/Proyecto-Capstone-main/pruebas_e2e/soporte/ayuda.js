// Utilidades compartidas por los casos E2E.
const { expect } = require('@playwright/test');

// Cuentas ficticias del escenario demo y de la semilla E2E (misma clave que el escenario demo).
const CLAVE = 'demo-mypodo-2026';
const U = {
  maria: 'maria.gonzalez@example.com',
  camila: 'podologa.demo@example.com',
  tomas: 'podologo.demo@example.com',
  admin: 'admin.e2e@example.com',
  elena: 'elena.e2e@example.com',
  felipe: 'felipe.e2e@example.com',
};

async function entrar(page, email, clave = CLAVE) {
  await page.goto('/entrar/');
  await page.fill('#entrar-email', email);
  await page.fill('#entrar-clave', clave);
  await page.click('#form-entrar button[type=submit]');
}

async function entrarYEsperar(page, email, ruta) {
  await entrar(page, email);
  await expect(page).toHaveURL(ruta);
}

// RUT chileno con su dígito verificador (módulo 11).
function dv(cuerpo) {
  let suma = 0;
  let factor = 2;
  for (const d of String(cuerpo).split('').reverse()) {
    suma += Number(d) * factor;
    factor = factor === 7 ? 2 : factor + 1;
  }
  const r = 11 - (suma % 11);
  return r === 11 ? '0' : r === 10 ? 'K' : String(r);
}
let correlativo = 0;
function unico() {
  correlativo += 1;
  return `${Date.now().toString(36)}${correlativo}`;
}
function rutNuevo() {
  const cuerpo = 21000000 + Math.floor(Math.random() * 3000000);
  return { cuerpo, rut: `${cuerpo}-${dv(cuerpo)}` };
}

function datosRegistro(extra = {}) {
  const id = unico();
  return {
    nombre: 'Prueba',
    apellido: `E2E ${id}`,
    rut: rutNuevo().rut,
    fecha_nacimiento: '1990-03-15',
    telefono: '+56 9 1234 5678',
    telefono_contacto: '+56 9 8765 4321',
    direccion: 'Av. Siempre Viva 742',
    comuna: 'Santiago',
    actividad: 'Tester',
    email: `prueba.${id}@example.com`,
    password: 'Podologia-Segura-2026',
    ...extra,
  };
}

// Mailpit: la bandeja de los correos de desarrollo (docker-compose.yml, puerto 8025).
const MAILPIT = 'http://localhost:8025/api/v1';

/* Espera el último correo enviado a `email` y devuelve el primer enlace de su texto que
 * contenga `ruta` (sin el dominio, para abrirlo en el servidor de pruebas). */
async function enlaceDelCorreo(email, ruta, segundos = 20) {
  const limite = Date.now() + segundos * 1000;
  while (Date.now() < limite) {
    const busqueda = await fetch(`${MAILPIT}/search?query=${encodeURIComponent(`to:"${email}"`)}`);
    const { messages = [] } = await busqueda.json();
    if (messages.length) {
      const mensaje = await (await fetch(`${MAILPIT}/message/${messages[0].ID}`)).json();
      const enlace = (mensaje.Text.match(/https?:\/\/\S+/g) || [])
        .map((texto) => new URL(texto))
        .find((url) => url.pathname.startsWith(ruta));
      if (enlace) return enlace.pathname;
    }
    await new Promise((ok) => setTimeout(ok, 500));
  }
  throw new Error(`No llegó a Mailpit un correo para ${email} con ${ruta}`);
}

/* Crea un paciente nuevo por la API (más rápido que llenar el formulario en cada caso):
 * registra, abre el enlace de confirmación que llega a Mailpit y activa la cuenta. Deja la
 * sesión abierta en el navegador: page.request comparte las cookies de la página.
 * Con `consentimiento`, además lo acepta. */
async function nuevoPaciente(page, { consentimiento = true, ...extra } = {}) {
  const datos = datosRegistro(extra);
  const token = async () => {
    await page.request.get('/api/auth/csrf/');
    return (await page.context().cookies()).find((c) => c.name === 'csrftoken').value;
  };
  const post = async (url, cuerpo) => {
    const respuesta = await page.request.post(url, { data: cuerpo, headers: { 'X-CSRFToken': await token() } });
    expect(respuesta.ok(), `${url}: ${await respuesta.text()}`).toBeTruthy();
  };
  await post('/api/auth/registro/', datos);
  const enlace = await enlaceDelCorreo(datos.email, '/registro/confirmar/');
  // "Activar mi cuenta": crea la cuenta y abre la sesión.
  const activar = await page.request.post(enlace, { headers: { 'X-CSRFToken': await token() }, maxRedirects: 0 });
  expect(activar.status(), `${enlace}: ${await activar.text()}`).toBe(302);
  if (consentimiento) await post('/api/consentimientos/', { tipo: 'tratamiento_datos' });
  return datos;
}

/* Reserva por la interfaz: podólogo, tratamiento, primer día con horas y la hora indicada
 * (por defecto la primera). Devuelve el texto de la hora elegida. */
async function elegirHorario(page, { profesional = 'Camila Rojas', tratamiento = 'Podología básica', indiceHora = 0 } = {}) {
  await page.goto('/paciente/reservar/');
  await page.locator('[data-profesional]', { hasText: profesional }).click();
  await expect(page.locator('[data-profesional][aria-current="true"]')).toContainText(profesional);
  await page.locator('[data-tratamiento]', { hasText: tratamiento }).click();
  const horas = page.locator('#selector-horario .time-slot');
  await expect(horas.first()).toBeVisible();
  const hora = horas.nth(indiceHora);
  const texto = (await hora.textContent()).trim();
  await hora.click();
  await expect(page.locator('#paso-confirmar')).toBeVisible();
  return texto;
}

async function reservar(page, opciones = {}) {
  const hora = await elegirHorario(page, opciones);
  if (opciones.comentario) await page.fill('#comentarios', opciones.comentario);
  await page.click('#paso-confirmar button[type=submit]');
  await expect(page.getByRole('heading', { name: '¡Reserva confirmada!' })).toBeVisible();
  return hora;
}

// Fecha "AAAA-MM-DD" en hora de Chile, desplazada `dias` desde hoy.
function diaChile(dias = 0) {
  const d = new Date(Date.now() + dias * 86_400_000);
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santiago' }).format(d);
}

const toast = (page, texto) => expect(page.locator('[data-avisos] > div', { hasText: texto })).toBeVisible();

module.exports = {
  CLAVE, U, entrar, entrarYEsperar, dv, unico, datosRegistro, nuevoPaciente, elegirHorario,
  reservar, diaChile, toast, enlaceDelCorreo,
};
