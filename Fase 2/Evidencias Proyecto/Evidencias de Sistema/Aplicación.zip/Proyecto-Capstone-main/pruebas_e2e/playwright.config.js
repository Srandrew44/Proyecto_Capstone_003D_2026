// Pruebas de sistema (E2E) de MyPodo con Playwright. Ver PLAN_DE_PRUEBAS.md.
const { defineConfig } = require('@playwright/test');
const { PUERTO } = require('./soporte/entorno');

module.exports = defineConfig({
  testDir: './tests',
  // Un solo trabajador: los casos comparten la base de pruebas y algunos cambian la agenda.
  workers: 1,
  fullyParallel: false,
  timeout: 45_000,
  expect: { timeout: 10_000 },
  retries: 0,
  globalSetup: require.resolve('./soporte/global-setup'),
  globalTeardown: require.resolve('./soporte/global-teardown'),
  reporter: [
    ['list'],
    ['html', { outputFolder: 'reporte-html', open: 'never' }],
    ['json', { outputFile: 'resultados/resultados.json' }],
  ],
  outputDir: 'resultados/artefactos',
  use: {
    baseURL: `http://localhost:${PUERTO}`,
    channel: 'msedge', // Microsoft Edge ya instalado en el equipo: no descarga navegadores
    headless: true,
    locale: 'es-CL',
    timezoneId: 'America/Santiago',
    viewport: { width: 1366, height: 800 },
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
  },
});
