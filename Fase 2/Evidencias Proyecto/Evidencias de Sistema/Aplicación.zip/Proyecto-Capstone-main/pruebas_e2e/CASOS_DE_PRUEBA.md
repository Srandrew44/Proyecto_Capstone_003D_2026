# Casos de prueba del sistema — MyPodo

Son 40 casos de prueba E2E, automatizados con Playwright. Cada ID coincide con el título del test en `tests/`, así que el resultado de cada caso se puede rastrear en el reporte. El plan está en [PLAN_DE_PRUEBAS.md](PLAN_DE_PRUEBAS.md) y los resultados en [RESULTADOS_DE_PRUEBAS.md](RESULTADOS_DE_PRUEBAS.md).

**Prioridad:** A = alta, M = media, B = baja. **Tipo:** P = positivo (camino esperado), N = negativo (debe rechazarse).

## Resumen

| Módulo | Archivo | Casos | Positivos | Negativos |
|---|---|---|---|---|
| AUT · Autenticación y acceso | `01-autenticacion.spec.js` | 9 | 6 | 3 |
| REG · Registro | `02-registro-consentimiento.spec.js` | 4 | 1 | 3 |
| CON · Consentimiento | `02-registro-consentimiento.spec.js` | 3 | 2 | 1 |
| RES · Reserva | `03-reserva-citas.spec.js` | 4 | 2 | 2 |
| CIT · Mis citas | `03-reserva-citas.spec.js` | 3 | 2 | 1 |
| FIC · Ficha del paciente | `04-ficha-paciente.spec.js` | 2 | 2 | 0 |
| POD · Podólogo | `05-podologo.spec.js` | 9 | 8 | 1 |
| HOR · Horario y bloqueos | `06-horario-informes.spec.js` | 3 | 2 | 1 |
| INF · Informes | `06-horario-informes.spec.js` | 2 | 2 | 0 |
| RSP · Diseño adaptable | `06-horario-informes.spec.js` | 1 | 1 | 0 |
| **Total** | | **40** | **28** | **12** |

Los casos POD-06 y CON-03 también comprueban un rechazo: atención vacía y reserva sin consentimiento. En el resumen se cuentan como positivos.

---

## AUT · Autenticación y acceso

| ID | Caso | Pri. | Tipo | Precondiciones / datos | Pasos | Resultado esperado |
|---|---|---|---|---|---|---|
| AUT-01 | La portada pública carga y lleva a iniciar sesión | M | P | Sin sesión. | 1. Abrir `/`.<br>2. Presionar "Ya tengo cuenta". | La portada muestra el título "Cuidado podológico…". Se llega a `/entrar/` con el formulario de inicio de sesión. |
| AUT-02 | Un paciente inicia sesión y llega a su panel | A | P | Paciente `maria.gonzalez@example.com`. | 1. Abrir `/entrar/`.<br>2. Ingresar correo y clave.<br>3. Presionar "Iniciar sesión". | Redirige a `/paciente/`. El menú lateral dice "Paciente" y muestra "María González". |
| AUT-03 | Un podólogo inicia sesión y llega a su panel | A | P | Podóloga `podologa.demo@example.com`. | Igual que AUT-02. | Redirige a `/podologo/`. El menú dice "Podólogo" y tiene "Agenda del día". |
| AUT-04 | El administrador inicia sesión y llega a informes | A | P | Administrador `admin.e2e@example.com`. | Igual que AUT-02. | Redirige a `/informes/`. El menú dice "Administrador" y aparece el selector de podólogo. |
| AUT-05 | Con una contraseña incorrecta no entra y ve un aviso | A | N | Correo válido y clave `clave-equivocada`. | 1. Ingresar las credenciales.<br>2. Enviar. | Se muestra un aviso de error con texto y la página sigue en `/entrar/`. |
| AUT-06 | Una página protegida pide sesión y después vuelve a ella | A | P | Sin sesión. | 1. Abrir `/paciente/citas/`.<br>2. Iniciar sesión como María. | Primero redirige a `/entrar/?next=/paciente/citas/`. Después de entrar vuelve a `/paciente/citas/`. |
| AUT-07 | Cada rol solo entra a sus páginas | A | N | Sesiones de María (paciente) y de Camila (podóloga) en contextos separados. | 1. Como paciente, abrir `/podologo/agenda/` y `/informes/`.<br>2. Como podóloga, abrir `/paciente/citas/`. | El paciente vuelve a `/paciente/` y la podóloga a `/podologo/`. Ninguno ve páginas de otro rol. |
| AUT-08 | Cerrar sesión impide volver a las páginas privadas | A | P | Sesión de María. | 1. Presionar "Cerrar sesión".<br>2. Abrir `/paciente/`. | Tras cerrar sesión va a `/entrar/`. Al intentar volver, redirige a `/entrar/?next=…`. |
| AUT-09 | El parámetro `next` no puede llevar a otro sitio | A | N | URL `/entrar/?next=//sitio-externo.example.com/`. | 1. Iniciar sesión desde esa URL. | Termina en `localhost:8001/paciente/`, nunca en el sitio externo (evita una redirección abierta). |

## REG · Registro de pacientes

| ID | Caso | Pri. | Tipo | Precondiciones / datos | Pasos | Resultado esperado |
|---|---|---|---|---|---|---|
| REG-01 | Una contraseña débil se rechaza junto al campo | A | N | Datos válidos y contraseña `12345678`. | 1. Abrir `/entrar/#registro`.<br>2. Completar el formulario.<br>3. Presionar "Crear cuenta". | Aparece un error bajo el campo Contraseña, que queda marcado como `aria-invalid`. No se crea la cuenta. |
| REG-02 | Un RUT con dígito verificador incorrecto se rechaza | A | N | RUT `22333444` con un dígito verificador incorrecto. | Igual que REG-01. | Aparece un error bajo el campo RUT. |
| REG-03 | Un correo ya registrado se rechaza | A | N | Correo `maria.gonzalez@example.com`. | Igual que REG-01. | Aparece un error bajo el campo Correo electrónico. |
| REG-04 | Un registro válido crea la cuenta y lleva al consentimiento | A | P | Datos válidos con un correo y un RUT únicos. | Igual que REG-01. | Redirige a `/paciente/consentimiento/?nuevo=1` con el aviso "Tu cuenta está creada.". La sesión queda abierta y el menú muestra el correo. |

## CON · Consentimiento informado

| ID | Caso | Pri. | Tipo | Precondiciones / datos | Pasos | Resultado esperado |
|---|---|---|---|---|---|---|
| CON-01 | Sin marcar la casilla no se acepta | M | N | Paciente nuevo sin consentimiento. | 1. Abrir `/paciente/consentimiento/`.<br>2. Presionar "Aceptar consentimiento" sin marcar la casilla. | Aparece el error "Marca la casilla para aceptar.". |
| CON-02 | El paciente acepta el consentimiento | A | P | Paciente nuevo sin consentimiento. | 1. Marcar la casilla.<br>2. Presionar "Aceptar consentimiento". | Aparece "Aceptaste el consentimiento (versión v1)…" y el formulario se oculta. |
| CON-03 | Al revocarlo ya no puede reservar | A | P | Paciente nuevo con el consentimiento aceptado. | 1. Presionar "Revocar consentimiento" y confirmar.<br>2. Abrir `/paciente/reservar/`. | Vuelve a mostrarse el formulario para aceptar. En la reserva aparece el aviso de que falta el consentimiento informado. |

## RES · Reserva de horas

| ID | Caso | Pri. | Tipo | Precondiciones / datos | Pasos | Resultado esperado |
|---|---|---|---|---|---|---|
| RES-01 | Sin consentimiento se avisa y la reserva se rechaza | A | N | Paciente nuevo sin consentimiento. | 1. Abrir "Reservar hora".<br>2. Elegir a Camila Rojas y "Podología básica".<br>3. Elegir la primera hora libre.<br>4. Presionar "Confirmar reserva". | Se ve el aviso de consentimiento. Al confirmar aparece un error con el enlace "Ir al consentimiento" y no se crea la cita. |
| RES-02 | El paciente reserva en tres pasos y la cita aparece en Mis citas | A | P | Paciente nuevo con consentimiento. Comentario único. | 1. Paso 1: podólogo y tratamiento.<br>2. Paso 2: día y hora.<br>3. Paso 3: comentario y "Confirmar reserva".<br>4. Presionar "Ver mis citas". | Aparece "¡Reserva confirmada!" con Camila Rojas. En "Próximas" está la cita con la hora elegida, el tratamiento y el comentario. |
| RES-03 | Solo se ofrecen horas con al menos 24 horas de anticipación | A | N | Paciente nuevo con consentimiento. | 1. Elegir podólogo y tratamiento.<br>2. Revisar las horas ofrecidas. | Todas las horas mostradas empiezan 24 horas o más después del momento actual. Los días sin horas libres están deshabilitados en el calendario. |
| RES-04 | La reserva programa el correo de confirmación | M | P | Paciente nuevo con una reserva hecha. | 1. Abrir "Notificaciones".<br>2. Filtrar por "Programadas". | Hay al menos un correo en la lista, con el estado "Programado". |

## CIT · Mis citas

| ID | Caso | Pri. | Tipo | Precondiciones / datos | Pasos | Resultado esperado |
|---|---|---|---|---|---|---|
| CIT-01 | El paciente cancela su cita con un motivo | M | P | Paciente nuevo con una cita reservada. | 1. Abrir "Mis citas".<br>2. Presionar "Cancelar" en la cita.<br>3. Escribir el motivo "Viaje de trabajo".<br>4. Presionar "Sí, cancelar". | La cita pasa al historial con el estado "Cancelada" y el motivo "Viaje de trabajo". |
| CIT-02 | El paciente cambia la hora de su cita | M | P | Paciente nuevo con una cita reservada. | 1. Presionar "Cambiar hora".<br>2. Elegir otra hora en el calendario.<br>3. Presionar "Confirmar cambio". | La cita queda en "Próximas" con la nueva hora, distinta de la original. |
| CIT-03 | Una cita a menos de 24 horas no se puede cambiar en línea | A | N | Elena (semilla): una cita en 3 horas y otra en 5 días. | 1. Entrar como Elena.<br>2. Abrir "Mis citas". | La cita cercana dice "Faltan menos de 24 horas…" y no tiene botones. La de 5 días sí tiene "Cambiar hora". |

## FIC · Ficha del paciente

| ID | Caso | Pri. | Tipo | Precondiciones / datos | Pasos | Resultado esperado |
|---|---|---|---|---|---|---|
| FIC-01 | El paciente ve su ficha y descarga el PDF de su derivación | A | P | María (demo), con atenciones y una derivación a dermatología. | 1. Abrir "Mi ficha clínica".<br>2. Descargar el PDF de la derivación. | Se ven los antecedentes y las atenciones, sin botones para corregir. El PDF responde 200 con el tipo `application/pdf`. |
| FIC-02 | Un paciente sin ficha ve un aviso en vez de un error | M | P | Felipe (semilla), sin ficha. | 1. Abrir "Mi ficha clínica". | Aparece "Todavía no tienes ficha…" en lugar de un error. |

## POD · Podólogo

Todos los casos de este módulo usan la sesión de Tomás Fuentes (`podologo.demo@example.com`).

| ID | Caso | Pri. | Tipo | Precondiciones / datos | Pasos | Resultado esperado |
|---|---|---|---|---|---|---|
| POD-01 | La agenda del día muestra las citas, sus cifras y se navega por días | M | P | Citas de hoy de Elena y Felipe (semilla). | 1. Abrir "Agenda del día".<br>2. Ir al día siguiente con "→".<br>3. Volver con "Hoy". | Se ven las citas de Felipe y Elena y la cifra de citas es 2 o más. La fecha y la URL cambian al día siguiente, y "Hoy" vuelve a la fecha actual. |
| POD-02 | Registra que un paciente no asistió | A | P | Cita de Felipe que empezó hace 90 minutos. | 1. Presionar "No asistió" en la cita de Felipe.<br>2. Confirmar. | Aparece el aviso "Inasistencia registrada." y la cita queda con el estado "No asistió". |
| POD-03 | Cancela una cita futura indicando el motivo | M | P | Cita de Elena dentro de 5 días. | 1. Abrir la agenda de ese día.<br>2. Presionar "Cancelar".<br>3. Escribir el motivo.<br>4. Presionar "Cancelar cita". | Aparece "Cita cancelada y paciente avisado.". La cita queda "Cancelada" con el motivo visible. |
| POD-04 | Crea la ficha de un paciente nuevo | A | P | Sofía (semilla): con consentimiento y sin ficha. | 1. En "Pacientes y fichas", ver que Sofía figura "Sin ficha".<br>2. Presionar "Crear ficha".<br>3. Marcar Diabetes = Sí y presión 130/85.<br>4. Presionar "Crear ficha". | Aparece "Ficha creada.". Se muestran los antecedentes (con 130/85) y el formulario "Nueva atención". |
| POD-05 | No crea la ficha de un paciente sin consentimiento | A | N | Gonzalo (semilla), sin consentimiento. | 1. Abrir la ficha de Gonzalo.<br>2. Presionar "Crear ficha". | Aparece el error "…no tiene vigente el consentimiento de datos…" y no se crea la ficha. |
| POD-06 | Atiende una cita de la agenda: valida y la deja realizada | A | P | Cita de Elena que empezó hace 3 horas. | 1. En la agenda, presionar "Atender".<br>2. Guardar la atención vacía.<br>3. Completar la observación y el tratamiento.<br>4. Guardar.<br>5. Volver a la agenda. | La ficha se abre con la cita ya elegida. Vacía, la API la rechaza con un error. Completa, aparece "Atención registrada.". En la agenda la cita queda "Realizada". |
| POD-07 | Corrige una atención y la original queda reemplazada | A | P | Ficha de Elena. Se registra una atención con una observación única. | 1. Presionar "Corregir" en esa atención.<br>2. Escribir el motivo y un hallazgo nuevo en el pie izquierdo.<br>3. Presionar "Guardar corrección". | Aparece "Corrección registrada.". La nueva atención tiene la etiqueta "Corrección" y la original queda marcada "Reemplazada" (no se borra). |
| POD-08 | Emite una derivación y su PDF se puede descargar | A | P | Ficha de Elena con una atención nueva. | 1. Presionar "Derivar".<br>2. Elegir Traumatología y escribir el motivo.<br>3. Presionar "Emitir derivación".<br>4. Descargar el PDF. | Aparece "Derivación a Traumatología emitida…". El PDF responde 200 con el tipo `application/pdf`. |
| POD-09 | Edita los antecedentes mórbidos de la ficha | M | P | Ficha de Elena. | 1. Presionar "Editar".<br>2. Marcar Várices = Sí y alergias "Penicilina".<br>3. Guardar.<br>4. Recargar la página y reabrir "Editar". | Aparece "Antecedentes actualizados." y se ve "Penicilina". Después de recargar, Várices sigue en "Sí". |

## HOR · Horario y bloqueos

| ID | Caso | Pri. | Tipo | Precondiciones / datos | Pasos | Resultado esperado |
|---|---|---|---|---|---|---|
| HOR-01 | Agrega un tramo semanal y lo desactiva | M | P | Tomás. Sábado de 09:00 a 11:00. | 1. Agregar el tramo.<br>2. Presionar "Desactivar". | Aparece "Tramo agregado." y el tramo se ve bajo Sábado. Al desactivarlo queda inactivo y el botón cambia a "Activar". |
| HOR-02 | Bloquea un período y después lo quita | M | P | Tomás. Dentro de 20 días, de 10:00 a 12:00. | 1. Crear el bloqueo con un motivo.<br>2. Presionar "Quitar" y confirmar. | Aparece "Horario bloqueado…" y el bloqueo figura en la lista. Al quitarlo aparece "Bloqueo quitado." y desaparece de la lista. |
| HOR-03 | Rechaza un bloqueo que termina antes de empezar | M | N | Inicio a las 12:00 y fin a las 10:00 del mismo día. | 1. Presionar "Bloquear horario". | Aparece el error "Debe ser posterior al inicio". |

## INF · Informes de gestión

| ID | Caso | Pri. | Tipo | Precondiciones / datos | Pasos | Resultado esperado |
|---|---|---|---|---|---|---|
| INF-01 | El podólogo ve su informe, cambia el período y descarga el PDF | M | P | Camila, con historia desde el mes anterior (demo). | 1. Abrir "Informes".<br>2. Presionar "Mes anterior".<br>3. Descargar el PDF. | Se ven las tarjetas de cifras y el gráfico semanal. El período cambia y las citas del período son más de 0. El enlace del PDF lleva los filtros y responde 200 con el tipo `application/pdf`. |
| INF-02 | El administrador compara podólogos y filtra por uno | M | P | Administrador. | 1. Presionar "Mes anterior".<br>2. Elegir a Tomás Fuentes en el selector. | La tabla "Por podólogo" incluye a Camila Rojas y a Tomás Fuentes. El selector tiene 3 opciones. Al filtrar, el PDF incluye `profesional=` y el informe se vuelve a calcular. |

## RSP · Diseño adaptable

| ID | Caso | Pri. | Tipo | Precondiciones / datos | Pasos | Resultado esperado |
|---|---|---|---|---|---|---|
| RSP-01 | En el celular el menú se abre con el botón y permite navegar | B | P | Ventana de 390×844. Sesión de María. | 1. Presionar el botón ☰.<br>2. Presionar "Mis citas". | El menú está oculto hasta presionar ☰ y después se ve. Navega a `/paciente/citas/` y la página no tiene desplazamiento horizontal. |
