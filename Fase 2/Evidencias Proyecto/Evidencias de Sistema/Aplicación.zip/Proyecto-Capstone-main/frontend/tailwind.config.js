/** Sistema de diseño de MyPodo (13/11/2026): tema teal clínico limpio, con títulos
 * en Figtree y cuerpo en Noto Sans. `acento` se usa para acciones principales
 * y cumple contraste AA con blanco; `acento-vivo` es solo decorativo. */
module.exports = {
  content: [
    '../apps/**/templates/**/*.html',
    '../templates/**/*.html',
    '../apps/web/static/web/js/**/*.js',
    '../apps/**/templatetags/*.py',
    '../apps/web/*.py',
  ],
  theme: {
    extend: {
      colors: {
        primario: { DEFAULT: '#0F766E', oscuro: '#134E4A', claro: '#E6F2F0', violeta: '#115E59' },
        acento: { DEFAULT: '#C2410C', oscuro: '#9A3412', vivo: '#EA580C', claro: '#FFF1E8' },
        fondo: '#F6FAF9',
        borde: { DEFAULT: '#DCE7E5', fuerte: '#B8CBC8' },
        texto: { DEFAULT: '#1F2937', secundario: '#4A5A62', tenue: '#5B6B73' },
        exito: { DEFAULT: '#15803D', fondo: '#ECFDF3' },
        aviso: { DEFAULT: '#B45309', fondo: '#FFFBEB' },
        peligro: { DEFAULT: '#B91C1C', fondo: '#FEF2F2' },
        info: { DEFAULT: '#1D4ED8', fondo: '#EFF6FF' },
        podologo: { DEFAULT: '#0E7490', claro: '#E0F2F7' },
      },
      fontFamily: {
        sans: ['"Noto Sans"', 'system-ui', '-apple-system', '"Segoe UI"', 'sans-serif'],
        titulo: ['Figtree', '"Noto Sans"', 'system-ui', 'sans-serif'],
        display: ['Figtree', '"Noto Sans"', 'system-ui', 'sans-serif'],
      },
      borderRadius: { sm: '6px', md: '8px', lg: '12px', xl: '16px' },
      boxShadow: {
        sm: '0 1px 2px rgba(16,40,38,.06)',
        md: '0 1px 2px rgba(16,40,38,.06), 0 4px 12px rgba(16,40,38,.05)',
        lg: '0 12px 32px rgba(16,40,38,.12)',
      },
    },
  },
  plugins: [require('@tailwindcss/forms')],
};
