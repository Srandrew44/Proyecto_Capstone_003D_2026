// Copia htmx y las fuentes a static: el sitio no carga nada de CDN ni de Google
// (la CSP solo permite 'self', y así las visitas no le entregan la IP del paciente a nadie).
const fs = require('fs');
const path = require('path');

const destino = path.join(__dirname, '..', 'apps', 'web', 'static', 'web');
const copias = [
  ['htmx.org/dist/htmx.min.js', 'vendor/htmx.min.js'],
  ...[600, 700].map((peso) => [
    `@fontsource/figtree/files/figtree-latin-${peso}-normal.woff2`,
    `fuentes/figtree-${peso}.woff2`,
  ]),
  ...[400, 500, 600].map((peso) => [
    `@fontsource/noto-sans/files/noto-sans-latin-${peso}-normal.woff2`,
    `fuentes/noto-sans-${peso}.woff2`,
  ]),
];

for (const [origen, archivo] of copias) {
  const final = path.join(destino, archivo);
  fs.mkdirSync(path.dirname(final), { recursive: true });
  fs.copyFileSync(require.resolve(origen), final);
}
console.log(`Copiados ${copias.length} archivos a ${destino}`);
